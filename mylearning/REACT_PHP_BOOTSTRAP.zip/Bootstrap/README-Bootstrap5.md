# 1. Bootstrap 5 Turorial

​	Bootstrap 5 is the newest version of Bootstrap, which is the most popular HTML, CSS, and JavaScript framework for creating responsive, mobile-first websites. Bootstrap 5 is completely free to download and use!

## 1.1 Bootstrap 5 vs. Bootstrap 3 & 4

​	Bootstrap 5 is the newest version of Bootstrap; with new components, faster stylesheet and more responsiveness. Bootstrap 5 supports the latest, stable releases of all major browsers and platforms. However, Internet Explorer 11 and down is not supported.

​	The main difference between Bootstrap 5 and Bootstrap 3 & 4, is Bootstrap 5 has switched to JavaScript instead of jQuery.



# 2. Bootstrap 5 Get Started

## 2.1 What is Bootstrap?

* Bootstrap is a free font-end framework for faster and easier web development
* Bootstrap includes HTML and CSS based design templates for typography, forms, buttons, tables, navigation, modals, image carousels and many other, as well as optional JavaScript plugins.
* Bootstrap also gives you the ability to easily create responsive designs

<b>What is Responsive Web Design?</b>

​	Responsive web design is about creating web sites which automatically adjust themselves to look good on all devices, from sall phones to large desktops.

```
//Bootstrap 5 Example:
<!DOCTYPE html>
<html>
<head>
	<title>Bootstrap 5 Example</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container-fluid p-5 bg-primary text-white text-center">
	<h1>My First Bootstrap Page</h1>
	<p>Resize this responsive page to see the effect!</p>
</div>
<div class="container mt-5">
	<div class="row">
		<div class="col-sm-4">
			<h3>Column 1</h3>
			<p>As I began to love myself I understood how much it
				offend somebody if I try to force my desires on 
				this person, even though I knew the time was not
				right and the person was not ready for it.</p>
			<p>And even though this person was me.</p>
		</div>
		<div class="col-sm-4">
			<h3>Column 2</h3>
			<p>As I began to love myself I stopped craving for a different
				lift, and I could see that everything that surrounded me
				was inviting me to grow.</p>
			<p>Today I call it "MATURITY".</p>
		</div>
		<div class="col-sm-4">
			<h3>Column 3</h3>
			<p>As I began to love myself I understood that at any cicumstance
				, I am in the right place at the right time, and everything
				happends at the exactly right moment.</p>
			<p>So I could be calm. Today I call it "SELF-CONFIDENCE".</p>
		</div>
	</div>
</div>
</body>
</html>
```

## 2.2 Bootstrap Versions

​	Bootstrap 5 (released 2021) is the newest version of Bootstrap (released 2013).

## 2.3 Why Use Bootstrap?

​	Advantages of Bootstrap:

* <b>Easy to use</b>: Anybody with just basic knowledge of HTML and CSS can start using Bootstrap.
* <b>Responsive features</b>: Bootstrap's responsive CSS adjusts to phones, tablets, and desktops.
* <b>Mobile-first approach</b>: In Bootstrap, mobile-first style are part of the core framewordk.
* <b>Browser compatibility</b>: Bootstrap 5 is compatible with all modern browsers (Chrome, Firefox, Edge, Safari, and Opera). <b>Note</b> that if you need support for IE11 and down, you must use either BS4 or BS3.

## 2.4 Where to Get Bootstrap 5?

​	There are two ways to start using Bootstrap 5 on your own web site.

* Include Bootstrap 5 from a CDN
* Download Bootstrap 5 from getbootstrap.com

## 2.5 Bootstrap 5 CDN

​	If you don't want to download and host Bootstrap 5 yourself, you can include it from a  CDN (Content Delivery Network). jsDelivr provides CDN support for Bootstrap's CSS and JavaScript.

<b>One advantage of using the Bootstrap 5 CDN:</b>

​	Many users already have downloaded Bootstrap 5 from jsDelivr when visiting another site. As a result, it will be loaded from cache when they visit your site, which leads to faster loading time. Also, most CDN's will make sure that once a user request a file from it, it will be served from the server closest to them, which also leads to faster loading time.

<b>JavaScript?</b>

​	Bootstrap 5 uses JavaScript for different components (like modals, tooltips, popovers etc).

​	However, if you just use the CSS part of Bootstrap, you don't need them.

## 2.6 Create Your First Wbe Page With Bootstrap 5

1. <b>Add the HTML5 doctype</b>

​	Bootstrap 5 uses HTML elements and CSS properties that require the HTML5 doctype.

​	Always include the HTML5 doctype at the beginning of the page, along with the lang attribute and the correct title adn character set:

```
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Bootstrap 5 Example</title>
		<meta charset="utf-8">
	</head>
</html>
```

2. <b>Bootstrap 5 is mobile-first</b>

​	Bootstrap 5 is designed to be responsive to mobile devices. Mobile-first styles are part of the core framework. To ensure proper rendering and touch zooming, add the following <span style="color:red;">\<meta></span> tag inside the <span style="color:red;">\<head></span> element:

```
<meta name="viewport" content="width=device-width, initial-scale=1">
```

​	The <span style="color:red;">width=device-width</span> part sets the width of the page to follow the screen-width of the device (which will vary depending on he devlce). The <span style="color:red;">initial-scale=1</span> part sets the initial zoom level when the page is first loaded by the browser.

3. <b>Containers</b>

​	Bootstrap 5 also requires a containing element to wrap site contents.

​	There are two container classes to choose from:

* The <span style="color:red;">.container</span> class provides a responsive <b>fixed width container</b>.
* The <span style="color:red;">.container-fluid</span> class provides a <b>full width container</b>, spanning the entire width of the viewport.

## 2.7 Two Basic Bootstrap 5 Pages

​	The following example shows the code for a basic Bootstrap 5 page (with a responsive fixed width container):

```
<div class="container">
  <h1>My First Bootstrap Page</h1>
  <p>This part is inside a .container class.</p>
  <p>The .container class provides a responsive fixed width container.</p>
</div>
```

​	The following example show the code for a basic Bootstrap 5 page (with a full width container):

```
<div class="container-fluid">
  <h1>My First Bootstrap Page</h1>
  <p>This part is inside a .container-fluid class.</p>
  <p>The .container-fluid class provides a full width container, spanning the entire width of the viewport.</p>
</div>
```



# 3. Bootstrap 5 Containers

## 3.1 Bootstrap 5 Containers

​	You learned from the previous chapter that Bootstrap requires a containing element to wrap site contents. Containers are used to pad the content inside them, and there are two container classes available.

## 3.2 Fixed Container

​	Use the <span style="color:red;">.container</span> class to create a responsive, fixed-width container.

​	Note that its width (<span style="color:red;">max-width</span>) will change on different screen sizes:

|           | Extran small<br><576px | Small<br>>=576px | Medium<br>>=768px | Large<br>>=992px | Extra Large<br>>=1200px | XXL<br>>=1400px |
| --------- | ---------------------- | ---------------- | ----------------- | ---------------- | ----------------------- | --------------- |
| max-width | 100%                   | 540px            | 720px             | 960px            | 1140px                  | 1320px          |

​	Open the example below and resize the browser window to see that the container width will change at different breakpoints:

```
<div class="container">
	<h1>My First Bootstrap Page</h1>
	<p>This is some text...</p>
</div>
```

<b>Note:</b> The XXL breakpoint is <b>new</b> in Bootstrap 5, while the largest breakpoint in Bootstrap 4 is Extra Large.

## 3.3 Fluid Container

​	Use the <span style="color:red;">.container-fluid</span> class to create a full width container, that will always span the entire width of the screen (<span style="color:red;">width</span> is always <span style="color:red;">100%</span>).

## 3.4 Container Padding

​	By default, containers have left and right padding, with no top or bottom padding. Therefore, we often use <b>spacing utilites</b>, such as extra padding and margins to make them look even better. For example, <span style="color:red;">.pt-5</span> means "add a large <b>top padding</b>":

```
<div class="container pt-5"></div>
```

## 3.5 Container Border and Color

​	Other utilities, such as borders and colors, are often often used together with containers:

```
<div class="container p-5 my-5 border"></div>
<div class="container p-5 my-5 bg-dark text-white"></div>
<div class="container p-5 my-5 bg-primary text-white"></div>
```

## 3.6 Responsive Containers

​	You can also use the <span style="color:red;">.container-sm|md|lg|xl</span> classes to determine when the container should be responsive. The <span style="color:red;">max-width</span> of the container will change on different screen sizes/viewports:

| Class          | Extra samll<br><576px | Samll<br>>=766px | Medium<br>>=768px | Large<br>>=992px | Extra large<br>>=1200px | XXL<br>>=1400px |
| -------------- | --------------------- | ---------------- | ----------------- | ---------------- | ----------------------- | --------------- |
| .container-sm  | 100%                  | 540px            | 720px             | 960px            | 1140px                  | 1320px          |
| .container-md  | 100%                  | 100%             | 720px             | 960px            | 1140px                  | 1320px          |
| .container-lg  | 100%                  | 100%             | 100%              | 960px            | 1140px                  | 1320px          |
| .container-xl  | 100%                  | 100%             | 100%              | 100%             | 1140px                  | 1320px          |
| .container-xxl | 100%                  | 100%             | 100%              | 100%             | 100%                    | 1320px          |

```
<div class="container-sm">.container-sm</div>
<div class="container-md">.container-md</div>
<div class="container-lg">.container-lg</div>
<div class="container-xl">.container-xl</div>
<div class="container-xxl">.container-xxl</div>
```

<span style="font-size:20px;">Did You Know?</span>

​	W3.CSS is an excellent alternative to Bootstrap 5.



# 4. Bootstrap 5 Grids

## 4.1 Bootstrap 5 Grid System

​	Bootstrap's grid system is built with flexbox and allows up to 12 columns across the page.

​	If you do not want to use all 12 columns individually, you can group the columns together to create wider columns:

<img src="img/grid.jpg" width="80%">

​	The grid system is responsive, and the columns will re-arrange automatically depending on the screen size. Make sure that he sum adds up to 12 or fewer (it is not required that you use all 12 available columns).

## 4.2 Grid Classed

​	The Bootstrap 5 grid system has six classes:

* <span style="color:red;">.col-</span> - (extra small device - screen width less than 576px)
* <span style="color:red;">.col-sm-</span> - (small device - screen width equal to or greater than 576px)
* <span style="color:red;">.col-md-</span> - (medium devices - screen width equal to or greater than 768px)
* <span style="color:red;">.col-xl-</span> - (xlarge devices - screen width equal to or greater than 1200px)
* <span style="color:red;">.col-xxl-</span> - (xxlarge devices - screen width equal to or greater than 1400px)

​	The classess above can be combined to create more dynamic and flexible layouts.

​	<b>Tip:</b> Each class scales up, so if you want to set the same width for <span style="color:red;">sm</span> and <span style="color:red;">md</span>, you only need to specify <span style="color:red;">sm</span>.

## 4.3 Basic Structure of a Bootstrap 5 Grid

​	The following is a basic structure of a Bootstrap 5 grid:

```
<div class="row">
	<div class="col-md-3">Col-md-1</div>
	<div class="col-md-5">Col-md-5</div>
	<div class="col-md-2">JCol-md-2</div>
</div>
<div class="row">
	<div class="col">Col 1</div>
	<div class="col">Col 2</div>
	<div class="col">Col 3</div>
</div>
```

​	First example, create a row (<span style="color:red;">\<div class="row"></span>). Then, add the desired number of columns(tags withe appropriate <span style="color:red;">.col-\*-\* </span>classes). The first star represents the responsiveness: sm, md, lg, xl or xxl, while the second star represents a number, which should add up to 12 for each row (?).

​	Second example: instead of adding a number of to each <span style="color:red;">col</span>, let bootstrap handle the layout, to create equal width columns: two <span style="color:red;">"col"</span> elements = 50% width to each col, while three cols = 33.33% width to each col. Four cols = 25% width, etc. You can also use <span style="color:red;">.col-sm|md|lg|xl|xxl</span> to make the columns responsive.

## 4.4 Examples 

### 4.4.1 Three Equal Columns

​	The following example shows how to create three equal-width columns, on all devices and screen widths:

```
<div class="row">
  <div class="col p-3 bg-primary text-white">.col</div>
  <div class="col p-3 bg-dark text-white">.col</div>
  <div class="col p-3 bg-primary text-width">.col</div>
</div>
```

### 4.4.2 Responsive Columns

​	The following example shows how to create four equal-width columns starting at tablets and scaling to extra large desktops. <b>On mobile phones or screens that are less than 576px wide, the columns will automatically stack on top of each other</b>.

```
<div class="row">
    <div class="col-sm-3 p-3 bg-primary text-white">.col</div>
    <div class="col-sm-3 p-3 bg-dark text-white">.col</div>
    <div class="col-sm-3 p-3 bg-primary text-white">.col</div>
    <div class="col-sm-3 p-3 bg-dark text-white">.col</div>
</div>
```

### 4.4.3 Two Unequal Responsive Columns

​	The following example shows how to get two various-width columns starting at tablets and scaling to large extra desktops:

```
<div class="row">
    <div class="col-sm-4 p-3 bg-primary text-white">.col</div>
	<div class="col-sm-8 p-3 bg-dark text-white">.col</div>
</div>
```



# 5. Bootstrap 5 Text/Typograph

## 5.1 Bootstrap 5 Default Settings

​	Bootstrap 5 uses a default <span style="color:red;">font-size</span> of 1rem (16px by default), and its <span style="color:red;">line-height</span> is 1.5; in addition, all <span style="color:red;">\<p></span> elements have <span style="color:red;">margin-top: 0</span> and <span style="color:red;">margin-bottom: 1rem</span>.

## 5.2 \<h1> - \<h6>

​	Bootstrap 5 styles HTML headings (<span style="color:red;">\<h1></span> to <span style="color:red;">\<h6></span>) with a bolder font-weight and a responsive font-size.

​	You can also use <span style="color:red;">.h1</span> to <span style="color:red;">.h6</span> classes on other elements to make them behave as headings if you want:

```
<p class="h1">h1 Bootstrap heading</p>
```

## 5.3 Display Headings

​	Display headings are used to stand out more than normal headings (larger font-size and lighter font-weight), and there are six classes to choose from: <span style="color:red;">.display-1</span> to <span style="color:red;">.display-6</span>:

```
<h1 class="display-1">Display 1</h1>
<h1 class="display-6">Display 6</h1>
```

## 5.4 \<small>

​	In Bootstrap 5 the HTML <span style="color:red;">\<samll></span> element (and the <span style="color:red;">.small</span> class) is used to create a smaller, secondary text in any heading:

```
<h1>h1 heading <small>secondary text</small></h1>
```

## 5.5 \<mark>

​	Bootstrap 5 will style <span style="color:red;">\<mark></span> and <span style="color:red;">.mark</span> with a yellow background color and some padding:

```
<p>Use the mark element (or the .mark class) to <mark>highlight</mark> text.</p>
```

## 5.6 \<abbr>

​	Bootstrap 5 will style the HTML <span style="color:red;">\<abbr></span> element with a dotted border bottom and a cursor with question mark on hover:

```
<p>The <abbr title="World Health Organizaion">WHO</abbr>was founded in 1948.</p>
```

## 5.7 \<blockquote>	

​	Add the <span style="color:red;">.blockquote</span> class to a <span style="color:red;">\<blockquote></span> when quoting blocks of content from another source. And when naming a source, like "from WWF's website", use the <span style="color:red;">.blockquote-footer</span> class:

```
<blockquote class="blockquote">
    <p>For 50 years, WWF has been protecting the future of nature. The world's leading conservation organization, WWF works in 100 countries and is supported by 1.2 million members in the United States and close to 5 million globally.</p>
    <footer class="blockquote-footer">From WWF's website</footer>
  </blockquote>
```

## 5.8 \<dl>

​	Bootstrap 5 will style the HTML <span style="color:red;">\<dl></span> element in the following way (practice it):

```
  <dl>
    <dt>Coffee</dt>
    <dd>- black hot drink</dd>
    <dt>Milk</dt>
    <dd>- white cold drink</dd>
  </dl>
```

## 5.9 \<code>

```
<p>The following HTML elements: <code>span</code>, <code>section</code>, and <code>div</code> defines a section in a document.</p>
```

## 5.10 \<kbd>

```
<p>Use <kbd>ctrl + p</kbd> to open the Print dialog box.</p>
```

## 5.11 \<pre>

```
<pre>
Text in a pre element
is displayed in a fixed-width
font, and it preserves
both      spaces and
line breaks.
</pre>
```

## 5.12 More Typography Classes

| Class                   | Description                                                  |
| :---------------------- | :----------------------------------------------------------- |
| `.lead`                 | Makes a paragraph stand out                                  |
| `.text-start`           | Indicates left-aligned text                                  |
| `.text-break`           | Prevents long text from breaking layout                      |
| `.text-center`          | Indicates center-aligned text                                |
| `.text-decoration-none` | Removes the underline from a link                            |
| `.text-end`             | Indicates right-aligned text                                 |
| `.text-nowrap`          | Indicates no wrap text                                       |
| `.text-lowercase`       | Indicates lowercased text                                    |
| `.text-uppercase`       | Indicates uppercased text                                    |
| `.text-capitalize`      | Indicates capitalized text                                   |
| `.initialism`           | Displays the text inside an `<abbr>` element in a slightly smaller font size |
| `.list-unstyled`        | Removes the default list-style and left margin on list items (works on both `<ul>` and `<ol>`). This class only applies to immediate children list items (to remove the default list-style from any nested lists, apply this class to any nested lists as well) |
| `.list-inline`          | Places all list items on a single line (used together with `.list-inline-item` on each \<li> elements) |



# 6. Bootstrap 5 Colors

## 6.1 Text Colors

​	Bootstrap 5 has some contextual classes that can be used to provide "meaning through colors". The classes for text colors are: <span style="color:red;">.text-muted</span>, <span style="color:red;">.text-primary</span>, <span style="color:red;">.text-success</span>, <span style="color:red;">.text-info</span>, <span style="color:red;">.text-warning</span>, <span style="color:red;">.text-danger</span>, <span style="color:red;">.text-secondary</span>, <span style="color:red;">.text-white</span>, <span style="color:red;">.text-dark</span>, <span style="color:red;">.text-body</span> (default body color/often block) and <span style="color:red;">.text-light</span>.

```
  <p class="text-muted">This text is muted.</p>
  <p class="text-primary">This text is important.</p>
  <p class="text-success">This text indicates success.</p>
  <p class="text-info">This text represents some information.</p>
  <p class="text-warning">This text represents a warning.</p>
  <p class="text-danger">This text represents danger.</p>
  <p class="text-secondary">Secondary text.</p>
  <p class="text-dark">This text is dark grey.</p>
  <p class="text-body">Default body color (often black).</p>
  <p class="text-light">This text is light grey (on white background).</p>
  <p class="text-white">This text is white (on white background).</p>
```

​	You can also add 50% opacity for black or white text with the <span style="color:red;">.text-black-50</span> or <span style="color:red;">.text-white-50</span> classes:

```
<p class="text-black-50">Black text with 50% opacity on white background</p>
<p class="text-white-50 bg-dark">White text with 50% opacity on black background</p>
```

## 6.2 Background Colors

​	The classes for background colors are: <span style="color:red;">.bg-primary</span>, <span style="color:red;">.bg-success</span>, <span style="color:red;">.bg-info</span>, <span style="color:red;">.bg-warning</span>, <span style="color:red;">.bg-danger</span>, <span style="color:red;">.bg-secondary</span>, <span style="color:red;">.bg-dark</span>, and <span style="color:red;">.bg-light</span>.

```
  <div class="bg-primary p-3"></div>
  <div class="bg-success p-3"></div>
  <div class="bg-info p-3"></div>
  <div class="bg-warning p-3"></div>
  <div class="bg-danger p-3"></div>
  <div class="bg-secondary p-3"></div>
  <div class="bg-dark p-3"></div>
  <div class="bg-light p-3"></div>
```

​	The <span style="color:red;">.bg-<i>color</i></span> classes above does not work well with text, or at least then you have to specify a proper <span style="color:red;">.text-<i>color</i></span> class to get the right text color for each background.

​	However, you can use the <span style="color:red;">.text-bg-<i>color</i></span> classes and Bootstrap will automatically handle the appropriate text color for each background color:

```
  <p class="text-bg-primary">This text is important.</p>
  <p class="text-bg-success">This text indicates success.</p>
  <p class="text-bg-info">This text represents some information.</p>
  <p class="text-bg-warning">This text represents a warning.</p>
  <p class="text-bg-danger">This text represents danger.</p>
  <p class="text-bg-secondary">Secondary background color.</p>
  <p class="text-bg-dark">Dark grey background color.</p>
  <p class="text-bg-light">Light grey background color.</p>
```



# 7. Bootstrap 5 Tables

## 7.1 Basic Table

​	A basic Bootstrap 5 table has a light padding and horizontal dividers.

​	The <span style="color:red;">.table</span> class adds basic styling to a table:

```
<table class="table">
	<thead>
		<tr>
			<th>Fistname</th>
			<th>Lastname</th>
			<th>Email</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>Joe</td>
			<td>Biden</td>
			<td>JoeBiden@example.com</td>
		</tr>
	</tbody>
</table>
```

## 7.2 Striped Rows

​	The <span style="color:red;">.table-striped</span> class adds zebra-stripes to a table.

## 7.3 Bordered Table

​	The <span style="color:red;">.table-bordered</span> class adds borders on all sides of the table and cell.

## 7.4 Hover Rows

​	The <span style="color:red;">.table-hover</span> class adds a hover effect (grey background color) on table row.

## 7.5 Black/Dark Table

​	The <span style="color:red;">.table-dark</span> class a black background to the table.

​	Combine <span style="color:red;">.table-dark</span> and <span style="color:red;">.table-striped</span> to create a dark, striped table:

```
  <table class="table table-dark table-striped">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
      </tr>
      <tr>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
      </tr>
      <tr>
        <td>July</td>
        <td>Dooley</td>
        <td>july@example.com</td>
      </tr>
    </tbody>
  </table>
```

## 7.6 Hoverable Dark Table

​	The <span style="color:red;">.table-hover</span> class adds a hover effect (grey background-color) on table rows.

## 7.7 Borderless Table

​	The <span style="color:red;">.table-boderless</span> class removes borders from the table.

## 7.8 Contextual Classes

​	Contextual classes can be used to color the whole table (<span style="color:red;">\<table></span>), the table rows (<span style="color:red;">\<rt></span>) or table cells (<span style="color:red;">\<td></span>).

```
<div class="container mt-3">
	<h2>Contextual Classes</h2>
	<p>Contextual classes can be used to color the table, table rows or table cells. The 
	classes that can be used are: .table-primary, .table-success, .table-info, .table-warning,
	.table-danger, .table-active, .table-secondary, .table-light, .table-dark:</p>
	<table class="table">
		<thead>
			<tr>
				<th>Firstname</th>
				<th>Lastname</th>
				<th>Email</th>
			</tr>
		</thead>
		<body>
			<tr>
				<td>Default</td>
				<td>Defaultson</td>
				<td>def@somemail.com</td>
			</tr>
			<tr class="table-primary">
				<td>Primary</td>
				<td>Joe</td>
				<td>joe@example.com</td>
			</tr>
			<tr class="table-success">
				<td>Success</td>
				<td>Trump</td>
				<td>trump@example.com</td>
			</tr>
			<tr class="table-danger">
				<td>Danger</td>
				<td>Moe</td>
				<td>mary@example.com</td>
			</tr>
		</body>
	</table>
</div>
```

​	The contextual classes that can be used are:

| Class              | Description                                                  |
| :----------------- | :----------------------------------------------------------- |
| `.table-primary`   | Blue: Indicates an important action                          |
| `.table-success`   | Green: Indicates a successful or positive action             |
| `.table-danger`    | Red: Indicates a dangerous or potentially negative action    |
| `.table-info`      | Light blue: Indicates a neutral informative change or action |
| `.table-warning`   | Orange: Indicates a warning that might need attention        |
| `.table-active`    | Grey: Applies the hover color to the table row or table cell |
| `.table-secondary` | Grey: Indicates a slightly less important action             |
| `.table-light`     | Light grey table or table row background                     |
| `.table-dark`      | Dark grey table or table row background                      |

## 7.9 Table Head Colors

​	You can also use any of the contextual classes to only add a background color to the table header:

```
  <table class="table">
    <thead class="table-dark">
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
      </tr>
      <tr>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
      </tr>
      <tr>
        <td>July</td>
        <td>Dooley</td>
        <td>july@example.com</td>
      </tr>
    </tbody>
  </table>
```

## 7.10 Small table

​	The <span style="color:red;">.table-sm</span> class makes the table smaller by cutting cell padding in halt.

## 7.11 Responsive Tables

​	The <span style="color:red;">.table-responsive</span> class adds a scrollbar to the table when needed (when it is too big borizontally).

```
<div class="table-responsive">	<!-- On `div` -->
	<table class="table">
	...
	</table>
</div>
```

​	You can also decide when the table should get a scrollbar, depending on the screen width:

| Class                   | Screen width |
| :---------------------- | :----------- |
| `.table-responsive-sm`  | < 576px      |
| `.table-responsive-md`  | < 768px      |
| `.table-responsive-lg`  | < 992px      |
| `.table-responsive-xl`  | < 1200px     |
| `.table-responsive-xxl` | < 1400px     |



# 8. Bootstrap 5 Images

## 8.1 Rounded Corners

​	The <span style="color:red;">.rounded</span> class adds rounded corners to an image:

```
<img src="street.jpg" class="rounded" alt="Street screen">
```

## 8.2 Circle

​	The <span style="color:red;">.rounded-circle</span> class shapes the image to a circle:

```
<img src="street.jpg" class="rounded-circle" alt="Street screen">
```

## 8.3 Thumbnail

​	The <span style="color:red;">.img-thumbnail</span> class shapes the image to a thumbnail (bordered):

```
<img src="street.jpg" class="img-thumbnail" alt="Street screen">
```

## 8.4 Aligning Images

​	Float an image to the left with the <span style="color:red;">.float-start</span> class or to the right with <span style="color:red;">.floata-end</span>.

```
<img src="paris.jpg" class="float-start">
<img src="pari2.jpg" class="float-end">
```

## 8.5 Centered Image

​	Center an image by adding the utility classes <span style="color:red;">.mx-auto</span> (margin: auto) and <span style="color:red;">.d-block</span> (display: block) to the image.

```
<img src="paris.jpg" class="mx-auto d-block">
```

## 8.6 Responsive Images

​	Images come in all sizes. So do screens. Responsive images automatically adjust to fit the size of the screen. Create responsive images by adding an <span style="color:red;">.img-fluid</span> class to the <span style="color:red;">\<img></span> tag. The image will then scale nicely to the parent element.

​	The <span style="color:red;">.img-fluid</span> class applies <span style="color:red;">max-width: 100%</span> and <span style="color:red;">heigth: auto</span> to the image:

```
<img class="img-fluid" src="ny.jpg" alt="New York">
```



# 9. Bootstrap 5 Jumbotron

## 9.1 Bootstrap 5 Jumbotron

​	A jumbotron was introduced in Bootstrap 3 as a big padded box for calling extra attention to some special content or information.	

​	Jumbotrons are no longer supported in Bootstrap 5. <b>However</b>, you can use a <span style="color:red;">\<div></span> element and add special helper classed together with a color class to achieve the same effect:

```
<div class="mt-4 p-5 bg-primary text-white rounded">
  <h1>Jumbotron Example</h1>
  <p>Lorem ipsum...</p>
</div>
```



# 10. Bootstrap 5 Alerts

## 10.1 Alerts

​	Bootstrap 5 provides an easy way to create predefined alert message. Alerts are created with the <span style="color:red;">.alert</span> class, followed by one of the contextual classes <span style="color:red;">.alert-success</span>, <span style="color:red;">.alert-info</span>, <span style="color:red;">.alert-danger</span>, <span style="color:red;">.alert-primary</span>, <span style="color:red;">.alert-secondary</span>, <span style="color:red;">.alert-light</span> or <span style="color:red;">.alert-dark</span>:

```
<div class="alert alert-success">
	<strong>Success!</strong>Indicates a successful or positive action.
</div>
```

## 10.2 Alert Links 

​	Add the <span style="color:red;">.alert-link</span> class to any links inside the alert box to create "matching colored links":

```
<div class="alert alert-success">
  <strong>Success!</strong> You should <a href="#" class="alert-link">read this message</a>.
</div>
```

## 10.3 Closing Alerts

​	To close the alert message, add a <span style="color:red;">.alert-dismissible</span> class to the alert container. Then add <span style="color:red;">class="btn-close"</span> and <span style="color:red;">data-bs-dimiss="alert"</span> to a link or a button element (when you click on this the alert box will disappear).

```
<div class="alert alert-success alert-dismissible">
	<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
	<strong>Success!</strong>This alert box can be close by click right cross.
</div>
```

## 10.4 Animated Alerts

​	The <span style="color:red;">.fade</span> and <span style="color:red;">.show</span> classes adds a fading effect when closing the alert message:

```
<div class="alert alert-danger alert-dismissible fade show">
```



# 11. Bootstrap 5 Buttons

## 11.1 Button Styles

​	Bootstrap 5 provides different styles of buttons:

```
<button type="button" class="btn">Basic</button>
<button type="button" class="btn btn-primary">Primary</button>
<button type="button" class="btn btn-secondary">Secondary</button>
<button type="button" class="btn btn-success">Success</button>
<button type="button" class="btn btn-info">Info</button>
<button type="button" class="btn btn-warning">Warning</button>
<button type="button" class="btn btn-danger">Danger</button>
<button type="button" class="btn btn-dark">Dark</button>
<button type="button" class="btn btn-light">Light</button>
<button type="button" class="btn btn-link">Link</button>
```

​	The button classes can be used on <span style="color:red;">\<a></span>, <span style="color:red;">\<button></span>, or <span style="color:red;">\<input></span> elements:

```
<a href="#" class="btn btn-success">Link Button</a>
<button type="button" class="btn btn-success">Button</button>
<input type="button" class="btn btn-success" value="Input Button">
<input type="submit" class="btn btn-success" value="Submit Button">
<input type="reset" class="btn btn-success" value="Reset Button">
```

<b>Why do we put a # in the href attribute of the link?</b>

​	Sine we do not have any page to link it to, and we do not want to get a "404" message, we put # as the link. In real life it should of course been a real URL to the "Search" page.

## 11.2 Button Outline

​	Bootstrap 5 also provides eight outline/bordered buttons.

​	Move the mouse over them to see an additional "hover" effect:

```
<button type="button" class="btn btn-outline-primary">Primary</button>
<button type="button" class="btn btn-outline-secondary">Secondary</button>
<button type="button" class="btn btn-outline-success">Success</button>
<button type="button" class="btn btn-outline-info">Info</button>
<button type="button" class="btn btn-outline-warning">Warning</button>
<button type="button" class="btn btn-outline-danger">Danger</button>
<button type="button" class="btn btn-outline-dark">Dark</button>
<button type="button" class="btn btn-outline-light text-dark">Light</button>
```

## 11.3 Button Sizes

​	Use the <span style="color:red;">.btn-lg</span> class for larger button or <span style="color:red;">.btn-sm</span> class for small buttons:

```
<button type="button" class="btn btn-primary btn-lg">Large</button>
<button type="button" class="btn btn-primary">Default</button>
<button type="button" class="btn btn-primary btn-sm">Small</button>
```

## 11.4 Block Level Buttons

​	To create a block level button that spans the entire width of the parent element, use the <span style="color:red;">.d-grid</span> "helper" class on the parent element:

```
<div class="d-grid">
	<button type="button" class="btn btn-primary btn-block">Full-Width Button</button>
</div>
```

​	If you have many block-level buttons, you can control the space between them with the <span style="color:red;">.gap-*</span> class:

```
<div class="d-grid gap-3">
  <button type="button" class="btn btn-primary btn-block">Full-Width Button</button>
  <button type="button" class="btn btn-primary btn-block">Full-Width Button</button>
  <button type="button" class="btn btn-primary btn-block">Full-Width Button</button>
</div>
```

## 11.5 Active/Disabled Buttons

​	A button can be set to an active (appear pressed) or a disabled (unclickable) state. 

​	The class <span style="color:red;">.ative</span> makes a button appear pressed, and the <span style="color:red;">disabled</span> attribute makes a button unclickable. Note that \<a> element do not support the disabled attribute and must therefore use the <span style="color:red;">.disabled</span> class to make it visually appear disabled.

```
<div class="container mt-3">
  <h2>Button States</h2>
  <button type="button" class="btn btn-primary">Primary Button</button>
  <button type="button" class="btn btn-primary active">Active Primary</button>
  <button type="button" class="btn btn-primary" disabled>Disabled Primary</button>
  <a href="#" class="btn btn-primary disabled">Disabled Link</a>
</div>
```

## 11.6 Spinner Buttons

​	You can also add "spinners" to a button, which you will learn more about in [BS5 Spinners Tutorial](https://www.w3schools.com/bootstrap5/bootstrap_spinners.php):

```
<button class="btn btn-primary">
  <span class="spinner-border spinner-border-sm"></span>
</button>
<button class="btn btn-primary">
  <span class="spinner-border spinner-border-sm"></span>
  Loading..
</button>
<button class="btn btn-primary" disabled>
  <span class="spinner-border spinner-border-sm"></span>
  Loading..
</button>
<button class="btn btn-primary" disabled>
  <span class="spinner-grow spinner-grow-sm"></span>
  Loading..
</button>
```



# 12. Bootstrap 5 Button Groups

## 12.1 Button Groups

​	Bootstrap 5 allows you to group a series of buttons together (on a single line) in a button group. Use a <span style="color:red;">\<div></span> element with class <span style="color:red;">.btn-group</span> to create a button group:

```
<div class="btn-group">
	<button type="button" class="btn btn-primary">Apple</button>
	<button type="button" class="btn btn-primary">Huawei</button>
	<button type="button" class="btn btn-primary">Samung</button>
</div>
```

<b>Tip:</b> Instead of applying button sizes to every button in a group, use class <span style="color:red;">.btn-group-lg</span> for a large button group or the <span style="color:red;">.btn-group-sm</span> for a small button group.

```
<div class="btn-group btn-group-lg">
	<button type="button" class="btn btn-primary">Apple</button>
	<button type="button" class="btn btn-primary">Huawei</button>
	<button type="button" class="btn btn-primary">Samung</button>
</div>
```

## 12.2 Vertical Button Groups

​	Bootstrap 5 also supports vertical button group. Use the class <span style="color:red;">.btn-group-vertical</span> to create a vertical button group:

```
<div class="btn-group-vertical">
  <button type="button" class="btn btn-primary">Apple</button>
  <button type="button" class="btn btn-primary">Samsung</button>
  <button type="button" class="btn btn-primary">Sony</button>
</div>
```

## 12.3 Button Groups Side by Side

​	Button groups are "inline" by default, which makes them appear side by side when you have multiple groups:

```
<div class="btn-group">
  <button type="button" class="btn btn-primary">Apple</button>
  <button type="button" class="btn btn-primary">Samsung</button>
  <button type="button" class="btn btn-primary">Sony</button>
</div>

<div class="btn-group">
  <button type="button" class="btn btn-primary">BMW</button>
  <button type="button" class="btn btn-primary">Mercedes</button>
  <button type="button" class="btn btn-primary">Volvo</button>
</div>
```

## 12.4 Nesting Button Group & Dropdown Menus

​	Nest button groups to create dropdown menus (you will learn more about dropdown in a later chapter):

```
<div class="btn-group">
	<button type="button" class="btn btn-primary">Apple</button>
	<button type="button" class="btn btn-primary">Samsung</button>
	<div class="btn-group">
		<button type="button" class="btn btn-primary dropdown-toggle"
			data-bs-toggle="dropdown">Huawei</button>
		<ul class="dropdown-menu">
			<li><a class="dropdown-item" href="#">Tablet</a></li>
			<li><a class="dropdown-item" href="#">Smartphone</a></li>
		</ul>
	</div>
</div>
```



# 13. Bootstrap 5 Badges

## 13.1 Badges

​	Badges are used to add additional information to any content.

​	Use the <span style="color:red;">.badge</span> class together with a contextual class (like <span style="color:red;">.bg-secondary</span>) within <span style="color:red;">\<span></span> elements to create rectangular badges. Note that badges scale to match the size of the parent element (if any):

```
<h4>Example heading <span class="badge bg-secondary">New</span></h4>
```

## 13.2 Contextual Badges

​	Use any of the contextual classes (<span style="color:red;">.bg-*</span>) to change the color of a badge:

```
<span class="badge bg-primary">Primary</span>
<span class="badge bg-danger">Danger</span>
```

## 13.3 Pill Badges

​	Use the <span style="color:red;">.rounded-pill</span> class to make the badges more round:

```
<span class="badge rounded-pill bg-success">Success</span>
<span class="badge rounded-pill bg-danger">Danger</span>
```

## 13.4 Badge inside an Element

​	An example of using a badge inside a button:

```
<button type="button" class="btn btn-primary">
	Messages <span class="badge bg-danger">4</span>
</button>
```



# 14. Bootstrap 5 Progress Bars

## 14.1 Basic Progress Bar

​	A progress bar can be used to show how far a user is in a process.

​	To create a default progress bar, add a <span style="color:red;">.progress</span> class to a container element and add the <span style="color:red;">.progress-bar</span> class to its child element. Use the CSS <span style="color:red;">width</span> property to set the width of the progress bar:

```
<div class="progress">
	<div class="progress-bar" style="width: 70%"></div>
</div>
```

## 14.2 Progress Bar Height

​	The height of the progress bar is <span style="color:red;">1rem</span> (usually <span style="color:red;">16px</span>) by default. Use the CSS <span style="color:red;">height</span> property to change it. Note that you must set the same height for the progress container and the progress bar:

```
<div class="progress" style="height: 20px">
	<div class="progress-bar" style="width: 40%; height: 20px"></div>
</div>
```

## 14.3 Progress Bar Labels

​	Add text inside the progress bar to show the visible percentage:

```
<div class="progress mt-2">
	<div class="progress-bar" style="width: 70%">70%</div>
</div>
```

## 14.4 Colored Progress Bars

​	By default, the progress bar is blue (primary). Use any of the contextual background classes to change its color:

```
<div class="progress mt-2">
	<div class="progress-bar bg-info" style="width: 30%"></div>
</div>
<div class="progress">
	<div class="progress-bar bg-dark" style="width: 50%"></div>
</div>
```

## 14.5 Striped Progress Bars

​	Use the <span style="color:red;">.progress-bar-striped</span> class to add stripes to the progress bars:

```
<div class="progress mt-5">
	<div class="progress-bar progress-bar-striped" style="width: 40%"></div>
</div>
```

## 14.6 Animated Progress Bar

​	Add the <span style="color:red;">.progress-bar-animated</span> class to animate the progress bar:

```
<div class="progress mt-5">
	<div class="progress-bar progress-bar-striped progress-bar-animated" 
	style="width: 70%"></div>
</div>
```

## 14.7 Multiple Progress Bars

​	Progress bars can also be stacked:

```
<div class="progress mt-3">
	<div class="progress-bar bg-success" style="width:40%">
		Free Space
	</div>
	<div class="progress-bar bg-warning" style="width: 10%">
		Warning
	</div>
	<div class="progress-bar bg-danger" style="width: 20%">
		Danger
	</div>
</div>
```



# 15. Bootstrap 5 Spinners

## 15.1 Spinners

​	To create a spinner/loader, use the <span style="color:red;">.spinner-border</span> class:

```
<div class="spinner-border"></div>
```

## 15.2 Colored Spinners

​	Use any <b>text color utilites</b> to add a color to the spinner:

```
<div class="spinner-border text-muted"></div>
<div class="spinner-border text-primary"></div>
<div class="spinner-border text-success"></div>
<div class="spinner-border text-info"></div>
<div class="spinner-border text-warning"></div>
<div class="spinner-border text-danger"></div>
<div class="spinner-border text-secondary"></div>
<div class="spinner-border text-dark"></div>
<div class="spinner-border text-light"></div>
```

## 15.3 Growing Spinners

​	Use the <span style="color:red;">.spinner-grow</span> class if you want the spinner/loader to grow instead of "spin":

```
<div class="spinner-grow text-muted"></div>
<div class="spinner-grow text-primary"></div>
<div class="spinner-grow text-success"></div>
<div class="spinner-grow text-info"></div>
<div class="spinner-grow text-warning"></div>
<div class="spinner-grow text-danger"></div>
<div class="spinner-grow text-secondary"></div>
<div class="spinner-grow text-dark"></div>
<div class="spinner-grow text-light"></div>
```

## 15.4 Spinner Size

​	Use <span style="color:red;">.spinner-border-sm</span> or <span style="color:red;">.spinner-grow-sm</span> to create a smaller spinner:

```
<div class="spinner-border spinner-border-sm"></div>
<div class="spinner-grow spinner-grow-sm"></div>
```

## 15.5 Spinner Buttons

​	You can also add spinners to a button, with or without text (refer button chapter):

```
<button class="btn btn-primary">
  <span class="spinner-border spinner-border-sm"></span>
</button>
<button class="btn btn-primary">
  <span class="spinner-border spinner-border-sm"></span>
  Loading..
</button>
<button class="btn btn-primary" disabled>
  <span class="spinner-border spinner-border-sm"></span>
  Loading..
</button>
<button class="btn btn-primary" disabled>
  <span class="spinner-grow spinner-grow-sm"></span>
  Loading..
</button>
```



# 16. Bootstrap 5 Pagination

​	If you have a web site with lots of pages, you may wish to add some sort of pagination to each page.

​	To create a basic pagination, add the <span style="color:red;">.pagination</span> class to an <span style="color:red;">\<ul></span> element. Then add the <span style="color:red;">.page-item</span> to each <span style="color:red;">\<li></span> element and a <span style="color:red;">.page-link</span> class to each link inside the <span style="color:red;">\<li></span>.

```
<ul class="pagination">
	<li class="page-item"><a class="page-link" href="#">Previous</a></li>
	<li class="page-item"><a class="page-link" href="#">1</a></li>
	<li class="page-item"><a class="page-link" href="#">2</a></li>
	<li class="page-item"><a class="page-link" href="#">3</a></li>
	<li class="page-item"><a class="page-link" href="#">Next</a></li>
</ul>
```

## 16.1 Active State

​	The <span style="color:red;">.active</span> class is used to "highlight" the current page:

```
<ul class="...">
	<li ... ></li>
	<li class="page-item active"><a class="page-link" href="#"></a>2</li>
	<li ... ></li>
</ul>
```

## 16.2 Disabled State

​	The <span style="color:red;">.disabled</span> class is used for un-clickable links:

```
<ul class="...">
	<li class="page-item disabled"<a class="page-link" href="#">Previous</a></li>
	<li ...></li>
</ul>
```

## 16.3 Pagination Sizing

​	Pagination blocks can also be sized to a larger or a smaller size.

​	Add class <span style="color:red;">.pagination-lg</span> for larger blocks or <span style="color:red;">.pagination-sm</span> for smaller blocks:

```
<ul class="pagination pagination-lg">
  <li class="page-item"><a class="page-link" href="#">Previous</a></li>
  <li class="page-item"><a class="page-link" href="#">1</a></li>
  <li class="page-item"><a class="page-link" href="#">2</a></li>
  <li class="page-item"><a class="page-link" href="#">3</a></li>
  <li class="page-item"><a class="page-link" href="#">Next</a></li>
</ul>
```

## 16.4 Pagination Alignment

​	Use utility classed to change the alignment of the pagination:

```
<!-- Default (left-aligned) -->
<ul class="pagination" style="margin:20px 0">
  <li class="page-item">...</li>
</ul>
<!-- Center-aligned -->
<ul class="pagination justify-content-center" style="margin:20px 0">
  <li class="page-item">...</li>
</ul>
<!-- Right-aligned -->
<ul class="pagination justify-content-end" style="margin:20px 0">
  <li class="page-item">...</li>
</ul>
```

## 16.5 Breadcrumbs

​	Another form for pagination, is breadcrumbs.

​	The <span style="color:red;">.breadcrumb</span> and <span style="color:red;">.breadcrumb-item</span> classes indicates the current page's location within a navigation hierarchy:

```
<ul class="breadcrumb">
  <li class="breadcrumb-item"><a href="#">Photos</a></li>
  <li class="breadcrumb-item"><a href="#">Summer 2017</a></li>
  <li class="breadcrumb-item"><a href="#">Italy</a></li>
  <li class="breadcrumb-item active">Rome</li>
</ul>
```



# 17. Bootstrap 5 List Groups

## 17.1 Basic List Groups

​	The most basic list group is an unordered list whit list items.

​	To create a basic list group, use an <span style="color:red;">\<ul></span> element with class <span style="color:red;">.list-group</span>, and <span style="color:red;">\<li></span> elements with calss <span style="color:red;">.list-group-item</span>:

```
<ul class="list-group">
	<li class="list-group-item">First item</li>
	<li class="list-group-item">Second item</li>
	<li class="list-group-item">Third item</li>
</ul>
```

## 17.2 Active State

​	Use the <span style="color:red;">.active</span> class to highlight the current item:

```
	<li class="list-group-item active">Second item</li>
```

## 17.3 List Group With Linked Items

​	To create a list group with linked items, use <span style="color:red;">\<div></span> instead of <span style="color:red;">\<ul></span> and <span style="color:red;">\<a></span> instead of <span style="color:red;">\<li></span>. Optionally, add the <span style="color:red;">.list-group-item-action</span> class if you want a grey background color on hover:

```
<div class="list-group mt-4">
	<a href="#" class="list-group-item list-group-item-action">First item</a>
	<a href="#" class="list-group-item list-group-item-action">Second item</a>
	<a href="#" class="list-group-item list-group-item-action">Third item</a>
</div>
```

## 17.4 Disabled Item

​	The <span style="color:red;">.disabled</span> class adds a lighter text color to the disabled item. And when used on links, it will remove the hover effect.

```
	<a href="#" class="list-group-item disable">Disabled item</a>
```

## 17.5 Flush / Remove Borders

​	Use the <span style="color:red;">.list-group-flush</span> class to remove some borders and rounded corners.

```
<ul class="list-group list-group-flush">
  <li class="list-group-item">First item</li>
  <li class="list-group-item">Second item</li>
  <li class="list-group-item">Third item</li>
  <li class="list-group-item">Fourth item</li>
</ul>
```

## 17.6 Numbered List Groups

​	Use the <span style="color:red;">.list-group-numbered</span> class to create list items with numbers in front of them:

```
<ol class="list-group list-group-numbered">
  <li class="list-group-item">First item</li>
  <li class="list-group-item">Second item</li>
  <li class="list-group-item">Third item</li>
</ol>
```

## 17.7 Horizontal List Groups

​	If you want the list items to display horizontally instead of vertically (side by side instead of on top of each other), add the <span style="color:red;">.list-group-horizontal</span> class to <span style="color:red;">.list-group</span>:

```
<ul class="list-group list-group-horizontal">
  <li class="list-group-item">First item</li>
  <li class="list-group-item">Second item</li>
  <li class="list-group-item">Third item</li>
  <li class="list-group-item">Fourth item</li>
</ul>
```

## 17.8 Contextual Classes

​	Contextual classes can be used to add color to the list items.

​	The classes for coloring list-items are: <span style="color:red;">.list-group-item-success</span>, <span style="color:red;">.list-group-item-secondary</span>, <span style="color:red;">.list-group-item-info</span>, <span style="color:red;">.list-group-item-warning</span>, <span style="color:red;">.list-group-item-danger</span>, <span style="color:red;">.list-group-item-primary</span>, <span style="color:red;">.list-group-item-dark</span>, <span style="color:red;">.list-group-item-light</span>.

```
<ul class="list-group">
  <li class="list-group-item list-group-item-success">Success item</li>
  <li class="list-group-item list-group-item-secondary">Secondary item</li>
  <li class="list-group-item list-group-item-info">Info item</li>
  <li class="list-group-item list-group-item-warning">Warning item</li>
  <li class="list-group-item list-group-item-danger">Danger item</li>
  <li class="list-group-item list-group-item-primary">Primary item</li>
  <li class="list-group-item list-group-item-dark">Dark item</li>
  <li class="list-group-item list-group-item-light">Light item</li>
</ul>
```

## 17.9 Link items with Contextual Classes

```
<div class="list-group">
  <a href="#" class="list-group-item list-group-item-action">Action item</a>
  <a href="#" class="list-group-item list-group-item-action list-group-item-success">Success item</a>
  <a href="#" class="list-group-item list-group-item-action list-group-item-secondary">Secondary item</a>
  <a href="#" class="list-group-item list-group-item-action list-group-item-info">Info item</a>
  <a href="#" class="list-group-item list-group-item-action list-group-item-warning">Warning item</a>
  <a href="#" class="list-group-item list-group-item-action list-group-item-danger">Danger item</a>
  <a href="#" class="list-group-item list-group-item-action list-group-item-primary">Primary item</a>
  <a href="#" class="list-group-item list-group-item-action list-group-item-dark">Dark item</a>
  <a href="#" class="list-group-item list-group-item-action list-group-item-light">Light item</a>
</div>
```

## 17.10 List Group with Badges

​	Combine <span style="color:red;">.badge</span> classes with utility/helper classes to add badges inside the list group:

```
<ul class="list-group">
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Inbox
    <span class="badge bg-primary rounded-pill">12</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Ads
    <span class="badge bg-primary rounded-pill">50</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Junk
    <span class="badge bg-primary rounded-pill">99</span>
  </li>
</ul>
```



# 18. Bootstrap 5 Cards

## 18.1 Cards

​	A card in Bootstrap 5 is a bordered box with some padding around its content. It includes options for headers, footers, content, colors, etc.

## 18.2 Basic Card

​	A basic card is created with the <span style="color:red;">.card</span> class, and content inside the card has a <span style="color:red;">.card-body</span> class.

```
<div class="card">
	<div class="card-body">Basic card</div>
</div>
```

## 18.3 Header and Footer

​	The <span style="color:red;">.card-header</span> class adds a heading to the card and the <span style="color:red;">.card-footer</span> class adds a footer to the card:

```
<div class="card">
	<div class="card-header">Header</div>
	<div class="card-body">Content</div>
	<div class="card-footer">Footer</div>
</div>
```

## 18.4 Contextual Cards

​	To add a background color the card, use contextual classes (<span style="color:red;">.bg-primary</span>, <span style="color:red;">.bg-success</span>, <span style="color:red;">.bg-info</span>, <span style="color:red;">.bg-warning</span>, <span style="color:red;">.bg-danger</span>, <span style="color:red;">.bg-secondary</span>, <span style="color:red;">.bg-dark</span> and <span style="color:red;">.bg-light</span>).

```
<div class="card bg-primary text-white mt-3">
	<div class="card-body">Primary card</div>
</div>
```

## 18.5 Titles, text, and links

​	Use <span style="color:red;">.card-title</span> to add card titles to any heading element. The <span style="color:red;">.card-text</span> class is used to remove bottom margins for a \<p> element if it is the last child (or the only one) inside <span style="color:red;">.card-body</span>. The <span style="color:red;">.card-link</span> class adds a blue color to any link, and a hover effect.

```
<div class="card mt-3">
	<div class="card-body">
		<h4 class="card-title">Card title</h4>
		<p class="card-text">Some example text...</p>
		<a href="#" class="card-link">Card link</a>
		<a href="#" class="card-link">Another link</a>
	</div>
</div>
```

## 18.6 Card Images

​	Add <span style="color:red;">.card-img-top</span> or <span style="color:red;">.card-img-bottom</span> to an <span style="color:red;">\<img></span> to place the image at the top or at the bottom inside the card. Note that we have added the image outside of the <span style="color:red;">.card-body</span> to span the entire width:

```
<div class="card mt-3" style="width:200px">
	<img class="card-img-top" src="img/card.jpg" alt="Card image">
	<div class="card-body">
	<he class="card-title">Joe Biden</h4>
	<p class="card-text">Some text...</p>
	<a href="#" class="btn btn-danger">See Profile</a>
	</div>
</div>
```

## 18.7 Card Image Overlays

​	Turn an image into a card background and use <span style="color:red;">.card-img-overlap</span> to add text on top of the image:

```
<div class="card mt-3" style="width:200px">
	<img class="card-img-top" src="img/card.jpg" alt="Card image">
	<div class="card-img-overlay">
	<he class="card-title">Joe Biden</h4>
	<p class="card-text">Some text...</p>
	<a href="#" class="btn btn-danger">See Profile</a>
	</div>
</div>
```



# 19. Bootstrap 5 Dropdowns

## 19.1 Basic Dropdown

​	A dropdown menu is a toggleable menu that allows the user to choose one value from a predefined list:

```
<div class="dropdown">
	<button type="button" class="btn btn-primary dropdown-toggle" 
		data-bs-toggle="dropdown">
		Dropdown button
	</button>
	<ul class="dropdown-menu">
		<li><a class="dropdown-item" href="#">Link 1</a></li>
		<li><a class="dropdown-item" href="#">Link 2</a></li>
		<li><a class="dropdown-item" href="#">Link 3</a></li>
	</ul>
</div>
```

<span style="font-size:20px;">Example Explained</span>

​	The <span style="color:red;">.dropdown</span> class indicates a drop-down menu.

​	To open the drop-down menu, use a button or a link with a class of <span style="color:red;">.dropdown-toggle</span> and the <span style="color:red;">data-bs-toggle="dropdown"</span> attribute.

​	Add the <span style="color:red;">.dropdown-menu</span> class to <span style="color:red;">\<div></span> element to actually build the dropdown menu. Then add the the <span style="color:red;">.dropdown-item</span> class to each element (links or buttons) inside the dropdown menu.

## 19.2 Dropdown Divider 

​	The <span style="color:red;">.dropdown-divider</span> class is used to separate links inside the dropdown menu with a thin horizontal border:

```
	<li><hr class="dropdown-divider">Others</hr></li>
```

## 19.3 Dropdown Header

​	Use the <span style="color:red;">.dropdown-header</span> class to add headers inside the dropdown menu:

```
	<li><h5 class="dropdown-header">Menu header</h5></li>
```

## 19.4 Disable and Active items

​	Highlight a specific dropdown item with the <span style="color:red;">.active</span> class (adds a blue background color).

​	To disable an item in the dropdown menu, use the <span style="color:red;">.disabled</span> class (gets a light-grey text color color and a "no-parking-sign" icon on hover):

```
<div class="dropdown">
	<button type="button" class="btn btn-primary dropdown-toggle" 
		data-bs-toggle="dropdown">
		Dropdown button
	</button>
	<ul class="dropdown-menu">
		<li><h5 class="dropdown-header">Dropdown header</h5></li>
		<li><a class="dropdown-item" href="#">Link 1</a></li>
		<li><a class="dropdown-item" href="#">Link 2</a></li>
		<li><a class="dropdown-item" href="#">Link 3</a></li>
		<li><a class="dropdown-item active" href="#">Link 4</a></li>
		<li><a class="dropdown-item disabled" href="#">Link 5</a></li>
		<li><hr class="dropdown-divider">Others</hr></li>
	</ul>
</div>
```

## 19.5 Dropdown Position

​	You can also create a "dropend" of "dropstart" menu, by adding the <span style="color:red;">.dropend</span> or <span style="color:red;">.dropstart</span> class to the dropdown element. Note that the caret/arrow is added automatically.

```
<div class="dropdown dropend">
<div class="dropdown dropstart">
```

## 19.6 Dropdown Menu Right

​	To right-align the dropdown menu, add the <span style="color:red;">.dropdown-menu-end</span> class to the element with .dropdown-menu:

```
<div class="dropdown dropdown-menu-end">
```

## 19.7 Dropup

​	If you want the dropdown menu to expand upwards instead of downward, change the \<div> element with class="dropdown" to <span style="color:red;">"dropup"</span>:

```
<div class="dropup">
```

## 19.8 Dropdown Text

​	The <span style="color:red;">.dropdown-item-text</span> class is used to add plain text to a dropdown item, or used on links for default link styling.

```
	<li><a class="dropdown-item-text" href="#">Text Link</a></li>
	<li><span class="dropdown-item-text">Just Text</span></li>
```

## 19.9 Grouped Buttons with a Dropdown

```
<div class="btn-group">
  <button type="button" class="btn btn-primary">Apple</button>
  <button type="button" class="btn btn-primary">Samsung</button>
  <div class="btn-group">
    <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">Sony</button>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Tablet</a></li>
      <li><a class="dropdown-item" href="#">Smartphone</a></li>
    </ul>
  </div>
</div>
```

## 19.10 Vertical Button Group w/ Dropdown

```
<div class="btn-group-vertical">
  <button type="button" class="btn btn-primary">Apple</button>
  <button type="button" class="btn btn-primary">Samsung</button>
  <div class="btn-group">
    <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">Sony</button>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Tablet</a></li>
      <li><a class="dropdown-item" href="#">Smartphone</a></li>
    </ul>
  </div>
</div>
```



# 20. Bootstrap 5 Collapse

## 20.1 Basic Collapsible

​	Collapsibles are useful when you want to hide and show large amount of content:

```
<button class="btn btn-success" data-bs-toggle="collapse" data-bs-target="#demo20">Collapsible</button>
<div id="demo20" class="collapse">
	As I began to love myself I quit stealing my own time, and I stopped designing
	huge projects for the future. Today, I only do what brings me joy hand happiness,
	things I love to do and that make my heart cheer, and I do them in my own way
	and in my own rhythem. Today I call it "SIMPLICITY".
</div>
```

<span style="font-size:20px">Example Explained</span>

​	The <span style="color:red;">.collapse</span> class indicates a cllapsible element (a \<div> in our example); this is the content that will be shown or hidden with a click of a button.

​	To control (show/hide) the collapsible content, add the <span style="color:red;">data-bs-toggle="collapse"</span> atrribute to an \<a> or a \<button> element. Then add the <span style="color:red;">data-bs-target="#id"</span> attribute to connect the button with the collapsible content (\<div id="demo">).

​	<b>Note:</b> For \<a> element, you can use the <span style="color:red;">href</span> attribute instead of the <span style="color:red;">data-bs-target</span> attribute:

```
<a href="#deom" data-bs-toggle="collapse">Collaspible</a>
	<div id="demo" class="collapse">
	<!-- SOMETHIMG HERE -->
	</div>
```

​	By default, the collapsible content is hidden. However, you can add the <span style="color:red;">.show</span> class to show the content by default:

```
	<div id="demo" class="collapse show">
	<!-- SOMETHING HERE -->
	</div>
```

 ## 20.2 Accordion

​	The following example shows a simple accordion by extending the card component.

<b>Note:</b> Use the <span style="color:red;">data-bs-parent</span> attribute to make sure that all collapsible elements under the specified parent will be closed when one of the collapsible item is shown:

```
 <div id="accordion">
    <div class="card">
      <div class="card-header">
        <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
          Collapsible Group Item #1
        </a>
      </div>
      <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
        <div class="card-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseTwo">
        Collapsible Group Item #2
      </a>
      </div>
      <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
        <div class="card-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseThree">
          Collapsible Group Item #3
        </a>
      </div>
      <div id="collapseThree" class="collapse" data-bs-parent="#accordion">
        <div class="card-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </div>
      </div>
    </div>
  </div>
```



# 21. Bootstrap 5 Navs

## 21.1 Nav Menus

​	If you want to create a simple horizontal menu, add the <span style="color:red;">.nav</span> class to a <span style="color:red;">\<ul></span> element, followed by <span style="color:red;">.nav-item</span> for each <span style="color:red;">\<li></span> and add the <span style="color:red;">.nav-link</span> class to their links:

```
<ul class="nav">
	<li class="nav-item">
		<a class="nav-link" href="#">Link 1</a>
	</li>
	<li class="nav-item">
		<a class="nav-link ative" href="#">Link 2</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="#">Link 3</a>
	</li>
	<li class="nav-item">
		<a class="nav-link disabled" href="#">Link 4 (disabled)</a>
	</li>
</ul>
```

## 21.2 Aligned Nav

​	Add the <span style="color:red;">.justify-content-center</span> class to center the nav, and the <span style="color:red;">.justify-content-end</span> class to right-align the nav.

```
<ul class="nav justify-content-center">
<ul class="nav justify-content-end">
```

## 21.3 Vertical Nav

​	Add the <span style="color:red;">.flex-column</span> class to create a vertical nav:

```
<ul class="nav flex-column">
```

## 21.4 Tabs

​	Turn the nav menu into navigation tabs with the <span style="color:red;">.nav-tabs</span> class. Add the <span style="color:red;">.active</span> class to the active/current link. If you want the tabs to be toggleable, see the last example on this page:

```
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" href="#">Active</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" href="#">Disabled</a>
  </li>
</ul>
```

## 21.5 Pills

​	Turn the nav menu into navigation pills with the <span style="color:red;">.nav-pills</span> class. If you want the pills to be toggleable, see the last example on this page:

```
<ul class="nav nav-pills">
  <li class="nav-item">
    <a class="nav-link active" href="#">Active</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" href="#">Disabled</a>
  </li>
</ul>
```

## 21.6 Justified Tabs/pills

​	Justify the tabs/pills with the <span style="color:red;">.nav-justify</span> class (equal width):

```
<ul class="nav nav-pills nav-justified">...</ul>
<ul class="nav nav-tabs nav-justified">...</ul>
```

## 21.7 Pills with Dropdown

​	Expand one \<li> to dropdown:

```
<ul class="nav nav-pills">
  <li class="nav-item">
    <a class="nav-link active" href="#">Active</a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#">Dropdown</a>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Link 1</a></li>
      <li><a class="dropdown-item" href="#">Link 2</a></li>
      <li><a class="dropdown-item" href="#">Link 3</a></li>
    </ul>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" href="#">Disabled</a>
  </li>
</ul>
```

## 21.8 Tabs with Dropdown

```
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" href="#">Active</a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#">Dropdown</a>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Link 1</a></li>
      <li><a class="dropdown-item" href="#">Link 2</a></li>
      <li><a class="dropdown-item" href="#">Link 3</a></li>
    </ul>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" href="#">Disabled</a>
  </li>
</ul>
```

## 21.9 Toggleable / Dynamic Tabs

​	To make the tabs toggleable, add the <span style="color:red;">data-toggle="tab"</span> attribute to each link. Then add a <span style="color:red;">.tab-pane</span> class with a unique ID for every tab and wrap them inside a <span style="color:red;">\<div></span> element with class <span style="color:red;">.tab-content</span>.

​	If you want the tabs to fade in and out when clicking on them, add the <span style="color:red;">.fade</span> class to <span style="color:red;">.tab-pane</span>:

```
<ul class="nav nav-tabs" role="tablist">
	<li class="nav-item">
		<a class="nav-link active" data-bs-toggle="tab" href="#home">Home</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" data-bs-toggle="tab" href="#menu1">Menu 1</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" data-bs-toggle="tab" href="#menu2">Menu 2</a>
	</li>
</ul>
<div class="tab-content">
	<div id="home" class="container tab-pane active"><br>
		<h3>HOME</h3>
		<p>Here is some text....</p>
	</div>
	<div id="menu1" class="container tab-pane fade"><br>
		<h3>MENU 1</h3>
		<p>Here is some text....</p>
	</div>
	<div id="menu2" class="container tab-pane fade"><br>
		<h3>MENU 2</h3>
		<p>Here is some text....</p>
	</div>
</div>
```

## 21.10 Toggleable / Dynamic Pills

​	The same code applies to pills; only change the data-toggle attribute to <span style="color:red;">data-toggle-"pill"</span>:

```
	<a class="nav-link" data-bs-toggle="pill" href="#menu1">Menu1</a>
```



# 22. Bootstrap 5 Navbars

## 22.1 Navigation Bars

​	A navigation bar is a navigation header that is placed at the top of the page.

## 22.2 Basic Navbar

​	With Bootstrap, a navigation bar can extend or collapse, depending on the screen size.

​	A standard navigation bar is created with the <span style="color:red;">.navbar</span> class, followed by a responsive collapsing class: <span style="color:red;">.navbar-expand-xxl|xl|lg|md|sm</span> (stacks the navbar vertically on xxlarge, extra large, extra large, large, medium or small screens).

​	To add links inside the navbar, use either an <span style="color:red;">\<ul></span> element (or a <span style="color:red;">\<div></span>) with <span style="color:red;">class="navbar-nav"</span>. Then add <span style="color:red;">\<li></span> elements with a <span style="color:red;">.nav-item</span> class followed by an <span style="color:red;">\<a></span> element with a <span style="color:red;">.nav-link</span> class:

```
<nav class="navbar navbar-expand-sm bg-light">
	<div class="container-fluid">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link" href="#">Link 1</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="#">Link 2</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="#">Link 3</a>
			</li>
		</ul>
	</div>
</nav>
```

## 22.3 Vertical Navbar

​	Remove the <span style="color:red;">.navbar-expand-*</span> class to create a navigation bar that will always to vertical, practice it.

## 22.4 Centered Navbar

​	Add the <span style="color:red;">.justify-content-center</span> class to center the navigation bar:

```
<nav class="navbar navbar-expand-sm bg-light justify-content-center">
	//...
</nav>
```

## 22.5 Colored Navbar

​	Use any of the <span style="color:red;">.bg-color</span> classes to change the background color of the navbar (<span style="color:red;">.bg-primary</span>, <span style="color:red;">.bg-success</span>, <span style="color:red;">.bg-info</span>, <span style="color:red;">.bg-warning</span>, <span style="color:red;">.bg-danger</span>, <span style="color:red;">.bg-secondary</span>, <span style="color:red;">.bg-dark</span> and <span style="color:red;">.bg-light</span>)

​	<b>Tip:</b> Add a <b>white</b> text color to all links in the navbar with the <span style="color:red;">.navbar-dark</span> class, or use the <span style="color:red;">.navbar-light</span> class to add a <b>black</b> text color.

```
<nav class="navbar navbar-expand-sm  justify-content-center bg-warning navbar-dark">
	<div class="container">	<!-- Delete this element pair to be centered -->
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link disabled" href="#">Disabled</a>
			</li>
			<li class="nav-item">
				<a class="nav-link active" href="#">Actived</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="#">Link2</a>
			</li>
		</ul>
	</div>
</div>
```

<b>Active/disabled state</b>: Add the <span style="color:red;">.acitve</span> class to an <span style="color:red;">\<a></span> element to highlight the current link, or the <span style="color:red;">.disable</span> class to indicate that the link is unclickable.

## 22.6 Brand / Logo

​	The <span style="color:red;">.navbar-brand</span> class is used to highlight the brand/logo/project name of your page.

```
<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
	<div class="container">		<!-- try container-fluid -->
		<a class="navbar-brand" href="#">Logo</a>
	</div>
</nav>
```

​	When using the <span style="color:red;">.navbar-brand</span> class with images, Bootstrap 5 will automatically style the image to fit the navbar vertically:

```
<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
	<div class="container-fluid">
		<a class="navbar-brand" href="#">
			<img src="img/avator.png" alt="logo" style="width: 40px;" class="rounded-pill">
		</a>
	</div>
</nav>
```

## 22.7 Navbar Text

​	Use the <span style="color:red;">.navbar-text</span> class to vertical align any elements inside the navbar that are not links (ensures proper padding and text color):

```
<br>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
	<div class="container-fluid">
		<span class="navbar-text">Navbar text</span>
	</div>
</nav>
```

​	Very often, especially on small screens, you want to hide the navigation links and replace them with a button that should reveal them when clicked on,

​	To create a collapsible navigation bar, use a button with <span style="color:red;">class="navbar-toggler"</span>, <span style="color:red;">data-bs-toggle="collapse"</span>, and <span style="color:red;">data-bs-target="#target"</span>. Then wrap the navbar content (links, etc) inside a \<div> element with <span style="color:red;">class="collapse navbar-collapse"</span>, followed by an id that matches the <span style="color:red;">data-bs-target</span> of the button: "<i>target</i>".

(After my testing, found this don't work on my browser)

```
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
	<div class="container-fluid">
		<a class="navbar-brand" href="#">Logo</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
			data-bs-target="#collapsibleNavbar">
			 <span class="navbar-toggler-icon"></span>
    		</button>
		<div class="collapse navbar-collapse" id="collapsiableNavbar">
			<ul class="navbar-nav">
				<li class="navbar-item">
					<a class="nav-link" href="#">Link1</a>
				</li>
				<li class="navbar-item">
					<a class="nav-link" href="#">Link2</a>
				</li>
				<li class="navbar-item">
					<a class="nav-link" href="#">Link3</a>
				</li>
			</ul>
		</div>
	</div>
</nav>
```

<b>Tip:</b> You can also remove the <span style="color:red;">.navbar-expand-md</span>(?) class to ALWAYS hide navbar links and display the toggler button.

## 22.8 Navbar With Dropdown

​	Navbar can also hold dropdown menus (add this part under above \<ul>):

```
<li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Dropdown</a>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="#">Link</a></li>
    <li><a class="dropdown-item" href="#">Another link</a></li>
    <li><a class="dropdown-item" href="#">A third link</a></li>
  </ul>
</li>
```

## 22.9 Navbar Forms and Buttons

​	You can also include forms inside the navigation bar (like search):

```
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="javascript:void(0)">Logo</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mynavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)">Link</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)">Link</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)">Link</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="text" placeholder="Search">
        <button class="btn btn-primary" type="button">Search</button>
      </form>
    </div>
  </div>
</nav>
```

## 22.10 Fixed Navigation Bar

​	The navigation bar can also be fixed at the top or at the bottom of the page.

​	A fixed navigation bar stays visible in a fixed position independent of the page scroll. The <span style="color:red;">.fixed-top</span> class makes the navigation bar fixed at the <b>top</b>:

```
<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
	//...
</nav>
```

​	Use the <span style="color:red;">.fixed-bottom</span> class to make the navbar stay at the <b>bottom</b> of the page, and use the <span style="color:red;">.sticky-top</span> class to make the navbar fixed/stay at the <b>top</b> of the page when you scroll <b>past</b> it. <b>Note:</b> This class not work in IE11 and eariler (will treat it as <span style="color:red;">position: relative</span>).



# 23. Bootstrap 5 Carousel

## 23.1 Carousel / Slideshow

​	The Carousel is a slideshow for cycling through elements (refer my github page).

## 23.2 How TO create a Carousel

​	The following example shows how to create a basic carousel with indicators and controls:

```
<div id="demo18" class="carousel slide" data-bs-ride="carousel">
	<!-- Indicators/dots -->
	<div class="carousel-indicators">
		<button type="button" data-bs-target="#demo18" 
			data-bs-slide-to="0" class="active"></button>
		<button type="button" data-bs-target="#demo18"
			data-bs-slide-to="1"></button>
		<button type="button" data-bs-target="#demo18" 
			data-bs-slide-to="2"></button>
	</div>
	<!-- The slideshow/carousel -->
	<div class="carousel-inner">
		<div class="carousel-item active">
			<img src="img/image1.jpg" alt="Image 1" class="d-block" style="width:100%">
		</div>
		<div class="carousel-item">
			<img src="img/image2.jpg" alt="Image 2" class="d-block" style="width:100%">
		</div>
		<div class="carousel-item">
			<img src="img/image3.jpg" alt="Image 3" class="d-block" style="width:100%">
		</div>
	</div>
	<!-- Left and right controls/icons -->
	<button class="carousel-control-prev" type="button"
	data-bs-target="#demo18" data-bs-slide="prev">
		<span class="carousel-control-prev-icon"></span>
	</button>
	<button class="carousel-control-next" type="button"
	data-bs-target="#demo18" data-bs-slide="next">
		<span class="carousel-control-next-icon"></span>
	</button>
</div> 
```

<span style="font-size:20px;">Example explained</span>

​	A description of what each class from the example above to:

| Class                         | Description                                                  |
| :---------------------------- | :----------------------------------------------------------- |
| `.carousel`                   | Creates a carousel                                           |
| `.carousel-indicators`        | Adds indicators for the carousel. These are the little dots at the bottom of each slide (which indicates how many slides there are in the carousel, and which slide the user are currently viewing) |
| `.carousel-inner`             | Adds slides to the carousel                                  |
| `.carousel-item`              | Specifies the content of each slide                          |
| `.carousel-control-prev`      | Adds a left (previous) button to the carousel, which allows the user to go back between the slides |
| `.carousel-control-next`      | Adds a right (next) button to the carousel, which allows the user to go forward between the slides |
| `.carousel-control-prev-icon` | Used together with .carousel-control-prev to create a "previous" button |
| `.carousel-control-next-icon` | Used together with .carousel-control-next to create a "next" button |
| `.slide`                      | Adds a CSS transition and animation effect when sliding from one item to the next. Remove this class if you do not want this effect |

## 23.3 Add Captions to Slides

​	Add elements inside <span style="color:red;">\<div class="carousel-caption"></span> within each <span style="color:red;">\<div class="carousel-item"></span> to create a caption for each slide:

```
<div class="carousel-item">
	<img src="img/image2.jpg" alt="Image 2">
	<div class="carousel-caption">
		<h3>This is a caption</h3>
		<p>Here are some texts....</p>
	</div>
</div>
```



# 24. Bootstrap 5 Modal

## 24.1 Modals

​	The Modal component is a dialog box/popup window that is displayed on top of the current page.

## 24.2 How To Create a Modal

​	The following example shows how to create a basic modal:

```
<button type="button" class="btn btn-primary" data-bs-toggle="modal"
	data-bs-target="#myModal">
	Open modal
</button>
<div class="modal" id="myModal">
	<div class="modal-dialog">
		<div class="modal-content"
			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">Modal Heading</h4>
				<button type="button" class="btn-close"
				data-bs-dismiss="modal"></button>
			</div>
			<!-- Modal body -->
			<div class="modal-body">
				Modal body ...
			</div>
			<!-- Modal footer ... -->
			<div class="modal-footer">
				<button type="button" class="btn btn-danger"
				data-bs-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
```

## 24.3 Add animation

​	Use the <span style="color:red;">.fade</span> class to add a fading effect when opening and closing the modal:

```
<div class="modal fade" id="myModal"></div>
```

## 24.3 Modal Size

​	Change the size of the modal by adding the <span style="color:red;">.modal-sm</span> class for small modals (max-width 300px), <span style="color:red;">.modal-lg</span> class for large modals (max-width 800px), or <span style="color:red;">.modal-xl</span> for extra large modals (max-width 1140px). Default is 500px max-width.

​	Add the size class to the <span style="color:red;">\<div></span> element with class <span style="color:red;">.modal-dialog</span>:

```
<div class="modal" id="myModal">
	<div class="modal-dialog modal-sm">
```

<b>Note:</b> Default modal size is medium (500px max-width).

## 24.4 Fullscreen Modals

​	If you want the modal to span the whole width and height of the page, use the <span style="color:red;">.modal-fullscreen</span> class:

```
<div class="modal-dialog modal-fullscreen">
```

## 24.5 Responsive Fullscreen Modals

​	You can also control when the modal should be in fullscreen, with the <span style="color:red;">.modal-fullscreen-\*-\*</span> classes:

| Class                                                      | Description             |
| ---------------------------------------------------------- | ----------------------- |
| <span style="color:red;">.modal-fullscreen-sm-down</span>  | Fullscreen below 576px  |
| <span style="color:red;">.modal-fullscreen-md-down</span>  | Fullscreen below 768px  |
| <span style="color:red;">.modal-fullscreen-lg-down</span>  | Fullscreen below 992px  |
| <span style="color:red;">.modal-fullscreen-xl-down</span>  | Fullscreen below 1200px |
| <span style="color:red;">.modal-fullscreen-xxl-down</span> | Fullscreen below 1400px |

## 24.6 Centered Modal

​	Center the modal vertically and horizontally within the page, with the <span style="color:red;">.modal-dialog-centered</span> class:

```
<div class="modal-dialog modal-dialog-centered">
```

## 24.7 Scrolling Modal

​	When you have a lot of content inside the modal, a scrollbar is added to the page. 

```
<div class="modal-dialog">
```

​	However, it is possible to only scroll inside the modal, instead of the page itself, by adding <span style="color:red;">.modal-dialog-scrollable</span> to <span style="color:red;">.modal-dialog</span>:

```
<div class="modal-dialog modal-dialog-scrollable">
```



# 25. Bootstrap 5 Tooltip

## 25.1 Tooltips

​	The Tooltip component is mall pop-up box that appears when the user moves the mouse the mouse pointer over an element.

## 25.2 How To Create a Tooltip

​	To create a tooltip, add the <span style="color:red;">data-bs-toggle="tooltip"</span> attribute to an element.

​	Use the <span style="color:red;">title</span> attribute to specify the text that should be displayed inside the tooltip:

```
<button type="button" class="btn btn-primary" data-bs-toggle="tooltip"
	title="Hooray!">Hover over me!</button>
```

<b>Note:</b> Tooltips must be initialized with JavaScript to work.

​	The following code will enable all tooltips in the document:

```
<button type="button" class="btn btn-primary" data-bs-toggle="tooltip" title="Hooray!">
	Hover over me!
</button>
<script>
// Initialize tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})
</script>
```

## 25.3 Positioning Tooltips

​	By default, the tooltip will appear on top of the element.

​	Use the <span style="color:red;">data-bs-placement</span> attribute to set the position of the tooltip on top, bottom, left or the right side of the element:

```
<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Hooray!">Hover</a>
<a href="#" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Hooray!">Hover</a>
<a href="#" data-bs-toggle="tooltip" data-bs-placement="left" title="Hooray!">Hover</a>
<a href="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Hooray!">Hover</a>
```



# 26. Bootstrap 5 Popover

## 26.1 Popovers

​	The Popover component is similar to tooltips; it is a pop-up box that appears when the user clicks on an element. The difference is that the popover can contain much more content.

## 26.2 How To Create a Popover

​	To create a popover, add the <span style="color:red;">data-bs-toggle="popover" attribute to an element. Use the <span style="color:red;">title</span> attribute to specify the header text of the popover, and use the <span style="color:red;">data-bs-content</span> attribute to specify the text that should be displayed inside the popover's body:

```
<button type="button" class="btn btn-primary" data-bs-toggle="popover" title="Popover Header" data-bs-content="Some content inside the popover">Toggle popover</button>
```

<b>Note:</b> Popovers must be initialized with JavaScript to work.

​	The following code will enable all popovers in the document.

```
<script>
var popoverTriggerList = 
[].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
	return new bootstrap.Popover(popoverTriggerEl)
})
</script>
```

## 26.3 Positioning Popovers

​	By default, the popover will appear on the right side of the element.

​	Use the <span style="color:red;">data-bs-placement</span> attribute to set the position of the popover on top, bottom, left or right side of the element:

```
<a href="#" title="Header" data-bs-toggle="popover" data-bs-placement="top" data-content="Content">Top</a>
<a href="#" title="Header" data-bs-toggle="popover" data-bs-placement="bottom" data-content="Content">Bottom</a>
<a href="#" title="Header" data-bs-toggle="popover" data-bs-placement="left" data-content="Content">Left</a>
<a href="#" title="Header" data-bs-toggle="popover" data-bs-placement="right" data-content="Content">Right</a>
```

<b>Note:</b> The placement attributes do not work as you expect if it is not enough room for them. For example: if you use the top placement at the top of a page (where it is no room for it), it will instead display the popover below the element or to the right (wherever it is room for it).

## 26.4 Closing Popovers

​	By default, the popovers is closed when you click on the element again.

​	However, you can use the <span style="color:red;">data-bs-trigger="focus"</span> attribute which will close the popover when clicking outside the element:

```
<div class="container mt-3">
  <h3>Dismissible Popover</h3>
  <a href="#" title="Dismissible popover" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-content="Click anywhere in the document to close this popover">Click me</a>
</div>
```

## 26.5 Hoverable Popover

​	<b>Tip</b>: If you want the popover to be displayed when you move the mouse pointer over the element, use the <span style="color:red;">data-bs-trigger</span> attribute with a value of "<span style="color:red;">hover</span>":

```
<a href="#" title="Header" data-bs-toggle="popover" data-bs-trigger="hover" data-bs-content="Popover text">Hover over me</a>
```



# 27. Bootstrap 5 Toasts

## 27.1 Toasts

​	The toast component is like an alert box that is only shown for a couple of seconds when something happens (i.e. when the user clicks on a button, submits a form, etc).

## 27.2 How To Create a Toast

​	To create a toast, use the <span style="color:red;">.toast</span> class, and add a <span style="color:red;">.toast-header</span> and a <span style="color:red;">.toast-body</span> inside of it.

​	<b>Note:</b> Toasts are hidden by default. Use the <span style="color:red;">.show</span> class if you want to display it. To close it, use a \<button> element and add <span style="color:red;">data-bs-dismiss="toast"</span>:

```
<div class="toast show">
  <div class="toast-header">
    Toast Header
    <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
  </div>
  <div class="toast-body">
    Some text inside the toast body
  </div>
</div>
```

## 27.3 Open a Toast

​	To show a toast with a click of a button, you must initialize it with JavaScript: select the specified element and call the <span style="color:red;">toast()</span> method.

​	The following code will show all "toasts" in the document when you click on a button:

```
<div class="container mt-3">
  <h3>Toast Example</h3>
  <p>In this example, we use a button to show the toast message.</p>

  <button type="button" class="btn btn-primary" id="toastbtn">Show Toast</button>
  
  <div class="toast">
    <div class="toast-header">
      <strong class="me-auto">Toast Header</strong>
      <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
    </div>
    <div class="toast-body">
      <p>Some text inside the toast body</p>
    </div>
  </div>
</div>
<script>
document.getElementById("toastbtn").onclick = function() {
  var toastElList = [].slice.call(document.querySelectorAll('.toast'))
  var toastList = toastElList.map(function(toastEl) {
    return new bootstrap.Toast(toastEl)
  })
  toastList.forEach(toast => toast.show()) 
}
</script>
```



# 28. Bootstrap 5 Scrollspy

## 28.1 Scrollspy

​	Scrollspy is used to automatically update links in a navigation list based on <b>scroll</b> position.

## 28.2 How To Create a Scrollspy

​	The following example shows how to create a scrollspy:

```
<!-- The scrollable area -->
<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="50">

<!-- The navbar - The <a> elements are used to jump to a section in the scrollable area -->
<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
...
  <ul class="navbar-nav">
    <li><a href="#section1">Section 1</a></li>
    ...
</nav>

<!-- Section 1 -->
<div id="section1">
  <h1>Section 1</h1>
  <p>Try to scroll this page and look at the navigation bar while scrolling!</p>
</div>
...

</body>
```

<span style="font-size:20px;">Example Explained</span>

​	Add <span style="color:red;">data-bs-spy="scroll"</span> to the element that should be used as the scrollable area (often this is the <span style="color:red;">\<body></span> element).

​	Then add the <span style="color:red;">data-bs-target</span> attribute with a value of the id or the class name of the navigation bar (<span style="color:red;">.narvbar</span>). This is to make sure that the navbar is connected with the scrollable area.

​	Note that scrollable elements must match the ID of the links inside the navbar's list item (<span style="color:red;">\<div id="section1"></span> matches <span style="color:red;">\<a href="#section1"></span>).

​	The optional <span style="color:red;">data-bs-offset</span> attribute specifies the number of pixels to offset from top when calculating the position of scroll. This is useful when you feel that the links inside the navbar changes the active state too soon or too early when jumping to the scrollable elements. Default is 10 pixels.

<b>Requires relative positioning</b>: The element with data-bs-spy="scroll" requires the CSS <b>position</b> property, with a value of "relative" to work properly.



# 29. Bootstrap 5 Offcanvas

## 29.1 Offcanvas

​	Offcanvas is similar to modals (hidden by default and shown when actived), expect that is often used as a sidebar navigation menu.

## 29.2 How To Create an Offcanvas Sidebar

​	The following example shows how to create an offcanvas sidebar:
```
<div class="offcanvas offcanvas-start" id="demo21">
	<div class="offcanvas-header">
		<h1 class="offcanvas-title">Heading</h1>
		<button type="button" class="btn-close" 
		data-bs-dismiss="offcanvas"></button>
	</div>
	<div class="offcanvas-body">
		<p>As I began to love myself I freed myself of  anything that is no</p>
		<p>good for my health - food, people, things, situations, and </p>
		<p>everything that drew me down and away from myself. At first</p>
		<p>I called this attitude a healthy egoism. Today I know it is "LOVE OF ONESLEF".</p>
	</div>
</div>
<button class="btn btn-danger" type="button" data-bs-toggle="offcanvas"
	data-bs-target="#demo21">
	Open Offcanvas Sidebar
</button>
```

<span style="font-size:20px;">Example Explained</span>

​	The <span style="color:red;">.offcanvas</span> class creates the offcanvas sidebar.

​	The <span style="color:red;">.offcanvas-start</span> class positions the offcanvas, and makes it 400px wide. See examples below for more positioning classes. The <span style="color:red;">.offcanvas-title</span> class ensures proper margins and line-height. The add you content inside the <span style="color:red;">.offcanvas-body</span> class.

​	To open the offcanvas sidebar, you must use a <span style="color:red;">\<button></span> or an <span style="color:red;">\<a></span> element that points to the id of the <span style="color:red;">.offcanva</span> container (<span style="color:red;">#demo21</span> here).

​	To open the offcanvas sidebar with an <span style="color:red;">\<a></span> element, you can point to <span style="color:red;">#demo21</span> with the href attribute, instead of <span style="color:red;">data-bs-target</span> attribute.

## 29.3 Offcanvs Position

​	Use the <span style="color:red;">.offcanvas-start|end|top|bottom</span> to positon the offcanvas to the left, right, top or bottom:

```
<div class="offcanvas offcanvas-end" id="demo21">
```

## 29.4 Responsive OffCanvas Menu

​	You can also control when you want to hide or show the offcanvas menu on different screen widths, withe the <span style="color:red;">.offcanvas-sm|md|lg|xl|xxl</span> classes:

```
<div class="offcanvas offcanvas-start offcanvas-lg" id="demo">
  <div class="offcanvas-header">
    <h1 class="offcanvas-title">Heading</h1>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
  </div>
  <div class="offcanvas-body">
    <p>Some text lorem ipsum.</p>
    <p>Some text lorem ipsum.</p>
    <p>Some text lorem ipsum.</p>
    <button class="btn btn-secondary" type="button">A Button</button>
  </div>
</div>

<div class="container-fluid mt-3">
  <h3>Responsive Offcanvas Menu</h3>
  <p>You can also hide or show the offcanvas menu on different screen widths, with the .offcanvas-sm|md|lg|xl|xxl classes.</p>
  <p>In this example, we hide the offcanvas menu on screens larger than 991px wide. Note that we also hide the button that opens the offcanvas (d-lg-none).</p>
  <p class="text-bg-danger">Resize the browser window to see the result.</p>
  <button class="btn btn-primary d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#demo">
    Open Offcanvas Sidebar
  </button>
</div>
```

## 29.5 Dark OffCanvas Menu

​	Use the <span style="color:red;">.text-bg-dark</span> class to create a dark offcanvas menu.

​	<b>Tip:</b> We have also added the <span style="color:red;">.btn-close-white</span> class to <span style="color:red;">.btn-close</span>, to create a white close button that looks nice with the dark background:

```
<div class="offcanvas offcanvas-end" id="demo">
<button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
```



# 30. Bootstrap 5 Utilities

## 30.1 Utilities / Helper Classes

​	Bootstrap 5 has a lot of utility/helper classes to quickly style elements without using any CSS code.

## 30.2 Borders

​	Use the <span style="color:red;">border</span> classes to add or remove borders from an element.

```
<div class="container mt-3">
	<h2>Borders</h2>
	<p>Use the border classes to add or remove borders from an element</p>
	<span class="border"></span>
	<span class="border border-0"></span>
	<span class="border border-top-0"></span>
	<span class="border border-end-0"></span>
	<span class="border border-start-0"></span>
	<span class="border border-bottom"></span>
	<br>
	<span class="border-top"></span>
	<span class="border-bottom"></span>
	<span class="border-start"></span>
</div>
<style>
span {
	display: inline-block;
	width: 60px;
	height: 60px;
	margin: 6px;
	background-color: #f9f9f9;
}
</style>
```

## 30.3 Border Width

​	Use <span style="color:red;">.border-1</span> to <span style="color:red;">.border-5</span> to change the width of the border:

```
<span class="border border-1"></span>
```

## 30.4 Border Color

​	Add a color to the border with any of the contextual border color classes:

```
<div class="container mt-3">
	<h2>Borders</h2>
	<p>Use the border classes to add or remove borders from an element</p>
	<span class="border border-primary"></span>
	<span class="border border-0 border-4 border-secondary"></span>
	<span class="border border-top-0 border-success border-3"></span>
	<span class="border border-end-0 border-danger"></span>
	<span class="border border-start-0 border-warning"></span>
	<span class="border border-bottom border-info"></span>
	<br>
	<span class="border-top border-3 border-light"></span>
	<span class="border-bottom border-light"></span>
	<span class="border-start border-dark"></span>
</div>
```

## 30.5 Border Radius

​	Add rounded corners to an element with the <span style="color:red;">rounded</span> classes:

```
<div class="container mt-3">
	<h2>Borders</h2>
	<p>Use the border classes to add or remove borders from an element</p>
	<span class="myspan2 rounded"></span>
	<span class="myspan2 rounded-top"></span>
	<span class="myspan2 rounded-end3"></span>
	<span class="myspan2 rounded-start"></span>
	<span class="myspan2 rounded-circle"></span>
	<span class="myspan2 rounded-pill"></span>
	<br>
	<span class="myspan2 rounded-0"></span>
	<span class="myspan2 rounded-2"></span>
	<span class="myspan2 rounded-5"></span>
</div>
<style>
span.myspan2 {
	display: inline-block;
	width: 60px;
	height: 60px;
	margin: 6px;
	background-color: #555;
}
</style>
```

## 30.6 Float and Clearfix	

​	Float an element to the right with the <span style="color:red;">.float-end</span> class or to the left with <span style="color:red;">.float-start</span>, and clear floats with the <span style="color:red;">.clear-fix</span> class:

```
<div class="clearfix">
	<img src="img/image2.jpg" style="height: 400px;">
</div>
```

## 30.7 Responsive Floats

​	Float an element to the left or to the right depending on screen width, withe the responsive float classes (<span style="color:red;">.float-\*-start|end</span> - where * is <span style="color:red;">sm</span> >= 5760x, <span style="color:red;">md</span> >= 768px, <span style="color:red;">lg</span> >= 992px, <span style="color:red;">xl</span>>= 1200px or <span style="color:red;">xxl</span> >= 1400px ):

```
<div class="float-sm-end">Float right on small screens or wider</div><br>
<div class="float-md-end">Float right on medium screens or wider</div><br>
<div class="float-lg-end">Float right on large screens or wider</div><br>
<div class="float-xl-end">Float right on extra large screens or wider</div><br>
<div class="float-xxl-end">Float right on XXL screens or wider</div><br>
<div class="float-none">Float none</div>
```

## 30.8 Center ALign

​	Center an element with the <span style="color:red;">.mx-auto</span> class (adds margin-left and margin-right: auto):

```
<div class="mx-auto bg-warning" style="width:150px">Centered</div>
```

## 30.9 Width & Height

​	Set the width of an element with the w-* classes (<span style="color:red;">.w-25</span>, <span style="color:red;">.w-50</span>, <span style="color:red;">.w-75</span>, <span style="color:red;">.w-100</span>, <span style="color:red;">.mw-auto</span>, <span style="color:red;">.mw-100</span>), set the height of an element with the h-* classes (<span style="color:red;">.h-25</span>, <span style="color:red;">.h-50</span>, <span style="color:red;">.h-75</span>, <span style="color:red;">.h-100</span>, <span style="color:red;">-mh-auto</span>, <span style="color:red;">-mh-100</span>):

```
<div class="w-25 bg-warning">Width 25%</div>
<div class="w-50 bg-warning">Width 50%</div>
<div class="w-75 bg-warning">Width 75%</div>
<div class="w-100 bg-warning">Width 100%</div>
<div class="w-auto bg-warning">Auto Width</div>
<div class="mw-100 bg-warning">Max Width 100%</div>
```

## 30.10 Spacing

​	Bootstrap 5 has a wide range of responsive margin and padding utility classes. They work for all breakpoints: <span style="color:red;">xs</span> (<= 576px), <span style="color:red;">sm</span> (>=576px), <span style="color:red;">md</span> (>= 768px), <span style="color:red;">lg</span> (>= 992px), <span style="color:red;">xl</span> (>= 1200px) or <span style="color:red;">xxl</span> (>= 1400px).

​	The classes are used in the format: <span style="color:red;">{property}{sides}-{size}</span> for <span style="color:red;">xs</span> and <span style="color:red;">{property}{sides}-{breakpoint}-{size}</span> for <span style="color:red;">sm</span>, <span style="color:red;">md</span>, <span style="color:red;">lg</span>, <span style="color:red;">xl</span> and <span style="color:red;">xxl</span>.

​	Where <i>property</i> is one of:

* <span style="color:red;">m</span> - sets margin
* <span style="color:red;">p</span> - sets padding

​	And <i>sides</i> is one of:

* <span style="color:red;">t</span> - sets margin-top or padding-top
* <span style="color:red;">b</span> - sets margin-bottom or padding-bottom
* <span style="color:red;">s</span> - sets margin-left or padding-left
* <span style="color:red;">e</span> - sets margin-right or padding-right
* <span style="color:red;">x</span> - sets both left and right
* <span style="color:red;">y</span> - sets both top and bottom
* blank - sets a margin or padding on all 4 sides of the element

​	And <i> size</i> is one of:

* <span style="color:red;">0</span> - sets margin or padding to 0
* <span style="color:red;">1</span> - sets margin or padding to .25rem
* <span style="color:red;">2 </span>- sets margin or padding to .5rem
* <span style="color:red;">3</span> - sets margin or padding to .1rem
* <span style="color:red;">4</span> - sets margin or padding to 1.5rem
* <span style="color:red;">5</span> - sets margin or padding to 3rem
* <span style="color:red;">auto</span> - sets margin to auto

```
<div class="container mt-3">
  <h1>Spacing Utilities</h1>
  <p>Set the spacing of an element with the {property}{sides}-{breakpoint}-{size} classes. Omit breakpoint if you want the padding or margin to work on all screen sizes.</p>
  <div class="pt-4 bg-warning">I only have a top padding (1.5rem)</div>
  <div class="p-5 bg-success">I have a padding on all sides (3rem)</div>
  <div class="m-5 pb-5 bg-info">I have a margin on all sides (3rem) and a bottom padding (3rem)</div>
</div>
```

## 30.11 Shadows

​	Use the <span style="color:red;">shadow-</span> classes to add shadows to an element:

```
<div class="container mt-3">
  <h1>Shadows</h1>
  <p>Use the shadow- classes to to add shadows to an element:</p>
  <div class="shadow-none p-4 mb-4 bg-light">No shadow</div>
  <div class="shadow-sm p-4 mb-4 bg-white">Small shadow</div>
  <div class="shadow p-4 mb-4 bg-white">Default shadow</div>
  <div class="shadow-lg p-4 mb-4 bg-white">Large shadow</div>
</div>
```

## 30.12 Vertical Align

​	Use the <span style="color:red;">align-</span> classes to change the alignment of elements (only works on inline, inline-block, inline-table and table cell elements):

```
<div class="container mt-3">
  <h1>Vertical Align</h1>
  <p>Change the alignment of elements with the align classes (only works on inline, inline-block, inline-table and table cell elements):</p>
  <span class="align-baseline">baseline</span>
  <span class="align-top">top</span>
  <span class="align-middle">middle</span>
  <span class="align-bottom">bottom</span>
  <span class="align-text-top">text-top</span>
  <span class="align-text-bottom">text-bottom</span>
</div>
```

## 30.13 Aspect Ratio

​	Create responsive video or slideshows based on the width of the parent.

​	Add the <span style="color:red;">.ratio</span> class together with an aspect ratio of your choice <span style="color:red;">.ratio-\*</span> to a parent element, and add the embed (video or iframe) inside of it:

```
<div class="container mt-3">
  <h2>Aspect Ratio</h2>
  <p>Create a responsive video and scale it nicely to the parent element.</p>
  
  <h2>Aspect ratio 1:1</h2>
  <div class="ratio ratio-1x1">
    <iframe src="https://www.youtube.com/embed/tgbNymZ7vqY"></iframe>
  </div>
  <br>
  
  <h2>Aspect ratio 4:3</h2>
  <div class="ratio ratio-4x3">
    <iframe src="https://www.youtube.com/embed/tgbNymZ7vqY"></iframe>
  </div> 
  <br>
  
  <h2>Aspect ratio 16:9</h2>
  <div class="ratio ratio-16x9">
    <iframe src="https://www.youtube.com/embed/tgbNymZ7vqY"></iframe>
  </div>
  <br>
    
  <h2>Aspect ratio 21:9</h2>
  <div class="ratio ratio-21x9">
    <iframe src="https://www.youtube.com/embed/tgbNymZ7vqY"></iframe>
  </div>
</div>
```

## 30.14 Visibility

​	Use the <span style="color:red;">.visible</span> or <span style="color:red;">.invisible</span> classes to control the visibility of elements. <b>Note:</b> These classes do not change the CSS display value. They only add <span style="color:red;">visibility:visible</span> or <span style="color:red;">visibility:hidden</span>:

```
<div class="visible">Visible</div>
<div class="invisible">Invisible</div>
```

## 30.15 Close icon

​	Use the <span style="color:red;">.btn-close</span> class to style a close icon. This is often used for alerts and modals:
```
<button type="button" class="btn-close"></button>
```

## 30.16 Screenreaders

​	Use the <span style="color:red;">.visually-hidden</span> class to hide an element on all devices, except screen readers:

```
<span class="visually-hidden">I will be hidden on all screens except for screen readers.</span>
```

## 30.17 Colors

​	As described in the Colors chapter, here is a list of all text and background color classes:

​	The classes for text colors are: .text-muted, .text-primary, .text-success, .text-info, .text-warning, .text-danger, .text-secondary, .text-white, .text-dark, .text-body (default body color / often black) and .text-light.

​	Contextual text classes can be also used on links:

```
<div class="container mt-3">
  <h2>Contextual Link Colors</h2>
  <a href="#" class="text-muted">Muted link.</a>
  <a href="#" class="text-primary">Primary link.</a>
  <a href="#" class="text-success">Success link.</a>
  <a href="#" class="text-info">Info link.</a>
  <a href="#" class="text-warning">Warning link.</a>
  <a href="#" class="text-danger">Danger link.</a>
  <a href="#" class="text-secondary">Secondary link.</a>
  <a href="#" class="text-dark">Dark grey link.</a>
  <a href="#" class="text-body">Body/black link.</a>
  <a href="#" class="text-light">Light grey link.</a>
</div>
```

​	You can also add 50% opacity for black or white text with the <span style="color:red;">.text-black-50</span> or <span style="color:red;">.text-white-50</span> classes:

```
  <p class="text-black-50">Black text with 50% opacity on white background</p>
  <p class="text-white-50 bg-dark">White text with 50% opacity on black background</p>
```

## 30.18 Background Colors

​	The classes of background colors are: .bg-primary, .bg-success, .bg-info, .bg-warning, .bg-danger, .bg-secondary, .bg-dark and .bg-light.

​	The <span style="color:red;">.bg-<i>color</i></span> classes above does not work well with text, or atleast then you have to specify a proper <span style="color:red;">.text-<i>color</i></span> class to get the right text color for each background.

​	However, you can use the <span style="color:red;">.text-bg-<i>color</i></span> classes and Bootstrap will automatically handle the appropriate text color for each background color:

```
<div class="container mt-3">
  <h2>Background Color with Contrasting Text Color</h2>
  <p class="text-bg-primary">This text is important.</p>
  <p class="text-bg-success">This text indicates success.</p>
  <p class="text-bg-info">This text represents some information.</p>
  <p class="text-bg-warning">This text represents a warning.</p>
  <p class="text-bg-danger">This text represents danger.</p>
  <p class="text-bg-secondary">Secondary background color.</p>
  <p class="text-bg-dark">Dark grey background color.</p>
  <p class="text-bg-light">Light grey background color.</p>
</div>
```



# 31. Bootstrap 5 Flex

## 31.1 Flexbox

​	The biggest difference between Bootstrap 3 and Bootstrap 4 & 5 is that Bootstrap 5 now uses flexbox, instead of floats, to handle the layout.

​	The Flexible Box Layout Module, makes it easier to design flexible responsive layout structure without using float or positioning. If you are new to flex, you can read about it in [CSS Flexbox Tutorial](https://www.w3schools.com/css/css3_flexbox.asp).

<b>Note:</b> Flexbox is not supported in IE9 and eariler versions.

<b>If you require IE8-9 support, use Bootstrap 3</b>. It is the most stable version of Bootstrap, and it is still supported by the team for critical bugfixes and documentation changes. However, no new features will be added to it.

​	To create a flexbox container and to transform directo children into flex items, use the <span style="color:red;">d-flex</span> class:

```
<div class="d-flex p-2 bg-secondary text-white">
	<div class="p-3 bg-info">Flex item 1</div>
	<div class="p-3 bg-warning">Flex item 2</div>
	<div class="p-3 bg-primary">Flex item 3</div>
</div>
```

​	To create an inline flexbox container, use the <span style="color:red;">d-inline-flex</span> class.

## 31.2 Horizontal Direction

​	Use <span style="color:red;">.flex-row</span> to display the flex items horizontally (side by side). This is by default.

​	<b>Tip:</b> Use <span style="color:red;">.flex-row-reverse</span> to right-align the horizontal direction (and reverse).

```
<div class="d-flex flex-row bg-secondary text-white">
	<div class="p-3 bg-info">Flex item 1</div>
	<div class="p-3 bg-warning">Flex item 2</div>
	<div class="p-3 bg-primary">Flex item 3</div>
</div>
```

## 31.3 Vertical Direction

​	Use <span style="color:red;">.felx-column</span> to display the flex items vertically (on top of  each other), or <span style="color:red;">.flex-column-reverse</span> to reverse the vertical direction.

## 31.4 Justify Content

​	Use the <span style="color:red;">.justify-content-\*</span> classes to change the alignment of flex items. Valid classes are <span style="color:red;">start</span> (default), <span style="color:red;">end</span>, <span style="color:red;">center</span>, <span style="color:red;">between</span>, and <span style="color:red;">around</span>.

```
<div class="d-flex flex-row justify-content-between">
	<div class="p-3 bg-info">Flex item 1</div>
	<div class="p-3 bg-warning">Flex item 2</div>
	<div class="p-3 bg-primary">Flex item 3</div>
</div>
```

## 31.5 Fill / Equal Widths

​	Use <span style="color:red;">.flex-fill</span> on the flex items to force them into equal widths:

```
<div class="d-flex">
	<div class="p-2 bg-info flex-fill">Flex item 1</div>
	<div class="p-2 bg-primary flex-fill">Flex item 2</div>
</div>
```

## 31.6 Grow

​	Use <span style="color:red;">.flex-grow-1</span> on a flex item to take up the rest of the space. In the example below, the first two flex items take up their necessary space, while the last item takes up the rest of the available space:

```
<div class="d-flex">
  <div class="p-2 bg-info">Flex item 1</div>
  <div class="p-2 bg-warning">Flex item 2</div>
  <div class="p-2 bg-primary flex-grow-1">Flex item 3</div>
</div>
```

<b>Tip:</b> Use <span style="color:red;">.flex-shrink-1</span> on a flex item to make it shrink if necessary.

## 31.7 Order

​	Change the visual order of a specific flex item(s) with the <span style="color:red;">.order</span> classes. Valid classes are from 0 to 5, where the lowest number has highest priority (order-1 shown before order-2, etc..):

```
<div class="d-flex bg-secondary">
  <div class="p-2 bg-info order-3">Flex item 1</div>
  <div class="p-2 bg-warning order-2">Flex item 2</div>
  <div class="p-2 bg-primary order-1">Flex item 3</div>
</div>
```

## 31.8 Auto Margins

​	Easily add auto margins to flex items with <span style="color:red;">.ms-auto</span> (push items to the right), or by using <span style="color:red;">.me-auto</span> (push items to the left):

```
<div class="d-flex bg-secondary">
  <div class="p-2 ms-auto bg-info">Flex item 1</div>
  <div class="p-2 bg-warning">Flex item 2</div>
  <div class="p-2 bg-primary">Flex item 3</div>
</div>

<div class="d-flex bg-secondary">
  <div class="p-2 bg-info">Flex item 1</div>
  <div class="p-2 bg-warning">Flex item 2</div>
  <div class="p-2 me-auto bg-primary">Flex item 3</div>
</div>
```

## 31.9 Wrap

​	Control how flex items wrap in a flex container with <span style="color:red;">.flex-nowrap</span> (default), <span style="color:red;">.flex-wrap</span> or <span style="color:red;">.flex-wrap-reverse</span>.

```
 <div class="d-flex flex-wrap-reverse bg-light">
    <div class="p-2 border">Flex item 1</div>
    <div class="p-2 border">Flex item 2</div>
    <div class="p-2 border">Flex item 3</div>
    <div class="p-2 border">Flex item 4</div>
    <div class="p-2 border">Flex item 5</div>
    <div class="p-2 border">Flex item 6</div>
    <div class="p-2 border">Flex item 7</div>
    <div class="p-2 border">Flex item 8</div>
    <div class="p-2 border">Flex item 9</div>
    <div class="p-2 border">Flex item 10</div>
    <div class="p-2 border">Flex item 11</div>
    <div class="p-2 border">Flex item 12</div>
    <div class="p-2 border">Flex item 13 </div>
    <div class="p-2 border">Flex item 14</div>
    <div class="p-2 border">Flex item 15</div>
    <div class="p-2 border">Flex item 16</div>
    <div class="p-2 border">Flex item 17</div>
    <div class="p-2 border">Flex item 18</div>
    <div class="p-2 border">Flex item 19</div>
    <div class="p-2 border">Flex item 20</div>
    <div class="p-2 border">Flex item 21</div>
    <div class="p-2 border">Flex item 22</div>
    <div class="p-2 border">Flex item 23</div>
    <div class="p-2 border">Flex item 24</div>
    <div class="p-2 border">Flex item 25</div>
  </div>
```

## 31.10 Align Content

​	Control the vertical alignment of <b>gathered</b> flex items with the <span style="color:red;">.align-content-</span> classes. Valid classes are <span style="color:red;">.align-content-start</span> (default), <span style="color:red;">.align-content-end</span>, <span style="color:red;">.align-content-center</span>, <span style="color:red;">.align-content-between</span>, <span style="color:red;">.align-content-around</span> and <span style="color:red;">.align-content-stretch</span>.

<b>Note:</b> These classes have no effect on single rows of flex items.

```
  <div class="d-flex flex-wrap align-content-stretch bg-light" style="height:300px">
    <div class="p-2 border">Flex item 1</div>
    <div class="p-2 border">Flex item 2</div>
    <div class="p-2 border">Flex item 3</div>
    <div class="p-2 border">Flex item 4</div>
    <div class="p-2 border">Flex item 5</div>
    <div class="p-2 border">Flex item 6</div>
    <div class="p-2 border">Flex item 7</div>
    <div class="p-2 border">Flex item 8</div>
    <div class="p-2 border">Flex item 9</div>
    <div class="p-2 border">Flex item 10</div>
    <div class="p-2 border">Flex item 11</div>
    <div class="p-2 border">Flex item 12</div>
    <div class="p-2 border">Flex item 13 </div>
    <div class="p-2 border">Flex item 14</div>
    <div class="p-2 border">Flex item 15</div>
    <div class="p-2 border">Flex item 16</div>
    <div class="p-2 border">Flex item 17</div>
    <div class="p-2 border">Flex item 18</div>
    <div class="p-2 border">Flex item 19</div>
    <div class="p-2 border">Flex item 20</div>
    <div class="p-2 border">Flex item 21</div>
    <div class="p-2 border">Flex item 22</div>
    <div class="p-2 border">Flex item 23</div>
    <div class="p-2 border">Flex item 24</div>
    <div class="p-2 border">Flex item 25</div>
  </div>
```

  ## 31.11 Align Items

​	Control the vertical alignment of <b>single rows</b> of flex items withe the <span style="color:red;">.align-items-\*</span> classes. Valid classes are <span style="color:red;">.align-items-start</span>, <span style="color:red;">.align-items-end</span>, <span style="color:red;">.align-items-center</span>, <span style="color:red;">.align-items-baseline</span>, <span style="color:red;">.align-items-stretch</span> (default).

```
<div class="d-flex align-items-start">..</div>

<div class="d-flex align-items-end">..</div>

<div class="d-flex align-items-center">..</div>

<div class="d-flex align-items-baseline">..</div>

<div class="d-flex align-items-stretch">..</div>
```

## 31.12 Align Self

​	Control the vertical alignment of <b>a specified flex item</b> with the <span style="color:red;">.align-self-\*</span> classes. Valid classes are <span style="color:red;">.align-self-start</span>, <span style="color:red;">.align-self-end</span>, <span style="color:red;">.align-self-center</span>, <span style="color:red;">.align-self-baseline</span>, and <span style="color:red;">.align-self-stretch</span> (default).

```
<div class="d-flex bg-light" style="height:150px">
  <div class="p-2 border">Flex item 1</div>
  <div class="p-2 border align-self-start">Flex item 2</div>
  <div class="p-2 border">Flex item 3</div>
</div>
```

## 31.13 Responsive Flex Classes

​	All flex classes comes withe additional responsive classes, which makes it easy to set a specific flex class on a specific screen size.

​	The <span style="color:red;">\*</span> symbol can be replaced with sm, md, lg, xl or xxl, which represents small, medium, large, xlarge and xxlarge screens.



# 32. Bootstrap 5 Forms

## 32.1 Stacked Form

​	All textual \<input> and \<textarea> elements with class <span style="color:red;">.form-control</span> get proper form styling:

```
<div class="continer mt-3">
	<h2>Stacked form</h2>
	<form action="action_page.php">	<!-- No this file -->
		<div class="mb-3 mt-3">
			<label for="email">Email:</label>
			<input type="email" class="form-control" id="email"
				placeholder="Enter email" name="email">
		</div>
		<div class="mb-3">
			<label for="pwd">Password:</label>
			<input type="password" class="form-control" id="pwd"
				placeholder="Enter password" name="pswd">
		</div>
		<div class="form-check mb-3">
			<lable class="form-check-label">
				<input class="form-check-input" type="checkbox"
					name="remeber">
				Remember me
			</label>
		</div>
		<button type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>
```

<b>Note:</b> Notice that we add a <span style="color:red;">.form-label</span> class to each label element to ensure correct padding.

​	Checkboxs have different makrup. They are wrapped around a container element with <span style="color:red;">.form-check</span>, and labels have a class of <span style="color:red;">.form-check-label</span>, while checkboxes and radio buttons use <span style="color:red;">.form-check-input</span>.

## 32.2 Textarea

```
  <form action="/action_page.php">
    <div class="mb-3 mt-3">
      <label for="comment">Comments:</label>
      <textarea class="form-control" rows="5" id="comment" name="text"></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
```

## 32.2 Form Row/Grid (Inline Forms)

​	If you want your form elements to appear side by side, use <span style="color:red;">.row</span> and <span style="color:red;">.col</span>:

```
<div class="container mt-3">
	<h2>Inline Forms</h2>
	<p>If you want your elements to appear side by side, use .row and .col:</p>
	<form>
		<div class="row">
			<div class="col">
				<input type="text" class="form-control" placeholder="Enter email"
					name="email">
			</div>
			<div class="col">
				<input type="password" class="form-control" placeholder="Enter password"
					name="password">
			</div>
		</div>
	</form>
</div>
```

<b>Note:</b> Learn more about columns and row in the Grids chapter.

## 32.3 Form Control Size

​	You can change the size of <span style="color:red;">.form-control</span> inputs with <span style="color:red;">.form-control-lg</span> or <span style="color:red;">.form-control-sm</span>:

```
<input type="text" class="form-control form-control-lg" placeholder="Large input">
<input type="text" class="form-control" placeholder="Normal input">
<input type="text" class="form-control form-control-sm" placeholder="Small input">
```

## 32.4 Disabled and Readonly

​	Use the disabled and/or readonly attributes to disable the input field:

```
<input type="text" class="form-control" placeholder="Normal input">
<input type="text" class="form-control" placeholder="Disabled input" disabled>
<input type="text" class="form-control" placeholder="Readonly input" readonly>
```

## 32.5 Plain text Inputs

​	Use the <span style="color:red;">.form-control-plaintext</span> class to style an input field without borders, but keep proper margins and padding:

```
<form>
	<input type="text" class="form-control-plaintext" placeholder="Plaintext input">
		<input type="text" class="form-control mt-3" placeholder="Normal input">
</form>
```

## 32.6 Color Picker

​	To style and input with type="color" properly, use the <span style="color:red;">.form-contrl-color</span> class:

```
<input type="color" class="form-control form-control-color" value="#CCCCCC">
```



## 33. Bootstrap 5 Select

## 33.1 Select Menu

​	To style a select menu in Bootstrap 5, add the <span style="color:red;">.form-select</span> class to the \<select> element:

```
<div class="container mt-3">
	<h2>Select Menu</h2>
	<p>To style a select menu in Bootstrap 5, add the form-select class to the select element.</p>
	<form action="#">
		<label for="sel1" class="from-label">Select list (one):</label>
		<select class="form-select" id="sel1" name="sellist1">
			<option>1</option>
			<option>2</option>
			<option>3</option>
			<option>4</option>
		</select>
		<label for="sel2" class="form-label">Multiple select list (hold shift to select more than one):</label>
		<select multiple class="form-select" id="sel2" name="sellist2">
			<option>1</option>
			<option>2</option>
			<option>3</option>
			<option>4</option>
			<option>5</option>
			<option>6</option>
		</select>
		<button type="submit" class="btn btn-primary" mt-3">Submit</button>
	</form>
</div>
```

## 33.2 Select Menu Size

​	Use the <span style="color:red;">.form-select-lg</span> or <span style="color:red;">.form-select-sm</span> class to change the size of the select menu:

```
<select class="form-select form-select-lg">
<select class="form-select">
<select class="form-select form-select-sm">
```

## 33.3 Disabled Select Menu

​	Use the <span style="color:red;">disabled</span> attribute to disable the select menu:

```
<select class="form-select" disabled>
  <option>1</option>
  <option>2</option>
  <option>3</option>
  <option>4</option>
</select>
```

## 33.4 Data List

​	Bootstrap will also style data lists, which is a list of pre-defined options for an \<input> element:

```
<label for="browser" class="form-label">Choose your browser from the list:</label>
<input class="form-control" list="browsers" name="browser" id="browser">
<datalist id="browsers">
  <option value="Edge">
  <option value="Firefox">
  <option value="Chrome">
  <option value="Opera">
  <option value="Safari">
</datalist>
```



# 34. Bootstrap 5 Checkboxes and Radio buttons

## 34.1 Checkboxes

​	Checkboxes are used if you want the user to select any number of options from a list of present options.

```
<div class="container mt-3">
	<h2>Checkboxes</h2>
	<p>To style a checkbox, use a container element with a .form-check class,
		and add .form-check-label to labels, .form-check-input to the input
		with type="checkbox"</p>
	<form action="#">
			<div class="form-check">
				<input type="checkbox" class="form-check-input" id="check1"
				name="option1" value="something" checked>
				<label class="form-check-label" for="check1">Option 1</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" id="check2"
				name="option2" value="something">
				<label class="form-check-label" for="check2">Option 2</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" id="check3"
				name="option3" value="something">
				<label class="form-check-label" for="check3">Option 3</label>
			</div>
			<button type="submit" class="btn btn-primary mt-3">
				Submit</button>
	</form>
</div>
```

<span style="font-size:20px;">Example Explained</span>

​	To style checkboxes, use a wrapper element with <span style="color:red;">class="form-check"</span> to ensure proper margins for labels and checkboxes.

​	Then, add the <span style="color:red;">.form-check-label</span> class to label elements, and <span style="color:red;">.form-check-input</span> class to style checkboxes properly inside the <span style="color:red;">.form-check</span> container. Use the <span style="color:red;">checked</span> attribute to checked a select by default.

## 34.2 Radio buttons

​	Radio buttons are used if you want to limit the user to just one selection from a list of present options:

```
<div class="container mt-3">
	<h2>Radio buttons</h2>
	<form action="#">
			<div class="form-check">
				<input type="radio" class="form-check-input" id="radio1"
				name="optradio" value="option1" checked>
				<label class="form-check-label" for="radio1">Option 1</label>
			</div>
			<div class="form-check">
				<input type="radio" class="form-check-input" id="radio2"
				name="optradio" value="something">
				<label class="form-check-label" for="radio2">Option 2</label>
			</div>
			<div class="form-check">
				<input type="radio" class="form-check-input" id="radio3"
				name="optradio" value="something">
				<label class="form-check-label" for="radio3">Option 3</label>
			</div>
			<button type="submit" class="btn btn-primary mt-3">
				Submit</button>
	</form>
</div>
```

<b>NOTE:</b> <span style="color:blue;">To make radio buttons work, their name should be the same </span>.

## 34.3 Toggle Switches

​	If you want your checkbox to be styled as a toggle switch, use the <span style="color:red;">.form-switch</span> class together with the <span style="color:red;">.form-check</span> container:

```
<div class="container mt-3">
	<h2>Toggle Switch</h2>
	<form action="#">
			<div class="form-check form-switch">
				<input type="checkbox" class="form-check-input" id="mySwitch"
				name="darkmode" value="yese" checked>
				<label class="form-check-label" for="mySwitch">Dark mode</label>
			</div>
			<button type="submit" class="btn btn-primary mt-3">
				Submit</button>
	</form>
</div>
```



# 35. Bootstrap 5 Range

## 35.1 Custom Range

​	To style a range menu, add the <span style="color:red;">.form-range</span> class to the input element with type="range":

```
<div class="container mt-3">
	<h2>Custom Range</h2>
	<p>To create a custom range, add the .from-range class to the input element
		with the type="range":</p>
	<form action="#">
		<label for="customRange" class="form-label">Custon Range</label>
		<input type="range" class="form-range" id="customRange" name="points">
		<button type="submit" class="btn btn-primary" mt-3">Submit</button>
	</form>
</div>
```

## 35.2 Steps

​	By default, the interval between the range number is 1. You can change it by using the <span style="color:red;">step</span> attribute:

```
<input type="range" class="form-range" setp="3">
```

## 35.3 Min and Max

​	Be default, the minimum value is o and maximum value is 100. You can use the <span style="color:red;">min</span> and/or <span style="color:red;">max</span> attribute change it:

```
<input type="range" class="form-range" min="0" max="4">
```



# 36. Bootstrap 5 Input Groups

## 36.1 Input Groups

​	The <span style="color:red;">.input-group</span> class is a container to enhance an input by adding an icon, text or a button in front or behind the input field as a "help text".

​	To style the specified help text, use the <span style="color:red;">.input-group-text</span> class:

```
<div class="container mt-3">
	<h2>Input Group</h2>
	<p>The .input-group class is a container to enhance an input by adding an
	icon, text, or a button in front or behind the input field,</p>
	<form action="#">
		<div class="input-group mb-3">
			<span class="input-group-text">@</span>
			<input type="text" class="form-control" 
			placerholder="Username" name="username">
		</div>
		<div class="input-group mb-3">
			<input type="text" class="form-control" 
			placeholder="Your Email" name="email">
			<span class="input-group-text">
			@example.com</span>
		</div>
	</form>
</div>
```

## 36.2 Input Group Size

​	Use the <span style="color:red;">.input-group-sm</span> class for small input groups and <span style="color:red;">.input-group-lg</span> for large inputs groups.

```
<div class="input-group mb-3 input-group-sm">
   <span class="input-group-text">Small</span>
  <input type="text" class="form-control">
</div>

<div class="input-group mb-3">
  <span class="input-group-text">Default</span>
  <input type="text" class="form-control">
</div>

<div class="input-group mb-3 input-group-lg">
  <span class="input-group-text">Large</span>
  <input type="text" class="form-control">
</div>
```

## 36.3 Multiple Inputs and Helpers

```
<!-- Multiple inputs -->
<div class="input-group mb-3">
  <span class="input-group-text">Person</span>
  <input type="text" class="form-control" placeholder="First Name">
  <input type="text" class="form-control" placeholder="Last Name">
</div>

<!-- Multiple addons / help text -->
<div class="input-group mb-3">
  <span class="input-group-text">One</span>
  <span class="input-group-text">Two</span>
  <span class="input-group-text">Three</span>
  <input type="text" class="form-control">
</div>
```

## 36.4 Input Group with Checkboxes and Radios

​	You can also use checkboxes or radio buttons instead of text  (without \<form>):

```
<div class="container mt-3">
	<h2>Input Group with Checkboxes and Radios</h2>
	<div class="input-group mb-3">
		<div class="input-group-text">
			<input type="checkbox">
		</div>
		<input type="text" class="form-control" 
			placerholder="Username" name="username">
	</div>
	<div class="input-group mb-3">
		<div class="input-group-text">
			<input type="radio">
		</div>
		<input type="text" class="form-control" 
		placeholder="Your Email" name="email">
	</div>
</div>
```

## 36.5 Input Group Buttons

```
<div class="container mt-3">
  <h3>Input Group Buttons</h3>
  
  <div class="input-group mb-3 mt-3">
    <button class="btn btn-outline-primary" type="button">Basic Button</button>
    <input type="text" class="form-control" placeholder="Some text">
  </div>

  <div class="input-group mb-3">
    <input type="text" class="form-control" placeholder="Search">
    <button class="btn btn-success" type="submit">Go</button> 
  </div>

  <div class="input-group mb-3">
    <input type="text" class="form-control" placeholder="Something clever..">
    <button class="btn btn-primary" type="button">OK</button> 
    <button class="btn btn-danger" type="button">Cancel</button> 
  </div>
</div>
```

## 36.6 Input Group with Dropdown Button

​	Add a dropdown button in the input group. Note that you don't need the .dropdown wrapper, as youu normally would.

```
<div class="container mt-3">
	<h3>Input Groups with Dropdown Button</h3>
	<div class="input-group mt-3 mb-3">
		<button type="button" class="btn btn-primary dropdown-toggle"
			data-bs-toggle="dropdown">
			Dropdown button
		</button>
		<ul class="dropdown-menu">
			<li><a class="dropdown-item" href="#">Link 1</li>
			<li><a class="dropdown-item" href="#">Link 2</li>
			<li><a class="dropdown-item" href="#">Link 3</li>
		</ul>
		<input type="text" class="form-control" placeholder="Username">
	</div>
</div>
```



# 37. Bootstrap 5 Form Floating Labels

## 37.1 Floating Labels/Animated Labels

​	By default, when using labels, they normally appear on top of the input field.

​	With floating labels, you can insert the label inside the input field, and make them float/animate when you click on the input field:

```
<div class="container mt-3">
	<h3>Floating Lables - Inputs</h3>
	<p>Click inside the input field to see the floating label effect:</p>
	<form action="#">
		<div class="form-floating mb-3 mt-3">
			<input type="text" class="form-control" id="floatEmail"
			placeholder="Enter email" name="floatEmial">
			<label for="floatEmail">Email</label>
		</div>
		<div class="form-floating mb-3 mt-3">
			<input type="text" class="form-control" id="floatPwd"
			placeholder="Enter password" name="pswd">
			<label for="floatPwd">Password</label>
		</div>
		<button type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>
```

<b>Note:</b> <span style="color:blue;">Here, if second input's name "pswd" is same to another, when click the input field, a `submit` seems to be triggered</span>.

<b>Notes on floating labels:</b> The \<label> elements must come after the \<input> element, and the 

<span style="color:red;">placeholder</span> attribute is required for each \<input> element (even though it is not shown).

## 37.2 Textarea

```
<div class="container mt-3">
  <h2>Floating Labels - Textarea</h2>
  <p>Click inside the textarea to see the floating label effect:</p>
  <form action="/action_page.php">
    <div class="form-floating mb-3 mt-3">
      <textarea class="form-control" id="floatComment" name="floatText" placeholder="Comment goes here"></textarea>
      <label for="floatComment">Comments</label>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>
```

## 37.3 Select Menus

​	You can also use "floating-labels" on select menus. However, they will not float/get animated. The label will always appear in the top left corner, inside the select menu:

```
<div class="container mt-3">
  <h2>Floating Labels - Select</h2>
  <p>You can also use "floating-labels" on select menus. However, they will not float/get animated. The label will always appear in the top left corner, inside the select menu:</p>
  <form action="/action_page.php">
    <div class="form-floating mb-3 mt-3">
      <select class="form-select" id="sel1" name="sellist">
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
      </select>
      <label for="sel1" class="form-label">Select list (select one):</label>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>
```



# 38. Bootstrap 5 Form Validation

## 38.1 Form Validation

​	You can use different validation classes to provide valuable feedback to users. Add either <span style="color:red;">.was-validated</span> or <span style="color:red;">.needs-validations</span> to the <span style="color:red;">\<form></span> element, depending on whether you want to provide validation feedback before or after submitting the form. The input fields will have a green (valid) or red (invalid) border to indicate what's missing in the form. You can also add a <span style="color:red;">.valid-feedback</span> or <span style="color:red;">.invalid-feedback</span> message to tell the user explicitly what's missing, or needs to be done before submitting the form.

```
<div class="container mt-3">
	<h3>Form Validation</h3>
	<p>Try to submit the form.</p>
	<form action="#" class="was-validated">
		<div class="mb-3 mt-3">
			<label type="unmae" class="form-label">Username:</label>
			<input type="text" class="form-control" id="uname" 
			placeholder="Enter username" name="uname" required>
			<div class="valid-feedback">Valid.</div>
			<div class="invalid-feedback">Please fill out this field</div>
		</div>
		<div class="mb-3">
			<label type="for validPwd" class="form-label">Password:</label>
			<input type="password" class="form-control" id="validPwd"
			placeholder="Enter password" name="validPwd" required>
			<div class="valid-feedback">Valid...</div>
			<div class="invalid-feedback">Please fill out this field...</div> 
		</div>
		<div class="form-check mb-3">
			<input class="form-check-input" type="checkbox"
			id="validCheck" name="validRemember" required>
			<label class="form-check-label" for="validCheck">I agree.</label>
			<div class="valid-feedback">Valid.</div>
			<div class="invalid-feedback">Check to continue.</div>
		</div>
		<button type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>
```



# 39. Bootstrap 5 Grid System

## 39.1 The Grid System

​	Bootstrap's grid system is built with flexbox and allows up to 12 columns across the page.

​	If you do not want to use all 12 columns individually, you can group the columns together to create wider columns. The grid system is responsive, and the columns will re-arrange automatically depending on the screen size.

​	Make sure that the sum adds up to 12 or fewer (it is not required that you use all 12 available columns).

## 39.2 Grid Classes

​	The Bootstrap 5 grid system has six classes, refer chapter 4.



# 40. Bootstrap 5 Grid Stacked to horizontal

## 40.1 Grid Example: Stacked-to-horizontal

​	Let's create a basic grid system that starts out stacked on extra small devices, before becoming horizontal on larger devices.

​	The following example shows a simple "stacked-to-horizontal" two-column layout, meaning it will result in a 50%/50% split on all screens, except for extra small screens, which it will automatically stack (100%):

```
<div class="container-fluid mt-3">
	<h1>Grid Example</h1>
	<p>This example demonstrates a 50%/50% split on small, medium, 
	large, xlarge and xxlarge devices. 
	On extra small devices, it will stack (100% width).</p>
	<div class="row">
		<div class="col-sm-6 bg-primary text-white p-3">
			Some texts here ...
		</div>
		<div class="col-sm-6 bg-dark text-white p-3">
			Some other texts here ...
		</div>
	</div>
</div>
```

<b>Tip</b>: The numbers in the <span style="color:red;">.col-sm-\*</span> classes indicates how many columns the div should span (out of 12). SO, <span style="color:red;">.col-sm-1</span> spans 1 column, <span style="color:red;">.col-sm-4</span> spans 4 columns.

<b>Note:</b> Make sure that the sum adds up to 12 or fewer (it is not required that you use all 12 available columns).

<b>Tip</b>: You can turn any <b>full-width</b> layout into a <b>fixed-width responsive</b> layout, by changing the <span style="color:red;">.container-fluid</span> class to <span style="color:red;">.container</span>.

## 40.2 Auto Layout Columns

​	In Bootstrap 5, there is an easy way to create equal width columns for all devices: just remove the number from <span style="color:red;">.col-size-\*</span> and only use the <span style="color:red;">.col-size</span> class on a specified number of <b>col elements</b>. Bootstrap will recognize how many columns there are, and each column will get the same width. The size classes (sm, md, etc.) determines <b>when</b> the columns should be responsive:

```
<!-- Two columns: 50% width on all screens, except for extra small (100% width) -->
<div class="row">
  <div class="col-sm">1 of 2</div>
  <div class="col-sm">2 of 2</div>
</div>

<!-- Four columns: 25% width on all screens, except for extra small (100% width)-->
<div class="row">
  <div class="col-sm">1 of 4</div>
  <div class="col-sm">2 of 4</div>
  <div class="col-sm">3 of 4</div>
  <div class="col-sm">4 of 4</div>
</div>
```



## 41. Bootstrap 5 Grid Extra Small

## 41.1 Extra Small Grid Example

​	Assume we have a simple layout with two columns. We want the columns to split 15%/75% for <b>ALL</b> devices.

​	We will add the following classes to our two columns:

```
<div class="col-3">...</div>
<div class="col-9">...</div>
```

​	Below are some example for other percentages:

```
<!-- 33.3%/66.6% split -->
<div class="container-fluid">
  <div class="row">
    <div class="col-4 bg-primary">
      <p>Lorem ipsum...</p>
    </div>
    <div class="col-8 bg-dark">
      <p>Sed ut perspiciatis...</p>
    </div>
  </div>
</div>

<!-- 50%/50% split -->
<div class="container-fluid">
  <div class="row">
    <div class="col-6 bg-primary">
      <p>Lorem ipsum...</p>
    </div>
    <div class="col-6 bg-dark">
      <p>Sed ut perspiciatis...</p>
    </div>
  </div>
</div>
```



# 42. Bootstrap 5 Grid Small

​	Small devices are defined as having a screen width from <b>576 pixels to 767 pixels</b>.

​	For small devices we will use the <span style="color:red;">.col-sm-\*</span> classes. Here are some examples:

```
<!-- 33.3/66.6% split: -->
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-4 bg-primary">
      <p>Lorem ipsum...</p>
    </div>
    <div class="col-sm-8 bg-dark">
      <p>Sed ut perspiciatis...</p>
    </div>
  </div>
</div>

<!-- 50%/50% split: -->
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-6 bg-primary">
      <p>Lorem ipsum...</p>
    </div>
    <div class="col-sm-6 bg-dark">
      <p>Sed ut perspiciatis...</p>
    </div>
  </div>
</div>
```

## 42.1 Auto Layout Columns

​	In Bootstrap 5, there is an easy way to create equal width columns for all devices: just remove the number form <span style="color:red;">.col-sm-\*</span> and only use the <span style="color:red;">.col-sm</span> class on a specified number of <b>col elements</b>. Bootstrap will recognize how many columns there are, and each column will get the same width.

```
<!-- Two columns: 50% width on all screens, except for extra small (100% width) -->
<div class="row">
  <div class="col-sm">1 of 2</div>
  <div class="col-sm">2 of 2</div>
</div>

<!-- Four columns: 25% width on all screens, except for extra small (100% width)-->
<div class="row">
  <div class="col-sm">1 of 4</div>
  <div class="col-sm">2 of 4</div>
  <div class="col-sm">3 of 4</div>
  <div class="col-sm">4 of 4</div>
</div>
```



# 43. Bootstrap 5 Grid Medium

​	The following example will result in 25%/75% split on small devices and a 50%/50% split on mddium (and large, xlarge and xxlarge) devices. On extra small devices, it will automatically stack (100%):

```
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-3 col-md-6">
      <p>Lorem ipsum...</p>
    </div>
    <div class="col-sm-9 col-md-6">
      <p>Sed ut perspiciatis...</p>
    </div>
  </div>
</div>
```

<b>Note:</b> At the small size, the bootstrap look at classes with <b>-sm-</b> in them and use those, at medium size, look at classes with <b>-md-</b> in them and use those.

## 43.1 Using Only Medium

​	In the example below, we only specify the <span style="color:red;">.col-md-6</span> class (without <span style="color:red;">.col-sm-\*</span>). This means that medium, large, extra large and XXL devices will split 50%/50% - because the class scales up. However, for small and extra small devices, it will stack vertically (100% width):

```
<div class="row">
  <div class="col-md-6">
    <p>Lorem ipsum...</p>
  </div>
  <div class="col-md-6">
    <p>Sed ut perspiciatis...</p>
  </div>
</div>
```

## 43.2 Auto Layout Columns

​	Just remove the number from <span style="color:red;">.col-md-\*</span> and only use the <span style="color:red;">.col-md</span> class on a specified number of <b>col elements</b>.





## 44. Bootstrap 5 Grid Large & XL & XXL

​	This three types are similar to above, and Bootstrap look up the size tag (e.g. <b>-sm-</b>) and determine the grid layout, once the screen size less than the the smallest appointed tag, columns        stack automatically.

## 44.1 No Gutters

​	To change the gutters (extra space) between columns, use any of the <span style="color:red;">.g-1|2|3|4|5</span> classes (<span style="color:red;">.g-4</span> is default). To remove the gutter completely, use <span style="color:red;">.g-0</span>. Here is a example:

```
<div class="container-fluid">
    <div class="row g-0">
      <div class="col-3 bg-success">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br>
        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
      </div>
      <div class="col-9 bg-warning">
        Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
      </div>
    </div>
```





Sat, Apr 22, 2023. 16:21. Library, floor 2, zone c, 392.

<span style="color:red;">