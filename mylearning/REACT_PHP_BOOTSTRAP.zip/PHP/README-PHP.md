# 1. PHP Tutorial

## 1.1 Learn PHP

​	PHP is a server scripting language, and a powerful tool for making dynamic and interactive Web pages. PHP is a widely-used, free, and effecient alternative to competitors such as Microsoft's ASP.

## 

# 2. PHP Introduction

​	PHP code is executed on the server.

## 2.1 What You Should Already Know

​	Before you continue you should have a basic understanding of the following:

* HTML
* CSS
* JavaScript

## 2.2 What is PHP?

* PHP is an acronym for "PHP: Hypertext Preprocessor"
* PHP is a widely-used, open source scripting language
* PHP scripts are executed on the server
* PHP is free to download and use

​	<b>PHP is an amazing and popular language!</b>

​	It is powerful enough to be at the core of the biggest blogging system on the web (WordPress)!

​	It is deep enough to run large social networks!

​	It is also easy enough to be a beginners's first server side language.

## 2.3 What is a PHP File?

* PHP files can contain text, HTML, CSS, JavaScript, and PHP code.
* PHP code is executed on the server, and the result is returned to the browser as plain HTML
* PHP files have extension "<span style="color:red;">.php</span>".

## 2.4 What Can PHP Do?

* PHP can generate dynamic page content
* PHP can create, open, read, write, delete, and close files on the server
* PHP can collect form data
* PHP can send and receive cookies
* PHP can add, delete, modify data in your databse
* PHP can be used to control user-access
* PHP can encrypt data

​	With PHP you are not limited to ouput HTML. You can output images or PDF files. You can also output any text, such as XTHML and XML.

## 2.5 Why PHP?

* PHP runs on various platforms (Windows, Linux, Unix, Mac OS X, etc).
* PHP is compatible with almost all servers used today (Apache, IIS, etc)
* PHP supports a wide range of databases
* PHP is free, Download it from the official PHP resource
* PHP is easy to learn and runs efficiently on the server side

## 2.6 What's new in PHP 7

* PHP 7 is much faster than the previous popular stable release (PHP 5.6)
* PHP 7 has improved Error Handling
* PHP 7 supports stricter Type Declarations for function arguments
* PHP 7 supports new operators (like the spaceship operator: <span style="color:red;"><=></span>)



# 3. PHP Installation

## 3.1 What Do I Need?

​	To start using PHP, you can:

* Find a web host with PHP and MySQL support
* Intall a web server on your own PC, and the install PHP and MySQL

## 3.2 Use a Web Host with PHP Support

​	If you server has activated support for PHP you do not need to do anything.

​	Just create some <span style="color:red;">.php</span> files, place them in your web directory, and the server will automatically parse them for you. You do not need to compile anything or install any extra tools. Because PHP is free, most web hosts offer PHP supports.

## 3.3 Set Up PHP on Your Own PC

​	However, if your server does not support PHP, you must:

* install a web server
* install PHP
* install a database, such as MySQL

## 3.4 PHP Online Compiler / Editor

​	Refer [w3schools](w3schools.com).

## 3.5 Configuration PHP with Nginx (my aliyun server)

​	In my online server, compile the PHP source code failed (out of memory). So I have to choose another way to use PHP. Luckily, I found that I can install PHP-FPM ("fastCGI process manager") to use PHP with nginx (principle refer other document):

1. install fpm tool

```
apt update
apt install php-fpm
```

2. Check status (pay attention to the socket address)

```
systemctl status php8.1-fpm
```

```
log file: s: 11330 ExecStartPost=/usr/lib/php/php-fpm-socket-helper install /run/php/php-fpm.sock /
```

3. configure nginx

​	Under /etc/nginx, grep "*php" ./ and found the config file: default. Modified it:

```
        location ~ \.php$ {
                include snippets/fastcgi-php.conf;

        #       # With php-fpm (or other unix sockets):
                fastcgi_pass unix:/run/php/php8.1-fpm.sock;
        #       # With php-cgi (or other tcp sockets):
        #       fastcgi_pass 127.0.0.1:9000;
        #       fastcgi_pass unix:q;
        }

```

​	<b>Note:</b> <span style="color:blue;">Maybe also need to add "index.php" behind "index.html", or the server back 404</span>.



# 4. PHP Syntax

​	A PHP script is executed on the server, and the plain HTML result is sent back to the browser.

## 4.1 Basic PHP Syntax

​	A PHP  script can be placed anywhere in the document.

​	A PHP script starts with <span style="color:red;">\<?php</span> and ends with <span style="color:red;">?></span>.

```php
<?php
//PHP code
?>
```

​	The default file extension for PHP files is "<span style="color:red;">.php</span>".

​	A PHP file normally contains HTML tags, and some PHP scripting code.

​	Below, we have an example of a simple PHP file (first.php), with a PHP script that uses a built-in PHP function "<span style="color:red;">echo</span>" to output the text "Hello" on a web page!

```
<!DOCTYPE html>
<html>
<body>
<h1>My first PHP page</h1>
<?php
echo "Hello";
?>
</body>
</html>
```

<b>Note:</b> PHP statements end with a semicolon (<span style="color:red;">;</span>)

## 4.2 PHP Case Sensitivity

​	In PHP, keywords (e.g. <span style="color:red;">if</span>, <span style="color:red;">elst</span>, <span style="color:red;">while</span>, <span style="color:red;">echo</span>, etc.), classes, functions, and user-defined functions are not case-sensitive.

​	In the example below, all three echo statements below are equal and legal:

```
<!DOCTYPE html>
<html>
<body>
<?php
ECHO "Hello World!<br>";
echo "Hello World!<br>";
EcHo "Hello World!<br>";
?> 
</body>
</html>
```

<b>Note:</b> However, all variable names are case-sensitive!

​	Look at the example below; only the first statement will display the value of the <span style="color:red;">$color</span> variable! This is because <span style="color:red;">$color</span>, <span style="color:red;">$COLOR</span>, and <span style="color:red;">$coLOR</span> are treated as three different variables:

```
<!DOCTYPE html>
<html>
<body>
<?php
$color = "red";
echo "My car is " . $color . "<br>";
echo "My house is " . $COLOR . "<br>";
echo "My boat is " . $coLOR . "<br>";
?>
</body>
</html>
```



# 5. PHP Comments

## 5.1 Comments in PHP

​	A comment in PHP code is a line that is not executed as a part of the program. Its only purpose is to be read by someone who is looking at the code.

​	Comments can be used to:

* Let others understand your code
* Remind yourself of what you did - Most programmers have experienced coming back to their own work a year or two later and having to re-figure out what they did. Comments can remind you of what you were thinking when you wrote the code.

​	PHP supports several ways of commenting:

```
<!DOCTYPE html>
<html>
<body>
<?php
//This is a single-line comment
#This is also a single-line comment
/*
This is a multiple-lines comment block
that spans over multiple
*/
?>
</body>
</html>
```

​	You can also using comments to leave out parts of the code:

```
<?php
//You can also use comments to leave out parts of a code line
$x = 5 /* + 15 */ + 5;
echo $x;
?>
```



# 6. PHP Variables

​	Variables are "containers" for storing information.

## 6.1 Creating (Declaring) PHP Variables

​	In PHP, a variable starts with the <span style="color:red;">$</span> sign, followed by the name of the variable:

```
<?php
$txt = "Hello World!";
$x = 5;
$y = 10.5;
?>
```

​	After the execution of the statements above, the variable <span style="color:red;">$txt</span> will hold the value "Hello World!", the variable <span style="color:red;">$x</span> will hold the value 5, and the variable <span style="color:red;">$y</span> will hold the value 0.5.

<b>Note:</b> When you assign a text value to a variable, put quotes around the value.

<b>Note:</b> Unlike other programming languages, PHP has no command for declaring a variable. It is created the moment you first assign a value to it.

<b>Note:</b> Think of variables as containers for storing data.

## 6.2 PHP Variables

​	A variable can have a short name (like x and y) or a more descriptive name (age, carname, total_volume).

​	Rules for PHP variables:

* A variable starts with the <span style="color:red;">$</span> sign, followed by th name of the variable
* A variable name must start with a letter or the underscore character
* A variable name cannot start with a number
* A variable name can only contain alpha-numeric characters and underscores (A-z, 0-9, and _)
* Variable names are case-sensitive (<span style="color:red;">$age</span> and <span style="color:red;">$AGE</span> are two different variables)

<b>Note:</b> Remember that PHP variable names are case-sensitive!

## 6.3 Output Variables

​	The PHP <span style="color:red;">echo</span> statement is often used to output data to the screen.

​	The following example will show how to output text and a variable:

```
<?php
$txt = "W3School.com";
echo "I love $txt";
?>
```

​	The following example will produce the same output as the example above:

```
<?php
$txt = "W3School.com";
echo "I love " . $txt . "!";
?>
```

​	The following example will output the sum of two variables:

```
$x = 5;
$y = 6;
echo $x + $y;
```

## 6.4 PHP is a Loosely Typed Language

​	In the example above, notice that we did not have to tell PHP which data type the variable is.

​	PHP automatically associates a data type to the variable, depending on its value. Since the data types are not sent in a strict sense, you can do things like adding a string to an integer without causing an error.

​	In PHP 7, type declarations were added. This gives an option to specify the data type expected when declaring a function, and by enabling the strict requirement, it will throw a "Fatal Error" on a type mismatch.

​	You will learn more about <span style="color:red;">strict</span> and <span style="color:red;">non-strict</span> requirements, and data type declaration in the PHP function chapter.

## 6.5 PHP Variables Scope

​	In PHP, variables can be declared anywhere in the script. The scope of a variable is the part of the script where the variable can be referenced/used.

​	PHP has three different variables scope:

* local
* global
* static

## 6.6 Global and Local Scope

​	A variable declared <b>outside</b> a function has a GLOBAL SCOPE and can only be accessed outside a function:

```
$x = 5;		//global scope
function myTest() {
	echo "<p>Variable x inside function is: $x</p>";	//error, x not defined
}
```

​	A variable declared <b>within</b> a function has a LOCAL SCOPE and can only be accessed within that function:

```
function myTest() {
	$x = 5;
	//...
}
```

## 6.7 PHP The global Keyword

​	The <span style="color:red;">global</span> keyword is used to access a global variable from within a function. To do this, use the <span style="color:red;">global</span> keyword before the variable (inside the function):

```
$y = 10;
function myTest() {
	global $y;
	echo $y;
}
```

​	PHP also stores all global variables in an array called <span style="color:red;">$GLOBALS[<i>index</i>]</span>. The <i><span style="color:red;">index</span></i> holds the name of the variable. This array is also accessible from within functions and can be used to update global variables directly. The example above can be written like this:

```
$y = 10;
function myTest() {
	echo $GLOBALS['y'];
}
```

## 6.8 PHP The static Keyword

​	Normally, when a function is completed/executed,, all of its variables are deleted. However, sometimes we want a local variable NOT to be deleted. We need it for a further job. To do this, use the <span style="color:red;">static</span> keyword when you first declared the variable:

```
function myTest() {
	static $x = 0;
	echo $x;
	$x++;
}
myTest();
myTest();
```

​	Then, <span style="color:blue;">each time the function is called, that variable will still have the information it contained from the last time the function was called (similar to C ?)</span>.



# 7. PHP echo and print Statements

​	With PHP, there are tow basic ways to get output: <span style="color:red;">echo</span> and <span style="color:red;">print</span>.

​	In this tutorial, we use <span style="color:red;">echo</span> or <span style="color:red;">print</span> in almost every example. So. this chapter contains a little more info about those two output statements.

## 7.1 PHP echo and print Statements

​	<span style="color:red;">echo</span> and <span style="color:red;">print</span> are more or less the same. They are both used to output data to the screen. 

​	The difference are small: <span style="color:red;">echo</span> has no return value while <span style="color:red;">print</span> has a return value of 1 so it can be used in expression. <span style="color:red;">echo</span> can take multiple parameters (although such usage is rare) while <span style="color:red;">print</span> only one argument. <span style="color:red;">echo</span> is marginally faster than <span style="color:red;">print</span>.

## 7.2 The PHP echo Statement

​	The <span style="color:red;">echo</span> statement can be used withe or without parentheses: <span style="color:red;">echo</span> or <span style="color:red;">echo()</span>.

<b>Display Text</b>

```
echo "<h2>PHP is Fun!</h2>";
echo "This ", "string ", "was ", "made ", "with multiple parameters.";
```

<b>Display Variables</b>

````
$txt1 = "Learn PHP, to practice it!";
$x = 5.5;
echo "<h2>" . $txt1 . "<h2>";
echo $x;
````

## 7.3 The PHP print Statement

​	The <span style="color:red;">print</span> statement can also used with or without parentheses:<span style="color:red;">print</span> or <span style="color:red;">print()</span>.

<b>Display Text</b>

```
print "<h2>Talk is cheap, show me the code</h2>";
```

<b>Display Variables</b>

```
$txt1 = "Spending time, finding the amaze."
$x = 5.6;
print "<h2>" . $txt1 . "</h2>";
print $x;
```



# 8. PHP Data Types

## 8.1 PHP Data Types

​	Variables can store data of different types, and different data types can do different things. PHP supports the following data types:

* String
* Integer
* Float (floating point numbers - also called double)
* Boolean
* Array
* Object
* NULL
* Resource

## 8.2 PHP String

​	A string is a sequence of characters, a string can be any text inside quotes (single or double quotes).

## 8.3 PHP Integer

​	An integer data type is a non-decimal number between -2,147,483,648 and 2,147,483,647. Rules for integers:

* An integer must have at least one digit
* An integer must not have a decimal point
* An integer can be either positive or negative
* Integers can be specified in: decimal (base 10), hexadecimal (base 16), octal (base 8), or binary (base 2) notation

```
$x = 536435;
var_dump($x);		//return the data type and value
```

## 8.4 PHP Float

​	A float (floating point number) is a number with a decimal point or a number in exponential form.

## 8.5 PHP Boolean

​	A Boolean represents two possible states: TRUE or FALSE.

## 8.6 PHP Array

​	An array stores multiple values in one single variable.

```
$cars = array("BYD", "Volvo");
```

## 8.7 PHP Object

​	Classes and objects are two main aspects of object-oriented programming. A class is a template for objects, and an object is an instance of a class.

​	When the individual objects are created, they inherit all the properties and behaviors from the class, but each object will have different values for the properties.

​	Lets' assume we have a class named Car. A Car can have properties like modal, color, etc. We can define variables like $modal, $color, and son on, to hold the values of these properties.

​	When the individual objects (BYD, Volvo, etc) are created, they inherit all the properties and behaviors from the class, but each object will have different values for properties. If you create a __construct() function, PHP will automatically call this function when you create an object from the class:

```
class Car {
	public $color;
	public $modal;
	public function __construct($color, $modal) {
		$this->color = $color;
		$this->modal = $moda;
	}
	public function message() {
		return "My car is a " . $this->color . " " . $this->modal . "!";
	}
}
$myCar = new Car("black", "Volvo");
echo $myCar->message();
echo "<br>";
$myCar = new Car("red", "BYD");
echo $myCar->message();
```

 ## 8.8 PHP NULL Value

​	Null is a specified data type which can have only one value: NULL.

​	A variable of data type NULL is a variable that has no value assigned to it.

​	<b>Tip:</b> If a variable is created without a value, it is automatically assigned a value of NULL.

​	Variables can also be emptied by setting the value to NULL:

```
$x = "Hello World!";
$x = null;
var_dump($x);
```

## 8.9 PHP Resource

​	The special resource type is not an actual data type. It is the storing of a reference to functions and resources external to PHP. A common example of using the resource data type is a database call. We will not talk about the resource type here, since it is an advanced topic.



# 9. PHP Strings

​	A string is a sequence of characters, like "Hello".

## 9.1 PHP String Functions

​	In this chapter we will look at some commonly used functions to manipulates strings.

## 9.2 strlen() - Return the Length of a String

```
echo strlen("Hello World!");	//12
```

## 9.3 str_word_count() - Count Words in a String

​	The PHP <span style="color:red;">str_word_count()</span> function counts the number of words in a string:

```
echo str_word_count("Hello World!");	//2
```

## 9.4 strrev() - Reverse a String

​	The PHP <span style="color:red;">strrev()</span> function reverses a string:

```
echo strrev("Hello World!");	//!dlrow olleH
```

## 9.5 strpos() - Search For a Text Within a String

​	The PHP <span style="color:red;">strpos()</span> function searches for a specific text within a string. If a match is found, the function the character position of the first match. If no match is found, it will return FALSE:

```
echo strpos("Hello World!", "World!");	//output 6
```

<b>Tip:</b> The first character position in a string is 0.

## 9.6 str_replace() - Replace Text Within a String

​	The PHP <span style="color:red;">str_replace()</span> function replaces some characters with some other characters in a string:
```
echo str_replace("World", "Dolly", "Hello World");	//Hello Dolly
```



# 10. PHP Numbers

## 10.1 PHP Numbers

​	One thing to notice about PHP is that it provides automatic data type coversion.

​	So, if you assign an integer value to a variable, the type of that variable will automatically be an integer. Then, if you assign a string to the same variable, the type will change to a string. 

​	This automatic conversion can sometimes break your code.

## 10.2 PHP Integers

​	2, 256, -256, 10358, -179567 are all integers.

​	An integer is a number without any decimal part. An integer data type is a non-decimal number between -2147483648 and 2147483647 in 32 bit systems, and between -9223372036854775808 and 9223372036854775807 in 64 bit systems. A value greater (or lower) than this, will be stored as float, because it exceeds the limit of an integer.

<b>Note:</b> Another important thing to know is that even if 4*2.5 is 10, the result is stored as float, because one of the operands is a float.

​	Here are some rules for integers:

* An integer must have at least one digit
* An integer must NOT have a decimal point
* An integer can be either positive or negative
* Integers can be specified in three formats: decimal (10-based), hexadecimal (16-based - prefixed with 0x) or octal (8-based - prefixed with 0)

​	PHP has the following predefined constants for integers:

* PHP_INT_MAX - The largest integer supported
* PHP_INT_MIN - The smallest integer supported
* PHP_INT_SIZE - The size of an integer in bytes

​	PHP has the following functions to check if the type of a variable is integer:

* is_int()
* is_integer() - alias of is_int()
* is_long() - alias of is_int()

```
$x = 98274;
var_dump(is_int($x));	//bool(true)
$x = 8.2;
var_dump(is_int($x));	//bool(false)
```

## 10.3 PHP Floats

​	A float is a number with a decimal point or a number in exponential form.

​	2.0, 256.4, 10.358, 7.64E+5, 5.56E-5 are all floats.

​	The float data type can commonly store a value up to 1.7976931348623E+308 (platform dependent), and have a maximum precision of 14 digits.

​	PHP has the following functions to check if the type of a variable is float:

* is_float()
* is_double() - alias of is_float()

```
$x = 10.365;
var_dump(is_float($x));
```

## 10.4 PHP Infinity

​	A numeric value that is larger than PHP_FLOAT_MAX is considered infinite.

​	PHP has the following functions to check if a numeric value is finite or infinite:

* is_finite()
* is_infinite()

​	However, the PHP var_dump() function returns the data type and value:

```
$x = 1.9e411;
var_dump($x);
```

## 10.5 PHP NaN

​	NaN stands for Not a Number. NaN is used for impossible mathematical operations.

​	PHP has the following functions to check if a value is not a number:

* is_nan()

​	However, the PHP var_dump() function returns the data type and value:

```
$x = acos(8);
var_dump($x);
```

## 10.6 PHP Numerical Strings

​	The PHP is_numeric() function can be used to find whether a variable is numeric. The function returns true if the variable is a number or a numeric string, false otherwise:

```
$x = 5985;
var_dump(is_numeric($x));	//bool(true)
$x = "5985";
var_dump(is_numeric($x));	//bool(true)
$x = "59.85" + 100;
var_dump(is_numeric($x));	//bool(true)
$x = "Hello";
var_dump(is_numeric($x));	//bool(false)
```

<b>Note:</b> From PHP 7.0: The is_numeric() function will return FALSE for numeric strings in hexadecimal form (e.g. 0xf4c3b00c), as they are no longer considered as numeric strings.

## 10.7 PHP Casting Strings and Floats to Integers

​	Sometimes you need to cast a numerical value into another data type.

​	The (int), (integer), or intval() function are often used to convert a value to an integer:

```
$x = 23465.768;
$int_cast = (int)$x;
echo $int_cast;
echo "<br>";
// Cast string to int
$x = "23465.768";
$int_cast = (int)$x;
echo $int_cast;
```



# 11. PHP Math

​	PHP has a set of math functions that allows you to perform mathematical tasks on numbers.

## 11.1 PHP pi() Function

​	The <span style="color:red;">pi()</span> function returns the value of PI:

```
echo(pi());	//3.1415926535898
```

## 11.2 PHP min() and max() Functions

​	The <span style="color:red;">min()</span> and <span style="color:red;">max()</span> functions can be used to find the lowest or highest value in a list of arguments:

```
echo(min(0, 150, 30, 20, -8, -200));  // returns -200
echo(max(0, 150, 30, 20, -8, -200));  // returns 150
```

## 11.3 PHP abs() Function

​	The <span style="color:red;">abs()</span> function returns the absolute (positive) value of a number:

```
echo(abs(-6.7));	//6.7
```

## 11.4 PHP sqrt() Function

​	The <span style="color:red;">sqrt()</span> function returns the square root of a number:

```
echo(sqrt(64));		//8
```

## 11.5 PHP round() Function

​	The <span style="color:red;">round()</span> function rounds a floating-point number to its nearest integer:

```
echo(round(0.60));	//1
echo(round(0.49));	//0
```

## 11.6 Random Numbers

​	The <span style="color:red;">rand()</span> function generates a random number:

```
echo(rand());
```

​	To get more control over the random number, you can add the optional <i>min</i> and <i>max</i> parameters to specify the lowest integer and the highest integer to be returned.

​	For example, if you want a random integer between 10 and 100 (inclusive), use <span style="color:red;">rand(10, 100)</span>:

```
echo(rand(10, 100));
```



# 12. PHP Constants

​	Constants are like variables except that once they are defined they cannot be changed or undefined.

## 12.1 PHP Constans

​	A constant is an identifier (name) for a simple value. The value cannot be changed during the script. A valid constant name starts with a letter or underscore (no $ sign before the constant name).

<b>Note:</b> Unlike variables, constants are automatically global across the entire script.

## 12.2 Create a PHP Constant

​	To create a constant, use the <span style="color:red;">define()</span> function.

<span style="font-size:20px;">Syntax</span>

` define(name, value, case-insensitive)`

Parameters:

* <i>name</i>: Specifies the name of the constant
* <i>value</i>: Specified the value of the constant
* <i>case-insensitive</i>: Specifies whether the constant name should be case-insensitive, default is false.

```
define("GREETING", "Welcome to here!");
echo GREETING;
```

## 12.3 PHP Constant Arrays

​	In PHP7, you can create an Array constant using the <span style="color:red;">define()</span> function:

```
define("cars",[
	"BYD",
	"Volvo"
]);
echo cars[0];
```

## 12.4 Constants are Global

​	Constants are automatically global and can be used across the entire script:

```
define("GRETTING", "Welcom to here!");
function myTest() {
	echo GRETTING;
}
myTest();
```



# 13. PHP Operators

## 13.1 PHP Operators

​	Operators are used to perform operations on variables and values.

​	PHP divides the operators in the following groups:

* Arithmetic operators
* Assignment operators
* Comparison operators
* Increment/Decrement operations
* Logical operators
* String operators
* Array operators
* Conditional assignment operators

## 13.2 PHP Arithmetic Operators

​	The PHP arithmetic operators are used with numeric values to perform common arithmetical operators, such as addition, multiplication etc.

| Operator | Name           | Example  | Result                                  |
| -------- | -------------- | -------- | --------------------------------------- |
| +        | Addition       | $x + $y  | Sum of $x and $y                        |
| -        | Subtraction    | $x - $y  | Difference of $x and $y                 |
| *        | Multiplication | $x * $y  | Product of $x and $y                    |
| /        | Division       | $x / $y  | Quotient of $x and $y                   |
| %        | Modulus        | $x % $y  | Remainder of $x divided by $y           |
| **       | Exponentiation | $x ** $y | Result of raising $x to the $y'th power |

## 13.3 PHP Assignment Operators

​	The PHP assignment operators are used with numeric values to write a value to a variable. The basic assignment operator in PHP is "=". It means that the left operand gets set to the value of the assignment expression on the right.

| Assignment | Same as ... | Description                                                  |
| ---------- | ----------- | ------------------------------------------------------------ |
| x = y      | x = y       | The left operand gets set to the<br>value of the expression on the right |
| x += y     | x = x + y   | Addition                                                     |
| x -= y     | x = x - y   | Subtraction                                                  |
| x *= y     | x = x * y   | Multiplication                                               |
| x /= y     | x = x / y   | Division                                                     |
| x %= y     | x = x % y   | Modulus                                                      |

## 13.4 PHP Comparison Operators

​	The PHP comparison operators are used to compare two values (number or string):

| Operator | Name                     | Example   | Result                                                       |
| -------- | ------------------------ | --------- | ------------------------------------------------------------ |
| ==       | Equal                    | $x == $y  | Returns true if $x is equal to $y                            |
| ===      | Identical                | $x === $y | Returns true if $x is equal to $y, and they are of the same type |
| !=       | Not equal                | $x != $y  | Returns true if $x is not equal to $y                        |
| <>       | Not equal                | $x <> $y  | Returns true if $x is not equal to $y                        |
| !==      | Not identical            | $x !== $y | Returns true if $x is not equal to $y, or they are not of the same type |
| >        | Greater than             | $x > $y   | Returns true if $x is greater than $y                        |
| <        | Less than                | $x < $y   | Returns true if $x is less than $y                           |
| >=       | Greater than or equal to | $x >= $y  | Returns true if $x is greater than or equal to $y            |
| <=       | Less than or equal to    | $x <= $y  | Returns true if $x is less than or equal to $y               |
| <=>      | Spaceship                | $x <=> $y | Returns an integer less than, equal to, or greater than zero, depending on if $x is less than, equal to, or greater than $y. |

## 13.5 PHP Increment / Decrement Operators

| Operator | Name           | Description                           |
| -------- | -------------- | ------------------------------------- |
| ++$x     | Pre-increment  | Increments $x by one, then returns $x |
| $x++     | Post-increment | Returns $x, then increments $x by one |
| --$x     | Pre-decrement  | Decrements $x by one, then returns $x |
| $x--     | Post-decrement | Returns $x, then decrement $x by one  |

## 13.6 PHP Logical Operators

| Operator | Name | Example    | Result                                        |
| -------- | ---- | ---------- | --------------------------------------------- |
| and      | And  | $x and $y  | True if both $x and $y are true               |
| or       | Or   | $x or $y   | True if either $x or $y is true               |
| xor      | Xor  | $x xor $y  | True if either $x or $y is true, but not both |
| &&       | And  | $x && $y   | True if both $x and $y are true               |
| \|\|     | Or   | $x \|\| $y | True if either $x or $y is true               |
| !        | Not  | !$x        | True if $x is not true                        |

## 13.7 PHP String Operators

| Operator | Name                     | Example        | Result                           |
| -------- | ------------------------ | -------------- | -------------------------------- |
| .        | Concatenation            | $txt1 . $txt2  | Concatenation of $txt1 and $txt2 |
| .=       | Concatenation assignment | $txt1 .= $txt2 | Appends $txt2 to $txt1           |

## 13.8 PHP Array Operators

| Operator | Name         | Example   | Result                                                       |
| -------- | ------------ | --------- | ------------------------------------------------------------ |
| +        | Union        | $x + $y   | Union of $x and $y                                           |
| ==       | Equality     | $x == $y  | Returns true if $x and $y have the same key/value pairs      |
| ===      | Identity     | $x === $y | Returns true if $x and $y have the same key/value pairs in the same order and of the same types |
| !=       | Inequality   | $x != $y  | Returns true if $x is not equal to $y                        |
| <>       | Inequality   | $x <> $y  | Returns true if $x is not equal to  $y                       |
| !==      | Non-identity | $x !== $y | Returns true if $x is not identical to $y                    |

## 13.9 PHP Conditional Assignment Operators

​	PHP conditional assignment operators are used to set a value depending on conditions:

| Operator | Name            | Example                     | Result                                                       |
| -------- | --------------- | --------------------------- | ------------------------------------------------------------ |
| ?:       | Ternary         | $x = expr1 ? expr2 : expr3; | Returns the value of $x. The value of $x is expr2 if expr1=TRUE, otherwise $x is expr3. |
| ??       | Null coalescing | $x = expr1 ?? expr2;        | Returns the value of $x. The value of $x is expr1 if expr1 exists, and is not NULL, otherwise $x is expr2. |



# 14. PHP if...else...elseif Statements

## 14.1 PHP Conditional Statements

​	Very often when you write code, you want to perform different actions for different conditions. You can use conditional statements in your code to do this.

​	In PHP we have the following conditional statements:

* <span style="color:red;">if</span> statement - executes some code if one condition is true
* <span style="color:red;">if...else</span> statement - executes some code if a condition is true and another code if that condition if false
* <span style="color:red;">if...elseif...else</span> statement - executes different codes for more than two conditions
* <span style="color:red;">switch</span> statement - selects one of many blocks of code to be executed (sometimes more than one if no break)

## 14.2 PHP - The if Statement

<span style="font-size:20px;">Syntax</span>

`if(condition) {`

​	//code to be executed if condition is true;

`}`

```
$t = date("H");
if ($t < "20") {
	echo "Have a good day!";
}
```

## 14.3 PHP - The if...else Statement

```
$t = date("H");

if ($t < "20") {
  echo "Have a good day!";
} else {
  echo "Have a good night!";
}
```

## 14.4 PHP - The if...elseif...else Statement

```
$t = date("H");

if ($t < "10") {
  echo "Have a good morning!";
} elseif ($t < "20") {
  echo "Have a good day!";
} else {
  echo "Have a good night!";
}
```



# 15. PHP switch Statement

## 15.1 The PHP switch Statement

​	Use the <span style="color:red;">switch</span> statement to <b>select one (or more) of many blocks code to be executed</b>:

(similar to C so i won't describe the details)

```
$favcolor = "red";

switch ($favcolor) {
  case "red":
    echo "Your favorite color is red!";
    break;
  case "blue":
    echo "Your favorite color is blue!";
    break;
  case "green":
    echo "Your favorite color is green!";
    break;
  default:
    echo "Your favorite color is neither red, blue, nor green!";
}
```



# 16. PHP Loops

## 16.1 PHP Loops

​	Often when you write code, you want the same block of code to run over and over again a certain number of times. So, instead of adding several almost equal code-lines in a script, we can use loops.

​	Loops are used to execute the same block of code again and again, as long as certain condition it true. In PHP, we have the following loop types:

* <span style="color:red;">while</span> - loops through a block of code as long as the specified condition is true
* <span style="color:red;">do...while</span> - loops through a block of code once, and then repeats the loop as long as the specified condition is true (or doesn't break).
* <span style="color:red;">for</span> - loops through a block of code a specified number of times
* <span style="color:red;">foreach</span> - loops through a block of code for each element in an array

## 16.2 PHP while Loop

### 16.2.1 The PHP while Loop

​	The <span style="color:red;">while</span> loop executes a block of code as long as the specified condition is true.

<span style="font-size:20px;">Syntax</span>

```
while (condition is true) {
	//code to be executed
}
```

```
$x = 1;
while ($x <= 5) {
	echo "The number is: $x <br>";
	$x++;
}
```

## 16.3 PHP do while Loop

### 16.3.1 The PHP do...while Loop

​	The <span style="color:red;">do...while</span> loop will always execute the block of code once, it will then check the condition, and repeat the loop while the specified condition is true.

<span style="font-size:20px;">Syntax</span>

```
do {
	//code to be executed
} while (condition is true);
```

```
$x = 1;
do {
	echo "The number is: $x <br>";
	$x++;
} while ($x <= 5);
```

## 16.4 PHP for Loop

### 16.4.1 The PHP for Loop

​	The <span style="color:red;">for</span> loop used when you know in advance how many times the script should run.

<span style="font-size:20px;">Syntax</span>

```
for (init counter; test counter; increment/decrement counter) {
	//code to be executed for each iteration;
}
```

```
for ($x = 0; $x <= 10; $x++) {
	echo "Th number is: $x <br>";
}
```

## 16.5 PHP foreach Loop

### 16.5.1 The PHP foreach Loop

​	The <span style="color:red;">foreach</span> loop works only on array, and is used to loop through each key/value pair in an array:

<span style="font-size:20px;">Syntax</span>

```
foreach ($array as $value) {
	//code to be executed
}
```

​	For every loop iteration, the value of the current array element is assigned to $value and the array pointer is moved by one, until it reaches the last array element.

```
$colors = array("red", "green", "blue", "yellow");
foreach ($color as $value) {
	echo "$value <br>";
}
```

​	The following example will output both the keys and the values of the given array ($age):

```
$age = array("Peter"=>"30", "Ben"=>"23", "Joe"=>"29");
foreach ($age as $x => $val) {
	echo "$x = $val <br>";
}
```

## 16.6 PHP Break and Continue

### 16.6.1 PHP Break

​	You have already seen the <span style="color:red;">break</span> statement used in an earlier chapter of this tutorial. It was used to "jump out" of a <span style="color:red;">switch</span> statement.

​	The <span style="color:red;">break</span> statement can be also be used to jump out of a loop. This example jumps out of the loop when <b>x</b> is equal to <b>4</b>:

```
for ($x = 0; $x <= 10; $x++) {
	if ($x == 4) {
		break;
	}
	echo "The number is: $x <br>";
}
```

 ### 16.6.2 PHP Continue

​	The <span style="color:red;">continue</span> statement breaks one iteration (int the loop), if a specified condition occurs, and continue with the next iteration in the loop. The example skips the value of <b>4</b>:

```
for ($x = 0; $x < 10; $x++) {
	if ($x == 4) {
		continue;
	}
	echo "The number is: $x <br>";
}
```

### 16.6.3 Break and Continue in While Loop

​	You can also use <span style="color:red;">break</span> and <span style="color:red;">continue</span> in <span style="color:red;">while</span> loops:

```
$x = 0;
while ($x < 0) {
	if ($x == 2) {
		continue;
	}
	if ($x == 4) {
		break;
	}
	echo "The number is: $x <br>";
	$x++;
}
```



# 17. PHP Functions

​	The real power of PHP comes from its functions. PHP has more than 1000 builtl-in functions. and in addition you can create your own custom functions.

## 17.1 PHP Built-in Functions

​	PHP has over 1000 built-in functions that can be called directly, from within a script, to perform a specific task. Please check out our PHP reference for a complete overview of the [PHP built-in functions](https://www.w3schools.com/php/php_ref_overview.asp).

## 17.2 PHP User Defined Functions

​	Besides the built-in PHP functions, it is possible to create your own functions.

* A function is a block of statements that can be used repeatedly in a program.
* A function will not execute automatically when a page loads.
* A function will be executed by a call to the function.

## 17.3 Create a User Defined Function in PHP

​	A user-defined function declaration starts with the word <span style="color:red;">function</span>:

<span style="font-size:20px;">Syntax</span>

```
function functionName() {
	//code to be executed
}
```

<b>Note:</b> A function name must start with a letter or an underscore. Function names are NOT case-sensitive.

```
function writeMsg() {
	echo "Hello";
}
writeMsg();
```

## 17.4 PHP Function Arguments

​	Information can be passed to functions through arguments. An argument is just like a variable. Arguments are specified after the function name, inside the parentheses. You can 

add as many arguments as you want, just separate them with a comma.

​	The following example has a function with one argument ($fname). When the familyName() function is called, we also pass along a name (e.g. Jani), and the name is used inside the function, which outputs several different first names, but an equal last name:

```
function familyName($fname) {
	echo "$fname Refsnes.<br>";
}
familyName("Jani");
familyName("Hege");
familyName("Stale");
familyName("Kai Jim");
```

## 17.5 PHP is a Loosely Typed Language

​	In the example above, notice that we did not have to tell PHP which data type the variable is. PHP automatically associates a data type to the variable, depending on its value. Since the data types are not set in a strict sense, you can do things like adding a string to an integer without causing an error.

​	In PHP7, type declarations were added. This gives us an option to specify the expected data type when declaring a function, and by adding the <span style="color:red;">strict</span> declaration, it will throw a "Fatal Error" if the data type mismatches.

​	In the following example we try to send both a number and a string to the function without using <span style="color:red;">strict</span>:

```
function addNumbers(int $a, int $b) {
	return $a + $b;
}
echo addNumbers(5, "5 days");	//"5 days" is changed to int(5)
```

​	To specify <span style="color:red;">strict</span> we need to set <span style="color:red;">declare(strict_types=1);</span>. This must be on the very first line of the PHP file. In the following example we try to send both a number and a string to the function, but here we have added the <span style="color:red;">strict</span> declaration:

```
<?php declare(strict_types=1);	//strict requirement
function addNumbers(int $a, int $b) {
	return $a + $b;
}
echo addNumbers(5, "5 days");	//error
```

## 17.6 PHP Default Argument Value

​	The following example shows how to use a default parameter. If we call the function setHeight() without argument it takes the default value as argument:

```
<?php declare(strict_type=1);
function setHeight(int $minheight = 50) {
	echo "The height is: $minheight <br>";
}
setHeight(300);
setHeight();
```

## 17.7 PHP Functions - Returning values

​	To let a function return a value, use the <span style="color:red;">return</span> statement:

```
<?php declare(strict_type=1);
function sum(int $x, int $y) {
	$z = $x + $y;
	return $z;
}
echo "5 + 10 = " . sum(5,10) . "<br>";
echo "2 + 4 = " . sum(2,4);
```

## 17.8 PHP Return Type Declarations

​	PHP 7 also supports Type Declarations for the <span style="color:red;">return</span> statement. Like with the type declaration for function arguments, by enabling the strict requirement, it will throw a "Fatal Error" on a type mismatch.

​	To declare a type for the function return, add a colon (<span style="color:red;">:</span>) and the type right before the opening curly (<span style="color:red;">{</span>) bracket when declaring the function. In the following example we specify the return type for the function:

```
<?php declare(strict_types=1);
function addNumbers(float $a, float $b) : float {
	return $a + $b;
}
echo addNumbers(1.4, 0.3);
```

​	You can even specify a different return type, than the argument types, but make sure the return is the correct type:

```
<?php declare(strict_types=1);
function addNumbers(float $a, float $b) : int {
	return (int)($a + $b);
}
echo addNumbers(1.2, 3.9);
```

## 17.9 Passing Arguments by Reference

​	In PHP, arguments are usually passed by value, which means that a copy of the value is used in the function and the variable that was passed into the function cannot be changed.

​	When a function argument is passed by reference, changes to the argument also change the variable that was passed in. To turn a function argument into a reference, the <span style="color:red;">$</span> operator is used:

```
function add_five(&$value) {
	$value += 5;
}
$num = 2;
add_five($num);
echo $num;
```



# 18. PHP Arrays

​	An array stores multiple values in one single variable:

```
$cars = array("BYD", "Volvo");
echo "I have " . $cars[0] . "and " . $cars[1] . ".";
```

## 18.1 What is an array

​	An array is a special variable, which can hold more than one value at a time. If you have a list of items, storing the cars in single variables could look like this:

```
$cars1 = "BYD";
$cars2 = "Volvo";
```

​	However, what if you want to loop through the cars and find a specific one? And what if you had not 3 cars, but 300? 

​	The solution is to create an array!

​	An array can hold many values under a single name, and you can access the values by referring to an index number.

## 18.2 Create an Array in PHP

​	In PHP, the <span style="color:red;">array()</span> function is used to create an array:

```
array();
```

 	In PHP, there are three types of arrays:

* <b>Indexed arrays</b> - Arrays with a numeric index
* <b>Associative arrays</b> - Arrays with named keys
* <b>Multidimensional arrays</b> - Arrays containing one or more arrays

## 18.3 Get The Length of an Array - The count() Function

​	The <span style="color:red;">count()</span> function is used to return the length (the number of elements) of an aray:

```
$cars = array(...);
echo count($cars);
```

## 18.4 PHP Indexed Arrays

### 18.4.1 PHP Indexed Arrays

​	There are two ways to create indexed arrays:

​	The index can be assigned automatically (index always starts at 0), like this:

```
$cars = array(...);
$cars[0] = "BYD";
$cars[1] = "Volvo";
```

​	The following example creates an indexed array named $cars, assigns three elements to it, and then prints a test containing the array values:

```
<?php
$cars = array("Volvo", "BMW", "Toyota");
echo "I like " . $cars[0] . ", " . $cars[1] . " and " . $cars[2] . ".";
?>
```

### 18.4.2 Loop Through an Indexed Array

​	To loop through an print all the values of an indexed array, you could use a <span style="color:red;">rot</span> loop, like this:

```
<?php
$cars = array("Volvo", "BMW", "Toyota");
$arrlength = count($cars);

for($x = 0; $x < $arrlength; $x++) {
  echo $cars[$x];
  echo "<br>";
}
?>
```

## 18.5 PHP Associative Arrays

### 18.5.1 PHP Associative Arrays

​	Associative arrays are arrays that use named keys that you assign to them.

​	There are two ways to create an associative array:

```
$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
```

​	Or:

```
$age['Peter'] = "35";
$age['Ben'] = "37";
$age['Joe'] = "43";
```

​	The named keys can then be used in a script:

```
$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
echo "Peter is " . $age['Peter'] . " years old.";
?>
```

### 18.5.2 Loop Through an Associative Array

​	To loop through and print all the values of an associative array, you could use a <span style="color:red;">foreach</span> loop, like this:

```
<?php
$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");

foreach($age as $x => $x_value) {
  echo "Key=" . $x . ", Value=" . $x_value;
  echo "<br>";
}
```

## 18.6 PHP Multidimensional Arrays

### 18.6.1 PHP - Multidimensional Arrays

​	A multidimensional array is an array containing one or more arrays.

​	PHP supports multidimensional arrays that are two, three, four, five, or more levels deep. However, arrays more than three levels deep are hard to manage for most people.

<b>The dimension of an array indicated the number of indices you need to select an element</b>.

* For a two-dimensional array you need two indices to select an element.
* For a three-dimensional array you need three indices to select an element

## 18.6.2 PHP - Tow-dimensional Arrays

​	A two-dimensional array is an array of arrays (a three-dimensional array is an array of arrays of arrays).

​	First, take a look at the following table:

| Name       | Stock | Sold |
| :--------- | :---- | :--- |
| Volvo      | 22    | 18   |
| BYD        | 15    | 13   |
| Saab       | 5     | 2    |
| Land Rover | 17    | 15   |

​	We can store the data from the table above in a two-dimensional array, like this:

```
$cars = array(
	array("volvo",22, 18),
	array("byd", 15, 13),
	array("saab", 5, 2),
	array("land rover", 17, 15)
);
```

​	Now the two-dimensional $cars array contains four arrays, and it has tow indices: row and column. To get access to the elements of the $cars array we must point to the two indicies:

```
echo $cars[0][0].": In stock".$cars[0][1].", sold: ".$cars[0][2];
```

​	We can also put a <span style="color:red;">for</span> loop inside another <span style="color:red;">for</span> loop to get the elements of the $cars array:

```
for ($row = 0; $ros < 4; $ros++) {
	echo "<p>Row number $row</p>";
	echo "<ul>";
	for($col = 0; $col < 3; $col++) {
		echo "<li>.$cars[$row][$col].</li>";
	}
	echo "</ul>";
}
```

## 18.7 PHP Sorting Arrays

### 18.7.1 PHP - Sort Functions For Arrays

​	In this chapter, we will go through the following PHP array sort functions:

* <span style="color:red;">sort()</span> - sort arrays in ascending order
* <span style="color:red;">rsort()</span> - sort arrays in descending order
* <span style="color:red;">asort()</span> - sort associative arrays in ascending oder, according to the value
* <span style="color:red;">ksort()</span> - sort associative arrays in ascending order, according to the key
* <span style="color:red;">arsort()</span> - sort associative arrays in descending order, according to the value
* <span style="color:red;">krsort()</span> - sort associative arrays in descending order, according to the key

<b>Note:</b> The array was modified after sorting.

### 18.7.2 Sort Array in Ascending Order - sort()

​	Sorts array in ascending alphabetical order:

```
$cars = array("Volvo", "BMW", "Toyota");
sort($cars);
```

​	Sort array in ascending numerical order:
```
$numbers = array(4, 5, 6, 3, 9, 1, -1);
sort($numbers);
```

### 18.7.3 Sort Array in Descending Order - rsort()

```
$cars = array("Volvo", "BMW", "Toyota");
rsort($cars);
$numbers = array(4, 6, 2, 22, 11);
rsort($numbers);
```

### 18.7.4 Sort Array (Ascending Order), According to Key - ksort()

```
$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
ksort($age);
```

### 18.7.5 Other examples

```
$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
arsort($age);
$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
krsort($age);
```



# 19. PHP Global Variables - Superglobals

## 19.1 PHP Global Variables - Superglobals

​	Some predefined variables in PHP are named "superglobals", which means that they are always accessible, regardless of scope - and you can access them from any function, class or file without having to do anything special.

​	The PHP superglobal variables are:

* $GLOBALS
* $_SERVER
* $_REQUEST
* $_POST
* $_GET
* $_FILES
* $_ENV
* $_COOKIE
* $_SESSION

## 19.2 $GLOBALS

### 9.2.1 PHP $GLOBALS

​	$GLOBALS is a PHP super global variable which is used to access global variables from anywhere in the PHP script (also from within functions or methods). PHP stores all global variables in this array. The <i>index</i> holdes the name of the variable, so the variable can be refered via $GLOBALS[index]:

```
$x = 75;
$y = 34;
function addition() {
	$GLOBALS['z'] = $GLOBALS['x'] + $GLOBALS['y'];
}
addition();
echo $z;	//z need not to be declared
```

## 19.3 $_SEVER

### 19.3.1 PHP $_SERVER

​	$_SERVER is a PHP super global variable which holds information about headers, paths, and script locations. The example below shows how to use some of the element is $\_SVERVER:

```
echo "PHP_SELF: " . $_SERVER['PHP_SELF'] . "<br>";
echo "SERVER_NAME: " . $_SERVER['SERVER_NAME'] . "<br>";
echo "HTTP_HOST: " . $_SERVER['HTTP_HOST'] . "<br>";
echo "HTTP_REFRER: " . $_SERVER['HTTP_REFRER'] . " <br>";
echo "HTTP_USER_AGENT: " .  $_SERVER['HTTP_USER_AGENT'] . "<br>";
echo "SCRIPT_NAME: " .  $_SERVER['SCRIPT_NAME'] . "<br>";
echo "PHP_SELF: " .  $_SERVER['PHP_SELF'] . "<br>";
```

​	The following table lists the most important elements that can go inside $_SERVER:

| Element/Code                    | Description                                                  |
| :------------------------------ | :----------------------------------------------------------- |
| $_SERVER['PHP_SELF']            | Returns the filename of the currently executing script       |
| $_SERVER['GATEWAY_INTERFACE']   | Returns the version of the Common Gateway Interface (CGI) the server is using |
| $_SERVER['SERVER_ADDR']         | Returns the IP address of the host server                    |
| $_SERVER['SERVER_NAME']         | Returns the name of the host server (such as www.w3schools.com) |
| $_SERVER['SERVER_SOFTWARE']     | Returns the server identification string (such as Apache/2.2.24) |
| $_SERVER['SERVER_PROTOCOL']     | Returns the name and revision of the information protocol (such as HTTP/1.1) |
| $_SERVER['REQUEST_METHOD']      | Returns the request method used to access the page (such as POST) |
| $_SERVER['REQUEST_TIME']        | Returns the timestamp of the start of the request (such as 1377687496) |
| $_SERVER['QUERY_STRING']        | Returns the query string if the page is accessed via a query string |
| $_SERVER['HTTP_ACCEPT']         | Returns the Accept header from the current request           |
| $_SERVER['HTTP_ACCEPT_CHARSET'] | Returns the Accept_Charset header from the current request (such as utf-8,ISO-8859-1) |
| $_SERVER['HTTP_HOST']           | Returns the Host header from the current request             |
| $_SERVER['HTTP_REFERER']        | Returns the complete URL of the current page (not reliable because not all user-agents support it) |
| $_SERVER['HTTPS']               | Is the script queried through a secure HTTP protocol         |
| $_SERVER['REMOTE_ADDR']         | Returns the IP address from where the user is viewing the current page |
| $_SERVER['REMOTE_HOST']         | Returns the Host name from where the user is viewing the current page |
| $_SERVER['REMOTE_PORT']         | Returns the port being used on the user's machine to communicate with the web server |
| $_SERVER['SCRIPT_FILENAME']     | Returns the absolute pathname of the currently executing script |
| $_SERVER['SERVER_ADMIN']        | Returns the value given to the SERVER_ADMIN directive in the web server configuration file (if your script runs on a virtual host, it will be the value defined for that virtual host) (such as someone@w3schools.com) |
| $_SERVER['SERVER_PORT']         | Returns the port on the server machine being used by the web server for communication (such as 80) |
| $_SERVER['SERVER_SIGNATURE']    | Returns the server version and virtual host name which are added to server-generated pages |
| $_SERVER['PATH_TRANSLATED']     | Returns the file system based path to the current script     |
| $_SERVER['SCRIPT_NAME']         | Returns the path of the current script                       |
| $_SERVER['SCRIPT_URI']          | Returns the URI of the current page                          |

## 19.4 $_REQUEST

### 19.4.1 PHP $_REQUEST

​	PHP $_REQUEST is used to collect data after submitting an HTML form.

​	The example below shows a form with an input field and a submit button. When a user submits the data by clicking on "Submit", the form data is sent to the file specified in the action attribute of the \<form> tag. In this example, we point to this file itself for processing form data. If you wish to use another PHP file to process form data, replace that withe the file name of your choice. Then, we can use the super global variable $_REQUEST to collect the value of the input filed:

```
<html>
<body>
<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
  Name: <input type="text" name="fname">
  <input type="submit">
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_REQUEST['fname'];
  if (empty($name)) {
    echo "Name is empty";
  } else {
    echo $name;
  }
}
?>
</body>
</html>
```

<b>Note:</b> <span style="color:blue;">Pay attention to how we use the PHP code</span>.

## 19.5 $_POST

### 19.5.1 PHP $_POST

​	PHP $_POST is used to collect form data after submitting an HTML form with method="post". $\_POST is also widely used to pass variables.

​	The example below similar to above example:

```
<html>
<body>
<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
  Name: <input type="text" name="fname">
  <input type="submit">
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['fname'];
  if (empty($name)) {
    echo "Name is empty";
  } else {
    echo $name;
  }
}
?>
</body>
</html>
```

## 19.6 $_GET

### 19.6.1 PHP $_GET

​	PHP $_GET is used to collect form data after submitting an HTML form with method="get". $\_GET can also collect data sent in the URL.

​	Assume we have an HTML page that contains a hyperlink with parameters:

```
<body>
<a href="test_get.php?subject=PHP&web=W3schools.com">Test $GET</a>
</body>
```

​	When a user click on the link "Test $GET", the parameters "subject" and "web" are sent to "test_get.php", and you can then access their values in "test_get.php" with $_GET.

```
<html>
<body>
<?php
echo "Study " . $_GET['subject'] . " at " . $_GET['web'];
?>
</body>
</html>
```



# 20. PHP Regular Expressions

## 20.1 What is a Regular Expression?

​	A regular expression is a sequence of characters that form a search pattern. When you search for data in a text, you can use this search pattern to describe what you are search for. A regular expression can be a single character, or a more complicated pattern.

​	Regular expressions can be used to perform all types of text search and text replace operations.

## 20.2 Syntax

​	In PHP, regular expressions are strings composed of delimiters, a pattern and optional modifiers.

```
$exp = "/characters/i";
```

​	In the example above, <span style="color:red;">/</span> is the <b>delimiter</b>, <i>characters</i> is the <b>pattern</b> that is being searched for, and <span style="color:red;">i</span> is a <b>modifier</b> that makes the search case-insensitive.

​	The delimiter can be any character that is not a letter, number, backslash or space. The most common delimiter is the forward slash (/), but when your pattern contains forward slashes it is convenient to choose other delimiters such as # or ~.

## 20.3 Regular Expression Functions

​	PHP provides a variety of functions that allow you to use regular expressions. The <span style="color:red;">preg_match()</span>, <span style="color:red;">preg_match_all()</span> and <span style="color:red;">preg_replace()</span> functions are some of the most commonly used ones:

| Function         | Description                                                  |
| :--------------- | :----------------------------------------------------------- |
| preg_match()     | Returns 1 if the pattern was found in the string and 0 if not |
| preg_match_all() | Returns the number of times the pattern was found in the string, which may also be 0 |
| preg_replace()   | Returns a new string where matched patterns have been replaced with another string |

### 20.3.1 Using preg_match()

```
$str = "Visit my home!";
$pattern = "/home/i";
echo preg_match($pattern, $str);	//1
```

### 20.3.2 Using preg_match_all()

```
$str = "The rain in SPAIN falls mainly on the plains.";
$pattern = "/ain/i";
echo preg_match_all($pattern, $str); // Outputs 4
```

### 20.3.3 Using preg_replace()

```
$str = "Visit Microsoft!";
$pattern = "/microsoft/i";
echo preg_replace($pattern, "W3Schools", $str); // Outputs "Visit W3Schools!"
```

## 20.4 Regular Expression Modifiers

​	Modifiers can change how a search is performed:

| Modifier | Description                                                  |
| :------- | :----------------------------------------------------------- |
| i        | Performs a case-insensitive search                           |
| m        | Performs a multiline search (patterns that search for the beginning or end of a string will match the beginning or end of each line) |
| u        | Enables correct matching of UTF-8 encoded patterns           |

## 20.5 Regular Expression Patterns

​	Brackets are used to find a range of characters:

| Expression | Description                                              |
| :--------- | :------------------------------------------------------- |
| [abc]      | Find one character from the options between the brackets |
| [^abc]     | Find any character NOT between the brackets              |
| [0-9]      | Find one character from the range 0 to 9                 |

## 20.6 Metacharacters

​	Metacharacters are characters with a special meaning:

| Metacharacter | Description                                                  |
| :------------ | :----------------------------------------------------------- |
| \|            | Find a match for any one of the patterns separated by \| as in: cat\|dog\|fish |
| .             | Find just one instance of any character                      |
| ^             | Finds a match as the beginning of a string as in: ^Hello     |
| $             | Finds a match at the end of the string as in: World$         |
| \d            | Find a digit                                                 |
| \s            | Find a whitespace character                                  |
| \b            | Find a match at the beginning of a word like this: \bWORD, or at the end of a word like this: WORD\b |
| \uxxxx        | Find the Unicode character specified by the hexadecimal number xxxx |

## 20.7 Quantifiers

​	Quantifiers define quantities:

| Quantifier | Description                                                  |
| :--------- | :----------------------------------------------------------- |
| n+         | Matches any string that contains at least one *n*            |
| n*         | Matches any string that contains zero or more occurrences of *n* |
| n?         | Matches any string that contains zero or one occurrences of *n* |
| n{x}       | Matches any string that contains a sequence of *X* *n*'s     |
| n{x,y}     | Matches any string that contains a sequence of X to Y *n*'s  |
| n{x,}      | Matches any string that contains a sequence of at least X *n*'s |

<b>Note:</b> If your expression needs to search for one of the special characters you can use a backslash (\\) to escape them. For example, to search for one or more question marks you can use the following expression: $pattern = '/\\?+/';

## 20.8 Grouping

​	You can use parentheses  <span style="color:red;">( )</span> to apply quantifiers to entire patterns. They also can be used to select parts of the pattern to be used as a match..

```
//Use grouping to searchh for the word "banana" by looking for ba followed by tow instances of na:
$str = "Apples and bananas.";
$pattern = "/ba(na){2}/i";
echo preg_match($pattern, $str); // Outputs 1
```



# 21. PHP Form Handling

​	The PHP superglobals $_GET and $\_POST are used to collect form-data.

## 21.1 PHP - A Simple HTML Form

​	The example below displays a simple HTML form with two input fields and a submit button:

```
<html>
<body>
<form action="welcome.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
<input type="submit">
</form>
</body>
</html>
```

​	When th user fills out the form above and clicks the submit button, the form data is sent for processing to PHP file named "welcome.php". The form data is sent with the HTTP POST method.

​	To display the submitted data you could simply echo all the variables. The "welcome.php" looks like this:

```
<html>
<body>
Welcome <?php echo $_POST["name"]; ?><br>
Your email address is: <?php echo $_POST["email"]; ?>
</body>
</html>
```

​	The same result could also be achieved usint the HTTP GET method (and php echo $_GET):

```
<html>
<body>
<form action="welcome_get.php" method="get">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
<input type="submit">
</form>
</body>
</html>
```

<b>Think SECURITY when processing PHP forms!</b>

​	This page does not contain any form validation, it just shows how you can send and retrieve form data. However, the next pages will show how to process PHP forms with security in mide! Proper validation of form data is important to protect your form from hackers and spammers!

## 21.2 GET vs. POST

​	Both GET and POST create an array (e.g. array(key1 => value1, key2 => value2, key3 => value3, ...)). This array holds key/value pairs, where keys are the names of the form controls and values are the input data from the user.

​	Both GET and POST are treated as $_GET and $\_POST. These are superglobals, which means that they are always accessible, regardless of scope - and you can access them from any function, class or file without having to do anything special.

​	$_GET is an array of variables passed to the current script via the URL parameters.

​	$_POST is an array of variables passed to the current script via the HTTP POST method.

## 21.3 When to use GET?

​	Information sent from a form with the POST method is <b>invisible to others</b> (all names/values are embedded within the body of the HTTP request) and has <b>no limits</b> on the amount of information to send.

​	Moreover POST supports advanced functionality such as support for multi-part binary input while uploading files to server. However, because the variables are not displayed in the URL, it is not possible to bookmark the page.

<b>Developers prefer POST for sending form data</b>.



# 22. PHP Form Validation

## 22.1 PHP Form Validation

​	The HTML form we will be working at in these chapters, contains various input fields: required and optional text fields, radio buttons, and a submit button:

<img src="img/form_validation.jpg">

​	The validation rules for the form above are as follows:

| Field   | Validation Rules                                             |
| :------ | :----------------------------------------------------------- |
| Name    | Required. + Must only contain letters and whitespace         |
| E-mail  | Required. + Must contain a valid email address (with @ and .) |
| Website | Optional. If present, it must contain a valid URL            |
| Comment | Optional. Multi-line input field (textarea)                  |
| Gender  | Required. Must select one                                    |

## 22.2 Text Fields

​	The name, email, and website fields are text input elements, and the comment field is a  textarea. The HTML code looks like this:

```
Name: <input type="text" name="name">
E-mail: <input type="text" name="email">
Website: <input type="text" name="website">
Comment: <textarea name="comment" rows="5" cols="40"></textarea>
```

## 22.3 Radio Buttons

​	The gender fields are radio buttons and the HTML code looks like:

```
Gender:
<input type="radio" name="gender" value="female">Female
<input type="radio" name="gender" value="male">Male
<input type="radio" name="gender" value="other">Other
```

## 22.4 The Form Element

​	The HTML code of the form looks like this:

```
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
```

​	When the form is submitted, the form data is sent with method="post".

<b>What is teh $_SERVER["PHP_SELF"] variable?</b>

​	The $_SERVER["PHP_SELF"] is a super global variable that returns the filename of the currently executing script.

​	So, the $_SERVER["PHP_SELF"] sends the submitted form data to the page itself, instead of jumping to a different page. This way, the user will get error messages on the same page as the form.

<b>What is the htmlspecialchars() function?</b>

​	This function converts special characters to HTML entities. This means that it will replace HTML characters like < and > with \&lt; and \&gt;. This prevents attackers from exploiting the code by injecting HTML or JavaScript code (Cross-site Scripting attacks) in forms.

## 22.5 Big Note on PHP Form Security

​	The $_SERVER["PHP_SELF"] variable can be used by hackers. If PHP_SELF is used in your  page then a user can enter a slash (/) and then some Cross Site Scripting (XSS) commands to execute.

<b>Cross-site-scripting (XSS) is a type of computer security vulnerability typically found in Web application. XSS enables attackers to inject client-side script into Web pages viewed by other users.</b>

​	Assume we have the following form in a page named "test_form.php":

```
<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
```

​	Now, if a user enters the normal URL in the address bar like "http://www.example.com/test_form.php", the above code will be translated to:

```
<form method="post" action="test_form.php">
```

​	So far, so good.

​	However, consider that a user enters the following URL in the address bar:

```
http://www.example.com/test_form.php/%22%3E%3Cscript%3Ealert('hacked')%3C/script%3E
```

​	In this case, the above code will be translated to:

```
<form method="post" action="test_form.php/"><script>alert('hacked')</script>
```

​	This code adds a script tag and an alert command. And when the page loads, the JavaScript code will be executed. This is just a simple and harmless example how the PHP_SELF variable can be exploited.

​	Be aware of that <b>any JavaScript code can be added inside the \<script> tag!</span>. A hacker can redirect the user to a file on another server, and that file can hold malicious code that can alter the global variables or submit the form to another address to save the user data, for example.

## 22.6 How To Avoid $_SERVER["PHP_SELF"] Exploits?

​	#_SERVER["PHP_SELF"] exploits can be avoided by using the htmlspecialchars() function. This function converts special characters to HTML entities. Now if the user tries to exploit the PHP_SELF variable, it will result in the following output:

```
<form method="post" action="test_form.php/&quot;&gt;&lt;script&gt;alert('hacked')&lt;/script&gt;">
```

## 22.7 Validate Form Data With PHP

​	The first thing we will do is to pass all variables through PHP's htmlspecialchars() function. We will also do two more things when the use submits the form:

1. Strip unnecessary characters (extra space, tab, newline) from the user input data (with the PHP trim() function)
2. Remove backslashed (\\) from the user input data (with the PHP stripslashes() function)

​	The next step is to create a function that will do all the checking for us (which is much more convenient than writing the same code over and over again).

​	We named the function test_input(). Now, we can check each $_POST variable with the test_input() like this:

```
<?php
// define variables and set to empty values
$name = $email = $gender = $comment = $website = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = test_input($_POST["name"]);
  $email = test_input($_POST["email"]);
  $website = test_input($_POST["website"]);
  $comment = test_input($_POST["comment"]);
  $gender = test_input($_POST["gender"]);
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
```

​	Notice that at the start of the script, we check whether the form has been submitted using $_SERVER["REQUEST_METHOD"]. If the REQUEST_METHOD is POST, then the form has been submitted - and it should be validated. If it has not been submitted, skip the validation and display a blank form. 

​	However, in the example above, all input fields are optional. The script works fine even if the user does not enter any data. The next step is to make input fields required and create error messages if needed.



## 23. PHP Forms - Required Fields

## 23.1 PHP - Required Fields

​	From the validation rules table on the previous page, we see that the "Name", "E-mail", and "Gender" fields are required. These fields cannot be empty and must be filled out in the HTML form.

​	In the following code we have added some new variables: $nameErr, $emailErr, $genderErr, and $websiteErr. These error variables will hold error messages for the required fields. We have also added an <span style="color:red;">if else</span> statement for each $_POST variable. This checks if the $\_POST variable is empty (with the PHP <span style="color:red;">empty()</span> function). If it is empty, an error message is stored in the different error variables, and if it is not empty, it sends the user input data through the <span style="color:red;">test_input()</span> function:

```
<?php
//define variables and set to empty values
$nameErr = $emailErr = $genderErr = $websiteErr = "";
$name = $email = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["name"])) {
		$nameErr = "Name is required";
	} else {
		$name = test_input($_POST["name"]);
	}
	if (empty($_POST["email"])) {
		$nameErr = "E-mail is required";
	} else {
		$name = test_input($_POST["email"]);
	}
	if (empty($_POST["website"])) {
		$nameErr = "Website is required";
	} else {
		$name = test_input($_POST["website"]);
	}
	if (empty($_POST["comment"])) {
		$nameErr = "Comment is required";
	} else {
		$name = test_input($_POST["comment"]);
	}
	if (empty($_POST["gender"])) {
		$nameErr = "Gender is required";
	} else {
		$name = test_input($_POST["gender"]);
	}
}
?>
```

## 23.2 PHP - Display The Erro Messages

​	Then in the HTML form, we add a little script after each required field, which generates the correct error message if needed (that is if the user tries to submit the form without filling out the requires fields):

```
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

Name: <input type="text" name="name">
<span class="error">*<?php echo $nameErr;?></span>
<br><br>
E-mail:<input type="text" name="email">
<span class="error">*<?php echo $emailErr;?></span>
<br><br>
Website:<input type="text" name="website">
<span class="error">*<?php echo $websiteErr;?></span>
<br><br>
Comment:<textarea name="comment" rows="5" cols="40"></textarea>
<br><br>
Gender:
<input type="radio" name="gender" value="female">Female
<input type="radio" name="gender" value="male">Male
<input type="radio" name="gender" value="other">Other
<span class="error">*<?php echo $genderErr;?></span>
<br><br>
<input type="submit" name="submit" value="Submit">
</form>
```

​	The next step is to validate the input data, that is "Does the Name field contain only letters and whitespace?", and "Does the E-mail field contain a valid e-mail address syntax?", and if filled out, "Does the Website field contain a valid URL?".



# 24. PHP Forms - Validate E-mail and URL

## 24.1 PHP - Validate Name

​	The code below shows a simple way to check if the name field only contains letters, dashed, apostrophes and whitespaces. If the value of the name field is not valid, then store an error message:

```
$name = test_input($_POST["name"]);
if (!preg_matchh("/^[a-zA-Z-' ]*$/", $name)) {
	$nameErr = "Only letters and white space allowed";
}
```

## 24.2 PHP - Validate E-mail

​	The easiest and safest way to check whether an email address is well-formed is to use PHP's filter_var() function.

​	In the code below, if the e-mail address is not well-formed, then store an error message:

```
$email = test_input($_POST["email"]);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
	$emailErr = "Invalid email format";
}
```

## 24.3 PHP - Validate URL

​	The code below shows a way to check if a URL address syntax is valid (this regular expression also allows dashes in the URL). If the URL address syntax is not valid, then stores an error message:

```
$website = test_input($_POST["website"]);
if (!preg_match("/\b(?:http?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i", $website)) {
	$website = "Invalid URL";
}
```

## 24.4 PHP - Validate Name, E-mal, and URL

​	Now, the script look like this:

```
<?php
// define variables and set to empty values
$nameErr = $emailErr = $genderErr = $websiteErr = "";
$name = $email = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }

  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

  if (empty($_POST["website"])) {
    $website = "";
  } else {
    $website = test_input($_POST["website"]);
    // check if URL address syntax is valid (this regular expression also allows dashes in the URL)
    if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website)) {
      $websiteErr = "Invalid URL";
    }
  }

  if (empty($_POST["comment"])) {
    $comment = "";
  } else {
    $comment = test_input($_POST["comment"]);
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}
?>
```

​	The next step is to show how to prevent the form from emptying all the input fields when the user submits the form.



# 25. PHP Complete Form Example

## 25.1 PHP - Keep The Values in The Form

​	To show the values in the input fields after the user hits the submit button, we add a little PHP script inside the value attribute of the following input fields: name, emial, and website. In the comment textarea field, we put the script between the \<textarea> and \</textarea> tags. The little script outputs the value of the $name, $email, $website, and $comment variables.

​	Then, we also need to show which radio button that was checked. For this, we must manipulate the checked attribute (not the value attribute for radio buttons):

```
Name: <input type="text" name="name" value="<?php echo $name;?>">
E-mail: <input type="text" name="email" value="<?php echo $email;?>">
Website: <input type="text" name="website" value="<?php echo $website;?>">
Comment: <textarea name="comment" rows="5" cols="40"><?php echo $comment;?></textarea>

Gender:
<input type="radio" name="gender"
<?php if (isset($gender) && $gender=="female") echo "checked";?>
value="female">Female
<input type="radio" name="gender"
<?php if (isset($gender) && $gender=="male") echo "checked";?>
value="male">Male
<input type="radio" name="gender"
<?php if (isset($gender) && $gender=="other") echo "checked";?>
value="other">Other
```



# 26. PHP Date and Time

## 16.1 The PHP Date() Function

​	The PHP <span style="color:red;">date()</span> function formats a timestamp to a more readable date and time.

<span style="font-size:20px;">Syntax</span>

```
date(format, timestamp);
```

| Parameter | Description                                                  |
| :-------- | :----------------------------------------------------------- |
| format    | Required. Specifies the format of the timestamp              |
| timestamp | Optional. Specifies a timestamp. Default is the current date and time |

<b>Note:</b> A timestamp is a sequence of characters, denoting the date and/or time at which a certain event occurred.

## 16.2 Get a Date

​	The required <i>format</i> parameter of the date() function specifies how to format the date (or time).

​	Here are some characters that are commonly used for dates:

* d - Represents the day of the month (01 to 31)
* m - Represents a month (01 to 12)
* Y - Represents a year (in four digits)
* l (lowercase 'L') - Represents the day of the week

​	Other characters, like "/", ".", or "-" can also be inserted between the characters to add additional formatting. The example below formats today's date in different ways:

```
<?php
echo "Today is " . date("Y/m/d") . "<br>";
echo "Today is " . date("Y.m.d") . "<br>";
echo "Today is " . date("Y-m-d") . "<br>";
echo "Today is " . date("l") . "<br>";
?>
```

## 16.3 PHP Tip - Automatic Copyright Year

​	Use the <span style="color:red;">date()</span> function to automatically update the copyright year on your website:

```
&copy; 2023-<?php echo date("Y");?>
```

## 16.4 Get a Time

​	Here are some characters that are commonly used for times:

* H - 24-hour format at an hour (00 to 23)
* h - 12-hour format at an hour with leading zeros (01 to 12)
* i - Minutes with leading zeros (00 to 59)
* s - Seconds with leading zeros (00 to 59)
* a - Lowercase Ante meridiem and Post meridiem (am or pm)

```
<?php
echo "The time is ". date("h:i:sa");
?>
```

## 16.5 Get Your Time Zone

​	If the time you got back from the code is not correct, it's probably because your server is in another country or set up for a different timezone. So, if you need the time to be correct according to specified location, you can set the timezone you want to use.

​	The example below sets the timezone to "America/New_York", then output the curreent time in the specified format:

```
date_default_timezone_set("America/New_York");
echo "The time is " . date("h:i:sa");
```

## 16.6 Create a Date With mktime()

​	The optional <i>timestamp</i> parameter in the date() function specifies a timestamp. If omitted, the current date and time will be used (as examples above).

​	The PHP <span style="color:red;">mktime()</span> function returns the Unix timestamp for a date. The Unix timestamp contains the number of seconds between the Unix Epoch (January 1 1970 00:00:00 GMT) and the time specified.

<span style="font-size:20px;">Syntax</span>

```
mktime(hour, minute, second, month, day, year);
```

​	The example below creates a date and time with the <span style="color:red;">date()</span> function from a number of parameters in the <span style="color:red;">mktime()</span> function:

```
$d = mktime(11,14,54,8,12,2011);
echo "Created date is " . date("Y-m-d d:i:sa", $d);
```

## 16.7 Create a Date from a String With strtotime()

​	The PHP <span style="color:red;">strtotime()</span> function is used to convert a human readable date string into a Unix timestamp.

<span style="font-size:20px;">Syntax</span>

```
strtotime(time, now);
```

```
$d = strtotime(10:30am April 15 2101);
echo "Created date is " . date("Y-m-d h:i:sa", $d);
```

​	PHP is quite clever about converting a string to a date, so you can put in various values:

```
$d=strtotime("tomorrow");
echo date("Y-m-d h:i:sa", $d) . "<br>";

$d=strtotime("next Saturday");
echo date("Y-m-d h:i:sa", $d) . "<br>";

$d=strtotime("+3 Months");
echo date("Y-m-d h:i:sa", $d) . "<br>";
```

​	However, <span style="color:red;">strtotime()</span> is not perfect, so remember to check the strings put there.

## 16.8 More Date Examples

​	The example below outputs the dates for the next six Saturdays:

```
$startdate = strtotime("Saturday");
$enddate = strtotime("+6 weeks", $startdate);

while ($startdate < $enddate) {
  echo date("M d", $startdate) . "<br>";
  $startdate = strtotime("+1 week", $startdate);
}
```

​	The example below outputs the number of days until 4th of July:

```
$d1=strtotime("July 04");
$d2=ceil(($d1-time())/60/60/24);
echo "There are " . $d2 ." days until 4th of July.";
```



# 17. PHP Include Files

​	The <span style="color:red;">include</span> (or <span style="color:red;">require</span>) statement takes all the text/code/markup that exists in the specified file and copies it into the file that uses the include statement.

​	Including files is very useful when you want to include the same PHP, HTML, or text on multiple pages of a website.

## 17.1 PHP include and require Statements

​	It is possible to insert the content of one PHP file into another PHP file (before the server executes it), with the include or require statement.

<b>The include and require statements are identical, except upon failure</b>:

* <span style="color:red;">require</span> will produce a fatal error (E_COMPILE_ERROR) and stop the script
* <span style="color:red;">incldue</span> will only produce a warning (E_WARNING) and the script will continue

​	So, if you want the execution to go on and show users the output, even if the include file is missing, use the include statement. Otherwise, in case of FrameWork, CMS, or a complex PHP application coding, always use the require statement to include a key file to the flow of execution. This will help avoid compromising your application's security and integrity, just in-case one key file is accidentally missing.

​	Including files saves a lot of work. This means that you can create a standard header, footer, or menu file for all your web pages. Then when the header needs to be updated, you can update the header include file..

<span style="font-size:20px;">Syntax</span>

```
include 'filename';
or
require 'filename';
```

## 17.2 PHP include Examples

<span style="font-size:20px;">Example 1</span>

​	Assume we have a standard footer file called "footer.php", that looks like this:

```
<?php
echo "<p>Copyright &copy; 2023-" . date("Y") . " ****</p>";
?>
```

​	To include the footer file in a page, use the <span style="color:red;">include</span> statement:

```
<html>
<body>
<h1>Welcome to my home page!</h1>
<p>Some text.</p>
<p>Some more text.</p>
<?php include 'footer.php';?>
</body>
</html>
```

<span style="font-size:20px;">Example 2</span>

​	Assume we have a standard menu file called "menu.php":

```
<?php
echo '<a href="/default.asp">Home</a> -
<a href="/html/default.asp">HTML Tutorial</a> -
<a href="/css/default.asp">CSS Tutorial</a> -
<a href="/js/default.asp">JavaScript Tutorial</a> -
<a href="default.asp">PHP Tutorial</a>';
?>
```

​	All pages in the Web site should use this menu file. Here is how it can be done (we are using a \<div> element so that the menu easily can be styled with CSS later):

```
<html>
<body>
<div class="menu">
<?php include 'menu.php';?>
</div>
<h1>Welcome to my home page!</h1>
<p>Some text.</p>
<p>Some more text.</p>
</body>
</html>
```

<span style="font-size:20px;">Example 3</span>

​	Assume we have a file called "vars.php", with some variables defined:

```
<?php
$color = 'red';
$car = 'BYD';
?>
```

​	Then, if we include the "vars.php" file, the variables can be used in the calling file:

```
<html>
<body>
<h1>Welcome to my home page!</h1>
<?php include 'vars.php';
echo "I have a $color $car.";
?>
</body>
</html>
```

## 17.3 PHP include vs. require

​	The <span style="color:red;">require</span> statement is also used to include a file into the PHP code:

```
<html>
<body>
<h1>Welcome to my home page!</h1>
<?php require 'noFileExists.php';	//fatal error
echo "I have a $color $car.";
?>
</body>
</html>
```



# 18. PHP File Handling

## 18.1 PHP Manipulating Files

​	PHP has several functions for creating, reading, uploading, and editing files.

<b>Be careful when manipulating files!</b>

​	When you are manipulating files you must be very careful. You can do a lot of damage if you do something wrong. Common errors are: editing the wrong file, filling a hard-drive with garbage data, and deleting the content of a file by accident.

## 18.2 PHP readfile() Function

​	The <span style="color:red;">readfile()</span> function reads a file and writes it to the output buffer.

​	Assume we have a text file called "webdictionary.txt", stored on the server, that looks like this:

```
AJAX = Asynchronous JavaScript and XML
CSS = Cascading Style Sheets
HTML = Hyper Text Markup Language
PHP = PHP Hypertext Preprocessor
SQL = Structured Query Language
SVG = Scalable Vector Graphics
XML = EXtensible Markup Language
```

​	The PHP code to read the file and write it to the output buffer is as follows (the <span style="color:red;">readfile()</span> function returns the number of bytes read on success):

```
<?php
echo readfile("webdictionary.txt");
?>
```

​	The <span style="color:red;">readfile()</span> function is useful if all you want to do is open a file and read its contents.



# 19. PHP File Open/Read/Close

## 19.1 PHP Open File - fopen()

​	A better method to open files is with the <span style="color:red;">fopen()</span> function. This function gives you more options than the <span style="color:red;">readfile()</span> funciton.

​	We will use the text file, "webdictionary.txt", during the lessons.

​	The first parameter of <span style="color:red;">fopen()</span> contains the name of the file to be opened and the second parameter specifies in which mode the file should be opened. The following example also generates a message if the fopen() function is unable to open the specified file:

```
<?php
$myfile = fopen("webdictionary.txt", "r") or die("Unable to open file!");
echo fread($myfile, filezize("webdictionary.txt"));
fclose($myfile);
?>
```

​	The file may be opened in one of the following modes:

| Modes | Description                                                  |
| :---- | :----------------------------------------------------------- |
| r     | **Open a file for read only**. File pointer starts at the beginning of the file |
| w     | **Open a file for write only**. Erases the contents of the file or creates a new file if it doesn't exist. File pointer starts at the beginning of the file |
| a     | **Open a file for write only**. The existing data in file is preserved. File pointer starts at the end of the file. Creates a new file if the file doesn't exist |
| x     | **Creates a new file for write only**. Returns FALSE and an error if file already exists |
| r+    | **Open a file for read/write**. File pointer starts at the beginning of the file |
| w+    | **Open a file for read/write**. Erases the contents of the file or creates a new file if it doesn't exist. File pointer starts at the beginning of the file |
| a+    | **Open a file for read/write**. The existing data in file is preserved. File pointer starts at the end of the file. Creates a new file if the file doesn't exist |
| x+    | **Creates a new file for read/write**. Returns FALSE and an error if file already exists |

## 19.2 PHP Read File - fread()

​	The <span style="color:red;">fread()</span> function reads from an open file.

​	The first parameter of <span style="color:red;">fread()</span> contains the name of the file to read from and the second parameter specifies the maximum number of bytes to read.

```
fread($myfile, filesize("webdictionary.txt"));
```

## 19.3 PHP Close File - fclose()

​	The <span style="color:red;">fclose()</span> function is used to close an open file.

<b>Note:</b> It is a good programming practice to close files after you have finished with them. You don't want an open file running around on your server taking up resources!

```
$myfile = fopen("webdictionary.txt");
fclose($myfile);
```

## 19.4 PHP Read Single Line - fgets()

​	The <span style="color:red;">fget()</span> function is used to read a single line from a file. The example below outputs the first line of the "webdictionary.txt" file:

```
$myfile = fopen("...") or die("...");
echo fgets($myfile);
fclose($myfile);
```

<b>Note:</b> After a call to the <span style="color:red;">fgets()</span> function, the file pointer has moved to the next line.

## 19.5 PHP Check End-Of-File - feof()

​	The <span style="color:red;">feof()</span> function checks if the "end-of-file" (EOF) has been reached. The <span style="color:red;">feof()</span> function is useful for looping through data of unknown length. The example below reads a file line by line, until end-of-file is reached:

```
$myfile = fopen("...") or die("...");
while(!feof($myfile)) {
	echo fgets($myfile); . "<br>";
}
fclose($myfile);
```

## 19.6 PHP Read Single Character - fgets()

​	The <span style="color:red;">fgetc()</span> function is used to read a single character from a file.

```
$myfile = open("webdictionary.txt", "r") or die("Unable to open");
while (!feof($myfile)) {
	echo fgetc($myfile) . " ";
}
fclose($myfile);
```

<b>Note:</b> As the <span style="color:red;">fgetc()</span> called, the file pointer move forward (to the next character).



# 20. PHP File Create/Write

## 20.1 PHP Create File - fopen()

​	The <span style="color:red;">fopen()</span> function is also used to create a file. Maybe a little confusing, but in PHP, a file is created using the same function used to open files. If you use <span style="color:red;">fopen()</span> on a file that does not exist, it will create it, give that the file is opened for writing (w) or appending (a).

​	The example below creates a new  file called "testfile.txt". The file will be created in the same directory where the PHP code resides:

```
$myfile = fopen("testfile.txt", "w");
```

## 20.2 PHP File Permissions

​	If you are having errors when trying to get this code to run, check that you have granted your PHP file access to write information to the hard drive.

## 20.3 PHP Write to File - fwrite()

​	The <span style="color:red;">fwrite()</span> function is used to write to a file. The first parameter of <span style="color:red;">fwrite()</span> contains the name of the file to write to and the second parameter is the string to be written.

​	The example below writes a couple of names into a new file:

```
<?php
$myfile = fopen("newfile.txt", "w") or die("Unable to open/create");
$txt = "John Doe\n";
fwrite($myfile, $txt);
$txt = "Joe Biden";
fwrite($myfile, $txt);
$fclose($myfile);
?>
```

​	Notice that we wrote to the file "newfile.txt" twice. Each time we wrote to the file we sent the string $txt that first contained "John Doe" and second contained "Joe Biden". After we finished writing, we close the file. If open the new file, it would look like this:

```
John Doe
Joe Biden
```

## 20.4 PHP Overwriting

​	Now that "newfile.txt" contains some data we can show what happens when we open an existing file for writing. All the existing data will be ERASED and we start with an empty file.

​	In the example below we open existing file "newfile.txt", and write some new data into it:

```
$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
$txt = "Mickey Mouse\n";
fwrite($myfile, $txt);
fclose($myfile);
```

​	The file now would look like:

```
Mickey Mouse
```

## 20.5 PHP Append Text

​	You can append data to a file by using the "a" mode. The "a" mode appends text to the end of the file, while the  "w" mode overrides (and erases) the old content of the file.

```
$myfile = fopen("newfile.txt", "a") or die("Unable to open file!");
$txt = "Donald Duck\n";
fwrite($myfile, $txt);
$txt = "Goofy Goof\n";
fwrite($myfile, $txt);
fclose($myfile);
```

​	Now the file should be:

```
Mickey Mouse
Donald Duck
Goofy Goof
```



# 21. PHP File Upload

​	With PHP, it is easy to upload files to the server.

​	However, with ease comes danger, so always be careful when allowing file uploads!

## 21.1 Configure The "php.ini" File

​	First, ensure that PHP is configured to allow file uploads. In you "php.ini" file, search for the <span style="color:red;">file_uploads</span> directive, and set it to On (in my php-fpm, vi /etc/php/8.1/fpm/php.ini):

```
file_uploads = On;
```

## 21.2 Create The HTML Form

​	Next, create an HTML form that allow users to choose the image file they want to upload:

```
<!DOCTYPE html>
<html>
<body>
        <form action="upload.php" method="post" enctype="multipart/form-data">
                Select image to upload:
                <span id="fileName"></span>
                <input type="file" name="fileToUpload" id="fileToUpload" onclick="showFile()">
                <br>
                <input type="submit" value="Upload Image" name="submit">
        </form>
        <script>
                function showFile() {
                  		const element = 			document.getElementById("fileToUpload");
                        const target = document.getElementById("fileName");
                        target.innerHTML = element.value;
                }
        </script>
</body>
</html>
```

​	Some rules to follow for the HTML form above:

* Make sue that the form uses method="post"
* The form also needs the following attribute: enctype="multipart/form-data". It specifies which content-type to use when submitting the form

​	Without the requirement above, the file upload will not work. Other things to notice:

* The type="file" attribute of the \<input> tag show the input field ass a file-select control, with a "Browse" button next to the input control

​	The form above sends data to a file called "upload.php", which will create next.

## 21.3 Create The Upload File PHP Script

​	The "upload.php" file contains the code for uploading a file:

```
<?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]); //not "name"
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}
?>
```

​	PHP script explained:

* $target_dir = "uploads/" - specifies the directory where the file is going to be placed
* $target_file specifies the path of the file to be uploaded
* $uploadOk = 1 is not used yet (used later)
* $imageFileType holds the file extension of the file (in lower case)
* Next, check if the image file is an actual image or a fake image

​	<b>Note:</b> You will need to create a new directory called "uploads" in the directory where "upload.php" file resides. The uploaded files will be saved there.

## 21.4 Check if File Already Exists

​	Now we can add some restrictions.

​	First, we will check if the file already exists in the "uploads" floder. If it does, an error message is displayed, and $uploadOk is set to 0:

```
if (file_exists($target_file)) {
	echo "The file with same name already exists.";
	$uploadOk = 0;
}
```

## 21.5 Limit File Size

```
if ($_FILES["fileToUpload"]["size"] > 5000000) {	//5MB
	echo "File to lareger than 5MB."
	$uploadOk = 0;
}
```

## 21.6 Limit File Type

```
if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
	echo "Only JPG, JPEG, PNG & GIF are allowed."
	$uploadOk = 0;
}
```

## 21.7 Complete Upload File PHP Script

```
<?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}
// Check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
?>
```



# 22. PHP Cookies

## 22.1 What is a Cookie?

​	A cookies is often used to identify a user. A cookies is a small file that the server embeds on the user's computer. Each time the same computer requests a page with a browser, it will send the cookies too. With PHP, you can both create and retrieve cookies values.

## 22.2 Create Cookies With PHP

​	A cookies is created with the <span style="color:red;">setcookie()</span> function.

<span style="font-size:20px;">Syntax</span>

```
setcookie(name, value, expire, path, domain, secure, httponly);
```

​	Only the name parameter is required. All other parameters are optional.

## 22.3 PHP Creaet/Retrieve a Cookie

​	The following example creates a cookies named "user" with the value "Donald Trump". The cookie will expire after 30 days (86400 * 30). The "/" means that the cookie is available in entire website (otherwise, select the directory you prefer).

​	When then retrieve the value of the cookis "user" (using the global variable $_COOKIE). We also use the <span style="color:red;">isset()</span> function to find out if the cookie is set:

```
<?php
$cookie_name = "user";
$cookie_value = "Donald Trump";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
?>
<html>
<body>
<?php
if (!isset($_COOKIE[$cookie_name])) {
	echo "Cookie name " . $cookie_name . " is not set.";
} else {
	echo "Cookie name " . $cookie_name . " is set.<br>";
	echo "Value is " . $_COOKIE[$cookie_name];
}
?>
</body>
</html>
```

<b>Note:</b> The <span style="color:red;">setCookie()</span> function must appear BEFORE the \<html> tag.

<b>NOTE:</b> The value of the cookie is automatically URLencoded when sending the cookie, and automatically decoded when received (to prevent URLencoding, use <span style="color:red;">setrawcookie()</span> instaed).

## 22.4 Modify a Cookie Value

​	To modify a cookie, just set (again) the cookie use the <span style="color:red;">setcookie()</span> function:

```
setcookie($cookie_name, $cookie_newvalue, time() + (86400 * 30), "/");
```

## 22.5 Delete a Cookies

​	To delete a cookie, use the <span style="color:red;">setcookie()</span> function with an expiration date in the past:

```
setcookie($cookie_name, "", time() - 1);
```

## 22.6 Check if Cookies are Enabled

​	The following example creates a small script that checks whether cookies are enabled. First, try to create a test cookie with the <span style="color:red;">setcookie()</span> function, then count the $_COOKIE array available:

```
<?php
setcookie("test_cookie", "test", time() + 3600, "/");
?>
<html>
<body>
<?php
if (count($_COOKIE) > 0) {
	echo "Cookies are enabled.";
} else {
	echo "Cookies are disabled.";
}
?>
</body>
</html>
```



# 23. PHP Sessions

​	A session is a way to store information (in variables) to be used across multiple pages.

​	Unlike a cookie, the information is not stored on the user computer.

## 23.1 What is a PHP Session?

​	When you work with an application, you open it, do some changes, and then you close it. This is much like a Session. The computer knows who you are. It knows when you start the application and when you end. But on the internet there is one problem: the web server does not know who you are or what you do, because the HTTP address doesn't maintain state.

​	Session variables solve this problem by storing user information to be used across multiple pages (e.g. username, favorite color, etc). By default, session variables last until the use closes the browser.

​	So; Session variables hold information about one single user, and are available to all pages in one application.

<b>Tip:</b> If you need a permanent storage, you may want to store the data in a database or in files.

## 23.2 Start a PHP Session

​	A session is started with the <span style="color:red;">session_start()</span> function. Sessions variables are set with the PHP global variables: $_SESSION.

​	Now, let's create a new page called "demo_session1.php". In this page, we start a new PHP session and set some session variables.

```
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>
<?php
$_SESSION["favvolor"] = "green";
$_SESSION["favanimal"] = "cat";
echo "Session variables are set.";
?>
</body>
</html>
```

​	<b>Note:</b> The <span style="color:red;">session_start()</span> function also must be the very first thing in document, that is before any HTML tags.

## 23.3 Get PHP Session Variable Values

​	Next, we create another page named "demo_session2.php". From this page, we will access the session information we set on the first page.

​	Notice that session variables are not passed individually to each new page, instead they are retrieved from the session we open at the beginning of each page (<span style="color:red;">session_start()</span>).

​	Also notice that all session variable values are stored in the global $_SESSION variable:

```
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>
echo "Favorite color is " . $_SESSION["favcolor"] . " .<br>";
echo "favorite animal is " . $_SESSION["favanimal"] . " .<br>";
</body>
</html>
```

​	Another way to show all the session variable values for a user session is to run the following code:

```
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>
<?php
print_r($_SESSION);
?>
</body>
</html>
```

<b>How does it work? How does it know it's me?</b>

​	Most sessions set a user-key on the user's computer that looks something like this: 65487cf34ert8dede5a562e4f3a7e12. Then, when a session is opened on another page, it scans the computer for a user-key. If there is a match, it accesses that session, if not, is starts a new session.

## 23.4 Modify a PHP Session Variable

​	To change a session variable, just overwrite it:

```
$_SESSION["favcolor"] = "yellow";
print_r($_SESSION);
```

## 23. 5 Destroy a PHP Session

​	Th remove all global session variables and destroy the session, use <span style="color:red;">session_unset()</span> and <span style="color:red;">session_destroy()</span>:

```
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>
<?php
// remove all session variables
session_unset();
// destroy the session
session_destroy();
?>
</body>
</html>
```



# 24. PHP Filters

​	Validating data = Determine if the data is in proper form.

​	Sanitizing data = Remove any illegal character from the data.

## 24.1 The PHP Filter Extension	

​	PHP filters are used to validate and sanitize external input.

​	The PHP filter extension has many of the function needed for checking user input, and is designed to make data validation easier and quicker. The <span style="color:red;">filter_list()</span> function can be used to list what the PHP filter extension offers:

```
<table>
	<tr>
		<td>Filter Name</td>
		<td>Filter Id</td>
	</tr>
	<?php
	foreach (filter_list() as $id => $filter) {
		echo '<tr><td>' . $filter . '</td><td>' . filter_id($filter) . "</td></tr>";
	}
	?>
</table>
```

## 24.2 Why Use Filters?

​	Many web application receive external input. External input/data can be:

* User input from a form
* Cookies
* Web service data
* Server variables
* Database query resultls

<b>You should always validate external data?</b>

​	Invalid submitted data can lead to security problems and break your webpage! By using PHP filters you can be sure your application gets the correct input!

## 24.3 PHP filter_var() function

​	The <span style="color:red;">filter_var()</span> function both validate and sanitize data.

​	Tis function filters a single variable with a specified filter. It takes two pieces of data:

* The variable you want to check
* The type of check to use

## 24.4 Sanitize a String

​	The following example use the <span style="color:red;">filter_var()</span> function to remove all HTML tags from a string:

```
<?php
$str = "<h1>This is a header</h1>";
$newstr = filter_var($str, FILTER_SANNTIZE_STRING);
echo $newstr;
?>
```

## 24.5 Validate an Integer

​	The following example uses the <span style="color:red;">filter_var()</span> function to check if the variable $int is a integer (why ! && false?).

```
<?php
$int = 100;
if (!filter_var($int, FILTER_VALIDATE_INT) === false) {
  echo("Integer is valid");
} else {
  echo("Integer is not valid");
}
?>
```

<b>Tipe:</b> filter_var() and Problem With 0

​	In the example above, if $int was set to 0, the function will return "Integer is not valid". To solve this:

```
<?php
$int = 0;

if (filter_var($int, FILTER_VALIDATE_INT) === 0 || !filter_var($int, FILTER_VALIDATE_INT) === false) {
  echo("Integer is valid");
} else {
  echo("Integer is not valid");
}
?>
```

## 24.6 Validate an IP Address

```
<?php
$ip = "127.0.0.1";
if (!filter_var($ip, FILTER_VALIDATE_IP) === false) {
  echo("$ip is a valid IP address");
} else {
  echo("$ip is not a valid IP address");
}
?>
```

## 24.7 Sanitize and Validate an Email Address

​	The following example uses the <span style="color:red;">filter_vara()</span> function to remove illegal characters form the variable, then check if it is a valid email address:

```
<?php
$email = "john.doe@example.com";
// Remove all illegal characters from email
$email = filter_var($email, FILTER_SANITIZE_EMAIL);
// Validate e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
  echo("$email is a valid email address");
} else {
  echo("$email is not a valid email address");
}
?>
```

## 24.8 Sanitize and Validate a URL

```
<?php
$url = "https://www.w3schools.com";
// Remove all illegal characters from a url
$url = filter_var($url, FILTER_SANITIZE_URL);
// Validate url
if (!filter_var($url, FILTER_VALIDATE_URL) === false) {
  echo("$url is a valid URL");
} else {
  echo("$url is not a valid URL");
}
?>
```



# 25. PHP Filters Advanced

## 25.1 Validate an Integer Within a Range

​	The following example uses the <span style="color:red;">filter_var()</span> function to check if a variable is both of type INT, and between 1 and 200:

```
<?php
$int = 122;
$min = 1;
$max = 200;
if (filter_var($int, FILTER_VALIDATE_INT, array(
	"option" => array("min_range"=>$min, "max_range"=>$max)
	)) == false) {
		echo("Variable value is not within the legal range");
	} else {
		echo("Variable value is within the legal range");
	}
?>
```

## 25.2 Validate IPv6 Address

​	The following example uses the <span style="color:red;">filter_var()</span> function to check if the variable $ip is a valid IPv6 address:

```
<?php
$ip = "2001:0db8:85a3:08d3:1319:8a2e:0370:7334";
if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) === false) {
  echo("$ip is a valid IPv6 address");
} else {
  echo("$ip is not a valid IPv6 address");
}
?>
```

## 25.3 Validate URL - Must Contain QueryString

​	To check if the variable $url is a URL with a querystring:

```
<?php
$url = "https://www.w3schools.com";
if (!filter_var($url, FILTER_VALIDATE_URL, FILTER_FLAG_QUERY_REQUIRED) === false) {
  echo("$url is a valid URL with a query string");
} else {
  echo("$url is not a valid URL with a query string");
}
?>
```

## 25.4 Remove Characters With ASCII Value > 127

​	Uses the <span style="color:red;">filter_var()</span> function to sanitize a string, it will both remove all HTML tags, and all characters with ASCII value > 127:

```
<?php
$str = "<h1>Hello WorldÆØÅ!</h1>";
$newstr = filter_var($str, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
echo $newstr;
?>
```



# 26. PHP Callback Functions

## 26.1 Callback Functions

​	A callback function (often referred to as just "callback") is a function which is passed as an argument into another function.

​	Any existing function can be used as a callback function. To use a function as a callback, pass a string containing the name of the function as the argument of another function:

```
//Pass a callback to PHP's array_map() function too calculate the lengthh of every string in a array:
<?php
function my_callback($item) {
	return strlen($item);
}
$strings = ["apple", "orange", "banana", "coconut"];
$lengths = array_map("my_callback", $strings);
print_r($lengths);
?>
```

​	Starting with versio 7, PHP can pass anonymous function as callback:

```
$lengths = array_map(function($item) {return strlen($item);},
	$strings);
```

## 26.2 Callback is User Defined Functions

​	User-defined functions and method can also take callback functions as arguments. To use callback functions inside a user-defined function or method, call it by adding parentheses to the variable and pass arguments as with normal functions:

```
<?php
function exclaim($str) {
	return $str . "! ";
}
function ask($str) {
	return $str . "? ";
}
function printFormated($str, $format) {
	echo $format($str);
}
printFormated("Hello", "exclaim");
printFormated("Hello", "ask");
?>
```



# 27. PHP and JSON

## 27.1 PHP and JSON

​	PHP has some built-in functions to handle JOSN, first, we will look at the following two:

* <span style="color:red;">json_encode()</span>
* <span style="color:red;">json_decode()</span>

## 27.2 PHP -json_encode()

​	The <span style="color:red;">json_encode()</span> function is used to encode a value to JSON format (pay attention to "to"):

```
//Encode an associative array into JSON object:
$age = array("Peter"=>32, "Ben"=>13, "Joe"=>87);
echo json_encode($age);	//{"Peter":32,"Ben":13,"Joe":87}
```

```
//Encode an indexed array into JSON array (NOT object!):
$cars = array("Volvo", "BYD", "Toyota");
echo json_encode($cars);	//["Volvo","BYD","Toyota"]
```

<b>Note:</b> The first encode to a JSON object and the second one to JSON array.

## 27.3 PHP - json_decode()

​	The <span style="color:red;">json_decode()</span> function is used to decode a JSON object into a PHP object or an associative array:

```
//Decode JSON data into a PHP object:
$jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';
var_dump(json_decode($jsonobj)); //object(stdClass)#1 (3) { ["Peter"]=> int(35) ["Ben"]=> int(37) ["Joe"]=> int(43) }
```

​	The <span style="color:red;">json_decode()</span> function returns an object by default. The <span style="color:red;">json_decode()</span> function has a second parameter, and when set to true, JOSN objects are decoded into associative array:

```
$jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';
var_dump(json_decode($jsonobj, true));	//array(3) { ["Peter"]=> int(35) ["Ben"]=> int(37) ["Joe"]=> int(43) }
```

## 27.4 PHP - Accessing the Decoded Values

​	Here are two examples of how to access the decoded values from an object and from an associative array:

```
//Access the values from a PHP object:
$jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';
$obj = json_decode($jsonobj);
echo $obj->Peter;
echo $obj->Ben;
echo $obj->Joe;
```

```
//Access the values from a PHP associative array:
$jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';
$arr = json_decode($jsonobj, true);
echo $arr["Peter"];
echo $arr["Ben"];
echo $arr["Joe"];
```

## 27.5 PHP - Looping Through the Values

​	You can also loop through the values with a <span style="color:red;">foreach()</span> loop:

```
//Loop through the values of a PHP object:
$jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';
$obj = json_decode($jsonobj);
foreach($obj as $key => $value) {
  echo $key . " => " . $value . "<br>";
}
```

```
//Loop through the values of a PHP associative arry, similar to object:
$jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';
$arr = json_decode($jsonobj, true);
foreach($arr as $key => $value) {
  echo $key . " => " . $value . "<br>";
}
```



# 28. PHP Exceptions

## 28.1 What is an Exception?

​	An exception is an object that describes an error unexpected behaviour of a PHP script.

​	Exceptions are thrown by many PHP functions and classes. User defined functions and classes can also throw exceptions. Exceptions are a good way to stop a function when it comes across data that it cannot use.

## 28.2 Throwing an Exception

​	The <span style="color:red;">throw</span> statement allows a user defined function or method  to throw an exception. When an exception is thrown, the code following it will not be executed.

​	If an exception is not caught, a fatal error will occur with an "Uncaught Exception" message. Lets try to thrown an exception without catching it:

```
<?php
function divide($dividend, $divisor) {
	if($divisor == 0) {
		throw new Exception("Division by zero");
	}
	return $dividend / $divisor;
}
echo divide(5, 0);
?>
```

​	The result will look something like this:

```
Fatal error: Uncaught Exception: Division by zero in C:\...\test.php:4
Stack trace: #0 C:\...\test.php(9):
divide(5, 0) #1 {main} throw in C:\...\test.php on line 4
```

## 28.3 The try...catch Statement

​	To avoid the error from the example above, we can use the <span style="color:red;">try...catch</span> statement to catch exceptions and continue the process.

<span style="font-size:20px;">Syntax</span>

```
try {
	code that can throw exceptions
} catch(Exception $e) {
	code that runs when an exception is caught
}
```

```
<?php
function divide($dividend, $divisor) {
	if($divisor == 0) {
		throw new Exception("Division by zero");
	}
	return $dividend / $divisor;
}
try {
	echo divide(5, 0);
} catch (Exception $e) {
	echo "Unable to divide.";
}
?>
```

​	The catch block indicates what type of exception should be caught and the name of the variable which can be used to access the exception. In the example above, the type of exception is <span style="color:red;">Exception</span> and the variable name is <span style="color:red;">$e</span>.

## 28.4 The try...catch...finally Statement

​	The <span style="color:red;">try...catch...finally</span> statement can be used to catch exceptions. Code in the <span style="color:red;">finally</span> block will always run regardless of whether an exception was caught. If <span style="color:red;">finally</span> is present, the <span style="color:red;">catch</span> block is optional.

<span style="font-size:20px;">Syntax</span>

```
try {
	code that can throw exceptions
} catch(Exception $e) {
	code that runs when an exception is caught
} finally {
	code that always runs ragardless or whether an excepption was caught
}
```

```
<?php
function divide($dividend, $divisor) {
  if($divisor == 0) {
    throw new Exception("Division by zero");
  }
  return $dividend / $divisor;
}
try {
  echo divide(5, 0);
} catch(Exception $e) {
  echo "Unable to divide. ";
} finally {
  echo "Process complete.";
}
?>
```

```
<?php
function divide($dividend, $divisor) {
  if($divisor == 0) {
    throw new Exception("Division by zero");
  }
  return $dividend / $divisor;
}
try {
  echo divide(5, 0);
} finally {
  echo "Process complete.";
}
?>
```

## 28.5 The Exception Object

​	The Exception Object contains information about the error or unexpected behaviour that the function encountered.

<span style="font-size:20px;">Syntax</span>

```
new Exception(message, code, previous)
```

<span style="font-size:20px;">Parameter Values</span>

| Parameter | Description                                                  |
| :-------- | :----------------------------------------------------------- |
| message   | Optional. A string describing why the exception was thrown   |
| code      | Optional. An integer that can be used used to easily distinguish this exception from others of the same type |
| previous  | Optional. If this exception was thrown in a catch block of another exception, it is recommended to pass that exception into this parameter |

<span style="font-size:20px;">Methods</span>

​	When catching an exception, the following table shows some of the methods that can be used to get information about the exception:

| Method        | Description                                                  |
| :------------ | :----------------------------------------------------------- |
| getMessage()  | Returns a string describing why the exception was thrown     |
| getPrevious() | If this exception was triggered by another one, this method returns the previous exception. If not, then it returns *null* |
| getCode()     | Returns the exception code                                   |
| getFile()     | Returns the full path of the file in which the exception was thrown |
| getLine()     | Returns the line number of the line of code which threw the exception |

```
//Output information about an exception that was thrown:

```



# 29. PHP - What is OOP?

​	From PHP5, you can also write PHP code in an object-oriented style. Object-oriented programming is faster and easier to execute.

## 29.1 PHP What is OOP?

​	OOP stands for Object-Oriented Programming.

​	Procedural programming is about writing procedures or functions that perform operations on the data, while object-oriented programming is about creating objects that contains both data and functions.

​	Object-oriented programming has several advantages over procedural programming:

* OOP is faster and easier to execute
* OOP provides a clear structure for the programs
* OOP helps to keep the PHP code DRY "Don't Repeat Yourself", and makes the code easier to maintain, modify and debug
* OOP makes it possible to create full reusable applications with less code and shorter development time

​	<b>Tip:</b> The "Don't Repeat Yourself" (DRY) principle is about reducing the repetition of code. You should extract out the codes that are common for the application, and place them at a single place and reuse them instead of repeating it.

## 29.2 PHP - What are Classes and Objects

​	Classes and objects are the two main aspects of object-oriented programming.

​	Look at the following illustration to see the difference between class and object:

<img src="img/class_object.jpg">

​	So, a class is a template for objects, and an object is an instance of a class.

​	When the individual objects are created, they inherit all the properties and behaviour from the class, but each object will have different values for the properties.



# 30. PHP OOP - Classes and Objects

​	A class is a template for objects, and an object is an instance of class.

## 30.1 OOP Case

​	Let's assume we have a class named Fruit. A fruit can have properties like name, color, weight, etc. We can define variables like $name, $color, and $weight to hold the values of these properteis.

​	When the individual objects (apple, banana, etc) are created, they inherit all the properties and behaviors from the class, but each object will have different values for the properties.

## 30.2 Define a Class

​	A class is defined by using the <span style="color:red;">class</span> keyword, followed by the name of the class and a pair of curly braces ({ }). All its properties and methods go inside the braces:

```
<?php
class Fruit {
	//Properties
	public $name;
	public $color;
	//Methods
	function set_name($name) {
		$this->name = $name;
	}
	function get_name() : string {	//Doest it corrected?
		return $this->name;
	}
}

?>
```

<b>Note:</b> In a class, variables are called properties and functions are called methods.

## 30.3 Define Objects

​	Classes are nothing without objects! We can create multiple objects from a class. Each object has all the properties and methods defined in the class, but they will have different property values. Objects of a class are created using the <span style="color:red;">new</span> keyword.

​	In the example below, $apple and $banana are instances of the class Fruit:

```
$apple = new Fruit();
$banana = new Fruit();
$apple->set_name('Apple');
$banana->set_name("Banana");
```

## 30.4 PHP - The $this Keyword

​	The $this is not a variable but a keyword (?), it refers to the current object, and is only available inside methods.

## 30.5 PHP - instanceof

​	You can use the <span style="color:red;">instanceof</span> keyword to check if an object belongs to a specific class:

```
$apple = new Fruit();
var_dump($apple instanceof Fruit);	//bool(true)
```



# 31. PHP OOP - Constructor

## 31.1 PHP -  The __construct Function

​	A constructor allows you to initialize an object's properties upon creation of the object.

​	If you create a <span style="color:red;">__construct()</span> function, PHP automatically call this function when you create an object from a class. Notice that the contsruct function starts with two underscores(\_\_).

```
<?php
class Fruit {
  public $name;
  public $color;
  function __construct($name) {
    $this->name = $name;
  }
  function get_name() {
    return $this->name;
  }
}
$apple = new Fruit("Apple");
echo $apple->get_name();
?>
```

​	You can also appoint a default argument (optional argument) to the constructor:

```
<?php
class Fruit {
        public $name;
        public $color;
        function __construct($name, $color = "green") {
                $this->name = $name;
                $this->color = $color;
        }
};
$apple = new Fruit("Apple");
echo $apple->color;
?>

```



# 32. PHP OOP - Destructor

## 32.1 PHP - The __destruct Function

​	A destructor is called when the object is destructed or the script is stopped or exited.

​	If you create a <span style="color:red;">__destruct()</span> function, PHP will automatically call this at the end of the script.

```
<?php
class Fruit {
  public $name;
  public $color;
  function __construct($name) {
    $this->name = $name;
  }
  function __destruct() {
    echo "The fruit is {$this->name}.";
  }
}
$apple = new Fruit("Apple");
?>
```

<b>Tip:</b> As constructors and destructors helps reducing the amount of code, they are very useful!



## 33. PHP OOP - Access Modifiers

## 33.1 PHP - Access Modifiers

​	Properties and methods can have access modifiers which control where they can be accessed.

​	There are three access modifiers:

* <span style="color:red;">public</span> - the property or method can be accessed from everywhere (where the class can be accessed). This is default
* <span style="color:red;">protected</span> - the property or method can be accessed within the class and by classes derived from that class
* <span style="color:red;">private</span> - the property or method can ONLY be accessed within the class

```
<?php
class Fruit {
  public $name;
  protected $color;
  private $weight;
}
$mango = new Fruit();
$mango->name = 'Mango'; // OK
$mango->color = 'Yellow'; // ERROR
$mango->weight = '300'; // ERROR
?>
```

```
<?php
class Fruit {
  public $name;
  public $color;
  public $weight;

  function set_name($n) {  // a public function (default)
    $this->name = $n;
  }
  protected function set_color($n) { // a protected function
    $this->color = $n;
  }
  private function set_weight($n) { // a private function
    $this->weight = $n;
  }
}
$mango = new Fruit();
$mango->set_name('Mango'); // OK
$mango->set_color('Yellow'); // ERROR
$mango->set_weight('300'); // ERROR
?>
```



# 34. PHP OOP - Inheritance

## 34.1 PHP - What is Inheritance?

​	Inheritance in OOP = When a class derives from another class.

​	The child class will inherit all the public and protected properties and methods from the parent class. In addition, it can have its own properties and methods.

​	An inherited class is defined by using the <span style="color:red;">extends</span> keyword.

```
<?php
class Fruit {
  public $name;
  public $color;
  public function __construct($name, $color) {
    $this->name = $name;
    $this->color = $color;
  }
  public function intro() {
    echo "The fruit is {$this->name} and the color is {$this->color}.";
  }
}
// Strawberry is inherited from Fruit
class Strawberry extends Fruit {
  public function message() {
    echo "Am I a fruit or a berry? ";
  }
}
$strawberry = new Strawberry("Strawberry", "red");
$strawberry->message();
$strawberry->intro();
?>
```

<span style="font-szie:20px;">Example Explained</span>

​	The Strawberry class is inherited from the Fruit class.

​	This means that the Strawberry class can use the public $name and $color properties as well as the public __construct() and intro() methods from the Fruit class.

## 34.2 PHP - Inheritance and the Protected Access Modifier

​	In the previous chapter we learned that <span style="color:red;">protected</span> properties or methods can be accessed within the class and by classes derived from that class. What does that mean?

​	Let's look at an example:

```
<?php
class Fruit {
  public $name;
  public $color;
  public function __construct($name, $color) {
    $this->name = $name;
    $this->color = $color;
  }
  protected function intro() {
    echo "The fruit is {$this->name} and the color is {$this->color}.";
  }
}
class Strawberry extends Fruit {
  public function message() {
    echo "Am I a fruit or a berry? ";
  }
}
// Try to call all three methods from outside class
$strawberry = new Strawberry("Strawberry", "red");  // OK. __construct() is public
$strawberry->message(); // OK. message() is public
$strawberry->intro(); // ERROR. intro() is protected
?>
```

​	In the example above we see that if we try to call a <span style="color:red;">protected</span> method (intro()) form <span style="color:blue;">outside the class, we will receive an error</span>.

​	Let's look at another example:

```
<?php
class Fruit {
  public $name;
  public $color;
  public function __construct($name, $color) {
    $this->name = $name;
    $this->color = $color;
  }
  protected function intro() {
    echo "The fruit is {$this->name} and the color is {$this->color}.";
  }
}
class Strawberry extends Fruit {
  public function message() {
    echo "Am I a fruit or a berry? ";
    // Call protected method from within derived class - OK
    $this -> intro();
  }
}
$strawberry = new Strawberry("Strawberry", "red"); // OK. __construct() is public
$strawberry->message(); // OK. message() is public and it calls intro() (which is protected) from within the derived class
?>
```

​	In the example above we see that all works fine! It is because we call the <span style="color:red;">protected</span> method from inside the derived class.

## 34.3 PHP - Overriding Inherited  Methods

​	Inherited methods can be overridden by redefining the methods (use the same name) in the child class.

​	Look at the example below. The __construct() and intro() method in the child class will override the \_\_construct() and intro() methods in the parent class:

```
<?php
class Fruit {
  public $name;
  public $color;
  public function __construct($name, $color) {
    $this->name = $name;
    $this->color = $color;
  }
  public function intro() {
    echo "The fruit is {$this->name} and the color is {$this->color}.";
  }
}
class Strawberry extends Fruit {
  public $weight;
  public function __construct($name, $color, $weight) {
    $this->name = $name;
    $this->color = $color;
    $this->weight = $weight;
  }
  public function intro() {
    echo "The fruit is {$this->name}, the color is {$this->color}, and the weight is {$this->weight} gram.";
  }
}
$strawberry = new Strawberry("Strawberry", "red", 50);
$strawberry->intro();
?>
```

## 34.4 PHP - The final Keyword

​	The <span style="color:red;">final</span> keyword can be used to prevent class inheritance or to prevent method overriding. The follow example shows how to prevent class inheritance:

```
<?php
final class Fruit {
  // some code
}
// will result in error
class Strawberry extends Fruit {
  // some code
}
?>
```

​	The following example shows how to prevent method overriding:

```
<?php
class Fruit {
  final public function intro() {
    // some code
  }
}
class Strawberry extends Fruit {
  // will result in error
  public function intro() {
    // some code
  }
}
?>
```



# 35. PHP OOP - Class Constants

## 35.1 PHP - Class Contants

​	Constants cannot be changed once it is declared.

​	Class constants can be useful if you need to define some constant data within a class. A class constant is declared inside a class with the <span style="color:red;">const</span> keyword.

​	Class constants are case-sensitive. However, it is recommended to name the constants in all uppercase letters.

​	We can access a constant from outside the class by using the class name followed by the scope resolution operator ( <span style="color:red;">:: </span>) followed by the constant name, like here:

```
<?php
class Goodbye {
	const LEAVING_MESSAGE = "Thank you for your love.";
}
echo Goodbyd::LEAVING_MESSAGE;
?>
```

​	Or, we can access a constant from inside the class by using the <span style="color:red;">self</span> keyword followed by the scope resolution operator followed by the constant name, like here:

```
class Goodbye {
	const LEAVING_MESSAGE = "Thank you for your love.";
	public function byebye() {
		echo self::LEAVING_MESSAGE;
	}
}
$goodbye = new Goobdye();
$goodbye->byebye();
```



# 36. PHP OOP - Abstract Classes

## 36.1 PHP - What are Abstract Classes and Methods

​	Abstract classes and methods are when the parent class has a named method, but need its child class(es) to fill out the tasks.

​	An abstract class is a class that contains at least one abstract method. An abstract method is a method that is declared, but not implemented in the code.

​	An abstract class or method is defined withe the <span style="color:red;">abstract</span> keyword:

```
//Syntax:
abstract class ParentClass {
	abstract public function someMethod1();
	abstract public function someMethod2($name, $color);
	abstract public function someMethod3() : string;
}
```

​	<b>NOTE:</b>When inheriting from an abstract class, the child class method must be defined with the same name, and the same or a less restricted access modifier. So, if the abstract method is defined as protected, the child class method must be defined as either protected or public,  but not private. Also, the type and number of required arguments must be the same. However, the child classes may have optional arguments in addition.

​	So, when a child class is inherited from an abstract class, we have the following rules:

* The child class method must be defined with the same name and it redeclares the parent abstract method
* The child class method must be defined with the same or a less restricted access modifier
* The number of required argument must be the same. However, the child class may have optional arguments in addition

```
<?php
// Parent class
abstract class Car {
  public $name;
  public function __construct($name) {
    $this->name = $name;
  }
  abstract public function intro() : string;
}
// Child classes
class Audi extends Car {
  public function intro() : string {
    return "Choose German quality! I'm an $this->name!";
  }
}
class Volvo extends Car {
  public function intro() : string {
    return "Proud to be Swedish! I'm a $this->name!";
  }
}
class Citroen extends Car {
  public function intro() : string {
    return "French extravagance! I'm a $this->name!";
  }
}
// Create objects from the child classes
$audi = new audi("Audi");
echo $audi->intro();
echo "<br>";
$volvo = new volvo("Volvo");
echo $volvo->intro();
echo "<br>";
$citroen = new citroen("Citroen");
echo $citroen->intro();
?>
```

<span style="font-size:20px;">Example Explained</span>

​	The Audi, Volvo, and Citroen classes are inherited from the Car class. This means that the Audi, Volvo, and Citroen classes can use the public $name property as well as the public __construct() method from the Car class because of inheritance.

​	But, intro() is an abstract method that should be defined in all the child classes and they should return a string.

## 36.2 PHP - More Abstract Class Examples

```
<?php
abstract class ParentClass {
  // Abstract method with an argument
  abstract protected function prefixName($name);
}

class ChildClass extends ParentClass {
  public function prefixName($name) {
    if ($name == "John Doe") {
      $prefix = "Mr.";
    } elseif ($name == "Jane Doe") {
      $prefix = "Mrs.";
    } else {
      $prefix = "";
    }
    return "{$prefix} {$name}";
  }
}

$class = new ChildClass;
echo $class->prefixName("John Doe");
echo "<br>";
echo $class->prefixName("Jane Doe");
?>
```

​	Let's look at another example where the abstract method has an argument, and the child class has two optional arguments that are not defined in the parent's abstract method:

```
<?php
abstract class ParentClass {
  // Abstract method with an argument
  abstract protected function prefixName($name);
}

class ChildClass extends ParentClass {
  // The child class may define optional arguments that are not in the parent's abstract method
  public function prefixName($name, $separator = ".", $greet = "Dear") {
    if ($name == "John Doe") {
      $prefix = "Mr";
    } elseif ($name == "Jane Doe") {
      $prefix = "Mrs";
    } else {
      $prefix = "";
    }
    return "{$greet} {$prefix}{$separator} {$name}";
  }
}
$class = new ChildClass;
echo $class->prefixName("John Doe");
echo "<br>";
echo $class->prefixName("Jane Doe");
?>
```



# 37. PHP OOP - Interfaces

## 37.1 PHP - What are Interfaces?

​	Interfaces allows you to specify what methods a class should implemet.

​	Interfaces make it easy to use a variety of different classes in the same way. When one or more classes use the same interface, it is referred to as "polymorphism".

​	Interface are declared withe the <span style="color:red;">interface</span> keyword:

```
<?php
interface InterfaceName {
	public function someMethod1();
	public function someMethod2($name, $color);
	public function someMethod3() : string;
}
?>
```

## 37.2 PHP - Interfaces vs. Abstract Classes

​	Interface are similar to abstract classes. The difference between interfaces and abstract classes are:

* Interface cannot have properties, while abstract classes can
* All interface methods must be public, while abstract class methods is public or protected
* All methods in an interface are abstract, so they cannot be implemented in code and the abstract keyword is not necessary
* Classes can implement an interface while inheriting from another class at the same time

## 37.3 PHP - Using Interfaces

​	To implement an interface, a class must use the <span style="color:red;">implements</span> keyword.

​	A class that implements an interface must implement <b>ALL</b> of the interface's methods:

```
<?php
interface Animal {
	public function makeSound();
}
class Cat implements Animal {
	public function makeSound() {
		echo "Meow";
	}
}
$animal = new Cat();
$animal->makeSound();
?>
```

​	From the example above, let's say that we would like to write software which manages a group of animals. There are actions that all of the animals can do, but each animal does it in its own way. 

​	Using interfaces, we can write some code which can work for all of the animals even if each animal behaves differently:

```
<?php
// Interface definition
interface Animal {
  public function makeSound();
}
// Class definitions
class Cat implements Animal {
  public function makeSound() {
    echo " Meow ";
  }
}
class Dog implements Animal {
  public function makeSound() {
    echo " Bark ";
  }
}
class Mouse implements Animal {
  public function makeSound() {
    echo " Squeak ";
  }
}
// Create a list of animals
$cat = new Cat();
$dog = new Dog();
$mouse = new Mouse();
$animals = array($cat, $dog, $mouse);

// Tell the animals to make a sound
foreach($animals as $animal) {
  $animal->makeSound();
}
?>
```

​	At the end, we loop through all of the animal and tell them to make a sound even if we don't know what type of animal each one is.



# 38. PHP OOP - Traits

 ## 38.1 PHP - What are Traits?

​	PHP only supports single inheritance: a child class can inherit only form one single parent.

​	So, what if a class to inherit multiple behaviors? OOP traits solve this problem.

​	Traits are used to declare <b>methods</b> that can be used in multiple classes. Traits can have methods and abstract methods that can be used in multiple classes, and the methods can have any access modifiers (public, protected or private).	

​	Traits are declared with the <span style="color:red;">trait</span> keyword:

```
<?php
trait TraitName {
	//...
}
?>
```

​	To use a trait in a class, use the <span style="color:red;">use</span> keyword:

```
class MyClass {
	use TraitName;
}
```

```
trait message1 {
public function msg1() {
    echo "OOP is fun! ";
  }
}
class Welcome {
  use message1;
}
$obj = new Welcome();
$obj->msg1();
?>
```

<span style="font-size:20px;">Example Explained</span>

​	Here, we declare one trait: message1. Then, we create a class: Welcome. The class uses the trait, and all the methods in the trait will be available in the class.

​	If other classes need  to use the msg1() function, simply use the message1 trait in those classes. This reduces code duplication, because there is no need to redeclare the same method over and over again.

## 38.2 PHP - Using Multiple Traits

```
<?php
trait message1 {
  public function msg1() {
    echo "OOP is fun! ";
  }
}
trait message2 {
  public function msg2() {
    echo "OOP reduces code duplication!";
  }
}
class Welcome {
  use message1;
}
class Welcome2 {
  use message1, message2;
}
$obj = new Welcome();
$obj->msg1();
echo "<br>";
$obj2 = new Welcome2();
$obj2->msg1();
$obj2->msg2();
?>
```



# 39. PHP OOP - Static Methods

## 39.1 PHP - Static Methods

​	Static methods can be called directly - without creating an instance of the class first.

​	Static methods are declared with the <span style="color:red;">static</span> keyword:

```
class ClassName {
	public static function staticMethod() {
		echo "Hello...";
	}
}
```

​	To access a static method use the class name, double colon (::), and the method name:

```
ClassName::staticMethod();
```

​	Let's look at an example:

```
<?php
class greeting {
	publick static function welcom() {
		echo "Hello...";
	}
}
greeting::welcome();
?>
```

<span style="font-size:20px;">Example Explained</span>

​	Here, we declared a static method: welcome(). Then, we call the static method by using the class name, double colon (::), and the method name (without creating an instance of the class).

## 39.2 PHP - More on Static Methods

​	A class can have both static and non-static methods. A static method can be accessed from a method in the same class using the <span style="color:red;">self</span> keyword and double colon (::):

```
<?php
class greeting {
  public static function welcome() {
    echo "Hello World!";
  }
  public function __construct() {
    self::welcome();
  }
}
new greeting();
?>
```

<b>Note:</b> <span style="color:blue;">It's similar to the constant class</span>.

​	Static methods can also be called from methods in other classes. To do this, the static method should be <span style="color:red;">public</span>:

```
<?php
class A {
  public static function welcome() {
    echo "Hello World!";
  }
}
class B {
  public function message() {
    A::welcome();
  }
}
$obj = new B();
echo $obj -> message();
?>
```

​	To call a static method from a child class, use the <span style="color:red;">parent</span> keyword inside the child class. Here, the static method can be <span style="color:red;">public</span> or <span style="color:red;">protected</span>:

```
<?php
class domain {
  protected static function getWebsiteName() {
    return "W3Schools.com";
  }
}
class domainW3 extends domain {
  public $websiteName;
  public function __construct() {
    $this->websiteName = parent::getWebsiteName();
  }
}
$domainW3 = new domainW3;
echo $domainW3 -> websiteName;
?>
```



# 40. PHP OOP - Static Properties

## 40.1 PHP - Static Properties

​	Static properties can be called directly - without creating an instance of a class.

​	Static properties are declared with the <span style="color:red;">static</span> keyword:

```
//Syntax
class ClassName {
	public static $staticProp = "MAGA";
}
```

​	To access a static property use the class name, double colon (::) and the property name:

```
ClassName::$statciProp;
```

​	Let's look at an example:

```
<?php
class pi {
  public static $value = 3.14159;
}
// Get static property
echo pi::$value;			//Can this be used in another class ?
?>
```

## 40.2 PHP - More on Static Properties

​	A class can have both static and non-static properties. A static property can be accessed from a method in the same class using the <span style="color:red;">self</span>/ keyword and double colon (::):

```
<?php
class pi {
  public static $value=3.14159;
  public function staticValue() {
    return self::$value;
  }
}
$pi = new pi();
echo $pi->staticValue();
?>
```

​	To call a static property from a child class, use the <span style="color:red;">parent</span> keyword inside the child class:
```
<?php
class pi {
  public static $value=3.14159;
}
class x extends pi {
  public function xStatic() {
    return parent::$value;
  }
}
// Get value of static property directly via child class
echo x::$value;
// or get value of static property via xStatic() method
$x = new x();
echo $x->xStatic();
?>
```



# 41. PHP Namespaces

## 41.1 PHP Namespaces

​	Namespaces are qualifiers that solve two different problems:

1. They allow for better organization by grouping classes that work together to perform a task
2. They allow the same name to be used for more than one class

​	For example, you may have a set of classes which describe an HTML table, such as Table, Row and Cell while also having another set of classes to describe furniture, such as Table, Chair and Bed. Namespaces can be used to organize the classes into two different groups while also preventing the two Table and Table from being mixed up.

## 41.2 Declaring a Namespace

​	Namespaces are decalred at the beginning of a file using the  <span style="color:red;">namespace</span> keyword:

```
//Syntax:
<?php
namespace Html;
?>
```

<b>Note:</b> A <span style="color:red;">namespace</span> declaration must be the first thing in the PHP file. The following code would be invalid:

```
<?php
echo "Hello...";
namespace Html;
?>
```

​	Constants, classes and functions declared in this file will belong to the <b>Html</b> namespace:

```
<?php
namespace Html;
class Table {
  public $title = "";
  public $numRows = 0;
  public function message() {
    echo "<p>Table '{$this->title}' has {$this->numRows} rows.</p>";
  }
}
$table = new Table();
$table->title = "My table";
$table->numRows = 5;
?>
<!DOCTYPE html>
<html>
<body>
<?php
$table->message();
?>
</body>
</html>
```

​	For further organization, it is possible to have nested namespaces:

```
<?php
namespace Code\Html;
?>
```

## 41.3 Using Namespaces

​	Any code that follows a <span style="color:red;">namesapce</span> declaration is operating inside the namespace, so classes that belong to the namespace can be instantiated without any qualifiers. To access classes from outside a namespace, the class need to have the namesapce attached to it:

```
<?php
$table = new Html\Table();
$row = new Html\Row();
?>
```

​	When many classes from the same namespace are being used at the same time, it is easier to use the <span style="color:red;">namespace</span> keyword:

```
//Use classes from the Html namespace without the need for the Html\qualifier:
<?php
namespace Html;
$table = new Table();
$row = new Row();
?>
```

## 41.4 Namespace Alias

​	It can be useful to give a namespace or class an alias to make it easier to write. This is done with the <span style="color:red;">use</span> keyword:

```
<?php
use Html as H;
$table = new H\Table();
?>
```

​	<span style="color:blue;">Class can also have a alias</span>:

```
<?php
use Html\Table as T;
$table = new T();
?>
```



# 42. PHP Iterables

## 42.1 PHP - What is an Iterale?

​	An iterable is any value which can be looped through with a <span style="color:red;">foreach()</span> loop.

​	The <span style="color:red;">iterable</span> pseudo-type was introduced in PHP 7.1, and it can be used as a data type for function arguments and function return values.

## 42.2 PHP - Using Iterables

​	The <span style="color:red;">iterable</span> keyword can be used as a data type of a function argument or as the return type of a function:

```
//Use an iterable function argument:
<?php
function printIterable(iterable $myIterable) {
	foreach($myIterable as $item) {
		echo $item;
	}
}
$arr = ["a", "b", "c"];
printIterable($arr);
?>
```

```
//Return an iterable:
<?php
function getIterable():iterable {
	return ["a", "b", "c"];
}
$myIterable = getIterable();
foreach($myIterable as $item) {
	echo $item;
}
?>
```

## 42.3 PHP - Creating Iterables

<b>Arrays</b>

​	All arrays are iterables, so any array can be used as an argument of a function that requires an iterable.

<b>Iterators</b>

​	Any object that implements the <span style="color:red;">Iterator</span> interface can be used as an argument of a function that requires an iterable.

​	An iterator contains a list of items and provides methods to loop through them. It keeps a pointer to one of the elements in the list. Each item in the list should have a key which can be used to find the item.

​	An iterator must have these methods:

* <span style="color:red;">current()</span> - Returns the element that the pointer is currently pointing to. It can be any data type
* <span style="color:red;">key()</span> - Returns the key associated with the current element in the list. It can only be an integer, float, boolean or string
* <span style="color:red;">next()</span> - Moves the pointer to the next element in the list
* <span style="color:red;">rewind()</span> - Moves the pointer to the first element in the list
* <span style="color:red;">valid()</span> - If the internal pointer is not pointing to any element (for example, if next() was called at the end of the list), this should return false.

Example: Implement the Iterator interface and use it as an iterable:

```
<?php
// Create an Iterator
class MyIterator implements Iterator {
  private $items = [];
  private $pointer = 0;
  public function __construct($items) {
    // array_values() makes sure that the keys are numbers
    $this->items = array_values($items);
  }
  public function current() {
    return $this->items[$this->pointer];
  }
  public function key() {
    return $this->pointer;
  }
  public function next() {
    $this->pointer++;
  }
  public function rewind() {
    $this->pointer = 0;
  }
  public function valid() {
    // count() indicates how many items are in the list
    return $this->pointer < count($this->items);
  }
}
// A function that uses iterables
function printIterable(iterable $myIterable) {
  foreach($myIterable as $item) {
    echo $item;
  }
}
// Use the iterator as an iterable
$iterator = new MyIterator(["a", "b", "c"]);
printIterable($iterator);
?>
```



# 43. PHP MySQL Database

​	With PHP, you can connect to and manipulate databases.

​	MySQL is the most popular database system used with PHP.

## 43.1 What is MySQL

* MySQL is a database system used on the web 
* MySQL is a databse system that runs on a server
* MySQL is ideal for both small and large applications
* MySQL is very fast, reliable, and easy to use
* MySQL uses standard SQL
* MySQL compiles on a number of platforms
* MySQL is free to download and use
* MySQL is developed, distributed, and supported by Oracle Corporation
* MySQL is named after co-founder Monty Windenius's daugher: My

​	The data in a MySQL database are stored in tables. A table is a collection of related data, and it consists of columns and rows.

​	Database are useful for storing information categorically. A company may have a databse with the following tables:

* Employees
* Products
* Customers
* Orders

## 43.2 PHP + MySQL Database System

* PHP combined with MySQL are cross-platform (you can develop in Windows and serve on a Unix platform).

## 43.3 Database Queries

​	A query is a question or a request.

​	We can query a database for specific information and have a recordset returned.

​	Look at the following query (using standard SQL):

```
SELECT LastName FROM Employees
```

​	The query above selects all the data in the "LastName" column from the "Employees" table. 

## 43.4 Facts About MySQL Database

​	MySQL is the de-facto standard database system for web sites with HUGE volumes of both data and end-users (like Facebook, Twitter, and Wikipedia).

​	Another great thing about MySQL is that it can be scaled down to support embedded database applications.



## 44. PHP Connect to MySQL

​	PHP 5 and later can work with a MySQL database using:

* <b>MySQLi extension</b> (the "i" sands for improved)
* <b>PDO (PHP Data Objects)</b>

​	Earlier version of PHP used the MySQL extension. However, this extension was deprecated in 2012.

## 44.1 Should I Use MySQLi or PDO?

​	If you need a short answer, it would be "Whatever you like".

​	Both MySQL and PDO have their advantages:

​	PDO will work on 12 different database system, whereas MySQLi will only work with MySQL database. So, if you have to switch your project to use another database, PDO makes the process easy. You only have to change the connection string and a few queries. With MySQLi, you will need to rewrite the entire code - queries included.

​	Both are object-oriented, but MySQLi also offers a procedural API.

​	Both support Prepared Statements. Prepared Statements protect from SQL injection, and very important for web application security.

## 44.2 MySQL Examples in Both MySQLi and PDO Syntax

​	In this, and in the following chapters we demonstrate three ways of working with PHP and MySQL:

* MySQLi (object-oriented)
* MySQLi (procedural)
* PDO

## 44.3 Open a Connection to MySQL

​	Before we can access data in the MySQL database, we need to be table to connect to the server:

```
//MySQLi Object-Oriented:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
//Create a connection
$conn = new mysqli($servername, $username, $password);
//Check connection
if($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully.";
?>
```

<b>Note:</b> In my ubuntu server, with nginx+php-fpm, install the mysql extension via:

```
apt install php-mysql;
```

 	And then, create an account with password:

```
CREATE USER 'username'@'localhost' IDENTIFIED BY 'password';
GRANT ALL ON *.* TO 'pf'@'localhost';
SELECT CURRENT_USER();			//to see the current user
$mysqld -u pf -p				//Don't use mysqld instead mysql. or error"mysqld: Can not perform keyring migration : Invalid --keyring-migration-source option." may occur...
```

```
//MySQLi Procedural:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
// Create connection
$conn = mysqli_connect($servername, $username, $password);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
?>
```

```
//PDO(create the database "myDB" before):
<?php
$servername = "localhost";
$username = "username";
$password = "password";

try {
  $conn = new PDO("mysql:host=$servername;dbname=myDB", $username, $password);	
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo "Connected successfully";
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}
?>
```

<b>Note:</b> In the PDO example above me have also <b>specified a database (myDB) </b>. PDO require a valid database to connect to . If no database is specified, an exception is thrown (create a database: CREATE DATABSE myDB;).

<b>Tip:</b> A great benefit of PDO is that it has an exception class to handle any problems that may occur in our database queries. If an exception is thrown within the try { } block, the script stops executing and flows directly to the first catch() { } block.

## 44.4 Close the Connection

​	The connection will be closed automatically when the script ends. To close the connection before, use the following:

```
$conn->close();	//MySQLi Object-Oriented
mysql_close($conn);	//MySQLi Procedural
$conn = null;		//PDO
```



# 45. PHP Create a MySQL Database

​	A database consists of one or more tables.

​	You will need special CREATE privileges to create or to delete a MySQL database.

## 45.1 Create a MySQL Database Using MySQLi and PDO

​	The CREATE DATABASE statement is used to create a database in MySQL.	

​	The following examples create a database named "myDB":

```
//MySQLi Object-oriented:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// Create database
$sql = "CREATE DATABASE myDB";
if ($conn->query($sql) === TRUE) {
  echo "Database created successfully";
} else {
  echo "Error creating database: " . $conn->error;
}
$conn->close();
?>
```

<b>Note:</b> When you create a new database, you must only specify the first three arguments to the mysql object (servername, username and password).

<b>Tip:</b> If you have to use a specific port, add an empty string for the database-name argument, like: new mysql("localhost", "username", "password", "", port);

```
//MySQLi Procedural:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
// Create connection
$conn = mysqli_connect($servername, $username, $password);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// Create database
$sql = "CREATE DATABASE myDB";
if (mysqli_query($conn, $sql)) {
  echo "Database created successfully";
} else {
  echo "Error creating database: " . mysqli_error($conn);
}
mysqli_close($conn);
?>
```

```
<?php
$servername = "localhost";
$username = "username";
$password = "password";
try {
  $conn = new PDO("mysql:host=$servername", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "CREATE DATABASE myDBPDO";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "Database created successfully<br>";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}
$conn = null;
?>
```

<b>Tip:</b> A great benefit of PDO is that it has exception class.



# 46. PHP MySQL Create Table

​	A database table has its own unique name and consists of columns and rows.

## 46.1 Create a MySQL Table Using MySQLi and PDO

​	The CREATE TABLE statement is used to create a table in MySQL.

​	We will create a table named "myGuests", with five columns: "id", "fistname", "lastname", "email" and "reg_date":

```
CREATE TABLE MyGuests (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)
```

<b>Notes on the table above:</b>

​	The data type specifies what type of data the column can hold. After the data type, you can specify other optional attributes for each columns:

* NOT NULL - Each row must contain a value for that column, null values are not allowed.
* DEFAULT value - Set a default value that is added when no other value is passed.
* UNSIGNED - Used for number types, limits the stored data to positive numbers and zero.
* AUTO INCREMENT - MySQL automatically increase the value of the field by 1 each time a new record is added
* PRIMARY KEY - Used to uniquely identify the rows in a table. The column with PRIMARY_KEY setting is often an ID number, and is often used with AUTO_INCREMENT.

​	Each table should have a primary key column (in this case: the "id" column). Its value must be unique for each record in the table.

​	The following examples shows how to create the table in PHP:

````
//MySQLi Object-oritented:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// sql to create table
$sql = "CREATE TABLE MyGuests (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";
if ($conn->query($sql) === TRUE) {
  echo "Table MyGuests created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}
$conn->close();
?>
````

```
//MySQLi Procedural
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// sql to create table
$sql = "CREATE TABLE MyGuests (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";
if (mysqli_query($conn, $sql)) {
  echo "Table MyGuests created successfully";
} else {
  echo "Error creating table: " . mysqli_error($conn);
}
mysqli_close($conn);
?>
```

```
//PDO:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  // sql to create table
  $sql = "CREATE TABLE MyGuests (
  id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  firstname VARCHAR(30) NOT NULL,
  lastname VARCHAR(30) NOT NULL,
  email VARCHAR(50),
  reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "Table MyGuests created successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}
$conn = null;
?>
```

```
$mysql -u pf -p
$SHOW DATABASES;
$USE myDBPDO;
$SHOW TABLES;
```



# 47. PHP MySQL Insert Data

## 47.1 Insert Data Into MySQL Using MySQLi and PDO

​	After a database and a table have been created, we can start adding data in them.

​	Here are some syntax rules to follow:

* The SQL query must be quoted in PHP
* String values inside the SQL query must be quoted
* Numeric values must not be quoted
* The word NULL must not be quoted

​	The INSERT INTO statement is used to add new records to a MySQL table:

```
INSERT INTO table_name (column1, column2, column3, ...)
VALUES (value1, value2, value3, ...)
```

<b>Note:</b> If a column is AUTO_INCREMENT (like the "id" column) or TIMESTAMP with default update of current_timestamp (like the "reg_date" column), it is no need to be specified in the SQL query; MySQL automatically add the values.

​	The following example add a new record to the "myGuests" table:

```
//MySQLi Object-oriented:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";
if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
```

```
//MySQLi Procedural:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";
if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
```

```
//PDO:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "INSERT INTO MyGuests (firstname, lastname, email)
  VALUES ('John', 'Doe', 'john@example.com')";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "New record created successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}
$conn = null;
?>
```



# 48. PHP MySQL Get Last Inserted ID

## 48.1 Get ID of The Last Inserted Record

​	If we perform an INSERT or UPDATE on a table with an AUTO_INCREMENT field, we can get the ID of the last inserted/updated record immeditately.

​	In the table "myGuests", the "id" column is an AUTO_INCREMENT field:

```
CREATE TABLE MyGuests (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)
```

​	The following example are equal to the example from the previous page, except that we have added one single line of code to retrieve the ID of the last inserted record. We also echo the last inserted ID:

```
//MySQLi Object-Oriented:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";
if ($conn->query($sql) === TRUE) {
  $last_id = $conn->insert_id;
  echo "New record created successfully. Last inserted ID is: " . $last_id;
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>

```

```
//MySQLi Procedural:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";
if (mysqli_query($conn, $sql)) {
  $last_id = mysqli_insert_id($conn);
  echo "New record created successfully. Last inserted ID is: " . $last_id;
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
```

```
//PDO:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "INSERT INTO MyGuests (firstname, lastname, email)
  VALUES ('John', 'Doe', 'john@example.com')";
  // use exec() because no results are returned
  $conn->exec($sql);
  $last_id = $conn->lastInsertId();
  echo "New record created successfully. Last inserted ID is: " . $last_id;
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}
$conn = null;
?>
```



# 49. PHP MySQL Insert Multiple Records

## 49.1 Insert Multiple Records Into MySQL Using MySQLi and PDO 

​	Multiple SQL statements must be executed with the <span style="color:red;">mysql_multi_query()</span> function.

​	The following examples add three new records to the "myGuests" table:

```
//MySQLi Object-oriented:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com');";
$sql .= "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('Mary', 'Moe', 'mary@example.com');";
$sql .= "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('Julie', 'Dooley', 'julie@example.com')";
if ($conn->multi_query($sql) === TRUE) {
  echo "New records created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
```

<b>Note:</b> Each SQL statement must be separated by a semicolon.

```
//MuSQLi Procedural:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com');";
$sql .= "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('Mary', 'Moe', 'mary@example.com');";
$sql .= "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('Julie', 'Dooley', 'julie@example.com')";

if (mysqli_multi_query($conn, $sql)) {
  echo "New records created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
```

​	The PDO way is a little bit different:

```
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  // begin the transaction
  $conn->beginTransaction();
  // our SQL statements
  $conn->exec("INSERT INTO MyGuests (firstname, lastname, email)
  VALUES ('John', 'Doe', 'john@example.com')");
  $conn->exec("INSERT INTO MyGuests (firstname, lastname, email)
  VALUES ('Mary', 'Moe', 'mary@example.com')");
  $conn->exec("INSERT INTO MyGuests (firstname, lastname, email)
  VALUES ('Julie', 'Dooley', 'julie@example.com')");
  // commit the transaction
  $conn->commit();
  echo "New records created successfully";
} catch(PDOException $e) {
  // roll back the transaction if something failed
  $conn->rollback();
  echo "Error: " . $e->getMessage();
}
$conn = null;
?>
```



# 50. PHP MySQL Prepared Statements

​	Prepared statements are very useful against SQL injections.

## 50.1 Prepared Statements and Bound Parameters

​	A prepared statement is a feature used to execute the same (or similar) SQL statement repeatedly with hight efficiency.

​	Prepared statements basically work like this:

1. Prepare: An SQL statement template is created and sent to the database. Cretain values are left unspecifed, called parameters (labeled "?"). Example: INSERT INTO myGuests VALUES(?, ?, ?)
2. The database parses, compiles, and performs query optimization on the SQL statement template, and stores the result without executing it
3. Execute: At a later time, the application binds the values to the parameters, and the database executes the statement. The application may execute the statement as many times as it wants with different values

​	Compared to executing SQL statements directly, prepared statements have three main advantages:

* Prepared statements reduce parsing time as the preparation on the query is done by only (although the statement is executed multiple times)
* Bound parameters minimize bandwidth to the server as you need send only the parameters each time, and not the whole query
* Prepared statements are very useful against SQL injections, because parameter values, which are transmitted later using a different protocol, need not be correctly escaped. If the original statement templates is not derived from external input, SQL injection cannot occur.

## 50.2 Prepared Statements in MySQLi

​	The following example uses prepared statements and bound parameters in MySQLi:

```
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// prepare and bind
$stmt = $conn->prepare("INSERT INTO MyGuests (firstname, lastname, email) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $firstname, $lastname, $email);
// set parameters and execute
$firstname = "John";
$lastname = "Doe";
$email = "john@example.com";
$stmt->execute();

$firstname = "Mary";
$lastname = "Moe";
$email = "mary@example.com";
$stmt->execute();

$firstname = "Julie";
$lastname = "Dooley";
$email = "julie@example.com";
$stmt->execute();
echo "New records created successfully";
$stmt->close();
$conn->close();
?>
```

​	Look at the bind_param() function:

```
$stmt->bind_param("sss", $firstname, $lastname, $email);
```

​	This function binds the parameters to the SQL query and tells the database what the parameters are. The "sss" argument lists the types of data that the parameters are. The s character tells mysql that the parameter is a string. The argument may be one of the four:

* i - integer
* d - double
* s - string
* b - BLOB

​	We must have one of these for each parameter. By telling mysql what type of data to expect, we minimize the risk of SQL injections.

<b>Note:</b> If we want to insert any data from external sources (like user input), it is very important that the data is sanitized and validated.

## 50.3 Prepared Statements in PDO

```
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  // prepare sql and bind parameters
  $stmt = $conn->prepare("INSERT INTO MyGuests (firstname, lastname, email)
  VALUES (:firstname, :lastname, :email)");
  $stmt->bindParam(':firstname', $firstname);
  $stmt->bindParam(':lastname', $lastname);
  $stmt->bindParam(':email', $email);
  // insert a row
  $firstname = "John";
  $lastname = "Doe";
  $email = "john@example.com";
  $stmt->execute();
  // insert another row
  $firstname = "Mary";
  $lastname = "Moe";
  $email = "mary@example.com";
  $stmt->execute();
  // insert another row
  $firstname = "Julie";
  $lastname = "Dooley";
  $email = "julie@example.com";
  $stmt->execute();
  echo "New records created successfully";
} catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
}
$conn = null;
?>
```



# 51. Select Data From a MySQL Database

​	The SELECT statement is used to select data from one or more tables:

```
SELECT column_name(s) FROM table_name
```

​	or we can use the * character to select ALL columns from a table:

```
SELECT * FROM table_name
```

## 51.1 Select Data With MySQLi

​	The following example selects the id, firstname and lastname columns from the myGuests table and displays it on the page:

```
//MySQLi Object-oriented:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT id, firstname, lastname FROM MyGuests";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>
```

​	Code lines to explain from the example above:

​	First, we set up an SQL query that selects the id, firstname and lastname columns from the MyGuests table. The next line of code runs the query and puts the resulting data into a variable called $result.

​	Then, the function <span style="color:red;">num_rows()</span> checks if there are more than zero rows returned.

​	If there are more than zero rows returned, the function <span style="color:red;">fetch_assoc()</span> puts all the results into an associative array that we can loop through. The <span style="color:red;">while()`</span> loop loops through the result set and outputs the data from the id, firstname and lastname columns.

```
//MySQLi Procedural:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT id, firstname, lastname FROM MyGuests";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}
mysqli_close($conn);
?>
```

​	To better format the result, put the result in an HTML table:

```
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT id, firstname, lastname FROM MyGuests";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  echo "<table><tr><th>ID</th><th>Name</th></tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row["id"]."</td><td>".$row["firstname"]." ".$row["lastname"]."</td></tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>
```

## 51.2 Select Data With PDO (+Prepared Statements)

​	The following example use prepared statements. It selects the id, firstname and lastname columns from the myGuests table and displays it in an HTML table:

```
<?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Firstname</th><th>Lastname</th></tr>";
class TableRows extends RecursiveIteratorIterator {
  function __construct($it) {
    parent::__construct($it, self::LEAVES_ONLY);
  }
  function current() {
    return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
  }
  function beginChildren() {
    echo "<tr>";
  }
  function endChildren() {
    echo "</tr>" . "\n";
  }
}
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $stmt = $conn->prepare("SELECT id, firstname, lastname FROM MyGuests");
  $stmt->execute();
  // set the resulting array to associative
  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
  foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
    echo $v;
  }
} catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";
?>
```



# 52. PHP MySQL Use The WHERE Clause

## 52.1 Select and Filter Data From a MySQL Database

​	The WHERRE clause is used to filter records.

​	The WHERE clause is used to extract only those records that fulfill a specified condition

```
SELECT column_name(s) FROM table_name WHERE column_name operator value
```

## 52.2 Select and Filter Data With MySQLi

​	The following example selects the id, firstname and lastname columns from the myGuests table where that lastname is "Doe", and displays it on the page:

```
//MySQLi Object-oriented
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>
```

​	The following realized in the MySQLi procedural way:

```
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  echo "<table><tr><th>ID</th><th>Name</th></tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row["id"]."</td><td>".$row["firstname"]." ".$row["lastname"]."</td></tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>
```

## 52.3 Select Data With PDO (+Prepared Statements)

```
<?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Firstname</th><th>Lastname</th></tr>";

class TableRows extends RecursiveIteratorIterator {
  function __construct($it) {
    parent::__construct($it, self::LEAVES_ONLY);
  }
  function current() {
    return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
  }

  function beginChildren() {
    echo "<tr>";
  }
  function endChildren() {
    echo "</tr>" . "\n";
  }
}
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $stmt = $conn->prepare("SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe'");
  $stmt->execute();

  // set the resulting array to associative
  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
  foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
    echo $v;
  }
}
catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";
?>
```



# 53. PHP MySQL Use The ORDER BY Clause

## 53.1 Select and Order Data From a MySQL Database

​	The ORDER BY clause is used to sort the result-set in ascending or descending order.

​	The ORDER BY clause sorts the records in ascending order by default. To sort in descending order, use the DESC keyword:

```
SELECT column_name(s) FROM table_name ORDER BY column_name(s) ASC|DESC
```

## 53.2 Select and Order Data With MySQLi

```
//MySQLi Object-oriented, ordered by the lastname column:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, firstname, lastname FROM MyGuests ORDER BY lastname";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>
```

```
//MySQLi Procedural:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT id, firstname, lastname FROM MyGuests ORDER BY lastname";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}
mysqli_close($conn);
?>
```

​	Or put the result in an HTML table:

```
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT id, firstname, lastname FROM MyGuests ORDER BY lastname";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  echo "<table><tr><th>ID</th><th>Name</th></tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row["id"]."</td><td>".$row["firstname"]." ".$row["lastname"]."</td></tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>
```

## 53.3 Select Data With PDO (+Prepared Statements)

```
<?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Firstname</th><th>Lastname</th></tr>";
class TableRows extends RecursiveIteratorIterator {
  function __construct($it) {
    parent::__construct($it, self::LEAVES_ONLY);
  }
  function current() {
    return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
  }
  function beginChildren() {
    echo "<tr>";
  }
  function endChildren() {
    echo "</tr>" . "\n";
  }
}
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $stmt = $conn->prepare("SELECT id, firstname, lastname FROM MyGuests ORDER BY lastname");
  $stmt->execute();
  // set the resulting array to associative
  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
  foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
    echo $v;
  }
} catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";
?>
```



# 54. PHP MySQL Delete Data

## 54.1 Delete Data From a MySQL Table Using MySQLi and PDO

​	The DELETE statement is used to delete records from a table:
```
DELETE FROM tablel_name WHERE some_column = some_value
```

​	<b>Notice the WHERE clause in the DELETE syntax</b> : The WHERE clause specifies which record to be deleted. If omit this, all records will be deleted.

​	The following examples delete the record with id=3 in the table:

```
//MySQLi Object-Oriented:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// sql to delete a record
$sql = "DELETE FROM MyGuests WHERE id=3";
if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}
$conn->close();
?>
```

```
//MySQLi Procedural:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// sql to delete a record
$sql = "DELETE FROM MyGuests WHERE id=3";
if (mysqli_query($conn, $sql)) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);
?>
```

```
//PDO:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  // sql to delete a record
  $sql = "DELETE FROM MyGuests WHERE id=3";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "Record deleted successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}
$conn = null;
?>
```



## 55. PHP MySQL Update Data

## 55.1 Update Data In a MySQL Table Using MySQLi and PDO

​	The UPDATE statement is used to update existing records in a table:
```
UPDATE table_name
SET column1=value, column2=value2, ...
WHERE some_column=some_value
```

​	The following examples updates the record with id=2 in the table:

```
//MySQLi Object-Oriented:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "UPDATE MyGuests SET lastname='Doe' WHERE id=2";
if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}
$conn->close();
?>
```

```
//MySQLi Procedural:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "UPDATE MyGuests SET lastname='Doe' WHERE id=2";
if (mysqli_query($conn, $sql)) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . mysqli_error($conn);
}
mysqli_close($conn);
?>
```

```
//PDO:
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "UPDATE MyGuests SET lastname='Doe' WHERE id=2";
  // Prepare statement
  $stmt = $conn->prepare($sql);
  // execute the query
  $stmt->execute();
  // echo a message to say the UPDATE succeeded
  echo $stmt->rowCount() . " records UPDATED successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}
$conn = null;
?>
```

​	Practice them.



# 56. PHP MySQL Limit Data Selections

## 56.1 Limit Data Selections From a MySQL Database

​	MySQL provides a LIMIT clause that is used to specify the number of records to return.

​	The LIMIT clause makes it easy to code multi page results or pagination with SQL, and is very useful on large tables. Returning a large number of records can impact on performance.

​	Assume we wish to select all records from 1 - 30 (inclusive) from a table called "Orders". The SQL query would then look like this:

```
$sql = "SELECT * FROM Orders LIMIT 30"
```

​	When the SQL query above is run, it will return the first 30 records. What if we want to select records 16-25 (inclusive) ? Mysql also provides a way to handle this: by using OFFSET.

​	The SQL query below says "return only 10 records, start on record 16 (OFFSET 15)":

```
$sql = "SELECT * FROM Orders 10 OFFSET 15"
```

​	You could also use a shorter syntax to achieve the same result:

```
$sql = "SELECT * FROM Orders 15, 10"
```



# 57. PHP XML Parsers

## 57.1 What is XML?

​	The XML language is a way to structure data for sharing across websites.

​	Several web technologies like RSS Feeds and Podcasts are written in XML.

​	XML is easy to create. It looks a lot like HTML , expect that you make up your own tag.

## 57.2 What is an XML Parser?

​	To read and update, create and manipulate an XML document, you will need an XML parser. In PHP there are two major types of XML parsers:

* Tree-based Parsers
* Event-based Parsers

### 57.2.1 Tree-Based Parsers

​	Tree-based parsers holds the entire document in Memory and transforms the XML document into a Tree structure. It analyzes the whole document, and provides access to the Tree element (DOM). This type of parsers is a better option for smaller XML documents, but not for large XML document as it causes major performance issues.

​	Example of tree-based parsers:

* SimpleXML
* DOM

### 57.2.2 Event-Based Parsers

​	Event-based parsers do not hold the entire document in Memory, they read in one node at a time and allow you to interact with in real time. Once you move onto the next node, the old one is thrown away. This type of parse is well suited for large XML documents. It parser faster and consumes less memory.

​	Example of event-based parsers:

* XMLReader
* XML Expat Parser



# 58. PHP SimpleXML Parser

​	SimpleXML is a PHP extension that allows us to easily manipulate and get XML data.

## 58.1 The SimpleXML Parser

​	SimpleXML is a tree-based parser.

​	SimpleXML provides an easy way of getting an element's name, attributes and textual content if you know the XML document's structure or layout.

​	SimpleXML turns an XML document into a data structure you can iterate through like a collection of arrays and objects.

​	Compared to DOM or Expat parser, SimpleXML takes a fewer lines of code to read text data from an element.

## 58.2 Installation

​	From PHP 5, the SimpleXML functions are part of the PHP core, No installation is required to use these functions.

​	<b>Note:</b> In my server, I actually need to install it via:

```
apt install php-xml
```

## 58.3 PHP SimpleXML - Read From String

​	The PHP <span style="color:red;">simplexml_load_string()</span> function is used to read XML data from a string. Assume we have a variable that contains XML data, like this:

```
$myXMLData = 
"<?xml version='1.0" encoding='UTF-8'?>
<note>
<to>Tove</to>
<from>Jani</form>
<hading>Reminder</heading>
<body>Don't forget me this weekend!</body>
</note>";
```

​	The example below shows how to use the <span style="color:red;">simplexml_load_string()</span> function to read XML data from a string:

```
$xml = simplexml_load_string($myXMLData) or die("Error: Cannot crate object");
print_r($xml);	//SimpleXMLElement Object ( [to] => Tove [from] => Jani [heading] => Reminder [body] => Don't forget me this weekend! )
```

<b>Error Handling Tip:</b> Use the libxml functionality to retrieve all XML errors when loading the document and then iterate over the errors. The following examples tries to load a broken XML string:

```
<?php
libxml_use_internal_errors(true);
$myXMLData =
"<?xml version='1.0' encoding='UTF-8'?>
<document>
<user>John Doe</wronguser>
<email>john@example.com</wrongemail>
</document>";
$xml = simplexml_load_string($myXMLData);
if ($xml === false) {
  echo "Failed loading XML: ";
  foreach(libxml_get_errors() as $error) {
    echo "<br>", $error->message;
  }
} else {
  print_r($xml);
}
?>
```

```
Failed loading XML:
Opening and ending tag mismatch: user line 3 and wronguser
Opening and ending tag mismatch: email line 4 and wrongemail
```

## 58.4 PHP SimpleXML - Read From File

​	The PHP <span style="color:red;">simplexml_load_file()</span> function is used to read XML data from a file.

​	Assume we have an XML file caleld "note.xml", that looks like this:

```
<?xml version="1.0" encoding="UTF-8"?>
<note>
	<to>Tove</to>
	<form>Jani</form>
	<heading>Reminder</heading>
	<body>Don't forget me this weekend!</body>
</note>
```

​	The example below shows how to use the <span style="color:red;">simple_load_file()</span> function to read XML data from a file:

```
<?php
$xml = simplexml_load_file("note.xml") or die("Error: Cannot create object");
print_r($xml);
?>
```



# 59. PHP SimpleXML - Get Node/Attribute Values

​	SimpleXML is a PHP extension that allows us to easily manipulate and get XML data.

## 59.1 PHP SimpleXML - Get Node Values

```
<?php
$xml = simplexml_load_file("note.xml") or die("Erro: Cannot create object");
echo $xml->to . "<br>";
echo $xml->from . "<br>";
echo $xml->heading . "<br>";
echo $xml->body;
?>
```

​	The output will be:

```
Tove
Jani
Reminder
Don't forget me this weekend!
```

## 59.2 Another XML File

​	Assume we have an XML file called "books.xml", that looks like this:

```
<?xml version="1.0" encoding="utf-8"?>
<bookstore>
  <book category="COOKING">
    <title lang="en">Everyday Italian</title>
    <author>Giada De Laurentiis</author>
    <year>2005</year>
    <price>30.00</price>
  </book>
  <book category="CHILDREN">
    <title lang="en">Harry Potter</title>
    <author>J K. Rowling</author>
    <year>2005</year>
    <price>29.99</price>
  </book>
  <book category="WEB">
    <title lang="en-us">XQuery Kick Start</title>
    <author>James McGovern</author>
    <year>2003</year>
    <price>49.99</price>
  </book>
  <book category="WEB">
    <title lang="en-us">Learning XML</title>
    <author>Erik T. Ray</author>
    <year>2003</year>
    <price>39.95</price>
  </book>
</bookstore>
```

## 59.3 PHP SimpleXML - Get Node Values of Specific Elements

​	The following example gets the node value of the \<title> element in the first and second \<book> elements in the "books.xml" file:

```
<?php
$xml = simplexml_load_file("books.xml") or die("Error: Cannot create object");
echo $xml->books[0]->title . "<br>";
echo $xml->books[1]->title;
?>
```

​	The output of the code above will be:

```
Everyday Italian
Harry Potter
```

## 59.4 PHP SimpleXML - Get Node Values - Loop

​	The following example loops through all the \<book> elements in the "books.xml" file, and gets the node values of the \<title>, \<author>, \<year> and \<price> elemets:

```
<?php
$xml = simplexml_load_file("books.xml") or die("Erro: Cannot create object");
foreach ($xml->children() as $books) {
	echo $books->title . ", ";
	echo $books->author . ", ";
	echo $books->year . ", ";
	echo $books->price . "<br>";
}
?>
```

<b>Question:</b> Why I can't catch the exception from simplexml_load_file() when I pass a fault formated xml file?

## 59.5 PHP SimpleXML - Get Attributes Values

​	The following example get the attribute value of the "category" attribute of the first \<book> element and the attribute of the "lang" attribute of the \<title> element in the second \<book> element:

```
<?php
$xml = simplexml_load_file("books.xml") or die("Error: Cannot create object");
echo $xml->book[0]['category'] . "<br>";
echo $xml->book[1]->titile['lang'];
?>
```

## 59.6 PHP SimpleXML - Get Attribute Values - Loop

​	The following example gets the attribute values of the \<title> elements in the "books.xml" file:

```
foreach($xml->children() as $books) {
	echo $books->title['lang'];
	echo "<br>";
}
```



# 60. PHP XML Expat Parser

​	The built-in XML Parser makes it possible to process XML documents in PHP.

## 60.1 The XML Expat Parser

​	The Expat parser is an event-based parser. Look at the following XML fraction:

```
<from>Jani</from>
```

​	An event-based parser reports the XML above as a series of three events:

* Start element: from
* Start CDATA section, value: Jani
* Close element: from

​	The XML Expat Parser functions are part of the PHP core. There is no installation needed to use these functions.

## 60.2 The XML File

​	The XML file "note.xml" will be used in the example below:

```
<?xml version="1.0" encoding="UTF-8"?>
<note>
<to>Tove</to>
<from>Jani</from>
<heading>Reminder</heading>
<body>Don't foreget me this weekend!</body>
</note>
```

## 60.3 Initializing the XML Expat Parser

​	We want to initialize the XML Expat Parser in PHP, define some handlers for different XML events, and then parse the XML file:

```
<?php
//Initialize the XML parser:
#parser = xml_parser_create();
//Function to use at the start of an element
function start($parser, $element_name, $element_attrs) {
	switch($element_name) {
		case "NOTE":
			echo "-- Note --<br>";
			break;
		case "TO":
			echo "To: ";
			break;
		case "FROM":
			echo "From: ";
			break;
		case "HEADING":
			echo "Heading: ";
			break;
		case "BODY":
			echo "Message: ";
	}
}
function stop($parser, $element_name) {
	echo "<br>";
}
//Function to use when finding character data
function char($parser, $data) {
	echo $data;
}
xml_set_element_handler($parser, "start", "stop");
xml_set_character_data_data_handler($parser, "char");
$fp = fopen("note.xml", "r");
//Read data
while ($data = fread($fp, 4096)) {
	xml_parse($parser, $data, feof($fp)) or 
	die(sprintf("XML Error: %s at line %d",
	xml_error_string(xml_get_error_code($parser)),
	xml_get_current_line_number($parser)
	))
}
//Free the XML parser
xml_parser_free($parser);
?>
```

<span style="font-size:20px;">Example Explained</span>

1. Initialize the XML parser with the <span style="color:red;">xml_parser_create()</span> function
2. Create functions to use with the different event handlers
3. Add the <span style="color:red;">xml_set_element_handler()</span> function to specify which function will be executed when the parser encounters the opening and closing tags
4. Add the  <span style="color:red;">xml_set_character_data_handler()</span> function to specify which function will be executed when the parser encounter character dat
5. Parse the file "note.xml" with the <span style="color:red;">xml_parse()</span> function
6. In case of  an error, add <span style="color:red;">xml_error_string</span> function to convert an XML error to a textual description
7. Call the <span style="color:red;">xml_parser_free()</span> function to release the memory allocated with the <span style="color:red;">xml_parser_create()</span> function



# 61. PHP XML DOM Parser

​	The built-in DOM parser makes it possible to process XML documents in PHP.

## 61.1 The XML DOM Parser

​	The DOM parser is a tree-based parser.

​	Look at the following XML document fraction:

```
<!xml version="1.0" encoding="utf-8"?>
<from>Jani</from>
```

​	The DOM sees the XML above as a tree structure:

* Level 1: XML Document
* Level 2: Root element: \<from>
* Level 3: Text element: "Jani"

## 61.2 The XML File

```
<?xml version="1.0" encoding="UTF-8"?>
<note>
<to>Tove</to>
<from>Jani</from>
<heading>Reminder</heading>
<body>Don't forget me this weekend!</body>
</note>
```

## 61.3 Load and Output XML

​	We want to initialize the XML parser, load the xml, and output it:

```
<?php
$xmlDoc = new DOMDocument();
$xmlDoc->load("note.xml");
print $xmlDoc->saveXML();
?>
```

​	The output of the code above will be:

```
Tove Jani Remider Don't forget me this weekend!
```

​	If you select "View source" in the browser window, you will see the following HTML:

```
<?xml version="1.0" encoding="UTF-8"?>
<note>
<to>Tove</to>
<from>Jani</from>
<heading>Reminder</heading>
<body>Don't forget me this weekend!</body>
</note>
```

​	The example above creates a DOMDocument-Object and loads the XML from "note.xml" into it. Then the saveXML() function puts the internal XML document into a string, so we can output it.

## 61.4 Looping through XML

​	We want to initialize the XML parser, load the XML, and loop through all elements of the \<note> element:

```
<?php
$xmlDoc = new DOMDocument();
$xmlDoc->load("note.xml");
$x = $xmlDoc->documentElement;
foreach ($x->childNodes AS $item) {
  print $item->nodeName . " = " . $item->nodeValue . "<br>";
}
?>
```

​	The output of the code above will be:

```
#text =
to = Tove
#text =
from = Jani
#text =
heading = Reminder
#text =
body = Don't forget me this weekend!
#text =
```

​	In the example above you see that there are empty text nodes between each element!

​	When XML generates, it often contains white-spaces between the nodes. The XML DOM parser treats these as <b>ordinary elements</b>, and if you are not aware of them, they sometimes cause problems.



# 62. PHP - AJAX Introduction

​	AJAX is about updating parts of a web page, without reloading the whole page.

## 62.1 What is AJAX

​	AJAX = Asynchronous JavaScript and XML. AJAX is a technique for creating fast and dynamic web pages.

​	AJAX allows web pages to be updated asynchronously by exchanging small amounts of data with <b>server behind the scenes</b>. This means that it is possible to update parts of web page, without reloading the whole page.

​	Classic web pages, (which do not use AJAX) must reload the entire page if the content should change. Examples of applications using AJAX: Google Maps, Gmail, Youtube, and Facebook tabs.

## 62.2 How AJAX Works

<img src="img/AJAX_diagram.jpg">

## 62.3 AJAX is Based on Internet Standards

​	AJAX is based on internet standards, and use a combination of:

* XMLHttpRequest object (to exchange data asynchronously with a server)
* JavaScript/DOM (to display/interact with the information)
* CSS (to style the data)
* XML (often used as the format for transferring data)

<b>Note:</b> AJAX applications are browser-  and platform-independent!

## 62.4 Google Suggest

​	AJAX was made popular in 2005 by Google, with Google Suggest.

​	Google Suggest is using AJAX to create a very dynamic web interface: When you start typing in Google's search box, a JavaScript sends the letters off to a server and the server returns a list of suggestions.



# 63. PHP - AJAX and PHP

​	AJAX is used to create more interactive applications.

## 63.1 AJAX PHP Example

​	The following example will demonstrate how a web page can communicate with a weh server while a user type characteers in an input field.

​	When a user types a character in the input field, a function called "showHint()" is executed.

​	The function is triggered by the onkeyup event, here is the HTML code:

```
<html>
<head>
<script>
function showHint(str) {
  if (str.length == 0) {
    document.getElementById("txtHint").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "gethint.php?q=" + str, true);
    xmlhttp.send();
  }
}
</script>
</head>
<body>
<p><b>Start typing a name in the input field below:</b></p>
<form action="">
  <label for="fname">First name:</label>
  <input type="text" id="fname" name="fname" onkeyup="showHint(this.value)">
</form>
<p>Suggestions: <span id="txtHint"></span></p>
</body>
</html>
```

​	Code explanation:

​	First, check it the input field is empty (str.length == 0). If it is, clear the content of the txtHit placeholder and exit the function.

​	However, if the input field is not empty, do the following:

* Create an XMLHttpRequest object
* Create the function to be executed when the server response is ready
* Send the request off to a PHP file (gethit.php) on the server
* Notice that q parameter is added to the url (gethint.php?q="+str)
* And the str variable holds the content of the input field

## 63.2 The PHP File - "gethint.php"

​	The PHP file checks an array of names, and returns the corresponding name(s) to the browser:

```
<?php
// Array with names
$a[] = "Anna";
$a[] = "Brittany";
$a[] = "Cinderella";
$a[] = "Diana";
$a[] = "Eva";
$a[] = "Fiona";
$a[] = "Gunda";
$a[] = "Hege";
$a[] = "Inga";
$a[] = "Johanna";
$a[] = "Kitty";
$a[] = "Linda";
$a[] = "Nina";
$a[] = "Ophelia";
$a[] = "Petunia";
$a[] = "Amanda";
$a[] = "Raquel";
$a[] = "Cindy";
$a[] = "Doris";
$a[] = "Eve";
$a[] = "Evita";
$a[] = "Sunniva";
$a[] = "Tove";
$a[] = "Unni";
$a[] = "Violet";
$a[] = "Liza";
$a[] = "Elizabeth";
$a[] = "Ellen";
$a[] = "Wenche";
$a[] = "Vicky";
// get the q parameter from URL
$q = $_REQUEST["q"];
$hint = "";
// lookup all hints from array if $q is different from ""
if ($q !== "") {
  $q = strtolower($q);
  $len=strlen($q);
  foreach($a as $name) {
    if (stristr($q, substr($name, 0, $len))) {
      if ($hint === "") {
        $hint = $name;
      } else {
        $hint .= ", $name";
      }
    }
  }
}
// Output "no suggestion" if no hint was found or output correct values
echo $hint === "" ? "no suggestion" : $hint;
?>
```



# 64. PHP - AJAX and MySQL

​	AJAX can be used for interactive communication with a databse.

## 64.1 AJAX Database Example

​	The following example will demonstrate how a web page can fetch information from a data base with AJAX.

​	In the example below, when a user selects a person in the dropdown list, a function called "showUser()" is executed. The function is triggered by the onchange event.

​	Here is the HTML code:

```
<html>
<head>
<script>
function showUser(str) {
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","getuser.php?q="+str,true);
    xmlhttp.send();
  }
}
</script>
</head>
<body>
<form>
<select name="users" onchange="showUser(this.value)">
  <option value="">Select a person:</option>
  <option value="1">Peter Griffin</option>
  <option value="2">Lois Griffin</option>
  <option value="3">Joseph Swanson</option>
  <option value="4">Glenn Quagmire</option>
  </select>
</form>
<br>
<div id="txtHint"><b>Person info will be listed here...</b></div>
</body>
</html>
```

Code explanation:

​	First, check if person is selected. If no person is selected (str == ""), clear the content of txtHint and exit the function. If a person is selected, do the following:

* Create an XMLHttpRequest object
* Create the function to be executed when the server response is ready
* Send the request off to a file on the server
* Notice that a parameter (q) is added to the URL (with the content of the dropdown list)

## 64.2 The PHP File

​	The page on the server called by the JavaScript above is a PHP file called "getuser.php".

​	The source code in "getuser.php" runs a query against a MySQL database, and returns the result in an HTML table:

```
<!DOCTYPE html>
<html>
<head>
<style>
table {
  width: 100%;
  border-collapse: collapse;
}
table, td, th {
  border: 1px solid black;
  padding: 5px;
}
th {text-align: left;}
</style>
</head>
<body>
<?php
$q = intval($_GET['q']);
$con = mysqli_connect('localhost','peter','abc123');
if (!$con) {
  die('Could not connect: ' . mysqli_error($con));
}
mysqli_select_db($con,"ajax_demo");
$sql="SELECT * FROM user WHERE id = '".$q."'";
$result = mysqli_query($con,$sql);
echo "<table>
<tr>
<th>Firstname</th>
<th>Lastname</th>
<th>Age</th>
<th>Hometown</th>
<th>Job</th>
</tr>";
while($row = mysqli_fetch_array($result)) {
  echo "<tr>";
  echo "<td>" . $row['FirstName'] . "</td>";
  echo "<td>" . $row['LastName'] . "</td>";
  echo "<td>" . $row['Age'] . "</td>";
  echo "<td>" . $row['Hometown'] . "</td>";
  echo "<td>" . $row['Job'] . "</td>";
  echo "</tr>";
}
echo "</table>";
mysqli_close($con);
?>
</body>
</html>
```

Explanation: When the query is sent from the JavaScript to the PHP file, the following happends:

1. PHP opens a connection to a MySQL database
2. The correct person is found
3. An HTML table is created, filled with data, and sent back to the "txtHint" placeholder

​	As for DPO, use below code (here use my database "myGuests"):

```
<!DOCTYPE html>
<html>
<head>
<style>
table {
        width: 100%;
        border-collapse: collapse;
}
table, td, th {
        border: 1px solid black;
		padding: 5px;
}
th {text-align: left;}
</style>
</head>
<body>
<?php
$q = intval($_GET['q']);
$servername = "localhost";
$username = "pf";
$password = "pf135";
$dbname = "myDBPDO";
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if(!$conn) {
        die("Could not connect...");
}
$sql = "SELECT * FROM myGuests WHERE id = '".$q."'";
$stmt = $conn->query($sql);
//$stmt = $conn->prepare($sql);
//$result = $stmt->execute();
echo "<table>
<tr>
<th>Firstname</th>
<th>Lastname</th>
<th>Email</th>
<th>reg_date</th>
</tr>";
while($row = $stmt->fetch(PDO::FETCH_NUM)) {
        echo "<tr>";
        echo "<td>" . $row[1] . "</td>";
        echo "<td>" . $row[2] . "</td>";
        echo "<td>" . $row[3] . "</td>";
        echo "<td>" . $row[4] . "</td>";
        echo "</tr>";
}
echo "</table>";
$conn = null;
?>
</body>
</html>
```



# 65. PHP Example - AJAX and XML

​	AJAX can be used for interactive communication with an XML file.

## 65.1 AJAX XML Example

​	The following example will demonstrate how a web page can fetch information from an XML file with AJAX.

​	When a user selects a CD in the dropdown list, a function called "showCD()" is executed. The function is triggered by the "onchange" event:

```
<html>
<head>
<script>
function showCD(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","getcd.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>
<form>
Select a CD:
<select name="cds" onchange="showCD(this.value)">
  <option value="">Select a CD:</option>
  <option value="Bob Dylan">Bob Dylan</option>
  <option value="Bee Gees">Bee Gees</option>
  <option value="Cat Stevens">Cat Stevens</option>
</select>
</form>
<div id="txtHint"><b>CD info will be listed here...</b></div>
</body>
</html>
```

​	The showSD() function does the following:

* Check if a CD is selected
* Create an XMLHttpRequest object
* Create the function to be executed when the server response is ready
* Send the request off to a file on the server
* Notice that a parameter (q) is added to the URL (with the content of the dropdown list)

## 65.2 The PHP File

​	The page on the server called by the JavaScript above is a PHP file called "getcd.php". The PHP script loads an XML document, "cd_catalog.xml" (not show here), runs a query against the XML file, and returns the result as HTML:

```
<?php
$q=$_GET["q"];
$xmlDoc = new DOMDocument();
$xmlDoc->load("cd_catalog.xml");
$x=$xmlDoc->getElementsByTagName('ARTIST');
for ($i=0; $i<=$x->length-1; $i++) {
  //Process only element nodes
  if ($x->item($i)->nodeType==1) {
    if ($x->item($i)->childNodes->item(0)->nodeValue == $q) {
      $y=($x->item($i)->parentNode);
    }
  }
}
$cd=($y->childNodes);
for ($i=0;$i<$cd->length;$i++) {
  //Process only element nodes
  if ($cd->item($i)->nodeType==1) {
    echo("<b>" . $cd->item($i)->nodeName . ":</b> ");
    echo($cd->item($i)->childNodes->item(0)->nodeValue);
    echo("<br>");
  }
}
?>
```

​	When the CD query is sent from the JavaScript to the PHP page, the following happens:

1. PHP creates an XML DOM object
2. Find all \<artist> elements that matches the name sent from the JavaScript
3. Output the album information (send to the "txtHint" placeholder)



# 66. PHP Example - AJAX Live Search

​	AJAX can be used to create more user-friendly and interactive searches.

## 66.1 AJAX Live Search

​	The following example will demonstrate a live search, where you get search results while you type. Live search has many benefit compared to traditional searching:

* Results are shown as you type
* Results narrow as you continue typing
* If results become too narrow, remove characters to see a broader result.

​	The results in the example are found in an XML file (links.xml). To make this example small and simple, only six results are available.

## 66.2 Example Explained - The HTML Page

​	When a user types a character in the input field, the function "showResult()" is executed. The function is triggered by the "onkeyup" event:

```
<html>
<head>
<script>
function showResult(str) {
  if (str.length==0) {
    document.getElementById("livesearch").innerHTML="";
    document.getElementById("livesearch").style.border="0px";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearch").innerHTML=this.responseText;
      document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","livesearch.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>
<form>
<input type="text" size="30" onkeyup="showResult(this.value)">
<div id="livesearch"></div>
</form>
</body>
</html>
```

​	Source code explanation:

​	If the input field is empty (str.length == 0), the function clears the content of the livesearch placeholder and exits the function.

​	If the input field is not empty, the showResult() function executes the following;

* Create an XMLHttpRequest object
* Create the function to be executed when the server response is ready
* Send the request off to a file on the server
* Notice that a parameter (q) is added to the URL (with the content of the input field)

## 66.3 The PHP File

​	The page on the server called by the JavaScript above is a PHP file called "livesearch.php".

​	The source code in "livesearch.php" searches an XML file for titles matching the search string and returns the result:

```
<?php
$xmlDoc=new DOMDocument();
$xmlDoc->load("links.xml");
$x=$xmlDoc->getElementsByTagName('link');
//get the q parameter from URL
$q=$_GET["q"];
//lookup all links from the xml file if length of q>0
if (strlen($q)>0) {
  $hint="";
  for($i=0; $i<($x->length); $i++) {
    $y=$x->item($i)->getElementsByTagName('title');
    $z=$x->item($i)->getElementsByTagName('url');
    if ($y->item(0)->nodeType==1) {
      //find a link matching the search text
      if (stristr($y->item(0)->childNodes->item(0)->nodeValue,$q)) {
        if ($hint=="") {
          $hint="<a href='" .
          $z->item(0)->childNodes->item(0)->nodeValue .
          "' target='_blank'>" .
          $y->item(0)->childNodes->item(0)->nodeValue . "</a>";
        } else {
          $hint=$hint . "<br /><a href='" .
          $z->item(0)->childNodes->item(0)->nodeValue .
          "' target='_blank'>" .
          $y->item(0)->childNodes->item(0)->nodeValue . "</a>";
        }
      }
    }
  }
}
// Set output to "no suggestion" if no hint was found
// or to the correct values
if ($hint=="") {
  $response="no suggestion";
} else {
  $response=$hint;
}
//output the response
echo $response;
?>
```

​	If there is any text sent from the JavaScript (strlen($q) > 0), the following happens:

* Load an XML file into a new XML DOM object
* Loop through all \<title> elements to find matches from the text sent from the JavaScript
* Sets the correct url and title in the "$response" variable. If more than one match is found, all matches are added to the variable
* If no matches are found, the $response variable is set to "no suggestion"

 

# 67. PHP Example - AJAX Poll

## 67.1 AJAX Poll

​	The following example will demonstrate a poll where the result is shown without reloading.

​	When a user chooses an option, a function called "getVote()" is executed. The function is triggered by the "onclick" event:

```
<html>
<head>
<script>
function getVote(int) {
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("poll").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","poll_vote.php?vote="+int,true);
  xmlhttp.send();
}
</script>
</head>
<body>
<div id="poll">
<h3>Do you like PHP and AJAX so far?</h3>
<form>
Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
</form>
</div>
</body>
</html>
```

​	The getVote() function does the following:

* Create an XMLHttpRequest object
* Create the function to be executed when the server response is ready
* Send the request off to a file on the server
* Notice that a parameter (vote) is added to the URL (with the value of the yes or no option)

## 67.2 The PHP File

​	The page on the server called by the JavaScript above is a PHP file called "poll_vote.php":

```
<?php
$vote = $_REQUEST['vote'];
//get content of textfile
$filename = "poll_result.txt";
$content = file($filename);
//put content in array
$array = explode("||", $content[0]);
$yes = $array[0];
$no = $array[1];
if ($vote == 0) {
  $yes = $yes + 1;
}
if ($vote == 1) {
  $no = $no + 1;
}
//insert votes to txt file
$insertvote = $yes."||".$no;
$fp = fopen($filename,"w");
fputs($fp,$insertvote);
fclose($fp);
?>
<h2>Result:</h2>
<table>
<tr>
<td>Yes:</td>
<td><img src="poll.gif"
width='<?php echo(100*round($yes/($no+$yes),2)); ?>'
height='20'>
<?php echo(100*round($yes/($no+$yes),2)); ?>%
</td>
</tr>
<tr>
<td>No:</td>
<td><img src="poll.gif"
width='<?php echo(100*round($no/($no+$yes),2)); ?>'
height='20'>
<?php echo(100*round($no/($no+$yes),2)); ?>%
</td>
</tr>
</table>
```

​	The value is sent from the JavaScript, and the following happens:`

1. Get the content of the "poll_result.text" file
2. Put the content of the file in variables and add one to the selected variable
3. Write the result to the "poll_result.txt" file
4. Output a graphical representation of the poll result

## 67.3 The Text File

​	The text file (poll_result.txt) is where we store the data from the poll. It is stored like this:

```
0||0
```

​	The first number represents the "Yes" votes, the second number represents the "No" votes.

<b>Note:</b> Remember to allow your web server to edit the text file. Do <b>NOT</b> give everyone, just the web server (PHP).

Practice them...

<span style="color:red;">Tues, April 25, 2023. 19:31. Library floor 2, zone c, 298.</span>