# 1. React Tutorial 

​	React is a JavaScript library for building user interfaces.

​	React is used to build single-page application.

​	React allows us to create reusable UO components.

## 1.1 Create React App

​	To learn and test React, you should set up a React Enviornment on your computer.

​	This tutorial uses the <span style="color: red;">create-react-app</span>. The <span style="color: red;">create-react-app</span> tool is an officially supported way to create React applications.

​	Node.js is required to use <span style="color: red;">create-react-app</span>. Open you terminal in the directory you would like to create your application. Run this command to create a React application named my-react-app:

```
npx create-react-app my-react-app
```

​	<span style="color: red;">create-react-app</span> will set up everything you need to run a React application.

<b>Note:</b> If you've previously installed <span style="color: red;">create-react-app</span> globally, it is recommended that you uninstall the package to ensure npx always uses the lateset version of <span style="color: red;">create-react-app</span>. To uninstall, run this command: <span style="color: red;">npm-uninstall -g create-react-app</span>.

## 1.3 Run the React Application

​	Run those command to move to the <span style="color: red;">my-react-app</span> directory and execute the React application:

```
cd my-react-app
npm start
```

​	A ne browser window will pop up with your newly created React APP! If not, open your browser and type localhost:3000 in the address bar.

## 1.4 What you should already know

​	Before starting with React.JS, you should have intermediate exprience in:

* HTML
* CSS
* JavaScript

​	You should also have some experience with the new JavaScript features introduced in ECMAScript 6 (ES6), you will learn about them in the React ES6 chatper.



# 2. React Introduction

## 2.1 What is React?

​	React, sometimes referred to as a frontend JavaScript framework, is a JavaScript library created by Facebook. React is a tool for building UI components.

## 2.2 How does React Work?

​	1. React creates a VIRTUAL DOM in memory.

​	Instead of manipulating the browser's DOM directory, React creates a virtual DOM in memory, where it does all the necessary manipulatng, before making the changes in the browser DOM.

	2. React only changes what needs to be changed!

​	React finds out what changes have been made, and change <b>only</b> what needs to be changed. You will learn the various aspects of how React does this in the rest of this tutorial.

## 2.3 React.JS History

​	Current version of React.JS is v18.0.0 (April 2022, v18.16.0 April 2023). Initial Release to the Public (v0.3.0) was in July 2013. React.JS was first used in 2011 for Facebook's Newsfeed feature. Facebook Software Enginner, Jordan Walke, created it.

​	Current version of <span style="color: red;">create-react-app</span> is v5.0.1 (April 2022). <span style="color: red;">create-react-app</span> includes built toos such as webpack, Babel, and ESLint.



# 3. React Getting Started

​	To use React in production, you need npm which is included with Node.js.

​	To get an overview of what React is, you can write React code directory in HTML.

​	But in order to use React in production, you need npm and Node.js installed.

## 3.1 React Directory in HTML

​	The quickest way start learning React is to write React directory in your HTML files.

​	Start by including three scripts, the first two let us write React code in our JavaScripts, and the third, Babel, allows us to write JSX syntax and ES6 in older browsers.

```
//Example: Include three CDN's in HTML file:
<!DOCTYPE html>
<html>
  <head>
    <script src="https://unpkg.com/react@18/umd/react.development.js" crossorigin></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js" crossorigin></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  </head>
  <body>

    <div id="mydiv"></div>

    <script type="text/babel">
      function Hello() {
        return <h1>Hello World!</h1>;
      }

      ReactDOM.render(<Hello />, document.getElementById('mydiv'))
    </script>

  </body>
</html>
```

​	This way of using React can be OK for testing purposes, but for producation you will need to set up a <b>React environment</b>.

## 3.2 Setting up a React Environment

​	If you have npx and Node.js installed, you can create a React application by using <span style="color: red;">create-react-app</span> as described above. This command set up everything you need to run a React application.

## 3.3 Run the React Application

```
cd my-react-app
npm start
```

​	I hadn't found a way to access the port in my server (where I created my React environment), no matter <i>publicIP:3000</i> or <i>localIP</i>:3000, so I had to create a React environment in my vritual machine.

## 3.4 Modify the React Application

​	So far so good, but how do I change the content?

​	Look in the <span style="color: red;">my-react-app</span> diectory, and you will find a <span style="color: red;">src</span> folder. Inside the <span style="color: red;">src</span> folder there is a file called <span style="color: red;">App.js</span>, open it and it will look like this:

```
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
```

​	We can try changing the HTML content and save the file.

<b>Note:</b> Notice that the changes are visible immediately after you save the file, you do not have to reload the browser!

## 3.5 What's Next?

​	Now you have a React Environment on your computer, and you are ready to learn more about React. In the rest of this tutorial we will use our "Show React" tool to explain the various aspectes of React, and how they are displayed in the browser.

​	If you want to follow the same steps on your computer, start by stripping dow the <span style="color: red;">src</span> floder to only contain one file: <span style="color: red;">index.js</span>. You should asl remove any unnecessary lines of code inside the <span style="color: red;">index.js</span> file to make them look like the example in the "Show React" tool below:

```
import React from 'react';
import ReactDOM from 'react-dom/client';

const myFirstElement = <h1>Hello React!</h1>

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(myFirstElement);
```



# 4. React ES6

## 4.1 React ES6

### 4.1.1 What is ES6?

​	ES6 stands for ECMAScript 6.

​	ECMAScript was created to standardize JavaScript, and ES6 is the 6th version of ECMAScript, it was published in 2015, and is also known as ECMAScript 2015.

### 4.1.2 Why Should I Learn ES6?

​	React uses ES6, and you should be familiar with some of the new features like:

* Classes
* Arrow Functions
* Variables (let, const, var)
* Array Methods like <span style="color: red;">.map()</span>
* Destructuring
* Modules
* Ternary Operator
* Spread Operator

​	Some of them have studied previously, so I will omit some content.

## 4.2 React ES6 Classes

### 4.2.1 Classes

​	A class is a type of function, but instead of using the keyword <span style="color: red;">function</span> to initiate it, we use the keyword <span style="color: red;">class</span>, and the properties are assigned inside a <span style="color: red;">constructor()</span> method.

```
class Car {
	constructor(name) {
		this.brand = name;
	}
}
```

<b>Note:</b> Notice the case of the class name. We have begun the name, "Car", with an uppercase character. This is a standard naming convention for classes.

​	Now you can create objects using the Car class:

```
const mycar = new Car("BYD");
```

<b>Note:</b> The constructor function is called automatically when the object is initialized.

### 4.2.2 Method in Classes

​	You can add your own methods in a class:

```
class Car {
	constructor(name) {
		this.brand = name;
	}
	present() {
		return 'I have a ' + this.brand;
	}
}
const mycar = new Car("BYD");
mycar.present();
```

### 4.2.3 Class Inheritance

​	To create a class inheritance, use the <span style="color: red;">extends</span> keyword.

​	A class created with a class inheritance inherits all the methods from another class:

```
class Car {
	constructor(name) {
		this.brand = name;
	}
	present() {
		return 'I have a ' + this.brand;
	}
}
class BYD extends Car {
	constructor(name, series) {
		super(name);
		this.series = series;
	}
	show() {
		return this.present() + ', it is a ' + this.series;
	}
}
const mycar = new BYD("BYD", "Han");
mycar.show();
```

## 4.3 React ES6 Arrow Functions

### 4.3.1 Arrow Functions

​	Arrow functions allow us to write shorter function syntax:

```
hello = () => {
	return "Hello";
}
```

​	If the function has only one statement, and statement returns a value, you can remove the brackets and the <span style="color: red;">return</span> keyword:

```
hello = () => "Hello";
```

### 4.3.2 What about this?

​	Thd handling of <span style="color: red;">this</span> is also different in arrow functions compared to regular functions.

​	In short, with arrow functions there is no binding of <span style="color: red;">this</span>.

​	In regular functions the <span style="color: red;">this</span> keyword represented the object that called the function, which could be the window, the document, a button or whatever.

​	With arrow functions, the <span style="color: red;">this</span> keyword <i>always</i> represents the object that defined the arraow function.

​	Let us take a look at two examples to understand the difference.

​	With regular function, <span style="color: red;">this</span> represents the object that called the function, so it returns two different objects:

```
<button id="btn">Click Me!</button>
<p><strong>this</strong> represents:</p>
<p id="demo"></p>
<p>See the difference before and after the button is clicked.</p>
  
<script>
class Header {
  constructor() {
    this.color = "Red";
  }

  changeColor = function() {
    document.getElementById("demo").innerHTML += this;
  }
}
const myheader = new Header();
//The window object calls the function:
window.addEventListener("load", myheader.changeColor);
//A button object calls the function:
document.getElementById("btn").addEventListener("click", myheader.changeColor);
</script>
```

​	With an arrow function, <span style="color: red;">this</span> represents the Header object no matter who called the function:

```
<button id="btn">Click Me!</button>
<p><strong>this</strong> represents:</p>
<p id="demo"></p>

<script>
class Header {
  constructor() {
    this.color = "Red";
  }

  changeColor = () => {
    document.getElementById("demo").innerHTML += this;
  }
}
const myheader = new Header();
//The window object calls the function:
window.addEventListener("load", myheader.changeColor);
//A button object calls the function:
document.getElementById("btn").addEventListener("click", myheader.changeColor);
</script>
```

## 4.4 React ES6 Variables

### 4.4.1 Variables

​	Before ES6 there was only one way of defining your varibales: with the 

<span style="color: red;">var</span> keyword. If you did not define them, they would be assigned to the global object. Unless you were in strict mode, then you would get an error if your variables were undefined.

​	Now, with ES6, there are three ways of defining your variables: <span style="color: red;">var</span>, <span style="color: red;">let</span> , and <span style="color: red;">const</span>.

```
var x = 5.6;
```

​	If you use <span style="color: red;">var</span> outside of a function, it belongs to the global scope, and inside of a function, it belongs to that function, if you use <span style="color: red;">var</span> inside of a block, i.e. a for loop, the variable is still available outside of that block.

<b>SO:</b> <span style="color: red;">var</span> has a <i>function</i> scope, not a <i>block</i> scope.

```
let x = 4.7;
```

​	<span style="color: red;">let</span> is the block scoped version of <span style="color: red;">var</span>, and is limited to the block (or expression) where it is defined. If you use <span style="color: red;">let</span> inside of a block, i.e. a for loop, the variable is only available inside that loop.

<b>SO:</b> <span style="color: red;">let</span> has a block scope.

```
const x = 1.9;
```

​	<span style="color: red;">const</span> is a variable that once it has been created, its value can never change.

<b>Note:</b> <span style="color: red;">const</span> has a <i>block</i> scope. And the keyword <span style="color: red;">const</span> is a bit misleading:

​	Because of this you can NOT:

* Reassign a constant value
* Reassign a constant array
* Reassign a constant object

​	But you CAN:

* Change the elements of constant array (you can think that <i>array</i> variable is a link, the link is constant, but the elements of the link can be changed)
* Change the properties of constant object

## 4.5 React ES6 Array Methods

### 4.5.1 Array Methods

​	There are many JavaScript array methods. One of the most useful in React is the <span style="color: red;">.map()</span> array method. The <span style="color: red;">.map()</span> method allows you to run a function on each item in the array, returning a new array as the result. 

​	In React, <span style="color: red;">map()</span> can be used to generate lists.

```
const myArray = ['apple', 'banana', 'orange'];
const myList = myArray.map((item) => <p>{item}</p>)
```

## 4.6 React ES6 Destructing

### 4.6.1 Destructing

​	To illustrate destructing, we'ill make a sandwich. Do you take everything out of the refrigerator to make your sandwich? No, you only take out the items you would like to use on your sandwich.

​	Destructing is exactly the same. We may have an array or object that we are working with, but we only need some of the items contained in these. Destructing makes it easy to extrace only what is needed.

### 4.6.2 Destructing Arrays

​	Here is the old way of assigning array items to variable:

```
const vehicles = ['mustang', 'f-150', 'expedition'];
const car = vehicles[0];
const truck = vehicles[1];
const suv = vehicles[2];
```

​	Here is the new way of assinging array items to a variable:

```
const [car, truck, suv] = vehicles;
```

<b>Note:</b> When destructing arrays, the order that variables are declared is important.

​	If we only want the car and suv we can simply leave out the truck but keep  the comma:

```
const [car,, suv] = vehicles;
```

​	Destructing comes in handy when a function returns an array:

```
function calculate(a, b) {
	const add = a + b;
	const subtract = a - b;
	const multiply = a * b;
	const divide = a / b;
	return [add, subtract, multiply, divide];
}
const [add, subtract, multiply, divide] = calculate(54, 9);
```

### 4.6.3 Destructing Objects

​	Here is the old way of using an object inside a function:

```
const vehicleOne = {
	brand: 'BYD',
	model: 'Han',
	type: 'car',
	year: 2023,
	color: 'white'
}
myVehicle(vehicleOne);
//old way:
function myVehicle(vehicle) {
	const message = 'My ' + vehicle.type + ' is a ' + vehicle.color + ' ' + vehicle.brand + ' ' + vehicle.model + '.';
}
```

​	Here is the new way of using an object inside a function:

```
function myVehicle({type, color, brand, model}) {
	const message = 'My ' + type + ' is a ' + color + ' ' + brand + ' ' + model + '.';
}
```

<b>Note:</b> The object properteis do not have to be declared in a specific order.

​	We can even destructure deeply nested objects by referencing the nested object then using a colon and curly braces to again destructure the items needed from the nested object:

```
const vehicleOne = {
  brand: 'Ford',
  model: 'Mustang',
  type: 'car',
  year: 2021, 
  color: 'red',
  registration: {
    city: 'Houston',
    state: 'Texas',
    country: 'USA'
  }
}
myVehicle(vehicleOne)
function myVehicle({ model, registration: { state } }) {
  const message = 'My ' + model + ' is registered in ' + state + '.';
}
```

## 4.7 React ES6 Spread Operator

### 4.7.1 Spread Operator

​	The JavaScript spread operator (...) allows us to quickly copy all or part of an existing array or object into another array or object.

```
const numbersOne = [1, 2, 3];
const numbersTwo = [4, 5, 6];
const numbersCombined = [...numbersOne, ...numbersTwo];
```

​	The spread operator is often used in combination with destructing.

```
//Assign the first and second item from numbers to variables and put the rest in an array:
const numbers = [1, 2, 3, 4, 5, 6];
const [one, two, ...rest] = numbers;
```

​	We can use the spread operator with objects too:

```
const myVehicle = {
	brand: 'BYD',
	model: 'Han',
	color: 'white'
}
const updateMyVehicle = {
	type: 'car',
	year: 2023,
	color: 'yellow'
}
const myUpdatedVehicle = {...myVehicle, ...updateMyVehicle};
```

<b>Note:</b> The properties that did not match were combined, but the property that did match, 

<span style="color: red;">color</span>, was overwritten by the last object that was passed, <span style="color: red;">updateMyVehicle</span>. The resulting color is now yellow!

## 4.8 React ES6 Modules

### 4.8.1 Modules

​	JavaScript modules allow you to break up your code into spearat files. This makes it easier to maintain the code-base. ES Modules rely on the <span style="color: red;">importt</span> and <span style="color: red;">export</span> statements.

### 4.8.2 Export

​	You can export a function or variable from any file. Let us create a file named <span style="color: red;">person.js</span>, and fill it with the things we want to export. There are two types of exports: Named and Default.

### 4.8.3 Named Exports

​	You can create named exports two ways. In-line individually, or all at once at the bottom.

```
//In-line individually:
export const name = "Jesse";
export const age = 21;			//Like C keyword 'extern'
```

```
//All at once at the bottom
const name = "Biden";
const age = 81;
export {name, age}
```

### 4.8.4 Default Exports

​	Let us create another file, named <span style="color: red;">message.js</span>, and use it for demonstrating default export. You can only have one default export in a file:

```
const message = () => {
	cosnt name = "Trump";
	const age = 76;
	return name + ' is ' + age + 'years old.';
}
export default message;
```

## 4.8.5 Import

​	You can import modules into a file in two ways, based on if they are named exports or default exports. Nmaed exports must be destructed using curly braces:

```
//Import named exports from the file person.js
import {name, age} from "./person.js";
```

```
//Import a default from the file message.js
import message from "./message.js";
```

## 4.9 React ES6 Ternary Operator

### 4.9.1 Ternary Operator

​	The ternary operator is a simplified conditional operator like <span style="color: red;">if</span> / <span style="color: red;">else</span>.

Syntax:

​	<span style="color: red;">condition ? \<expression if true> : \<expression if false></span>

```
//An example using if-else
if (authenticated) {
	renderApp();
} else {
	renderLogin();
}
```

​	Here is the same example using a ternary operator:

```
authenticated ? renderApp() : renderLogin();
```



# 5. React Render HTML

​	React's goal is in many way to render HTML in a web page.

​	React renders HTML to the web page by using a function called <span style="color: red;">createRoot()</span> and its method <span style="color: red;">render()</span>.

## 5.1 The createRoot Function

​	The <span style="color: red;">createRoot()</span> function takes one argument, an HTML element. The purpose of the function is to define the HTML element where a React component should be displayed.

## 5.2 The render Method

​	The <span style="color: red;">rende()</span> method is then called to define the React component that should be rendered. But render where?

​	There is another folder in the root directory of you React project, named "public". In this folder, there is an <span style="color: red;">index.html</span> file.

​	You'll notice a single <span style="color: red;">\<div></span> in the body of this file. This is where our React application will be rendered.

```
//Display a paragraph inside an element with the id of "root":
const container = docuement.getElementById('root');
const root = ReactDOM.createRoot(container);
roo.render(<p>An element</p>);
```

​	The result is:

```
<body>
	<div id="root"><p>An element</p></div>
</body>
```

## 5.3 The HTML Code

​	The HTML code in this tutorial uses JSX which allows you to write HTML tags inside the JavaScript code:

​	Do not worry if the syntax is unfamiliar, you will learn more about JSX in the next chapter.

```
//Create a variable that contains HTML code and display it in the "root" node
const myelement = (
	<table>
		<tr>
			<th>Name</th>
		</tr>
		<tr>
			<td>John</td>
		</tr>
	</table>
);
const container = document.getElementById('root');
const root = ReactDOM.createRoot(container);
root.render(myelement);
```

## 5.4 Th Root Node

​	The root node is the HTML element where you want to display the result.

​	It is like a <i>container</i> for content managed by React. It does NOT have to be a <span style="color: red;">\<div></span> element and it does NOT have to have the <span style="color: red;">id='root'</span>.

```
<!-- The root node can be called whatever you like: -->
<body>
	<header id="sandy"></header>
</obdy>
```

```
//Display the result in the <header id="sandy"> element
const container = document.getElementById('sandy');
const root = ReactDOM.createRoot(container);
root.render(<p>Hello</p>);
```



# 6. React JSX

## 6.1 What is JSX?

​	JSX stands for JavaScritp XML. JSX allows us to write HTML in React. JSX makes it easier to write and add HTML in React.

## 6.2 Coding JSX

​	JSX allows us to write HTML element in JavaScript and place them in the DOM without any <span style="color: red;">createElement()</span> and/or <span style="color: red;">appendChild()</span> methods.

​	JSX converts HTML tags into react elements.

<b>Note:</b>  You are not required to use JSX, but JSX makes it easier to write React applications.

​	Here are two examples. The first uses JSX and the second does not:

```
//With JSX:
const myElement = <h1>I Love JSX!</h1>;
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(myElement);
```

```
//Without JSX:
const myElement = React.createElement('h1', {}, 'I won't use JSX!');
const root = ReactDOM.createRoto(document.getElementById('root'));
root.render(myElement);
```

​	As you can see in the first example, JSX allows us to write HTML directly within the JavaScript code. JSX is an extension of the JavaScript language based on ES6, and is tranlated into regular JavaScript at runtime.

## 6.3 Expressions in JSX

​	With JSX you can write expressions inside curly braces. The expression can be a React variable, or property, or any other valid JavaScript expression. JSX will execute the expression and return the result:

```
//Execute the expression 5 + 7
const myElement <h1>React is {5 + 7} times better with JSX</h1>;
```

## 6.4 Inserting a Large Block of HTML

​	To write HTML on multiple lines, put the HTML inside parenthese.

```
const myElement = (
	<u>
		<li>Mon</li>
		<li>Tue</li>
	</ul>
);
```

## 6.5 One Top Level Element

​	The HTML code must be wrapped in ONE top level element. So if you like to write two paragraphs, you must put them inside a parent element, like a <span style="color: red;">\<div></span> element.

```
//Wrap two paragraphs inside one DIV element:
const myElement = (
	<div>
		<p>It is a waste of energy when we try to conform to a pattern</p>
		<p>You are the world and the world is you.</p>
	</div>
);
```

<b>Note:</b> JSX will throw an error is the HTML is not correct, or if the HTML misses a parent element.

​	Alternatively, you can use a "fragment" to wrap multiple lines. This will prevent unnecessarily adding extra nodes to the DOM. a fragment looks like an empty HTML tag: <span style="color: red;">\<>\</></span>.

```
//Wrap two paragraphs inside a fragment
const myElement = (
	<>
		<p>Love, freedom, goodness and beauty are one, not separate.</p>
		<p>Beauty is where there is order.</p>
	</>
);
```

## 6.6 Elements Must be Closed

​	JSX <span style="color: blue;">follows XML rules</span>, and therefore HTML elements must be properly closed:

```
//Close empty elements with />
const myElement = <input type="text" />
```

<b>Note:</b> JSX will throw an error if the HTML is not properly closed.

## 6.7 Attribute class = className

​	The <span style="color: red;">class</span> attribute is a much used attribute in HTML, but since JSX is rendered as JavaScript, and the <span style="color: red;">class</span> keyword is a reserved word in JavaScript, you are not allowed to use it in JSX.

<b>Note:</b> If you want to dfine a class name, use attribute <span style="color: red;">className</span> instead. When JSX is rendered, it translates <span style="color: red;">className</span> attributes into <span style="color: red;">class</span> attributes.

```
const myElement = <h1 className="myclass">Hello</h1>;
```

## 6.8 Conditions - if statements

​	React supports <span style="color: red;">if</span> statements, but not <i>inside</i> JSX.

​	To be able to use conditional statements in JSX, you should put the <span style="color: red;">if</span> statements outside of the JSX, or you could use a ternary expression insted:

<span style="font-size:19px;">Option 1:</span>

​	Write <span style="color: red;">if</span> statements outside of the JSX code:

```
const x = 5;
let text = "Goodbye";
if (x < 10) {
	text = "Hello";
}
const myElement = <h1>{text}</h1>;
```

<span style="font-size:19px;">Option 2:</span>

​	Use ternary expressions instead:

```
const x = 5;
const myElemetn = <h1>{(x) < 10 ? "Hello" : "Goodbye"}</h1>;
```

<b>Note:</b> In order to embed a JavaScript expression inside JSX, the JavaScript must be wrapped with curly braces, <span style="color: red;">{ }</span>.



# 7. React Components

​	Components are like functions that return HTML elements.

## 7.1 React Components

​	Components are independent and reusable bits of code. They serve the same purpose as JavaScritp functions, but work in isolation and return HTML.

​	Components come in two types, Class components and Function components, in this tutorial we will concentrate on Function components.

<b>Note:</b> In older React code bases, you may find Class components primarily used. It is now suggested to use Function components along withh Hooks, which were added in React 16.9. There is an optional section on Class componentss for your reference.

## 7.2 Create Your First Component

​	When creating a React component, the componet's name <i>MUST</i> start with an upper case letter.

### 7.2.1 Class Component

​	A class component must include the <span style="color: red;">extends React.Component</span> statement. This statement creates an inheritance to React.Component, and give your componets access to React.Component's functions.

​	To component also requires a <span style="color: red;">render()</span> method, this method returns HTML.

```
class Car extends React.Component {
	render() {
		return <h2>Hi, a class component for car</h2>;
	}
}
```

### 7.2.2 Function Component

​	Here is the same same example as above, but created using a Function compoent instead. A function componet also returns HTML, and behaves much the same way as a Class component, but Function components can be written using much less code, are easier to understand, and will be preferred in this tutorial:

```
//Create a Function component called Car
function Car() {
	return <h2>Hi, a function component for a car</h2>;
}
```

## 7.3 Rendering a Component

​	Now your React application has a component called Car, which returns an <span style="color: red;">\<h2></span> element. To use this component in your application, use similiar syntax as normal HTML: <span style="color: red;">\<Car /></span>:

```
//Display the Car component in the "root" element:
const root = ReactDOM.createRoot(document.getELementById('root'));
root.render(<Car />);
```

## 7.4 Props

​	Components can be passed as <span style="color: red;">props</span>, whichh stands for properties.

​	Props are like function arguments, and you send them into the component as attributes. You will learn more about <span style="color: red;">props</span> in the next chapter:

```
//Use an attribute to pass a color to the Car component, and use it in the render() function:
function Car(props) {
	return <h2>I am a {props.color} Car!</h2>;
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Car color="red");
```

## 7.5 Components in Components

​	We can refer to components inside other components:

```
//Use the Car component inside the Garage component:
function Car() {
	return <h2>I am a Car!</h2>;
}
function Garage() {
	return (
		<>
			<h1>Who lives in my Garage?</h1>
			<Car />
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Gargae />);
```

## 7.6 Components in Files

​	React is all about re-using code, and it is recommended to split your components into separate files.

​	To do that, create a new file with a <span style="color: red;">.js</span> file extension and put the code inside it.

<b>Note:</b> The filename must start with an uppercase character

```
//Car.js
function Car() {
  return <h2>Hi, I am a Car!</h2>;
}
export default Car;
```

​	To be able to use the Car component, you have to import the file in your application.

```
import React from 'react';
import ReactDOM from 'react-dom/client';
import Car from './Car.js';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Car />);
```



# 8. React Class Componets

​	Before React 16.8, Class components were the only way to track state and lifecycle on a React component. Function component were considered "state-less".

​	With the addition of Hooks, Function components are now almost equivalent to Class components. The different are so minor that you will probably nerver need to use a Class component in React.

​	Even though Function components are preferred, there are no current plans on removing Class components from React. This section will give you an overview of how to use Class components in React.

<b>Note:</b> Feel freeto skip this section, and use Function Components instead.

## 8.1 Create a Class Component

​	When creating a React component, the component's name must start with an upper case letter. The component has to include the <span style="color: red;">extends React.Component</span> statement. The component also requires a <span style="color: red;">render()</span> method (returns HTML):

```
//1.Create a Class component 
class Car extends React.Component {
	render() {
		return <h2>Hi, I am a Car</h2>;
	}
}
```

​	Now use similar syntax as normal HTML: <span style="color: red;">\<Car /></span>:

```
//2.Use the component
root.render(<Car />);
```

## 8.2 Component Constructor

​	If there is a <span style="color: red;">constructor()</span> function in your component, this function will called when the component get initiated. The constructor function is where you initiate the component's properties.

​	In React, component properties shoudl be kept in an object called <span style="color: red;">state</span>.You will learn more about <span style="color: red;">state> </span>later.

​	The construcotr function is also where you honor the inheritance of the parent component by including the <span style="color: red;">super()</span> statement, which executes the parent component's constructor function, and your component has access to all functions of the parent component (<span style="color: red;">React.Component</span>).

```
//Create a constructor function in the Car component, and add a color property
class Car extends React.Component {
	constructor() {
		super();
		this.state = {color: "red"};
	}
	render() {
		return <h2>I am a Car!</h2>;
	}
}
```

​	Use the color property in the render() function:

```
class Car extends React.Component {
	constructor() {
		super();
		this.state = {color: "red"};
	}
	render() {
		return <h2>I am a {this.state.color} Car!</h2>;
	}
}
```

## 8.3 Props

​	Another way of handling component properties is by using <span style="color: red;">props</span>.

```
class Car extends React.Component {
	render() {
		return <h2>I am a {this.props.color} Car!</h2>;
	}
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Car color="red");
```

### 8.3.1 Props in the Constructor

​	If your component has a constructor function, the props should always be passed to the constructor and also to the React.Component via the <span style="color: red;">super()</span> method.

```
class Car extends React.Component {
	constructor(props) {
		super(props);
	}
	render() {
		return <h2>I am a {this.props.model}</h2>;
	}
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Car model="Mustang");
```

## 8.4 Components in Components

 We can refer to components inside other components:

```
//Use the Car components inside the Garage component:
class Car extends React.Component {
	render() {
		return <h2>I am a Car</h2>;
	}
}
class Garage extends React.Component {
	render() {
		return (
			<div>
				<p>Who live in my Garage?</h1>
				<Car />
			</div>
		);
	}
}
const root = ReactDOM.createRoot(document.getElementById('root'));
roor.render(<Garage />);
```

## 8.5 Components in Files

​	Refer prvious chapter.

## 8.6 React Class Component State

​	React Class components have a built-in <span style="color: red;">state</span> object. You might have noticed that we used <span style="color: red;">state</span> eariler in the component constructor section.

​	The <span style="color: red;">state</span> object is where you store property values that belongs to the component.

​	When the <span style="color: red;">state</span> object changes, the component re-renders.

### 8.6.1 Creating the state Object

​	The state object is initialized in the constructor:

```
class Car extends React.Component {
	constructor(props) {
		super(props);
		this.state = {brand: 'BYD'};
	}
	render() {
		//...
	}
}
```

​	The state object can contain as many properties as you like:

```
class Car extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			brand: "BYD",
			model: "Han",
			color: "white",
			year: 2023
		};
	}
	render() {
		//...
	}
}
```

### 8.6.2 Using the state Object

​	Refer to the <span style="color: red;">state</span> object anywhere in the component by using the <span style="color: red;">this.state.propertyname</span> syntax:

```
//Refer to the state object in the render() method:
class Car extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			brand: "BYD",
			model: "Han",
			color: "red",
			year: 2023
		};
	}
	render() {
		return (
			<div>
				<h1>My {this.state.brand}</h1>
				<p>
					It is a {this.state.color}
					{this.state.model}
					from {this.state.year}.
				</p>
			</div>
		);
	}
}
```

	### 8.6.3 Changing the state object

​	To change a value in the state object, use the <span style="color: red;">this.setState()</span> method.

​	When a value in the <span style="color: red;">state</span> object changes, the component will re-render, meaning that the output will change according to the new value(s):

```
//Add a button with an onClick event that will change the color property
class Car extends React.Componet {
	constructor(props) {
		super(props);
		this.state = {
			brand: "BYD",
			model: "han",
			color: "White",
			year: 2023
		};
	}
	changeColor = () => {
		this.setState({color: "blue"});
	}
	render)() {
		return (
			<div>
				<h1>My {this.state.brand}</h1>
				<p>
					It is a {this.state.color}
					{this.state.model}
					form {this.state.year}.
				</p>
				<button type="button"
					coClick={this.changeColor}
				>Change color</button>
			</div>
		);
	}
}
```

<b>Note:</b> Always use the <span style="color: red;">setState()</span> method to change the state object, it will ensure that the component knows its been updated and calls the render() method (and all the other lifecycle method).

## 8.7 Lifecycle of Components

​	Each component in React has a lifecycle which you can monitor and manipulate during its three main phases. The three phases are: <b>Mounting</b>, <b>Updating</b>, and <b>Unmounting</b>.

### 8.7.1 Mounting

​	Mounting means putting elements into the DOM. React has four built-in methods that get called, in this order, when mounting a component:

1. <span style="color: red;">constructor()</span>
2. <span style="color: red;">getDerivedStateFromProps()</span>
3. <span style="color: red;">render()</span>
4. <span style="color: red;">componentDidMount()</span>

​	The <span style="color: red;">render()</span> method is required and will always be called, the others are optional and will be called if you define them.

1. <b>Construtor</b>

​	The <span style="color: red;">constructor()</span> method is called before anything else, when the component is initiated, and it is the natural place to set up the initial <span style="color: red;">state</span> and other initial values.

​	The <span style="color: red;">constructor()</span> method is called with the <span style="color: red;">props</span>, as arguments, and you should always start by calling the <span style="color: red;">super(props)</span> before anything else, this will initiate the parent's constructor method and allows the component to inherit methods form its parent (<span style="color: red;">React.Component</span>):

```
class Header extends React.Component {
	constructor(props) {
		super(props);
		this.state = {favoritecolor: "red"};
	}
	render() {
		return (
			<h1>My Favorite Color is {this.state.favoritecolor}</h1>
		);
	}
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Header />);
```

2. <b>getDerivedStateFromProps</b>

​	The <span style="color: red;">getDrivedStateFromProps()</span> method is called right before rendering the element(s) in the DOM. This is the natural place to set the <span style="color: red;">state</span> object based on the initial <span style="color: red;">props</span>. It takes <span style="color: red;">state</span> as an argument, and returns an object with changes to the <span style="color: red;">state</span>.

​	The example below starts with the favorite color being "red", but the <span style="color: red;">getDerivedStateFromProps()</span> method upadtes the favorite color based on the <span style="color: red;">favcol</span> attribute:

```
class Header extends React.Component {
	constructor(props) {
		super(props);
		this.state = {favoritecolor: "red"};
	}
	static getDerivedStateFromProps(props, state) {
		return {favoritecolor: props.favcol};
	}
	render() {
		return (
			<h1>My Favorite Color is {this.state.favoritecolor}</h1>
		);
	}
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Header favcol="yellow" />);
```

3. <b>render</b>

​	The <span style="color: red;">render()</span> method is required, and is the method that actually outputs the HTML to the DOM.

4. <b>componentDidMount</b>

​	The <span style="color: red;">componentDidMount()</span> method is called after the component is required.

​	This is where you run statements that requires that the component is already placed in the DOM.

```
//At first my favorite color is red, but give me a second, it is yellow
class Header extends React.Component {
	construcot(props) {
		super(props);
		this.state = {favoritecolor: "red"};
	}
	componetDidMount() {
		setTimeout(() = > {
			this.setState({favoritecolor: "yellow"})
		}, 3000);
	}
	render() {
		return (
			<h1>My Favorite Color is {this.state.favoritecolor}</h1>
		);
	}
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Header />);
```

## 8.8 Updating

​	The next phase in the lifecycle is when a component is <i>updated</i>.

​	A component is updated whenever there is a change in the component's <span style="color: red;">state</span> or <span style="color: red;">props</span>.

​	React has five built-in methods that gets called, in this order, when a component is updated:

1. <span style="color: red;">getDerivedStateFromProps()</span>
2. <span style="color: red;">shouldComponentUpdate()</span>
3. <span style="color: red;">render()</span>
4. <span style="color: red;">getSnapshotBeforeUpdate()</span>
5. <span style="color: red;">componentDidUpdate()</span>

​	The <span style="color: red;">render()</span> method is required and will always be called, the others are optional and will be called if you define them.

1. <b>getDerivedStateFromProps</b>

​	Also at <i>updates</i> the <span style="color: red;">getDerivedStateFromProps</span> method is called. This is the first method that is called when a component gets updated. This is still the natural place to see the <span style="color: red;">state</span> object based on the initial props.

​	The example below has a button that changes the favorite color to blue, but since the <span style="color: red;">getDerivedStateFromProps()</span> method is called, which updates the state with the color from the favcol attribute, the favorite color is still rendered as yellow:

```
//If the component gets updated, the getDerivedStateFromProps() method is called:
class Header extends React.Component {
	constructor(props) {
		super(props);
		this.state = {favoritecolor:"red"};
	}
	static getDerivedStateFromProps(pros, state) {
		return {favoritecolor: props.favcol};
	}
	changeColor = () => {
		this.setState({favoritecolor:"blue"});
	}
	render() {
		return (
			<div>
			<h1>My Favorite Color is {this.state.favoritecolor}</h1>
			<button type="button" onClick={this.changColor}>
				Change color</button>
			</div>
		);
	}
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Header favcol="yellow" />);
```

2. <b>shouldComponentUpdate</b>

​	In the <span style="color: red;">shouldComponentUpdate()</span> method you can return a Boolean value that specifies whether React should continue with the rendering or not.

​	The default value is <span style="color: red;">true</span>.

​	The example below shows what happens when the <span style="color: red;">shouldComponentUpdate()</span> method reeturn <span style="color: red;">false</span>:

```
//Stop the component from rendering at any update:
class Header extends React.Component {
  constructor(props) {
    super(props);
    this.state = {favoritecolor: "red"};
  }
  shouldComponentUpdate() {
    return false;
  }
  changeColor = () => {
    this.setState({favoritecolor: "blue"});
  }
  render() {
    return (
      <div>
      <h1>My Favorite Color is {this.state.favoritecolor}</h1>
      <button type="button" onClick={this.changeColor}>Change color</button>
      </div>
    );
  }
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Header />);
```

​	Once you let the <span style="color: red;">shouldComponentUpdate()</span> method returns true, the button can change the color of the element.

3. <b>render</b>

​	The <span style="color: red;">render()</span> method is of course called when a component gets <i>updated</i>, it has to re-render the HTML to the DOM, with the new changes.

4. <b>getSnapshotBeforeUpdate</b>

​	In the <span style="color: red;">getSnapshotBeforeUpdate()</span> method you have access to the <span style="color: red;">props</span> and <span style="color: red;">staet</span> before the update, meaning that even after the update, you can check what the values were before the update.

​	If the <span style="color: red;">getSnapshotBeforeUpdate()</span> method is present, you should also include the <span style="color: red;">componentDidUpdate()</span> method, otherwise you will get an error.	

​	The example below might seem complicated, but all it does is this:

​	When the componet is <i>mounting</i> it is rendered withe the favorite color "red". When the component has been <i>mounted</i>, a timer changes the state, and after one second, the favorite color becoms "yellow". This action triggers the <i>update</i> phase, and since this component has a <span style="color: red;">getSnapshotBeforeUpdate()</span> method, this method is executed, and writes a message to the empty DIV1 element.

​	The the <span style="color: red;">componentDidUpate()</span> method is executed and writes a message in the empty DIV2 element:

```
//Use the getSnapshotBeforeUpdate() method to find out what the state object looked like before the update:
class Header extends React.Component {
	constructor(props) {
		super(props);
		this.state = {favoritecolor:"red"};
	}
	componentDidMount() {
		setTimeout(
			() => {
				this.setSate({favoritecolor:"yellow"})
			}, 2000);
	}
	getSnapshotBeforeUpdate(prevProps, prevState) {
		document.getElementById("div1").innerHTML = 
		"Before the update, the favorite was " + prevState.favoritecolor;
	}
	componentDidUpdate() {
		document.getElementById("div2").innerHTML =
		"The updated favorite is " + this.state.favoritecolor;
	}
	render() {
		return (
			<div>
				<h1>My Favorite Color is {this.state.favoritecolor}</h1>
				<div id="id1"></div>
				<div id="id2"></div>
			</div>
		);
	}
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Head />);
```

5. <b>componetDidUpdate</b>

​	The <span style="color: red;">componetDidUpate</span> method is called after the component is updated in the DOM.

​	You can refer the above code.

## 8.9 <b>Unmounting</b>

​	The next phase in the lifecycle is when a component is removed from the DOM, or <i>unmounting</i> as React likes to call it.

​	React has only one bulit-in method that gets called when a componet is unmounted:

* <span style="color: red;">componentWillUnmount()</span>

​	The <span style="color: red;">compoentWillUnmount</span> method is called when the component is about to be removed from the DOM.

```
//Click the button to delete the header:
class Container extends React.Component {
	constructor(props) {
		super(props);
		this.state = {show:true};
	}
	delHeader = () => {
		this.setState({show:false});
	}
	render() {
		let myheader;
		if (this.state.show) {
			myheader = <Child />;
		}
		return (
			<div> 
			{myheader}
			<button type="button" onClick={this.delHeader}>Delete</button>
			</div>
		);
	}
}
class Child extends React.Component {
	componentWillUnmount() {
		alert("The component is to be unmounted");
	}
	render() {
		return (
			<h1>Child</h1>
		);
	}
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Container />);
```



# 9. React Props

​	Props are arguments passed into React components.

​	Props are passed to components via HTML attributes.

## 9.1 React Props

​	React Props are like function arguments in JavaScript and attributes in HTML.

​	To send props into a computer, use the same syntax as HTML attributes:

```
//Add a "brand" attribute to the Car element:
const myElement = <Car brand="BYD" />;
```

​	The component receives the arguments as a <span style="color: red;">props</span> <span style="color: blue;">object</span>.

```
//Use the barnd attribute in the component:
function Car(props) {
	return <h2>I am a {props.brand}!</h2>;
}
```

## 9.2 Pass Data

​	Props are also how you pass data from one component to another, as parameter:

```
//Send the "brand" property from the Garage component to the Car component:
function Car(props) {
	return <h2>I am a {props.brand}</h2>;
}
function Garage() {
	return (
		<>
			<h1>Who lives in my garage?</h1>
			<Car brand="BYD"/>
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Garage />);
```

​	If you have a variable to send, and not a string as in the example above, just put the variable name inside curly brackets:

```
function Garage() {
	const carName = "BYD";
	return (
		<>
			<h1>Who lives in my garage?</h1>
			<Car brand={carName}/>
		</>
	);
}
```

​	Or if it was an object:

```
function Car(props) {
	return <h2>I am {props.brand.model}</h2>;
}
function Garage() {
	const carInfo = {name: "BYD", model: "Han"};
	return (
		<>
			<h1>Something here...</h1>
			<Car brand={carInfo}/>
		</>
	);
}
```

<b>Note:</b> React Props are read-onl ! You will get an erro if you try to change their value.



# 10. React Events

​	Just like HTML DOM events, React can perform actions based on user events.

​	React has the same events as HTML: click, change, mouseover etc.

## 10.1 Adding Events

​	React events are written in camelCase syntax:

​	<span style="color: red;">onClick</span> instead of <span style="color: red;">onclick</span>.

​	React event handlers are written inside curly braces:

​	<span style="color: red;">onClick={shoot}</span> instead of <span style="color: red;">onClick="shoot()"</span>.

```
//React:
<button onClick={shoot}>Take the shot</button>
//HTML
<button onclick="shoot()">Take the shot</button>
```

## 10.2 Passing Arguments

​	To pass an argument to an event handler, use an arrow function:

```
function Football() {
	const shoot = (a) => {
		alert(a);
	}
	return (
		<button onClick={() => shoot("Goal!")}>Take a shot</button>
	);
}
const root = ReactDOM.createRoot(docuement.getElementById('root'));
root.render(<Football />);
```

## 10.3 React Event Object

​	Event handlers have access to the React event that triggered the function.

​	In our example the event is the "click" event.

```
//Arrow Function: Sending the event object manually:
function Football() {
	const shoot = (a, b) => {
		alert(b.type);
        /*
        'b' represents the React event that triggered the function
        */
	}
	return (
		<button onClick={(event) => shoot("Goal", event)}>
			Take a shot</button>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Football />);
```



# 11. React Conditional Rendering

​	In React, you can conditionally render components.

​	There are several ways to do this.

## 11.1 if Statement

​	We can use the <span style="color: red;">if</span> JavaScript operator to decide which component to render.

```
function MissedGoal() {
	return <h1>MISSED</h1>;
}
function MadeGoal() {
	return <h1>Goal</h1>;
}
function Goal(props) {
	const isGoal = props.isGoal;
	if (isGoal) {
		return <MadeGoal />;
	}
	return <MissedGoal />;
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Goal isGoal={false}/>);
```

## 11.2 Logical && Operator

​	Another way to conditional render a React component is by using the <span style="color: red;">&&</span> operator.

```
function Garage(props) {
	const cars = props.cars;
	return (
		<>
		`<h1>Garage</h1>
		{cars.length > 0 &&
			<h2>
			`You have {cars.length} cars in garage.
			</h2>
		}
		</>
	);
}
const cars = ['BYD', 'BMW', 'Volvo'];
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Garage cars={cars}/>);
```

​	If <span style="color: red;">cars.length > 0 </span> is equates to true, the expression after <span style="color: red;">&&</span> will render.

## 11.3 Ternary Operator

```
function Goal(props) {
	const isGoal = props.isGoal;
	return (
		<>
			{isGoal ? <MadeGoal /> : <MissedGoal />}
		</>
	);
}
```



# 12. React Lists

​	In React, you will render lists with some type of loop.

​	The JavaScript <span style="color: red;">map()</span> array method is generally the preferred method.

<b>Note:</b> If you need a refresher on the <span style="color: red;">map()</span> method, check out the ES6 section.

```
//Render all of the cars from garage:
function Car(props) {
	return <li>I am a {props.brand}</li>;
}
function Garage() {
	const cars = ['BYD', 'BMW', 'Ford'];
	return (
		<>
			<h1>Something here...</h1>
			<ul>
				{cars.map((car) => <Car brand={car}/> )}
			</ul>
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Garage />);
```

​	When you run this code in your <span style="color: red;">create-react-app</span>, it will work but you will receive a warning that these is no "key" provided for the list items.

## 12.1 Keys

​	Keys allow React to keep track of elements. This way, if an item is updated or removed, only that item will be re-rendered instead of the entire list.

​	Keys need to be unique to each sibling. But they can be duplicated globally.

<b>Note:</b> Generally, the key should be a unique ID assigned to each item. As a last resort, you can use the array as a key.

```
//Let's refactor our previous example to include keys:
function Car(props) {
	return <li>I am a {props.brand}</li>;
}
function Garage() {
	const cars = [
		{id: 1, brand: 'BYD'},
		{id: 2, brand: 'BMW'},
		{id: 3, brand: 'Ford'}
	];
	return (
		<>
			<h1>Something here ...</h1>
			<ul>
				{cars.map((car) => <Car key={car.id} brand={car.brand} /> ")}
			</ul>
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Garage />);
```



# 13. React Forms

​	Just like in HTML, React uses forms to allow users to interact with the web page.

## 13.1 Adding Forms in React

​	You add a form with React like any other element:
```
//Add a form that allows users to enter their name:
function MyForm() {
	return (
		<form>
			<label>Enter your name:
				<input type="text" />
			</label>
		</form>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MyForm />);
```

​	This will work as normal, the form will submit and the page will refresh.

​	But this is generally not what we want to happen in React. We want to prevent this default behavior and let React control the form.

## 13.2 Handling Forms

​	Handling forms is about how you handle the data when it changes value or gets submitted. In HTML, form data is usually handled by the DOM.

​	In React, form data is usually handled by the components. When the data is handled by the components, all the data is stored in the component state.

​	You can control changes by adding event handlers in the <span style="color: red;">onChange</span> attribute. We can use the <span style="color: red;">useState</span> Hook to keep track of each inputs value and provided a "single source of truth" for the entire application.

```
function MyForm() {
	const [name, setName] = useState("");
	return (
		<form>
			<label>Enter your name:
				<input type="text" value={value}
				onChange={(e) => setName(e.target.value)} />
			</label>
		</form>
	);
}
```

## 13.3 Submitting Forms

​	You can control the submit action by adding an event handler in the <span style="color: red;">onSumbit</span> attribute for the <span style="color: red;">\<form></span>:

```
function MyForm() {
	const [name, setName] = useState("");
	const handleSubmit = (event) => {
		event.preventDefault();
		alert(`The name you entered was: ${name}`)
	}
	return (
		<form onSubmit={handleSubmit}>
			<label>Entery your name:
				<input type="text" value={name}
					onChange={(e) => setName(e.target.value)} />
			</label>
		</form>
	)
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MyForm />);
```

## 13.4 Multiple Input Fields

​	You can control the values of more than one input field by adding a <span style="color: red;">name</span> attribute to each element. We will initialize our state with an empty object.

​	To access the fields in the event handler use the <span style="color: red;">event.target.name</span> and <span style="color: red;">event.target.value</span> syntax. To update the state, use square brackets [bracket notaion] around the property name.

```
function MyForm() {
	const [inputs, setInputs] = useState({});
	const handleChange = (event) => {
		const name = event.target.name;
		const value = event.target.value;
		setInputs(values => ({...values, [name]: value}))
	}
	const handleSubmit = (event) => {
		event.preventDefault();
		alert(inputs);
	}
	return (
		<form onSubmit-{handleSubmit}>
			<label>Enter your name:
			<input type="text" name="username" 
			value={inputs.username || ""}
			onChange={handleChange} />
			</label>
			<label>Enter your age:
				<input type="text" name="age"
				value={inputs.age || ""}
				onChange={handleChange} />
			</label>
			<input type="submit" />
		</form>
	);
}
```

<b>Note:</b> We use the same event handler function for both input fields, we could write one event handler for each, but this gives us much cleaner code and is the preferred way in React.

## 13.5 Textarea

​	The textarea element in React is slightly different from ordinary HTML.

​	In HTML the value of a textarea was the text between the start tag <span style="color: red;">\<textarea></span> and the end tag <span style="color: red;">\</textarea></span>.

```
<textarea>
	Content of the textarea
</textarea>
```

​	In React the value of a textarea is placed in a value attribute. We'll use the <span style="color: red;">useState</span> Hook to mange the value of the textarea:

```
function MyForm() {
	const [textarea, setTextarea] = useState(
		"The content of a textarea goes in the value attribute"
	);
	const handleChange = (event) => {
		setTextarea(event.target.value)
	}
	return (
		<form>
			<textarea value={textarea} onChange={handleChange} />
		</form>
	)
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MyForm />);
```

## 13.6 Select

​	A drop down list, or a select box, in React is also a bit different from HTML.

​	In HTML, the selected value in the drop down list was defined with the <span style="color: red;">selected</span> attribute:

```
<select>
	<option value="BYD">BYD</option>
	<option value="BWM">BMW</option>
	<option value="Fiat">Fiat</option>
</select>
```

​	In React, the selected value is defined with a <span style="color: red;">value</span> attribute on the <span style="color: red;">select</span> tag:

```
//A simple select box, where the selected value "Volvo" is initialized in the constructor
function MyForm() {
	const [myCar, setMyCar] = useState("Volvo");
	const handleChange = (event) => {
		setMyCar(event.target.value);
	}
	return (
		<form>
			<select value={myCar} onChange={handleChange}>
				<option value="BYD">BYD</option>
				<option value="BMW">BMW</option>
				<option value="Volvo">Volvo</option>
				<option value="Fiat">Fiat</option>
			</select>
		</form>
	);
}
```

​	By making these slight changes to <span style="color: red;">\<textarea></span> and <span style="color: red;">\<select></span>, React is able to handle all input elements in the same way.



# 14. React Router

​	Create React App doesn't include page routing.

​	React Router is the most popular solution.

## 14.1 Add React Router

​	To add React Router in your application, run this in the terminal from the roo directory of the application:

```
npm i -D react-router-dom
```

<p>Note:</p> This tutorial uses React Router v6. If you are upgrading from v5, you will need to use the @latest flag: npm i -D react-router-dom@latest.

## 14.2 Floder Structure

​	To create an application with multiple page routes, let's first start with the file structure.

​	Within the <span style="color: red;">src</span> folder, we'll create a folder named <span style="color: red;">pages</span> with several files (src/pages/):

* <span style="color: red;">Layout.js</span>
* <span style="color: red;">Home.js</span>
* <span style="color: red;">Blogs.js</span>
* <span style="color: red;">Contact.js</span>
* <span style="color: red;">NoPage.js</span>

​	Each file will contain a very basic React component.

## 14.3 Basic Usage 

​	Now we will use our Router in our <span style="color: red;">index.js</span> file:

```
//Use React Router to route to pages based on URL:
import Layout from "./pages/Layout";
import Home from "./pages/Home";
import Blogs from "./pages/Blogs";
import Contact from "./pages/Contact";
import NoPage from "./pages/NoPage";
export default function App() {
	return (
		<BrowserRouter>
			<Routers>
				<Route path"/" element={<Layout />}>
					<Route index element={<Home />}/>
					<Route path="blogs" element={<Blogs />}/>
					<Route path="contact" element={<Contact />}/>
					<Route path="*" element={<NoPage />}/>
				</Route>
			</Routers>
		</BrowserRouter>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
```

Example Explained:

​	We wrap our content first with <span style="color: red;">\<BrowserRouter></span>.

​	Then we define out <span style="color: red;">\<Routes></span>. An application can have multiple <span style="color: red;">\<Routers></span>. Our basic example only uses one. <span style="color: red;">\<Route></span>s can be nested. The first <span style="color: red;">\<Route></span> has a path of <span style="color: red;">/</span> and renders the <span style="color: red;">Layout</span> component.

​	The nested <span style="color: red;">\<Route></span>s inherit and add to the parent route. So the <span style="color: red;">blogs</span> path is combined with the parent and becomes <span style="color: red;">/blogs</span>.

​	The <span style="color: red;">Home</span> component route does not have a path but has an <span style="color: red;">index</span> attribute. That specifies this route as the deafult route for the parent route, which is <span style="color: red;">/</span>.

​	Setting the <span style="color: red;">path</span> to <span style="color: red;">*</span> will act as a catch-all for any undefined URLs. This is great for a 404 error page.

## 14.4 Pages / Components

​	The <span style="color: red;">Layout</span> component has <span style="color: red;">\<Outlet></span> and <span style="color: red;">\<Link></span> elements. The <span style="color: red;">\<Outlet></span> returns the current route selected. <span style="color: red;">\<Link></span> is used to set the URL and keep track of browsing history.

​	Anytime we link to a internal path, we will use <span style="color: red;">\<Link></span> instead of <span style="color: red;">\<a href=""></span>. The "layout route" is a shared component that inserts common content on all pages, such as a navigation menu.

```
//Layout.js:
import {Outlet, Link} from "react-route-dom";
const Layout = () => {
	return (
		<>
		<nav>
			<ul>
				<li>
					<Link to="/">HOME</Link>
				</li>
				<li>
					<Link to="/blogs">Blogs</Link>
				</li>
				<li>
					<Link to="/contact">Contact</Link>
				</li>
			</ul>
		</nav>
		<Outlet />
		</>
	);
};
export default Layout;
//Home.js
const Home = () => {
	return <h1>Home</h1>;
};
export default Home;
//Blogs.js
const Blogs = () => {
	return <h1>Blog Articles</h1>;
};
export default Blogs;
//Contact.js
const Contact = () => {
	return <h1>Contact Me</h1>;
}	//...
export default Contact;
//NoPage.js
const NoPage = () => {
	return <h1>404</h1>;
};
export default NoPage;
```



# 15. React Memo

​	Using <span style="color: red;">memo</span> will cause React to skip rendering a component if its props have not changed. This can improve performance.

<b>Note:</b> This section uses React Hooks. See later section for more information.

## 15.1 Problem

​	In this example, the <span style="color: red;">Todos</span> component re-renders even when the todos have not changed.

```
import Todos from "./Todos";
const App = () => {
	const [count, setCount] = useState(0);
	const [todso, setTodos] = useState(["todo 1", "todo 2"]);
	const increment = () => {
		setCount((c) => c + 1);
	};
	return (
		<>
			<Todos todos={todos} />
			<hr />
			<div>
				Count: {count}
				<button onClick={increment}>+</button>
			</div>
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
```

```
//Todos.js
const Todos = ({todos}) => {
	console.log("chil render");
	return (
		<>
			<h2>My Todos</h2>
			{todos.map((todo, index) => {
				return <p key={index}>{todo}</p>;
			})}
		</>
	);
}
export default Todos;
```

​	When you click the increment button, the <span style="color: red;">Todos</span> component re-renders.

​	If this component was complex, it could cause performance issues.

## 15.2 Solution

​	To fix this, we can use <span style="color: red;">memo</span>.

​	Use <span style="color: red;">memo</span> to keep the <span style="color: red;">Todos</span> component from needlessly re-rendering. Wrap the <span style="color: red;">Todos</span> componet export in <span style="color: red;">memo</span>:

```
import {memo} from "react";
const Todos = ({todos}) => {
	console.log("child render");
	return (
		<>
			<h2>My Todos</h2>
			{todos.map((todo, index) => {
				return <p key={index}>{todo}</p>;
			})}
		</>
	);
}
export default memo(Todos);
```

​	Now the <span style="color: red;">Todos</span> component only re-render when the <span style="color: red;">todos</span> that are passed to it through props are updated.



# 16. Styling React Using CSS

​	There are many ways to style React with CSS, this tutorial will take a closer look at three common ways:

* Inline styling
* CSS stylesheets
* CSS Modules

## 16.1Inline Styling

​	To style an element with teh inline style attribute, the value must be a JavaScript object:

```
//Insert an object with the styling information:
const Header = () => {
	return (
		<>
			<h1 style={{color:"red"}}>Hello</h1>
			<p>Add a inline style</p>
		</>
	);
}
```

<b>NOTE:</b> In JSX, JavaScript expressions are written inside curly braces, and since JavaScript objects also use curly braces, the styling in the example above is written inside two sets of curly braces <span style="color: red;">{{ }}</span>.

### 16.1.1 camelCased Property Names

​	Since the inline CSS is written in a JavaScript object, properties with hyphen separators, like <span style="color: red;">background-color</span>, must be written with camel case syntax:

```
//Use backgroundColor instead of background-color:
const Header = () => {
	return (
		<>
		`<h1 style={{backgroundColor: "lightblue"}}>Hello</h1>
		<p>Add a inline cascending style</p>
		</>
	);
}
```

### 16.1.2 JavaScript Object

​	You can also create an object with styling information, and refer to it in the style attribute:

```
const Header = () => {
	const myStyle = {
		color: "white",
		backgroundColor: "DodgerBlue",
		padding: "10px",
		fontFamliy: "Sans-Serif"
	};
	return (
		<>
			<h1 style={myStyle}>Hello</h1>
		</>
	);
}
```

## 16.2 CSS Stylesheet

​	You can write your CSS stylong in a separate file, just save the file with the <span style="color: red;">.css</span> file extension, and import it in your application:

```
//Create a new file called "App.css" and insert some CSS code in it:
body {
	background-color: #282c34;
	color: white;
	padding: 40px;
	font-family: Sans-Serif;
	text-align: center;
}
```

<b>Note:</b> You can call the file whatever you like, just remember the correct fiel extension.

​	Import the stylesheet in you application:

```
import "./App.css";
const Header = () => {
	return (
		<>
			<h1>Hello</h1>
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render();
```

## 16.3 CSS Modules

​	Another way of adding styles to your application is to use CSS Modules.

​	CSS Modules are convenient for components that are placed in separate files.

<b>Note:</b> The CSS inside a module is available only for the component that imported it, and you do not have to worry about name conflicts.

​	Create the CSS module with the <span style="color: red;">.module.css</span> extension:

```
//Create a new file called "my-style.module.css" and insert some CSS code:
.bigblue {
	color: DodgerBlue;
	padding: 40px;
	font-family: Sans-Serif;
	taxt-align: center;
}
```

​	Import the stylesheet in you component:

```
import styles from "./my-style.module.css";
const Car = () => {
	return <h1 className={styles.bigblue}>Hello</h1>;
}
export default Car;
```

​	Import the component in application:

```
import Car from "./Car.js";
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Car />);
```



# 17. Styling React Using Sass

## 17.1 What is Sass

​	Sass is a CSS pre-processor.

​	Sass files are executed on the server and sends CSS to the browser.

​	You can learn more about Sass in our [Sass Tutorial](https://www.w3schools.com/sass/default.php)

## 17.2 Can I use Sass?

​	If you use the <span style="color: red;">create-react-app</span> in your project, you can easily install and use Sass in your React projects. Install Sass by running this command in your terminal:

```
npm i sass	//install sass
```

​	Now you are ready to include Sass files in your project.

## 17.3 Create a Sass file

​	Create a Sass file the same way as you create CSS files, but Sass files have the file extension <span style="color: red;">.scss</span>.

​	In Sass files you can use variables and other Sass functions:

```
//Create a variable to define the color of the text:
$myColor: red;
h1 {
	color: $myColor;
}
```

​	Import thee Sass file the same way as you imported a CSS file:

```
import './my-sass.scss';
const Header = () => {
	return (
		<>
			<h1>Hello</h1>
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Header />);
```



# 18. React Hooks

​	Hooks were added to React in version 16.8.

​	Hooks allow function components to have access to state and other React features. Because of this, class components are generally no longer needed.

<b>Note:</b> Although Hooks generally replace class components, there are no plans to remove classes from React.

## 18.1 What is a Hook?

​	Hooks allow us to "hook" into React features such as state and lifecycle methods:

```
//Here is an example of a Hook
import React, {useState} from 'react';
function FavoriteColor() {
	const [color, setColor] = useState("red");
	return (
	<>
		<h1>My Favorite color is {color}</h1>
		<button type="button" onClick={() => setColor("blue")}>Blue</button>
		<button type="button" onClick={() => setColor("red")}>Red</button>
		<button type="button" onClick={() => setColor("pink")}>Pink</button>
	</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<FavoriteColor />);
```

​	You must import Hooks from <span style="color: red;">react</span>. Here we are using the <span style="color: red;">useState</span> Hook to keep track of the application state. State generally refers to application data or properties that need to be tracked.

## 18.2 Hook Rules

​	There are 3 rules for hooks:

* Hooks can only be called inside React function components.
* Hooks can only be called at the top level of a component.
* Hooks cannot be conditional

<b>Note:</b> Hooks will not work in React class components.

## 18.3 Custom Hooks

​	If you have stateful logic that needs to be reused in several components, you can build your own custom hooks. We'll go into detail in the [Custom Hooks section](https://www.w3schools.com/react/react_customhooks.asp).



# 19. React useState Hook

​	The React <span style="color: red;">useState</span> Hook allows us to track state in a function component.

​	State generally refers to data or properties that need to be tracking in an application.

## 19.1 Import useState

​	To use the <span style="color: red;">useState</span> Hook, we first need to <span style="color: red;">import</span> it into our componet.

```
//At the top of your component, import the useState Hook
```

​	Notice that we are destructing <span style="color: red;">useState</span> form <span style="color: red;">react</span> as it is a named export.

## 19.2 Initialize useState

​	We initialize our stae by calling <span style="color: red;">useState</span> in our function component.

​	<span style="color: red;">useState</span> accepts an initial state and returns two values:

* The current state.
* A function that updates the state.

```
//Initialize state at the top of the function component:
function FavoriteColor() {
	const [color, setColor] = useState("");
}
```

​	Notice that again, we are destructing the returned values from <span style="color: red;">useState</span>.

​	The first value, <span style="color: red;">color</span>, is our current state.

​	The second value, <span style="color: red;">setColor</span>, is the <span style="color: blue;">function that is used to update our state</span>.

<b>Note:</b> These names are variables that can be named anything you would like.

​	Lastly, we set the initial state to an empty string: <span style="color: red;">useState("")</span>.

## 19.3 Read State

​	We can now include our state anywhere in our component:

```
//Use the state variable in the rendered component:
function FavoriteColor() {
	const [color, setColor] = useState("red");
	return <h1>My favorite color is {color}</h1>;
}
```

## 19.4 Update State

​	To update our state, we use our state updater function.

<b>Note:</b> We should never directly update state. Ex: <span style="color: red;">color =  "red"</span> is not allowed.

Example: Use a button to update the state:

```
function FavoriteColor() {
	const [color, setColor] = useState("red");
	return (
		<>
			<h1>My favorite color is {color}</h1>
			<button type="button" 
			onClick={() => setColor("blue")}>Blue</button>
		</>
	);
}
```

## 19.5 What Can State Hold

​	The <span style="color: red;">useState</span> Hook can be used to keep track of strings, numbers, booleans, arrays, objects, and any combination of these!

​	We could create multiple state Hooks to track individual values:

```
function Car() {
	const [brand, setBran] = useState("BYD");
	const [model, setModel] = useState("Han");
	cosnt [year, setYear] = useState("2023");
	return (
		<>
			<h1>My {brand}</h1>
			<p>
				It is a {model} from {year}.
			</p>
		</>
	);
}
```

​	Or, we can just use one state and include an object instead!

```
function Car() {
	const [car, setCar] = useState({
		brand: "BYD",
		model: "Han",
		year: "2023"
	});
	return (
		<>
			<h1>My {car.brand}</h1>
			<p>
				It is a {car.model} form {car.year}.
			</p>
		</>
	);
}
```

​	<b>Note:</b> Since we are now tracking a single object, we need to reference that object and then the property of that object when rendering the componet. (Ex: <span style="color: red;">car.brand</span>)

## 19.6 Updating Objects and Arrays in State

​	When state is updated, the entire state gets overwritten.

​	What if we only want to update the year of our car?

​	If we only called <span style="color: red;">setCar({year: "2024"})</span>, this would remove the brand, model from our state. We can use the JavaScript spread operator to help us.

```
//Use the JavaScript spread operator to update only the year of the car:
function Car() {
	const [car, setCar] = useState({
		brand: "BYD",
		model: "Han",
		year: "2023"
	});
	cosnt updateYear = () => {
		setCar(previousState => {
			return {...previousState, year: "2024"}
		});
	}
	return (
		<>
			<h1>My {car.brand}</h1>
			<p>
				It is a {car.model} form {car.year}.
			</p>
			<button type="button"
			onClick={updateColor}>2024</button>
		</>
	);
}
```

​	Because we need the current value of state, we pass a function into our <span style="color: red;">setCar</span> function. This function receives the previous value. We then return an object, spreading the <span style="color: red;">previousState</span> and overwriting only the year.



# 20. React useEffect Hooks

​	The <span style="color: red;">useEffect</span> Hook allows you to perform side effects in you components. Some examples of side effect are: fetching data, directly updating the DOM, and items.

​	<span style="color: red;">useEffect</span> accepts two arguments. The second argument is optional.

​	<span style="color: red;">useEffect(\<function>, [dependency])</span>

​	Let's use a timer as an example:

```
//Use setTimeout() to count 1 second after initial render:
import {useState, useEffect} from 'react';
function Timer() {
	const [count, setCount] = useState(0);
	useEffect(() => {
		setTimeout(() =>
			setCount((count) => count + 1);
		},1000);
	});
	return <h1>I've rendered {count} times!</h1>
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Timer />);
```

​	But wait!! It keeps counting even though it should only count once!

​	<span style="color: red;">useEffect</span> runs on every render. That means that when the count changes, a render happens, which then triggers another effect.

​	This is not what we want. There are several ways to control when side effect run. We should always include the second parameter which accepts an array. We can optionally pass dependencies to <span style="color: red;">useEffect</span> in this array.

1. No dependency passed:

```
useEffect(() => {
	//Runs on every render
});
```

2. An empty array:

```
useEffect(() => {
	//Runs only on the first render
}, []);
```

3. Props or state values:

```
useEffect(() => {
	//Runs on the first render
	//And any time any dependency value changes
}, [prop, state]);
```

​	So, to fix this issue, let's only run this effect on the initial render:

```
import {useState, useEffect} form "react";
function Timer() {
	const [count, setCount] = useState(0);
	uesEffect(
		() => {
			setTimeout(
				() => {
				 setCount((count) => count + 1);
				}
			,1000);
		}
	, []);
	return <h1>I've rendered {count} times</h1>;
}
```

​	You can try to include the dependency 'count' to see the effect. Here is another example:

```
import { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";

function Counter() {
  const [count, setCount] = useState(0);
  const [calculation, setCalculation] = useState(0);

  useEffect(() => {
    setCalculation(() => count * 2);
  }, [count]); // <- add the count variable here

  return (
    <>
      <p>Count: {count}</p>
      <button onClick={() => setCount((c) => c + 1)}>+</button>
      <p>Calculation: {calculation}</p>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Counter />);
```

## 20.1 Effect Cleanup

​	Some effects require cleanup to reduce memory leaks.

​	Timeouts, subscriptions, event listeners, and other effects that are no longer needed should be disposed. We do this by including a return function at the end of the <span style="color: red;">useEffect</span> Hook.

```
import { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";

function Timer() {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let timer = setTimeout(() => {
    setCount((count) => count + 1);
  }, 1000);
  return () => clearTimeout(timer)
  }, []);
  return <h1>I've rendered {count} times!</h1>;
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Timer />);
```

<b>Note:</b> To clear the timer, we had to name it.



# 21. React useContext Hook

## 21.1 React Context

​	React Context is a way to manage state globally. It can be used together with the <span style="color: red;">useState</span> Hook to share state between deeply nested components more easily than with <span style="color: red;">useState</span> alone.

## 21.2 The Problem

​	State should be held by the highest parent componet in the stack that requries access to the state. To illustrate, we have many nested components. The component at the top and bottom of the stack need access to the state.

​	To do this without Context, we will need to pass the state as "props" through each nested component. This is called "prop drilling".

```
//Passing "props" through nested components:
import {useState} from "react";
function Component1() {
	const [user, setUser] = useState("Jesse Hall");
	return (
		<>
			<h1>{`Hello ${user}`}</h1>
			<Component2 user={user} />
		</>
	);
}
function Component2({user}) {
	return (
		<>
			<h1>Component 2</h1>
			<Component3 user={user} />
		</>
	);
}
function Component3({user}) {
	return (
		<>
			<h1>Component 3</h1>
			<Component4 user={user} />
		</>
	);
}
function Component4({user}) {
	return (
		<>
			<h1>Component 4</h1>
			<Component4 user={user} />
		</>
	);
}
function Component5({user}) {
	return (
		<>
			<h1>Component 5</h1>
			<h2>{`Hello ${user} again!`}</h2>
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Component1 />);
```

​	Even though compoents 2-4 did not need the state, they had to pass the state along so that it could reach componet 5.

## 21.3 The Solution

​	The solution is to create context.

### 21.3.1 Create Context

​	To create context, you must Import <span style="color: red;">createContext</span> and initialize it:

```
import {useState, createContext} form 'react';
const UserContext = createContext();
```

​	Next we'll use the Context Provider to wrap the tree of componets that need the state Context.

### 21.3.2 Context Provider

​	Wrap child components in the Context Provider and supply the state value:

```
function Component1() {
	const [user, setUser] = useState("Jesse Hall");
	return (
		<UserContext.Provider value={user}>
			<h1>{`Hello ${user}`}</h1>
			<Component2 user={user} />
		</UserContext.Provider>
	);
}
```

​	Now, all components in this tree will have access to the user Context.

### 21.3.3 Use the useContext Hook

​	In order to use the Context in a child component, we need to access it using the <span style="color: red;">useContext</span> Hook. First, include the <span style="color: red;">useContext</span> in the import statement:

```
import {useState, createContext, useContext} from "react";
```

​	Then you can access the user Context in all components:

```
function Compont5() {
	const user = useContext(UserContext);
	return(
		<>
			<h1>Component 5</h1>
			<h2>{`Hello ${user} again!`}</h2>
		</>
	);
}
```

## 21.4 Full Example

```
import { useState, createContext, useContext } from "react";
import ReactDOM from "react-dom/client";
const UserContext = createContext();
function Component1() {
  const [user, setUser] = useState("Jesse Hall");
  return (
    <UserContext.Provider value={user}>
      <h1>{`Hello ${user}!`}</h1>
      <Component2 />
    </UserContext.Provider>
  );
}
function Component2() {
  return (
    <>
      <h1>Component 2</h1>
      <Component3 />
    </>
  );
}
function Component3() {
  return (
    <>
      <h1>Component 3</h1>
      <Component4 />
    </>
  );
}
function Component4() {
  return (
    <>
      <h1>Component 4</h1>
      <Component5 />
    </>
  );
}
function Component5() {
  const user = useContext(UserContext);
  return (
    <>
      <h1>Component 5</h1>
      <h2>{`Hello ${user} again!`}</h2>
    </>
  );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Component1 />);
```



# 22. React useRef Hook

​	The <span style="color: red;">useRef</span> Hook allows you to persist values between renders.

​	It can be used to store a mutable value that does not cause a re-render when updated.

​	It can be used to access a DOM element directly.

## 22.1 Does Not Cause Re-renders

​	If we tried to count how many times our application renders using the <span style="color: red;">useState</span> Hook, we would be caught in an infinite loop since this Hook itself causes a re-render.

​	To avoid this, we can use the <span style="color: red;">useRef</span> Hook.

```
//Use useRef to track application renders:
import {useState, useEffect, useRef} from "react";
function App() {
	const [inputValue, setInputValue] = useState("");
	const count = useRef(0);
	useEffect(
		() => {count.current = count.current + 1;}
	);
	return (
		<>
			<input type="text" value={inputValue}
			onChange={(e) => setInputValue(e.target.value)}/>
			<h1>Render Count: {count.current}</h1>
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
```

​	<span style="color: red;">useRef()</span> only returns one item. It returns an Object called <span style="color: red;">current</span>.

​	When we initialize <span style="color: red;">useRef</span> we set the initial value: <span style="color: red;">useRef(0)</span>.

<b>Note:</b> It's like doing this: <span style="color: red;">const count = {current:0}</span>. We can access the count by using <span style="color: red;">count.current</span>.

​	Run this on your computer and try typing in the input to see the application render count increase.

## 22.2 Accessing Dom Elements

​	In general, we want to let React handle all DOM manipulation. But there are some instances where <span style="color: red;">useRef</span> can be used without causing issues. In React, we can add a <span style="color: red;">ref</span> attribute to an element to acces it directly in the DOM.

```
inport {useRef} from "react";
function App() {
	const inputElement = useRef();
	const focusInput = () => {
		inputElement.current.focus();
	};
	return (
		<>
			<input type="text" ref={inputElement}/>
			<button onClick={focusInput}>Foces Input</button>
		</>
	);
}
const root = //...;
root.render(<App />);
```

## 22.3 Tracking State Changes

​	The <span style="color: red;">useRef</span> Hook can also be used to keep track of previous state values.

​	This is because we are able to persist <span style="color: red;">useRef</span> values between renders.

```
//Use useRef to keep track of previous state values:
import {useState, useEffect, useRef} from "react";
function App() {
	const [inputValue, setInputValue] = useState("");
	const previousInputValue = useRef("");
	useEffect(
		() => {previosInputValue.current = inputValue;}, [inputValue]
	);
	return (
		<>
			<input type="text" value={inputValue}
			onChange={(e) => setInputValue(e.target.value)}/>
		</>
	);
}
```

​	This time we use a combination of <span style="color: red;">useState</span>, <span style="color: red;">useEffect</span>, and <span style="color: red;">useRef</span> to keep track of the previous state. In the <span style="color: red;">useEffect</span>, we are updating the <span style="color: red;">useRef</span> current value each time the <span style="color: red;">inputValue</span> is updated by entering text into the input field.



# 23. React useReducer Hook

​	The <span style="color: red;">useReducer</span> Hook is similar to the <span style="color: red;">useState</span> Hook. It allows for custom state logic.

​	If you find yourself keeping track of multiple preces of state that rely on complex logic, <span style="color: red;">useReducer</span> may be useful.

## 23.1 Syntax

​	The useReducer Hook acctpts two argument:

useReducer(\<render>, \<initialState>)

​	The <span style="color: red;">reducer</span> function contains your custom state logic and the <span style="color: red;">initialState</span> can be a simple value but generall will contain an object. The <span style="color: red;">useReducer</span> Hook returns the current <span style="color: red;">state</span> and a <span style="color: red;">dispatch</span> method.

​	Here is an example of <span style="color: red;">useReducer</span> in a counter app:

```
import {useReducer} from "react";
const initialTodos = [
	{
		id: 1,
		title: "Todo 1",
		complete: false,
	},
	{
		id: 2,
		title: "Todo 2",
		complete: false,
	}
];
const reducer = (state, action) => {
	switch(ction.type) {
		case "COMPLETE":
			retrn state.map(
				(todo) => {
					if (todo.if == action.id) {
						return {...todo, complete: !todo.complete};
					} else {
						return todo;
					}
				}
			);
		default:
			return state;
	}
};
function Todos() {
	const [todos, dispath] = useReducer(reducer, initialTodos);
	const handleComplete = (todo) => {
		dispatch({type: "COMPLETE", id: todo,id});
	};
	return (
		<>
			{todo.map(
				(todo) => (
					<div key={todo.id}>
						<label>
							<input type="checkbox" checked={todo.complete}
							onChange={() => handleComplete(todo)} />
							{todo.title}
						</label>
					</div>
				)
			)}
		</>
	);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Todos />);
```

​	This is the logic to keep track of the todo complete status. All of the logic to add, delete, and complete a todo could be contained within a single <span style="color: red;">useReducer</span> Hook by adding more actions.



# 24. React useCallbeack Hook

​	The React <span style="color: red;">useCallback</span> Hook returns a memorized callback function.

<b>Note:</b> Think of memoization as caching a value so that it does not need to be recacluated.

​	This allows us to isolate resource intensive functions so that they will not automatically run on every render. Thee <span style="color: red;">useCallback</span> Hook only runs when one of its dependencies update. This can improve performance.

<b>Note:</b> The <span style="color: red;">useCallback</span> and <span style="color: red;">useMemo</span> Hooks are similar. The main difference is that <span style="color: red;">useMemo</span> returns a memoized <i>value</i> and <span style="color: red;">useCallback</span> returns a memoized <i>function</i>. You can learn more about useMemo in the useMemo chapter.

## 24.1 Problem

​	One reason to use <span style="color: red;">useCallback</span> is to prevent a component form re-rendering unless its props have changed. In this example, you migth think that the <span style="color: red;">Todos</span> component will not re-render unless the <span style="color: red;">todos</span> change:

```
//index.js:
import {useState} form "react";
import Todos form"./Todos";
const App = () => {
	const [count, setCount] = useState(0);
	const [todos, setTodos] = useState([]);
	const increment = () => {
		setCount(
			(c) => c + 1;
		);
	};
	const addTodo = () => {
		setTodos(
			(t) => [...t, "New Todo"];
		);
	};
	return (
		<>
			<Todos todos={todos} addTodo={addTodo} />
			<hr />
			<div>
				Count: {count}
				<button onClick={increment}>+</button>
			</div>
		</>
	);
};
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
```

```
//Todos.js:
import {memo} from "react";
const Todos = ({todos, addTodo}) => {
	console.log("child render");
	return (
		<>
			<h2>My Todos</h2>
			{todos.map(
				(todo, index) => {return <p key={index}>{todo}</p>;}
			)}
			<button onClick={addTodo}>Add Todo</button>
		</>
	);
};
export default memo(Todos);
```

​	Try running this and click the count increment button.

​	You will notice that the <span style="color: red;">Todos</span> component re-renders even when the <span style="color: red;">todos</span> do not change. Why does this not work? We are using <span style="color: red;">memo</span>, so the <span style="color: red;">Todo</span> component should not re-render since neither the <span style="color: red;">todos</span> state nor the <span style="color: red;">addTodo</span> function are changing when the count is incremented. This is because of something called "referential equality".

​	Every time a component re-renders, its functions get created. Because of this, the <span style="color: red;">addTodo</span> function has actually changed.

## 24.2 Solution

​	To fix this, we can use the <span style="color: red;">useCallback</span> Hook to prevent the function from being recreated unless necessary. Use the <span style="color: red;">useCallback</span> Hook to prevent the <span style="color: red;">Todos</span> component from re-rendering needlessly:

```
//index.js:
import {useState, useCallback} from "react";
import Todos from "./Todos";
const App = () => {
	const [count, setCount] = useState(0);
	const [todos, setTodos] = useState([]);
	const increment = () => {
		setCount(
			(c) => c + 1;
		);
	};
	const addTodo = useCallback(
		() => {
			setTodos(
				(t) => [...t, "New Todo"];
			);
		}, [todos]
	);
	return (
		<>
			<Todos todos={todos} addTodo={addTodo} />\
			<hr />
			<div>
				Count: {count}
				<button onClick={increment}>+</button>
			</div>
		</>
	);
};
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
```

```
//Todo.js
Same to above Todo.js file.
```

​	Now the <span style="color: red;">Todos</span> component will only re-render when the <span style="color: red;">todos</span> prop changes.



# 25. React useMemo Hook

​	The React <span style="color: red;">useMemo</span> Hook returns a memoized value.

<b>Note:</b> Think of memoization as caching a value so that it does not need to be calculated.

​	The <span style="color: red;">useMemo</span> Hook only runs when one of its dependencies update. This can imporve performance.

<b>Note:</b> The <span style="color: red;">useMemo</span> and <span style="color: red;">useCallback</span> Hooks are similar. The main difference is that <span style="color: red;">useMemo</span> returns a memoized value and <span style="color: red;">useCallback</span> returns a memoized function. You can learn more about <span style="color: red;">useCallback</span> in previous chapter.

## 25.1 Performance

​	The <span style="color: red;">useMemo</span> Hook can be used to keep expensive, resource intensive functions from needlessly running. In this example, we have an expensive function that runs on every render. When changing the count or adding a todo, you will notice a delay in execution.

```
//A poor performing function. The expensiveCalculation function runs on every render:
const App = () => {
	const [count, setCount] = useState(0);
	const [todos, setTodos] = useState([]);
	const calculation = expensiveCalculation(count);
	const increment = () => {
		setCount(
			(c) => c + 1;
		);
	};
	const addTodo = () => {
		setTodos(
			(t) => [...t, "New Todo"];
		);
	};
	return (
		<div>
			<div>
				<h2>My Todos</h2>
				{todos.map(
					(todo, index) => {return <p key={index}>{todo}</p>;}
				)}
				<button onClick={addTodo}>Add Todo</button>
			</div>
			<hr />
			<div>
				Count: {count}
				<button onClick={increment}>+</button>
				<h2>Expensive Calculation</h2>
				{calculation}
			</div>
		</div>
	);
};
const expensiveCalculation = (num) => {
	console.log("Calculating...");
	for (let i = 0; i < 1000000000; i++) {
		num += 1;
	}
	return num;
};
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
```

## 25.2 Use useMemo

​	To fix this performance issue, we can use the <span style="color: red;">useMemo</span> Hook to memoize the <span style="color: red;">expensiveCalculation</span> function. This will cause the function to only run when needed.

​	We can wrap the expensive function call with <span style="color: red;">useMemo</span>. The <span style="color: red;">useMemo</span> Hook accepts a second parameter to declare dependencies. The expensive function will only run when its dependencies have changed.

​	In the following example, the expensive function will only run when <span style="color: red;">count</span> is changed and not when todo's are added.

```javascript
import {useState, useMemo} form "react";
const App = () => {
	const [count, setCount] = useState(0);
    const [todos, setTodos] = useState([]);
    const calculation = useMemo(
    	() => expensiveCalculation(count), [count]
    );
    const increment = () => {
      	setCount(
        	(c) => c + 1;
        )  
    };
    const addTodo = () => {
      	setTodos(
        	(t) => [...t, "New Todo"];
        ); 
    };
    return (
    	<div>
        	<div>
        		<h2>My Todos</h2>
        		{todos.map(
    				(todo, index) => {
        				return <p key={index}>{todo}</p>;
    				}
    			)}
				<button onClick={addTodo}>Add todo</button>
        	</div>
        	<hr />
        	<div>
        		Count: {count}
				<button onClick={increment}>+</button>
				<h2>Expensive Calculation:</h2>
				{calculation}
        	</div>
        </div>
    );
};
const expensiveCalculation = (num) => {
    console.log("Calculating ...");
    for (let i = 0; i < 1000000000; i++) {
        num += 1;
    }
    return num;
};
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
```



# 26. React Custom Hooks

]	Hooks are reusable functions. When you  have component logic that needs to be used by multiple components, we can extrac that logic to a cutsom Hook. Custom Hooks start with "use". Example: <span style="color: red;">useFectch</span>.

## 26.1 Build a Hook

​	In the following code, we are fetching data in our <span style="color: red;">Home</span> component and displaying it.

​	We will use the JSONPlaceholder service to fetch fake data. This service is greater for testing application when there is no existing dta. To learn more, check out the JavaScript Fectch API section.

​	Use the JSONPlaceholder service to fetch fake "todo" items and display the titles on the page:

```
//index.js
import {useState, useEffect} from "react";
const Home = () => {
	const [data, setData] = useState(null);
	useEffect(
		() => {
			fecth("https://jsonplaceholder.typicode.com/todos")
			.then((res) => res.json())
			.then((data) => setData(data));
		}, []
	);
	return (
		<>
			{data && data.amp(
				(item) => {return <p key={item.id}>{item.title}</p>;}
			)}
		</>
	);
};
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Home />);
```

​	The fectch logic may be needed in other components as well, so we will extract that into a custom Hook. Move the fecth logic to a new file to be used as a custom Hook:

```
//useFetch.js:
import {useState, useEffect} from "react";
const useFetch = (url) => {
	const [data, setData] = useState(null);
	useEffect(
		() => {
			fetch(url)
			.then((res) => res.json())
			.then((data) => setData(data));
		}
	, [url]);
	return [data];
};
export default useFetch;
```

```
//index.js
import useFetch from "./useFetch";
const Home = () => {
	const [data] = useFecth("https://jsonplaceholder.typicode.com/todos");
	return (
		<>
			{data && 
				data.map((item) => {
					return <p key={item.id}>{item.title}</p>;
				}	
			}
		</>
	);
};
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Home />);
```

<span style="font-size:20px;">Example Explained:</span>

​	We have created a new file called <span style="color: red;">useFecth.js</span> containing a function called <span style="color: red;">useFetch</span> which contains all of the logic needed to fetch our data. We removed the hard-coded URL and replaced it with a <span style="color: red;">url</span> variable that can be passed to the custom Hook.

​	Lastly, we aree returning our data from our Hook. In <span style="color: red;">index.js</span>, we are importing our <span style="color: red;">useFetch</span> Hook and utilizing it like any other Hook. This is where we pass in the URL to fetch data from.	

​	Now we can reuse this custon Hook in any component to fetch data from any URL.

<span style="color: red;">Thu, Apr 20, 2023. 11:28. Library 2rd floor, zone c 369.</span>



<span style="color: red;">
