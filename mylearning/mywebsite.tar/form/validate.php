<!DOCTYPE html>
<html>
<body>
<?php
$info = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	      if (preg_match("/pf123456/i", $_POST["pwd1"])) {
	      	$info = "<a href=\"valid.php\">Click me</a>";
	      } else {
	        $info = "<p style=\"font-size: 20px;\">Input correct password to access website....</p>";
	      }
}
?>

<form method="post" action="<?php 
	echo htmlspecialchars($_SERVER["PHP_SELF"]);
	?>">
	<p style="font-size: 20px;">
		Input password to access me:
	</p>
	<input type="text" name="pwd1">
	<input type="submit" name="submit" value="Submit">
	<span><?php echo "<br>" . $info . ""; ?></span>

</form>
</body>
</html>
