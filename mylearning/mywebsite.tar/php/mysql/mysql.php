<?php

echo "<table style='boder: solid 1px block;'>";
echo "<tr><th>ID</th><th>FirstName</th><th>LastName</th></tr>";
class TableRows extends RecursiveIteratorIterator {
  function __construct($it) {
    parent::__construct($it, self::LEAVES_ONLY);
  }

  function current() {
    return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
  }

  function beginChildren() {
    echo "<tr>";
  }

  function endChildren() {
    echo "</tr>" . "\n";
  }
}


$servername = "localhost";
$username = "pf";
$password = "pf135";
$conn = "";
try {
	//$conn = new mysqli($servername, $username, $password);
	//$conn = mysqli_connect($servername, $username, $password);
	$conn = new PDO("mysql:host=$servername;dbname=myDBPDO", $username, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	//create a database
	//$sql = "CREATE DATABASE myDBPDO";
	//$conn->exec($sql);
	//Create a table:
	$sql = "CREATE TABLE myGuests (
		id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		firstname VARCHAR(30) NOT NULL,
		lastname VARCHAR(30) NOT NULL,
		email VARCHAR(50),
		reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)";
	//Insert Multiple:
	$conn->beginTransaction();
	$conn->exec("INSERT INTO myGuests (firstname, lastname, email)
		VALUES ('Jon', 'Doe', 'john@qq.com')");
	$conn->exec("INSERT INTO myGuests (firstname, lastname, email)
		VALUES ('Mary', 'Moe', 'mary@example.com')");
	$conn->exec("INSERT INTO myGuests (firstname, lastname, email)
		VALUES ('Julie', 'Dooley', 'julie@example.com')");
	$conn->commit();
	//$conn->exec($sql);
	//Add a record:
	//$sql = "INSERT INTO myGuests (firstname, lastname, email) VALUES
//		('Joe', 'Biden', 'biden@gmail.com')";
	//$conn->exec($sql);
	$stmt = $conn->prepare("SELECT id, firstname, lastname FROM myGuests");
	$stmt->execute();
	$result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
	foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
		echo $v;
	}
} catch (Exception $e) {
	die("Exception: " . $e);
}
/*
if($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}*/
echo "</table>";
echo "Connected & created successfully";
?>
