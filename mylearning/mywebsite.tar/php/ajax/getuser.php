<!DOCTYPE html>
<html>
<head>
<style>
table {
	width: 100%;
	border-collapse: collapse;
}
table, td, th {
	border: 1px solid black;
	padding: 5px;
}
th {text-align: left;}
</style>
</head>
<body>
<?php
$q = intval($_GET['q']);
$servername = "localhost";
$username = "pf";
$password = "pf135";
$dbname = "myDBPDO";
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if(!$conn) {
	die("Could not connect...");
}
$sql = "SELECT * FROM myGuests WHERE id = '".$q."'";
$stmt = $conn->query($sql);
//$stmt = $conn->prepare($sql);
//$result = $stmt->execute();
echo "<table>
<tr>
<th>Firstname</th>
<th>Lastname</th>
<th>Email</th>
<th>reg_date</th>
</tr>";
while($row = $stmt->fetch(PDO::FETCH_NUM)) {
	echo "<tr>";
	echo "<td>" . $row[1] . "</td>";
	echo "<td>" . $row[2] . "</td>";
	echo "<td>" . $row[3] . "</td>";
	echo "<td>" . $row[4] . "</td>";
	echo "</tr>";
}
echo "</table>";
$conn = null;
?>
</body>
</html>
