<?php
$xml = "";
echo "start....<br>";
try {
	if(!function_exists("simplexml_load_file")) {echo "not exists...";}
	$xml = simplexml_load_file("books.xml") or die("Error: Cannot create object");
} catch(Exception $e) {
	echo "load file failed...";
	die($e);
}
try {
	foreach($xml->children() as $books) {
		echo $books->title . ", ";
		echo $books->author . ", ";
		echo $books->year . ", ";
		echo $books->price . "<br>";
	}
} catch(Exception $e) {
	echo "foreach failed...";
	die($e);
}
echo "Book1's category: " . $xml->book[0]['category'] . "<br>";
echo "Book2's language: " . $xml->book[1]->title['lang'] . "<br>";
echo "SimpleXML Finished...<br><br>";


$xmlDoc = new DOMDocument();
$xmlDoc->load("note.xml");
print $xmlDoc->saveXML();
?>
