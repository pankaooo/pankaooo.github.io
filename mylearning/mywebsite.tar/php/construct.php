<?php
class Fruit {
	public $name;
	public $color;
	function __construct($name, $color = "green") {
		$this->name = $name;
		$this->color = $color;
	}
};
$apple = new Fruit("Apple");
echo $apple->color;
?>
