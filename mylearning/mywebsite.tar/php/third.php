<?php
class Car {
	public $color;
	public $modal;
	public function __construct($color, $modal) {
		$this->color = $color;
		$this->modal = $modal;
	}
	public function message() {
		return "My car is a " . $this->color . " " . $this->modal . "!";
	}
}
$myCar = new Car("blue", "BYD");
echo $myCar->message();
echo "<br>";

echo "PHP_SELF: " . $_SERVER['PHP_SELF'] . "<br>";
echo "SERVER_NAME: " . $_SERVER['SERVER_NAME'] . "<br>";
echo "HTTP_HOST: " . $_SERVER['HTTP_HOST'] . "<br>";
echo "HTTP_REFRER: " . $_SERVER['HTTP_REFRER'] . " <br>";
echo "HTTP_USER_AGENT: " .  $_SERVER['HTTP_USER_AGENT'] . "<br>";
echo "SCRIPT_NAME: " .  $_SERVER['SCRIPT_NAME'] . "<br>";
echo "REMOTE_ADDR: " .  $_SERVER['REMOTE_ADDR'] . "<br>";
echo "REMOTE_PORT: " .  $_SERVER['REMOTE_PORT'] . "<br>";
?>
