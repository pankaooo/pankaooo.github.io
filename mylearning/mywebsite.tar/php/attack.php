<!DOCTYPE html>
<html>
<body>
<form method="post" action=<?php echo $_SERVER["PHP_SELF"];?>"></form>
</body>
</html>
