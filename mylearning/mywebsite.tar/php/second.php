<!DOCTYPE html>
<html>
<body>
<?php
$x = 5 /* + 15 */ + 5;
echo $x;
echo "\n";
echo var_dump($x);
?>
</body>
</html>
