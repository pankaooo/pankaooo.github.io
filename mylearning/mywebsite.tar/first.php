<!DOCTYPE html>
<html>
<body>
<?php
$color = "red";
echo "My car is" . $color . "<br>";
echo "My bike is" . $coLOR . "<br>";
?>
</body>
</html>
