
var i = 0;
function timedCount() {
	i = i + 1;
	postMessage(i);
	setTimeout("timedCount()", 500);	//timeout (ms) and handler function
}
timedCount();				//Executed it at start.
