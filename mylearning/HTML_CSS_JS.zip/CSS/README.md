# 1. CSS Introduction

## 1.1 What is CSS?

1. CSS stands for Cascading Style Sheets
2. CSS describes how HTML elements are to be displayed on screen, paper, or in other media
3. CSS saves a lot of work. It can control the layout of multiple web pages all at once
4.  External sytlesheets are stored in CSS files



# 2. CSS Syntax

<b>A CSS rule consists of a selector and a declaration block.</b>

| Selector | Declaration   | Declaration       |
| -------- | ------------- | ----------------- |
| h1       | {color: blue; | font-size: 12px;} |



# 3. CSS Selectors

<b>A CSS Selector selects the HTML element(s) you want to style.</b>

## 3.1 CSS Selectors

​	CSS Selectors are used to "find" (or select) the HTML element you want to style.

​	We can divide CSS selectors into five categories:

​		• Simple selector (select elements based on name, id, class)

​		• Combinator selectors (select elements based on a specific relationship between them)

​		• Pseudo-elements selectors (select and style a part of an element)

​		• Pseudo-class selectors (select elements based on a certain state)

​		• Attribute selectors (select elements based on an attribute or attribute value)

| Selector              | Selector name       | Example    | Example description                           |
| --------------------- | ------------------- | ---------- | --------------------------------------------- |
| #id                   | id selector         | #firstname | selects the elements with id="firstname"      |
| .class                | class selector      | .intro     | selects all elements with calss="intro"       |
| element.class         | combinator selector | p.intro    | selects only \<p> elements with class="intro" |
| *                     | universal selector  | *          | selects all elements                          |
| element               | element selector    | p          | selects all \<p> element                      |
| element, element, ... | group elements      | div, p     | selects all \<div> and \<p> elements          |



# 4. CSS How To

<b>When a browser read a style sheet, it will format the HTML document according to the information in the style sheet.</b> 

## 4.1 Three Ways to Insert CSS

1. External CSS
2. Internal CSS
3. Inline CSS

## 4.2 External CSS

​	With an external style sheet, you can changed the look of an entire website by changing

just one file!

​	Each HTML page must include a reference to the external style sheet file inside the \<link> element, inside the head section.

```
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/mystyle.css">
</head>

<body>
<h1>This is a heading</h1>
<p>This is a paragraph.<p>
</body>
</html>
```

```
body {
	background-color: lightblue;
}

h1 {
	color: navy;
	margin-left: 20px;
}
```

## 4.3 Internal CSS

​	An internal style sheet may be used if one single HTML page has a unique style.

The internal style is defined inside the \<style> element, inside the \<head> section (or others).

```
<!DOCTYPE html>
<html>
<head>
<style>
p {
	color: white;
	font-size: 16px;
}
</style>
</head>

<body>
<p>This is paragraph.</p>
</body>
</html>
```

## 4.4 Inline CSS

​	An inline style may be used to apply a unique style for a single element.

To use inline styles, add the style attribute to the relevant element. The style attribute can

contain any CSS property.

```
<!DOCTYPE html>
<html>
<body>
<p style="color: red; font-size: 20px;">This is a paragraph.</p>
</body>
</html>
```

## 4.5 Multiple Style Sheets

​	If some properties have been defined for the same selector (element) in different style

sheets, the value from the last read style sheet will be used (as for the external CSS, the order is

where it was added).

## 4.6 Cascading Order

​	What style will be used when there is more than one style specified for an HTML element?

All the styles in a page will "cascade" into a new "virtual" style sheet by the following rules, where

number one has the highest priority:

 	1. Inline style (inside an HTML element)
 	2. External and internal style sheets (int the head section)
 	3. Browser default



# 5. CSS Comments

<b>CSS comments are not displayed in the browser, but they can help document your source code.</b>

## 5.1 CSS Comments

​	Comments are used to explain the code, and may help when you edit the source code at a later date.

​	Comments are ignored by browsers. A CSS comment is placed inside the \<style> element, and starts with /* and ends with */.

## 5.2 HTML and CSS Comments

​	From the HTML tutorial, you learned that you can add comments to your HTML source by using <!-- ... --> syntax.

​	In the following example, we use a combination of HTML and CSS comments.

```
<!DOCTYPE html>
<html>
<head>
<style>
p {
	color: red; /*Set all paragraph color to red*/
}
</style>
</head>

<body>
<h2>My heading</h2>
<!-- These paragraphs will be red -->
<p>CSS comments are not shown in the output.</p>
</body>
</html>
```



# 6. CSS Colors

<b>Colors are specified using predefined color names, or RGB, HEX, HSL, RGBA, HSLA values.</b>

​	Below are three types of color representation, please refer HTML part for details.

	1. RGB (RED, GREEN, BLUE)
	1. HEX (Hexadecimal)
	1. HSL (Hue, Saturation, lightness)

# 7. CSS Backgrounds

## 7.1 CSS background-color

```
body {
	background-color: lightblue;
	opacity: 0.3;		/*Can also defined via rgba*/
}
```

## 7.2 CSS background-image

​	By default, the image is repeated so it covers the entire element.

```
body {
	background-image: url("img/image1.jpg");	//Dont forget the 'url'!!!
}
```

​	When using inline CSS, pay attention to the url wrapped in single quot instead of dual quote.

```
<body style="background-image: url('img/image4.jpg');" >
```

## 7.3 CSS background image repeat

​	By default, the <span style="color: red;">background-image</span> property repeats an image bot horizontally and vertically.

```
body {
	background-image: url("gradient_bg.png");
	background-repeat: repeat-x;	/*Repeat only horizontally*/
}
```

​	We can also make the background image showing once by specify the <span style="color: red">background-repeat</span> to no-repeat property.

​	The <span style="color: red">background-position</span> property is used to specify the position of the background image.

```
body {
	background-image: url("img_tree.png");
	background-repeat: no-repeat;
	background-position: right top;
}
```

## 7.4 CSS background-attachment

​	The <span style="color: red;">background-attachment</span> property specifies whether the background image should scroll or be fixed (will not scroll with the rest of the image).

```
body {
	/*...*/
	background-attachment: fixed;	/*or 'scroll'*/
}
```

## 7.5 CSS background shorthand

​	To shorten the code, it is also possible to specify all the background properties in one single property. This is called a shorthand property.

```
body {
	/*When using shorthand, the order should be fixed (it does not matter
		if one of the property values is missing.)*/
	background: #ffffff url("img_tree.png") no-repeat right top;
}
```



# 8. CSS Borders

<b>The CSS border properties allow you to specify the style, width, and color of an element's border.</b>

## 8.1 CSS Border Style

​	The <span style="color: red;"> border-style </span>property specifies what kind of border to display.

The following values are allowd:

* dotted - Defines a dotted border

* dashed - Defines a dashed border

* solid - Defines a solid border

* double - Defines a double border

* groove - Defines a 3D grooved border. The effect depends on the border-color value

* inset - Defines a 3D border. The effect depends on the border-color value

* outset, none, hidden -- Practice it！

  Pay attention to that the <span style="color: red;">border-style </span> property can have from one to four values (for the top border, right border, bottom border, and the left border, practice to find the rule! )

## 8.2 Border width

```
p.one {
	border-style: solid;
	border-width: 5px 20px;	/*5px top and bottom, 20px on the sides*/
}
p.two {
	border-style: solid;
	border-width: thick;	/*May medium*/
}
```

## 8.3 Border color

​	If <span style="color: red;">border-color </span>is not set, it inherits the color of the element.

```
p.one {
	border-style: solid;
	border-color: red green;
}
```

## 8.4 CSS border sides

​	In CSS, there are also properties for specifying each of the borders (top, right, bootom, and left):

```
p {
	border-top-style: dotted;
	border-right-style: solid;
	border-bottom-style: dashed;
	border-left-style: hidden;
}
```

## 8.5 Border shorthand

​	The 'border' property is a shorthand property for 'border-width', 'border-style' (required) and 'border-color'.

```
p {
	border: 5px solid red;
}
p {
	border-left: 6px solid green;
}
```

## 8.6 Rounded borders

```
p {
	border: 2px solid red;
	border-radius: 5px;
}
```



# 9. CSS Margins

## 9.1 Margins

​	The CSS <span style="color: red;">margin</span> properties are used to create space around elements, outside of any defined borders.

​	With CSS, you have full control over the margins. There are properties for setting the margin for each side of an element (top, right, bottom, and left).

## 9.2 Individual sides

​	CSS has properties for specifying the margin for each side of an element (below code), all the margin properties can have following values (negative values are allowed):

* auto - the browser calculates the margin
* length - specifies a margin in px, pt, cm, etc.
* % - specifies a margin in % of the width of the containing element
* inherit - specifies that the margin be inherited from the parent element

```
p {
	margin-top: 20px;
	margin-bottom: 20%;
	margin-right: auto;
	margin-left: inherit;
}
```

## 9.3 Shorthand property

```
p {
	margin: 20px 20% auto inherit;	/*margin is shorthand of above fout properties*/
}
```

## 9.4 Others

​	You can set the margin property to auto to horizontally center the element within its container. The element will then take up the specified width, and the remaining space will be split equally between the left and right margins.

​	Example, lets the left margin of the <p class="ex1"> element be inherited from the parent element \<div>:

```
div {
	border: 1px solid red;
	margin-left: 100px;
}
p.ex1 {
	margin-left: inherit;
}
```

## 9.5 Margin collapse

<b>Sometimes two margins collapse into a single margin.</b>

​	Top and bottom margins of elements are sometimes collapsed into a single margin that is equal to the largest of the two margins. This does not happen on left and right margins! 

```
h1 {
	margin: 0 0 50px 0;
}
h2 {
	margin: 20px 0 0 0;
}
```

​	In the example above, the \<h1> element has a bottom margin of 50px and the \<h2> element has a top margin set to 20px. Common sense would seem to suggest that the vertical margin between the \<h1> and the \<h2> would be a total of 70px. But due to margin collapse, the actual margin ends up being 50px.



# 10. CSS Padding

<b>Padding is used to create space around an element's content, inside of any defined borders.</b>

​	All the padding properties can have the following values (negative values are allowed):

* length - specifies a padding in px, pt, cm, etc.
* % - specifies a padding in % of the width of the containing element
* inherit - specifies that the padding should be inherited from the parent element

```
div {
	padding-top: 50px;
	padding-right: 30px;
	padding-bottom: 50px;
	padding-left: 80px;
}
```

## 10.1 Shorthand property

​	The <span style="color: red">padding </span> property is a shorthand for the above four individual padding properties.  Just like the margin property, practice it.

## 10.2 Padding and element width

​	The CSS <span style="color: red;">width</span> property specifies the width of the element's content area. The content area is portion inside the padding, border, and margin of an element (the box model).

​	So, if an element has a specified width, the padding added to that element will be added to the total width of the element. This is often an undesirable result.

```
div {
	width: 300px;
	padding: 25px;	/*The actual width of the <div> element will be 350px. */
}
```

​	To keep the width at 300px, no matter the amount of padding, you can use the <span style="color: red">box-sizing</span> property. This causes the element to maintain its actual width; if you increase the padding, the available content space will decrease.

```
div {
	width: 300px;
	padding: 25px;
	box-sizing: border-box;
}
```



# 11. CSS Height/Width

​	The CSS <span style="color: red">height</span> and <span style="color: red">width</span> properties are used to set the height and width of an element.

​	The CSS <span style="color: red">max-width</span> property is used to set the maximum width of an element.

​	The height and width properties do not include padding, borders, or margins.

​	The <span style="color: red">height</span> and <span style="color: red">width</span> properties may have the following values:

* <span style="color: red">auto</span> - This default. The browser calculates the height and width
* <span style="color: red">length</span> - Defines the height/width in px, cm, etc.
* <span style="color: red">%</span> - Defines the height/width in percent of the containing block
* <span style="color: red">initial</span> - Set the height/width to its default value
* <span style="color: red">inherit</span> - The height/width will be inherited from its parent value

```
div.height {
	height: 200px;
	width: 50%;
	max-width: 400px;
	background-color: yellow;
}
```



# 12. CSS Box Model

<b>All HTML elements can be condidered as boxes.</b>

## 12.1 The CSS box model

​	In CSS, the term "box model" is used when talking about design and layout.

The CSS box model is essentially a box that wraps around every HTML element. It consists of: margins, borders, padding, and the actual content. The image below illustrates the box model:

<img src="img/boxModel.jpg" width="50%" align="left">

```
div.boxModel {
	width: 300px;	/*content!!*/
	border: 15px solid green;	
	padding: 50px;
	margin: 20px;
}
```



# 13. CSS Outline

​	An outline is a line drawn outside the element's border.

CSS has the following outline properties:

* outline-style
* outline-color
* outline-width
* outline-offset
* outline

<b>Note: </b>Outline differs from borders! Unlike border, the outline is drawn outside the element's border, and may overlap other content. Also, the outline is NOT a part of the element's dimensions; the element's total width and height is not affected by the width of the outline.

## 13.1 CSS Outline Style

​	The <span style="color: red;"> outline-style</span> property values are totally similar to border's, practice it!

```
div.outline {
	outline-style: dotted;
	outline-color: pink;
	outline-width: 10px;
	outline-offset: 2px;
}
```

## 13.2 CSS Outline - Shorthand property

​	The <span style="color: red;">outline </span> property is a shorthand property for setting the following individual outline properties:

* outline-width
* outline-style
* otuline-color

```
p.ex1 {
	outline: 3px dashed green;
}
p.ex2 {
	outline: dotted yellow;
}
```

## 13.3 CSS Outline Offset

​	The <span style="color: red;">outline-offset </span>property adds space between an outline and the edge/border of an element. The space between an element and its outline is transparent.

​	

# 14. CSS Text

## 14.1 Text Color

```
p {
	background-color: yellow;
	color: white;			/*text color*/
}
```

## 14.2 Text Alignment

1. text-align

   The <span style="color: red;">text-align</span> property is used to set the horizontal alignment of a text. A text can be left or right aligned, centered, or justified.

2. text-align-last

   The <span style="color: red;">text-align-last</span> property specifies how to align the last line of a text.

3. direction

​		The <span style="color: red;">direction</span> and <span style="color: red;">unicode-bidi</span> properties can be used to change the text direction of an elemnt. (unicode-bidi: used together with the direction property to set or return whether the text should be overridden to support multiple languages in the same document.)

```
p {
	direction: rtl;		/*right to left*/
	unicode-bidi: bidi-override;
}
```

	4. vertical-align

​		The <span style="color: red;">vertical-align</span> property sets the vertical alignment of an elemnt.

```
p {
	vertical-align: baseline;	//text-top, text-bootom, sub, super
}
```

## 14.3 CSS Text Decoration

	1. text-decoration-line

​		The <span style="color: red;">text-decoration-line</span> property is used to add a decoration line to text. The values include:

​	overline, line-through, underline (and their combination).

 2. text-decoration-color

 3. text-decoration-style

    The <span style="color: red">text-decoration-style</span> property is used to set the style of the decoration line, the values include: solid, double, dotted, dashed, wavy, none, hidden.

 4. text-decoration-thickness

 5. The Shorthand Property - text-decoration

    The <span style="color: red">text-decoration</span> property is a shorthand property for:

    * text-decoration-line (required)
    * text-decoration-color
    * text-decoration-style
    * text-decoration-thickness

<b>A Small Tip</b>

​	All links in HTML are underlines by default. Sometimes you see that links are styled with no underline. The <span style="color: red">text-decoration: none</span> is used to remove the underline from links.

## 14.4 CSS Text Transformation

​	The <span style="color: red">text-transform</span> property is used to specify uppercase and lowercase letters in a text.

```
p.uppercase {
	text-transform: uppercase;
}
p.capitalize {
	text-transform: capitalize;
}
```

## 14.5 CSS Text Spacing

 1. text-indent

    The <span style="color: red;">text-indent</span> property is used to specify the indentation of the first line of a text.

 2. letter-spacing

​		The <span style="color: red;">letter-spacing</span> property is used to specify the space between the characters in a text.

3. line-height

4. word-spacing

   The <span style="color: red;">word-spacing</span> property is used to specify the space between the words in a text.

5. white-space

   The <span style="color: red;">white-space</span> property specifies how white-space inside an element is handled.

   ```
   p {
   	white-space: nowrap;	/*All in a line (delete break)*/
   }
   /*Other examples:*/
   p.text-spacing {
   	text-indentation: 20px;
   	letter-spacing: 5px;
   	line-height: 40px;
   }
   ```

## 14.6 CSS Text Shadow

1. text-shadow

​		The <span style="color:red">text-shadow</span> property adds shadow to text.

```
p.shadow {
	text-shadow: 2px 2px 5px red;	/*horizontal shadow, vertical shadow and blur*/
}
p.shadow {
	color: white;
	text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
}
```



# 15. CSS Fonts

## 15.1 Font Family

### 15.1.1 Font Selection is Important

​	Choosing the right font has a huge impact on how experience a website.

​	The right font can create a strong identity for your brand.

​	Using a font that is easy to read is important. The font adds value to your text. It is also important to choose the correct color and text size for the font.

### 15.1.2 Generic Font Families

​	In CSS there are five generic font families:

1. <b>Serif</b> fonts have a small stroke at the edges of each letter. They create a sense of formality and elegance.
2. <b>Sans-serif</b> fonts have clean lines (no small strokes attached). They create a modern and minimalistic look.
3. <b>Monospace</b> fonts - here all the letters have the same fixed width. They create a mechanical look.
4. <b>Cursive</b> fonts imitate human handwriting.
5. <b>Fantasy</b> fonts are decorative/playful fonts.

<img src="img/fontFamily.jpg" width="50%" align="left">

### 15.1.2 Some Font Examples

| Generic Font Family | Examples of Font Names                                       |
| ------------------- | ------------------------------------------------------------ |
| Serif               | <span style="font-family: 'Times New Roman'">Times New Roman</span> <br><span style="font-family: Georgia">Georgia</span><br><span style="font-family: Garamond">Garamond</span> |
| Sans-serif          | <span style="font-family: Arial">Arial</span><br><span style="font-family: Verdana">Verdana</span><br><span style="font-family: Helvetica">Helvetica</span> |
| Monospace           | <span style="font-family: 'Courier New'">Courier New</span><br><span style="font-family: 'Lucida Console'">Lucida Console</span><br><span style="font-family: Monaco">Monaco</span> |
| Cursive             | <span style="font-family: 'Brush Script MT'">Brush Script MT</span><br><span style="font-family: 'Lucida Handwriting'">Lucida Handwriting</span> |
| Fantasy             | <span style="font-family: Copperplate">Copperplate</span><br><span style="font-family: Papyrus">Papyrus</span> |

### 15.1.3 The CSS font-family Property

​	In CSS, we use the <span style="color: red;">font-family</span> property should hold several font names as a "fallback" system, to ensure maximum compatibility between browsers/operating systems. Start with the font you want, and end with a generic family (to let the browser pick a similar font in the generic gamily, if no other fonts are available). The font names should be separated with comma. Read more about fallback fonts in the next chapter.

```
.p1 {
	font-family: "Times New Roma", Times, serif;	/*refer above table*/
}
```

## 15.2 Font Web Safe

### 15.2.1 What are Web Safe Fonts?

​	Web safe fonts are fonts that are universally installed across all browsers and devices.

### 15.2.2 Fallback Fonts

​	However, there are no 100% completely web safe fonts. There is always a chance that a font is not found or is not installed properly.

​	Therefore, it is very important to always use fallback fonts.

​	This means that you should add a list of similar "backup fonts" in the <span style="color: red;">font-family</span> property. If the first font does not work, the browser will try the next one, and the next one, and so on. Always end the list with a generic font family name.

```
p {
	font-family: Tahoma, Verdana, sans-serif;
}
```

### 15.2.3 Best Web Safe Fonts for HTML and CSS

​	The following list are the best web safe fonts for HTML and CSS:

* Arial (sans-serif) - the most widely used font for both online and printed media.
* Verdana (sans-serif) - very popular font, easily readable even for small font sizes.
* Tahoma (sans-serif) - has less space between the characters.
* Trebuchet MS (sans-serif) - Use this font carefully, not supported by all mobile operating systems.
* Times New Roman (serif) - one of the most recognizable fonts in the world, it looks professional and is used in many newspapers and "news" websites.
* Georgia (serif) - an elegant serif font, it is very readable at different font sizes, so it is a good candidate for mobile-responsive design.
* Garamond (serif) - a classical font used for many printed books, it has a timeless look and good readability.
* Courier New (monospace) - most used monospace serif font, and often used with coding displays, and many email providers use it as their default font. Courier New is also the standard font for movie screenplays.
* Brush Script MT (cursive) - designed to mimic handwriting, it is elegant and sophisticated, but can be hard to read.

## 15.3 CSS Font Fallbacks

### 15.3.1 Commonly Used Font Fallbacks

​	Below are some commonly used font fallbacks, orgainized by the 5 generic font families:

* <b>Serif</b>
* <b>Sans-serif</b>
* <b>Monospace</b>
* <b>Cursive</b>
* <b>Fantasy</b>

## 15.4 Font Style

### 15.4.1 Font Style

​	The <span style="color: red;">font-style</span> property is mostly used to specify italic text.

This property has three values:

* normal - The text is shown normally
* italic - The text is shown in italics
* oblique - The text is "leaning" (oblique is very similar to italic, but less supported)

```
p.text-style {
	font-style: italic;	/*or oblique, normal*/
}
```

### 15.4.2 Font Weight

​	The <span style="color: red;">font-weight</span> property specifies the weight of a font:

```
p.text-style {
	font-weight: bold;	/*or normal*/
}
```

### 15.4.3 Font Variant

​	The <span style="color: red;">font-variant</span> property specifies whether or not a text should be displayed in samll-caps font.

​	In a small-caps font, all lowercase letters are converted to uppercase letters. However, the converted uppercase letters appears in a smaller font size than the original uppercase in the text.

```
p.font-variant {
	font-variant: small-caps;
}
```

## 15.5 Font Size

### 15.5.1 Font Size

​	The <span style="color: red;">font-size</span> property sets the size of the text.

​	Being able to manage the text size is important in web design. However, you should not use font size adjustments to make paragraphs look like headings, or headings look like paragraphs.

Always use the proper HTML tags, like \<h1> - \<h6> for headings and \<p> for paragraphs.

The font-size value can be an absolute, or relative size.

Absolute size:

* Sets the text to a specified size
* Does not allow a user to change the text size in all browsers (bad for accessibility reasons)
* Absolute size is useful when the physical size of the output is known

Relative size:

* Sets the size relative to surrounding elements
* Allows a user to change the text size in browsers

<b>Note: </b>If you do not specify a font size, the default size for normal text, like paragraphs, is 16px (16px=1em).

### 15.5.2 Set Font Size With Pixels

​	Setting the text size with pixels gives you full control over the text size:

```
p.font-size {
	fotn-size: 40px;
}
```

### 15.5.3 Set Font Size With Em

​	To allow users to resize the text (in the browser menu), many developers use em instead of pixels.

​	1em is equal to the current font size. The default  text size in browsers is 16px. So, the default size of 1em is 16px.

```
p.font-size {
	font-size: 1.2em;
}
```

​	Unfortunately, there is still a problem with older versions of Internet Explorer. The text becoms larger than it should when made larger, and smaller when it should when made smaller.

### 15.5.4 Use a Combination of Percent and Em

​	The solution that works in all browsers, is to set a default font-size in percent for the <span style="color: red;">body</span> element:

```
body {
	font-size: 100%;
}
p.font-size {
	fotn-size: 1.2em;
}
```

### 15.5.5 Responsive Font Size

​	The text size can be set with a <span style="color: red;">vw</span> unit, which means the "viewport width". That way the text size will follow the size of the browser window.

```
<p style="font-size: 5vw;">Viewport width</p>
```

## 15.6 Font Google

### 15.6.1 Googel Fonts

​	If you do not want to use any of the standard fonts in HTML, you can use Google Fonts. Google Fonts are free to use, and have more than 1000 fonts to choose from.

### 15.6.2 How To Use Google Fonts

​	Just add a special style sheet link in the <span style="color: red;">\<head></span> section and then refer to the font in the CSS.

```
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
<style>
body {
	font-family: "Sofia", sans-serif;
}
</style>
</head>
```

### 15.6.3 Use Multiple Google Fonts

​	To use multiple Google fonts, just separate the font names with a pipe character (|), like this:

```
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong">
```

### 15.6.4 Styling Google Fonts

​	Of course you can style Google Fonts as you like, with CSS!

```
body {
	font-family: "SOfia", sans-serif;
	font-size: 20px;
	text-shadow: 3px 3px 3px #ababab;
}
```

### 15.6.5 Enabling Font Effects

​	Google has also enabled different font effects that you can use.

First add <span style="color: red;">effect=effectname</span> to the Google API, then add a special class name to the element that is going to use the special effect. The class name always starts with <span style="color: red;">font-effect-</span> and ends with the <span style="color: red;">effectname</span>.

```
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=fire">
/*Or like this:
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
*/

<p class="font-effect-fire">Sofia on Fire</p>
```

## 15.7 Font Pairings

<b>Great font pairings are essential to great design.</b>

### 15.7.1 Font Pairing Rules

​	Here are some basic rules to create great font pairings:

1. Complement

​		It is always safe to find font pairings that complement one another.

​	A great font combination should harmonize, without being too similar or too different.

2.  Use Font Superfamilies

​		A font superfamily is a set of fonts designed to work well together. So, using different fonts within the same superfamily is safe.

For example, the Lucida superfamily contains the following fonts: Lucida Sans, Lucida Serif, Lucida Typewriter Sans, Lucida Typerwriter Serif and Lucida Math.

3. Contrast is King

​		Two fonts that are too similar will often conflict. However, contrasts, done the right way, brings out the best in each font.

Example: Combing serif with sans serif is a well known combination.

A strong superfamily includes both serif and sans serif variations of the same font.

4. Choose Only One Boss

​		One font should be the boss. This establishes a hierarchy for the fonts on your page. This can be achieved by varying the size, weight and color.

```
body {
	font-family: Verdana, sans-serif;
	color: gray;
}
h1 {
	font-family: Georgia, serif;	/*Georgia is the boss here.*/
	color: white;
}
```

### 15.7.2 Popular font pairs

 1. Georgis & Verdana

 2. Helvetica & Garamond

    Below are popular Google font pairings

 3. Merriweather & Open Sans

 4. Ubuntu & Lora

 5. Abril Fatface & Poppins

 6. Cinzel & Fauna One

## 15.8 Font Shorthand

​	To shorten the code, it is also possible to specify all the individual font properties in one property. The <span style="color: red;">font</span> property is a shorthand property for:

* font-style
* font-variant
* font-weight
* font-size/line-height
* font-family

```
p.a {
	font: 20px Arial, sans-serif;
}
p.b {
	font: italic small-caps bold 12px/30px Georgia, serif;
}
```



# 16. CSS Icons

<b>Icons can easily be added to your HTML page, by using an icon library</b>

 ## 16.1 How To Add Icons

​	The simplest way to add an icon to your HTML page, is with an icon library, such as Font Awesome. Add the name of the specified icon class to any inline HTML element (like <span style="color: red;">\<i></span> or <span style="color: red;">\<span></span>).

​	All the icons in the icon libraries below, are scalable vectors that can be customized with CSS (size, color, shadow, etc.)

## 16.2 Font Awesome Icons

​	To use the Font Awesome icons, go to fontawesome.com, sign in, and get a code to add in the <span style="color: red;">\<head></span> section of your HTML page:

<span style="color: red;">\<script src=\"https://kit.fontawesome.com/</span><span style="font-style: italic;">yourcode.js</span><span style="color: red;">" crossorigin="anonymous">\</script></span>

Read more about how to get started with Font Awesome in Font Awesome tutorial. My code:

```
<script src="https://kit.fontawesome.com/a09d3592db.js" crossorigin="anonymous"></script>
```

## 16.3 Bootstrap Icons

​	To use the Bootstrap glyphicons, add the following line inside the <span style="color: red;">\<head></span> section of your HTML page:

```
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
```

## 16.4 Google Icons

​	To use the Google icons, add the following line inside the <span style="color: red;">\<head></span> section of your HTML page:

```
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
```



# 17. CSS Links

<b>With CSS, links can be styled in many different ways.</b>

## 17.1 Styling Links

​	Links can be styled with any CSS property (e.g., color, font-family, background, etc).

In addition, links can be styled differently depending on what <b>state</b> they are in.

The four links states are:

* a:link - a normal, unvisited link
* a:visited - a link the user has visited
* a:hover - a link when the user mouses over it (must come after a:link and a:visited)
* a:active - a link the moment it is clicked (must come after a:hover)

```
<style>
a:link {
	color: red;
}
</style>
<!-- ... -->
<p><a href="bootstrap.html" target="_blank">This is a link</a></p>
```

## 17.2 Text Decoration

​	The <span style="color: red;">text-decoration</span> property is mostly used to remove underline from links:

```
a:link {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
```

## 17.3 Background Color

​	The <span style="color: red;">background-color</span> property can be used to specify a background color for links.

## 17.4 Link Buttons

​	This example demonstrates a more advanced example where we combine several CSS properties to display links as boxed/buttons:

```
a:link, a:visited {
	background-color: #f4436;
}
```

## 17.5 Cursor Property

```
<p>Mouse over the words to change the cursor.</p>
<span style="cursor:auto">auto</span><br>
<span style="cursor:crosshair">crosshair</span><br>
<span style="cursor:default">default</span><br>
<span style="cursor:e-resize">e-resize</span><br>
<span style="cursor:help">help</span><br>
<span style="cursor:move">move</span><br>
<span style="cursor:n-resize">n-resize</span><br>
<span style="cursor:ne-resize">ne-resize</span><br>
<span style="cursor:nw-resize">nw-resize</span><br>
<span style="cursor:pointer">pointer</span><br>
<span style="cursor:progress">progress</span><br>
<span style="cursor:s-resize">s-resize</span><br>
<span style="cursor:se-resize">se-resize</span><br>
<span style="cursor:sw-resize">sw-resize</span><br>
<span style="cursor:text">text</span><br>
<span style="cursor:w-resize">w-resize</span><br>
<span style="cursor:wait">wait</span><br>
```



# 18. CSS Lists

## 18.1 HTML Lists and CSS List Properties

​	In HTML, there are two main types of lists:

* unordered lists (\<ul>) - the list items are marked with bullets
* ordered lists (\<ol>) - the list items are marked with numbers or letters

​	The CSS list properties allow you to:

* Set different list item markers for ordered lists
* Set different list item markers for unordered lists
* Set an image as the list item marker
* Add background colors to lists and list item

## 18.2 Different List Item Markers

​	The <span style="color: red;">list-style-type</span> property specifies the type of list item marker.

​	The following example shows some of the available list item markers:

```
ul.a {
	list-style-type: circle;	/*can also be: square, upper-roman, lower-alpha*/
}
```

## 18.3 An Image as The List Item Marker

​	The <span style="color: red;">list-style-image</span> property specifies an image as the list item marker:

```
ul {
	list-style-image: url("img/image3.jpg");
}
```

## 18.4 Position The List Item Markers

​	The <span style="color: red;">list-style-position</span> property specifies the position of the list-item markers (bullet points).

"list-style-position: outside;" means that the bullet points will be outside the list item. The start of each line of a list item will be aligned vertically. This is default:

<img src="img/list.jpg" width="70%" style="align: left;"  >

## 18.5 Remove Default Settings

​	The <span style="color: red;">list-style-type: none</span> property can also be used to remove the markers/bullets. Note that the list also has default margin and padding. To remove this, add margin: 0 and padding: 0 to \<ul> or \<ol>:

```
ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
}
```

## 18.6 List - Shorthand property

​	The <span style="color: red;">list-style</span> property is a shorthand property. It is used to set all the list properties in one declaration:

```
ul {
	list-style: square inside url("sqpurle.gif");
}
```

​	When using the shorthand property, the order of the property values are:

* list-style-type
* list-style-position
* list-style-image

## 18.7 Styling List With Colors

​	We can also style lists with colors, to make them look a little more interesting.

Anything added to the \<ol> or \<ul> tag, affects the entire list, while properties added to the \<li> tag will affect the individual list items:

```
ol li {
	background: #ffe5e5;
	color: darkred;
	padding: 5px;
	margin-left: 35px;
}
```



# 19. CSS Tables

## 19.1 Table Borders

### 19.1.1 Table Borders

​	To specify table borders in CSS, use the <span style="color: red;">border</span> property.

​	The example below specifies a solid border for \<table>, \<th>, and \<td> elements:

```
table, th, td {
	border: 1px solid;
}
```

### 19.1.2 Full-Width Table

​	The table above might seem small in some cases. If you need a table that should span the entire screen (full-width), add <span style="color: red;">width: 100%</span> to the \<table> element:

```
table.table-border {
	width: 100%;
}
```

### 19.1.3 Collapse Table Borders

​	The <span style="color: red;">border-collapse</span> property sets whether the table borders should be collapse into a single border:

```
table.table-border {
	border-collapse: collapse;
}
```

## 19.2 Table Size

### 19.2.1 Table Width and Height

​	The width and height of a table are defined by the <span style="color: red;">width </span>and <span style="color: red;">height</span> properties.

​	The example below sets the width of the table of 100%, and the height of the \<th> element to 70px:

```
table {
	width: 100%;
}
th {
	height: 70px;
}
```

## 19.3 Table Alignment

### 19.3.1 Horizontal Alignment

​	The <span style="color: red;">text-align</span> property sets the horizontal alignment (like left, right, or center) of the content in \<th> or \<td>.

​	By default, the content of \<th> elements are center-aligned and the content of \<td> elements are left-aligned.

```
td.table-border {
	text-align: center;
}
```

### 19.3.2 Vertical Alignment

​	The <span style="color: red;">vertical-align</span> property sets the vertical alignment (like top, bottom, or middle) of the content \<th> or \<td>.

​	By default, the vertical alignment of the content in a table is middle (for both \<th> and \<td> elements)

## 19.4 Table Style

### 19.4.1 Table Padding

​	To control the space between the border and the content in a table, use the <span style="color: red;">padding</span> property on \<td> and \<th> elements:

````
th, td {
	padding: 15px;
}
````

### 19.4.2 Horizontal Dividers

​	Add the <span style="color: red;">border-bottom</span> property to \<th> and \<th> for horizontal dividers:

```
th {
	border-bottom: 1px solid #ddd;
}
```

### 19.4.3 Hoverable Table

​	Use the <span style="color: red;">:hover</span> selector on \<tr> to highlight table rows on mouse over:

```
tr:hover {
	background-color: coral;
}
```

### 19.4.4 Striped Tables

​	For zebra-striped tables, use the <span style="color: red;">nth-child()</span> selector and add a <span style="color: red;">background-color</span> to all even (or odd) table rows:

```
tr: nth-child(even) {
	background-color: #f2f2f2;
}
```

### 19.4.5 Table Color

```
th {
	background-color: #04AA6D;
	color: whiet;
}
```

### 19.4.6 Responsive Table

​	A responsive table will display a horizontal scroll bar if the screen is too small to display the full content. Add a container element (like \<div>) with <span style="color: red;">overflow-x: auto</span> around the \<table> element to make it responsive:

```
<div style="overflow-x: auto;">
	<table>
		<!-- ... -->
	</table>
</div>
```

### 19.4.6 Other CSS Table Properties

| Property       | Description                                                  |
| -------------- | ------------------------------------------------------------ |
| border-spacing | Specifies the distance between the borders of adjacent cells |
| caption-side   | Specifies the placement of a table caption                   |
| empty-cells    | Specifies whether or not to display borders and background on empty cells in a table |
| table-layout   | Sets the layout algorithm to be used for a table             |



# 20. CSS Layout - The display Property

​	The <span style="color: red;">display</span> property is the most important CSS property for controlling layout.

## 20.1 The display Property

​	The <span style="color: red;">display</span> property specifies if/how an element is displayed.

Every HTML element has a default display value depending on what type of element it is. The default display value for most elements is <span style="color: red;">block</span> or <span style="color: red;"> inline</span>.

## 20.2 Block-level Elements

​	A block-level element always starts on a new line and takes up the full width available (stretches out the left and right as far as it can).

​	The \<div> element is a block-level element.

Examples of block-level element:

* \<h1> - \<h6>
* \<p>
* \<form>
* \<header>
* \<footer>
* \<section>

## 20.3 Inline Elements

​	An inline element does not start on a new line and only takes up as much width as necessary.

​	This is an inline <span style="font-style: italic;">\<span> </span>element inside a paragraph. Examples of inline elements:

* \<span>
* \<a>
* \<img>

## 20.4 Display: none;

​	<span style="color: red;">display: none;</span> is commonly used with JavaScript to hide and show elements without deleting and recreating them. Take a look at this example  if you want to know how this can be achieved:

```
<script>
	/*code to set the display property */
function Show() {
	var d = document.getElementByClass("show");
	d.style.display = inline;
}
</script>

<button type="button" conclick="Show()"></button>
<div class="show" style="display: none;"> 
	<!-- something here -->
</div>

<!-- After test, below code is available: -->
<script>
	/*code toe set the display property */
function Show() {
	alert("Start to show");
	document.getElementById("show").style.display = "block";
	/*d.style.display = block;*/	/*inline*/
}
</script>

<button type="button" onclick="Show()">Show</button>
<div > 
	<!-- something here -->
	<p id="show" style="display:none;">Test ...</p>
</div>
```

## 20.5 Override The Default Display Value

​	As mentioned, every element has a default display value. However, you can override this. Changing an inline element to a block element, or vice versa, can be useful for making the page look a specific way, and still follow the web standards.

​	A common example is making inline \<li> elements for horizontal menus:

```
li {
	display: inline;
}
```

<b>Note: </b>Setting the display property of an element only changes how the element is displayed, NOT what kind of element it is. So an inline element with <span style="color: red;">display: block;</span> is not allowed to have another block elements inside it!

## 20.6 Hide an Element - display:none or visibility:hidden?

​	Hiding an element can be done by setting the <span style="color: red;">display</span> property to <span style="color: red;">none</span>. The element will be hidden, and the page will be displayed as if the element is not there. <span style="color: red;">visibility:hidden;</span> also hides an element. However, the element will still take up the same spaces as before (still affect the layout).



# 21. CSS Max-width

## 21.1 Using width, max-width and margin: auto;

​	As mentioned in the previous chapter; a block-level element always takes up the full width available (stretches out to the left and right as far as it can).

​	Setting the <span style="color: red;">width</span> of a block-level element will prevent it from stretching out to the edges of its container. Then, you can set the margins to auto, to horizontally center the element within its container. The element will take up the specified width, and the remaining space will be split equally between the two margins.

```
<style>
div.width {
	width: 500px;	
}
</style>
```

<b>Note: </b>The problem with the <span style="color: red;">\<div></span> above occurs when the browser window is smaller than the width of the element. The browser then adds a horizontal scrollbar to the page.

​	Using <span style="color: red;">max-width</span> instead, in this situation, will improve the browser's handling of small windows. This is <b>important</b> when making a site usable on mall devices.

```
div.width {
	max-width: 500px;
	margin: auto;
	border: 3px solid #73AD21;
}
```

<b>Problem: </b>Stop text from wrapping around image: 

&nbsp;&nbsp;<img src="img/wrap.jpg" width="60%" style="align: left; padding: 20px;"> 

```
.imgbox {
	float: left;
	text-align: center;
	width: 600px;
}
div.width {
	overflow: hidden;
	max-width: 500px;
	margin: auto;
	border: 3px solid #73AD21;
}
```

​	Above, image are float and width=100%, so if we add <span style="color: red;">\<br clear="left;"</span>, the text still overlapped with the image, so we may set the image height=100%, or add some extra \<br>, we can also set the <span style="color: red;">overflow: hidden;</span> to \<div> to avoid the overlap of \<div>s.

<img src="img/div.jpg" style="padding: 20px;">



# 22.CSS Layout - The position property

​	The <span style="color: red;">position</span> property specifies the type of positioning method used for an element (static, relative, fixed, absolute or sticky).

## 22.1 The position Property

​	The <span style="color: red;">position</span> property specifies the type of positioning method used for an element.

There are five different position values:

* static
* relative
* fixed
* absolute
* sticky

​	Elements are then positioned using the top, bottom, left, and right properties. However, these properties will not work unless the <span style="color: red;">position</span> property is set first. They also work differently depending on the position value.

## 22.2 position: static;

​	HTML elements are positioned static by default.

​	Static positioned elements are not affected by the top, bottom, left, and right properties.

​	An element with <span style="color: red;">position: static;</span> is not positioned in any special way; it is always positioned according to the normal flow of the page:

````
div.static {
	position: static;
	border: 3px solid #73AD21;
}
````

## 22.3 position: relative;

​	An element with <span style="color: red;">position: relative;</span> is positioned to its normal  position.

​	Setting the top, right, bottom, and left properties of a relatively-positioned element will cause it to be adjusted away from its normal position. Other content will not be adjusted to fit into any gap left by the element:

```
div.relative {
	position: relatvive;
	left: 30px;
	border: 3px solid #45AD44;
}
```

## 22.4 position: fixed;

​	An element with <span style="color: red;">position: fixed;</span> is positioned relative to the viewport, which means it always stays in the same place even if the page is <b>scrolled</b>. The top, right, bottom, and left properties are used to position the element.

​	A fixed element does not leave a gap in the page where it would normally have been located.

Notice the fixed element in the lower-right corner of the page. Here is the CSS that is used:

```
div.fixed {
	position: fixed;
	bottom: 0;
	right: 0;
	width: 300px;
	border: 3px solid #991122;
}
```

## 22.5 position: absolute;

​	An element with <span style="color: red;">position: absolute;</span> is positioned relative to the nearest positioned ancestor (instead of positioned relative to the viewport, like fixed).

​	However, if an absolute positioned element has no positioned ancestors, it uses the document body, and moves along with page scrolling.

<b>Note: </b>Absolute positioned elements are removed from the normal flow, and can overlap elements.

```
div.absolute {
	position: absolute;
	top: 80px;
	right: 0;
	width: 200px;
	height: 100px;
	border: 3px dashed #72AD11;
}
```

## 22.6 position: sticky;

​	An element with <span style="color: red;">position: sticky;</span> is positioned based on the user's scroll position.

A sticky element toggles between <span style="color: red;">relative</span> and <span style="color: red;">fixed</span>, depending on the scroll position. It is positioned relative until a given offset position is met in the viewport - then it "sticks" in place (like position: fixed).

<b>Note: </b>Internet Explorer does not support sticky positioning. Safari requires a -webkit- prefix. You must also specify at least one of top, right, bottom or left for sticky positioning to work.

```
/*the sticky element sticks to the top of the page (top: 0)*/
div.sticky {
	position: -webkit-sticky;
	position: stcky;
	background-color: green;
	border: 2px solid #4CAF50;
}
```

​	All CSS Positioning Properties:

| Property | Description                                      |
| -------- | ------------------------------------------------ |
| bottom   | Sets the bottom margin edge for a positioned box |
| clip     | Clips an absolutely positioned element           |
| left     | Sets the left margin edge for a positioned box   |
| position | Specifies the type of positioning for an element |
| right    | Sets the right margin edge for a positioned box  |
| top      | Sets the top margin edge for a positioned box    |



# 23. CSS Layout - The z-index Property

​	The <span style="color: red;">z-index</span> property specifies the stack order of an element.

## 23.1 The z-index Property

​	When elements are positioned, they can overlap other elements.

The <span style="color: red;">z-index</span> property specifies the stack order of an element (which element should be placed in front of, or behind, the others).

An element can have a positive or negative stack order:

```
img {
	position: absolute;
	left: 0px;
	top: 0px;
	z-index: -1;
}
```

<b>Note: </b><span style="color: red;">z-index</span> only works on positioned elements and flex items (elements that are direct children of display: flex elements). 

## 23.2 Another z-index Example

```
<!DOCTYPE html>
<html>
<head>
<style>
.container {
  position: relative;
}
.black-box {
  position: relative;
  z-index: 1;
  border: 2px solid black;
  height: 100px;
  margin: 30px;
}
.gray-box {
  position: absolute;
  z-index: 3; /* gray box will be above both green and black box */
  background: lightgray;
  height: 60px;  
  width: 70%;
  left: 50px;
  top: 50px;
}
.green-box {
  position: absolute;
  z-index: 2; /* green box will be above black box */
  background: lightgreen;
  width: 35%;
  left: 270px;
  top: -15px;
  height: 100px;
}
</style>
</head>
<body>
<h1>Z-index Example</h1>
<p>An element with greater stack order is always above an element with a lower stack order.</p>
<div class="container">
  <div class="black-box">Black box (z-index: 1)</div>
  <div class="gray-box">Gray box (z-index: 3)</div>
  <div class="green-box">Green box (z-index: 2)</div>
</div>
</body>
</html>
```

## 23.3 Without z-index

​	If two positioned elements overlap each other without a <span style="color: red">z-index</span> specified, the element defined <b>last in the HTML code</b> will be shown on top.



# 24. CSS Layout - Overflow

​	The CSS <span style="color: red">overflow</span> property controls what happens to content that is too big to fit into an area.

## 24.1 CSS Overflow

​	The <span style="color: red">overflow</span> property specifies whether to clip the content or to add scrollbars when the content of an element is too big to fit in the specified area.

​	The <span style="color: red">overflow</span> property has the following values:

* visible - Default. The overflow is not clipped. The content renders outside the element's box
* hidden - The overflow is clipped, and the rest of the content will be invisible
* scroll - The overflow is clipped, and a scrollbar is added to see the rest of the content
* auto - Similar to scroll, but it adds scrollbars only when necessary

<b>Note: </b>The <span style="color: red">overflow</span> property only works for block elements with a specified height. In OS X Lion (on Max), scrollbars are hidden by default and only shown when being used (even though "overflow: scroll" is set).

## 24.2 overflow-x and overflow-y

​	The <span style="color: red">overflow-x</span> and <span style="color: red">overflow-y</span> properties specifies whether to change the overflow of content just horizontally or vertically (or both):

<span style="color: red">overflow-x</span> specifies what to do with the left/right edges of the content.

<span style="color: red">overflow-y</span> specifies what to do with the top/bottom edges of the content.

```
div {
	overflow-x: hidden;
	overflow-y: scroll;
}
```

## 24.3 overflow-wrap

​	This value specifies whether or not the browser can break lines with long words, if they overflow its container.



# 25. CSS Layout - float and clear

​	The CSS <span style="color: red;">float</span> property specifies how an element should float.

​	The CSS <span style="color: red;">clear</span> property specifies what elements can float beside the cleared element and on which side.

## 25.1 The flat Property

​	The <span style="color: red;">float</span> property is used for positioning and formatting content e.g. let and image float left to the text in a container.

​	The <span style="color: red;">float</span> property can have one of the following values:

* left - The element floats to the left of its container
* right - The element floats to the right of its container
* none - The element does not float (will be displayed just where it occurs in the text). This is default
* inherit - The element inherits the float value of its parent

### 25.1.1 Example - float: right;

```
img.right {
	float: right;
}
```

### 25.1.2 Example - Float Next To Each Other

​	Normally div elements will be displayed on top of each other. However, if we use <span style="color: red;">float: left;</span> we can let elements float next to each other:

```
div.div1 {
	float: left;
	background: red;
	padding-left: 15px;
}
div.div2 {
	float: left;
	background: green;
}
div.div3 {
	float: left;
	background: green;
}
```

## 25.2 clear and clearfix

### 25.2.1 The clear Property

​	When we use the <span style="color: red;">float</span> property, and we want the next element below (not on right or left), we will have to use the <span style="color: red;">clear</span> property.

​	The <span style="color: red;">clear</span> property specifies what should happen with the element that is next to a floating element, this property have one of the following values:

* none - The element is not pushed below left or right floated elements. This is default
* left - The element is pushed below left floated elements
* right - The element is pushed below right floated elements
* both - The element is pushed below left and right floated elements
* inherit - The element inherits the clear value from its parent

### 25.2.2 The clearfix Hack

​	If a floated element is taller than the container element, it will "overflow" outside of its container. We can then add a clearfix hack to solve this problem.

​	The <span style="color: red;">overflow: auto;</span> clearfix works well as long as you are able to keep control of your margins and padding (ele you might see scrollbars). The <b>new, modern clearfix hack</b> however, is safer to use, and the following code is used for most webpages:

```
.clearfix::after {
	content: "";
	clear: both;
	display: table;
}
```

### 25.2.3 box-sizing & float example

​	With the <span style="color: red;">float</span> property, it is easy to float boxed of content side by side:

```
* {
  box-sizing: border-box;
}

.box {
  float: left;
  width: 33.33%;
  padding: 50px;
}

.clearfix::after {
  content: "";
  clear: both;
  display: table;
}
<!-- some codes -->
<h2>Grid of Boxes</h2>
<p>Float boxes side by side:</p>

<div class="clearfix">
  <div class="box" style="background-color:#bbb">
  <p>Some text inside the box.</p>
  </div>
  <div class="box" style="background-color:#ccc">
  <p>Some text inside the box.</p>
  </div>
  <div class="box" style="background-color:#ddd">
  <p>Some text inside the box.</p>
  </div>
</div>
```

<b>What is box-sizeing?</b>

​	You can easily create three floating boxes side by side. However, when you add something that enlarges the width of each box (e.g. padding or borders), the box will break (not side by side). The <span style="color: red;">box-sizing</span> property allows us to include the padding and border in the box's total width (and height), making sure that the padding stays inside of the box and that it does not break.	Some examples refer the w3schools.



# 26. CSS Layout - display: inline-block

## 26.1 The display: inline-block value

​	Compared to <span style="color: red;">display: inline</span>, the major difference is that <span style="color: red;">display: inline-block</span> allows to set a width and height on the element.

​	Also, with <span style="color: red;">display: inline-block</span>, the top and bottom margins/paddings are respected, but with <span style="color: red;">display: inline</span> they are not.

​	Compared to <span style="color: red;">display: blcok</span>,  the major different is that <span style="color: red;">display: inline-block</span> does not add a line-break after the element, so the element can sit next to other elements.

​	The following example shows the different behaviors of <span style="color: red;">display: inline</span>, <span style="color: red;">display: inline-block</span> and <span style="color: red;">display: block</span>.

```
span.inline {
	display: inline;
	width: 100px;
	height: 100px;
	padding: 5px;
	border: 2px solid blue;
	background-color: yellow;
}
span.block {
	display: block;
	width: 100px;
	height: 100px;
	padding: 5px;
	border: 2px solid blue;
	background-color: yellow;
}
span.inline-block {
	display: inline-block;
	width: 100px;
	height: 100px;
	padding: 5px;
	border: 2px solid blue;
	background-color: yellow;
}
```

## 26.2 Using inline-block to Create Navigation Links

​	One common use for <span style="color: red;">display: inline-block</span> is to display list items horizontally instead of vertically. The following example creates horizontal navigation links:

```
.nav {
	background-color: yellow;
	list-style-type: none;
	text-align: center;
	padding: 0;
	margin: 0;
}
.nav li {
	display: inline-block;
	font-size: 20px;
	padding: 20px;
}
```



# 27. CSS Layout - Horizontal & Vertical Align

## 27.1 Center Align Elements

​	To horizontally center a block element (link \<div>), use <span style="color: red;">margin: auto;</span>

​	Setting the width of the element will prevent it from stretching out to the edges of its container.

​	The element will then take up the specified width, and the remaining space will be split equally between the two margins:

```
.center {
	margin: auto;
	width: 50%;
	border: 3px solid green;
	padding: 10px;
}
```

## 27.2 Center Align Text

​	To just center the text inside an element, use <span style="color: red;">text-align: center;</span>.

```
.center {
	text-align: center;
	border: 3px solid green;
}
```



## 27.3 Center an Image

​	To center an image, set left and right margin to <span style="color: red;">auto</span> and make it into a <span style="color: red;">block</span> element.

```
img {
	display: block;
	margin-left: auto;
	margin-right: auto;
	width: 40%;
}
```

## 27.4 Left and Right Align - Using position

​	One method for aligning elements is to use <span style="color: red;">position: absolute;</span>

## 27.5 Left and Right Align - Using float

```
.right {
  float: right;
  width: 300px;
  border: 3px solid #73AD21;
  padding: 10px;
}
```

## 27.6 The clearfix Hack

​	<b>Note: </b>If an element is taller than the element containing it, and it is floated, it will overflow of its container. You can use the 'clearfix hack' to fix this.

```
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}
```

## 27.7 Center Vertically - Using padding

​	There are many ways to center an element vertically in CSS. A simple solution is to use top and bottom padding:

```
.center {
	padding: 70px 0;
	border: 3px solid green;
	text-align: center;
}
```

## 27.8 Center Vertically - Using line-height

​	Another trick to use the <span style="color: red;">line-height</span> property with a value that is equal to the <span style="color: red;">height</span> property:

```
.center {
  line-height: 200px;
  height: 200px;
  border: 3px solid green;
  text-align: center;
}

/* If the text has multiple lines, add the following: */
.center p {
  line-height: 1.5;
  display: inline-block;
  vertical-align: middle;
}
```

## 27.9 Center Vertically - Using position & transform

​	If <span style="color: red;">padding</span> and <span style="color: red;">line-height</span> are not options, another solution is to use positioning and the <span style="color: red;">transform</span> property:

```
.center {
	height: 200px;
	position: relative;
	border: 3px solid green;
}
.center p {
	margin: 0;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
}
```

## 27.10 Center Vertically - Using Flexbox

​	You can also use flexbox to center things. Just note that flexbox is not supported in IE10 and earlier versions:

```
.center {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 200px;
	border: 3px solid green;
}
```



# 28. CSS Combinators

<b>A combinator is something that explains the relationship between the selectors.</b>

​	A CSS selector can contain more than one simple selector. Between the simple selectors, we can include a combinator.

​	There are four different combinators in CSS:

* descendant selector (space)
* child selector (>)
* adjacent sibling selector (+)
* general sibling selector (~)

## 28.1 Descendant Selector

​	The descendant selector matches all elements that are descendants of a specified element. The following example selects all \<p> elements <b>inside</b> \<div> elements:

```
div p {
	background-color: yellow;
}
```

## 28.2 Child Selector (>)

​	The child selects all elements that are the children of a specified element. The following example selects all \<p> elements that are <b>children</b> of a \<div> element:

```
div > p {	/*immediate child*/
	background-color: yellow;
}
```

## 28.3 Adjacent Sibling Selector (+)

​	The adjacent sibling selector is used to select an element that is directly after another specific element.

​	Sibling elements must have the same parent element, and "adjacent" means "immediately following". The following example selects the first \<p> element that are placed immediately after \<div> elements:

```
div + p {
	background-color: yellow;
}
```

## 28.4 General Sibling Selector (~)

​	The general sibling selector selects all elements that are next sibling of a specified element. The following example selects all \<p> elements that are next sibling of \<div> elements:

```
div ~ p {
	background-color: yellow;
}
```

| Selector            | Example | Example description                                          |
| ------------------- | ------- | ------------------------------------------------------------ |
| element element     | div p   | Selects all \<p> elements inside \<div> elements             |
| element > element   | div > p | Selects all \<p> elements where the parent is a \<div> element |
| element + element   | div + p | Selects the first \<p> element that are placed immediately after \<div> elements |
| element1 ~ element2 | p ~ ul  | Selects every \<ul> element that are preceded by a \<p> element |



# 29. CSS Pseudo - classed

## 29.1 What are Pseudo-classed?

​	A pseudo-class is used to define a special state of an element.

For example, it can be used to:

* Style an element when a user mouses over it
* Style visited and unvisited links differently
* Style an element when it gets focus

## 29.2 Syntax

​	The syntax of pseudo-classed:

```
selector:pseudo-class {
	property: value;
}
```

## 29.3 Anchor Pseudo-classes

​	Links can be displayed in different ways:

```
a:link {
	color: #FF0000;
}
a:visited {
	color: #00FF00;
}
a:hover {
	color: #FF00FF;
}
a:active {
	color: #0000FF;
}
```

<b>Note: </b><span style="color:red;">a:hover</span> MUST come after <span style="color:red;">a:link</span> and <span style="color:red;">a:visited</span> in the CSS definition in order to be effective! And <span style="color:red;">a:active</span> MUST come afteer <span style="color:red;">a:hover</span> in the CSS definition. Pseudo-class names are not case-sensitive.

## 29.4 Pseudo-classed and HTML Classes

​	Pseudo-classed can be combined with HTML classed:

When you hover over the link in the example, it will change color:

```
a.highlight:hover {
	color: #ff0000;
}
```

## 29.5 Hover on \<div>

​	An example of using the <span style="color:red;">:hover</span> pseudo-class on a \<div> element:

```
div:hover {
	background-color: blue;
}
```

## 29.6 Simple Tooltip Hover

​	Hover over a \<div> element to show a \<p> element (like a tooltip):

```
p.hover {
	display: none;
	background-color: yellow;
	padding: 20px;
}
div:hover p {
	display: block;
}

<div class="hover">
<p class="hover"><!-- Some code--></p>
</div>
```

## 29.7 CSS - The :first-child Pseudo-class

​	The <span style="color: red;">:first-child</span> pseudo-class matches a specified element that is the first child of another element.

## 29.8 Match the first \<p> element

​	In the following example, the selector matches any \<p> element that is the first child of any element:

```
p:first-child {
	color: blue;
}
```

## 29.9 Match the first \<i> element in all \<p> elements

​	In the following example, the selector matches the first \<i> element in all \<p> element:

```
p i:first-child {
	color: blue;
}
```

## 29.10 CSS - The :lang Pseudo-class

​	The <span style="color: red;">:lang</span> pseudo-class allows you to define special rules for different languages.

In the example below, <span style="color: red;">:lang</span> defines the quotation marks for \<q> elements with lang="no":

```
<!DOCTYPE html>
<html>
<head>
<style>
q:lang(no) {
	quotes: "~" "~";
}
</style>
</head>
<body>
<p>Some text <q lang="no">A quote in a paragraph is ~</q></p>
<p>In this example, :lang defines the quotation marks for q elements with lang="no":</p>
</body>
</html>
```

## 29.11 CSS - The :focus pseudo class

```
input.focus:focus {
	background-color: yellow;
}
```

## 29.12 All CSS Pseudo Classes

| Selector                                                     | Example               | Example description                                          |
| ------------------------------------------------------------ | --------------------- | ------------------------------------------------------------ |
| [:active](https://www.w3schools.com/cssref/sel_active.asp)   | a:active              | Selects the active link                                      |
| [:checked](https://www.w3schools.com/cssref/sel_checked.asp) | input:checked         | Selects every checked \<input> element                       |
| [:disabled](https://www.w3schools.com/cssref/sel_disabled.asp) | input:disabled        | Selects every disabled \<input> element                      |
| [:empty](https://www.w3schools.com/cssref/sel_empty.asp)     | p:empty               | Selects every \<p> element that has no children              |
| [:enabled](https://www.w3schools.com/cssref/sel_enabled.asp) | input:enabled         | Selects every enabled \<input> element                       |
| [:first-child](https://www.w3schools.com/cssref/sel_firstchild.asp) | p:first-child         | Selects every \<p> elements that is the first child of its parent |
| [:first-of-type](https://www.w3schools.com/cssref/sel_first-of-type.asp) | p:first-of-type       | Selects every \<p> element that is the first \<p> element of its parent |
| [:focus](https://www.w3schools.com/cssref/sel_focus.asp)     | input:focus           | Selects the \<input> element that has focus                  |
| [:hover](https://www.w3schools.com/cssref/sel_hover.asp)     | a:hover               | Selects links on mouse over                                  |
| [:in-range](https://www.w3schools.com/cssref/sel_in-range.asp) | input:in-range        | Selects \<input> elements with a value within a specified range |
| [:invalid](https://www.w3schools.com/cssref/sel_invalid.asp) | input:invalid         | Selects all \<input> elements with an invalid value          |
| [:lang(*language*)](https://www.w3schools.com/cssref/sel_lang.asp) | p:lang(it)            | Selects every \<p> element with a lang attribute value starting with "it" |
| [:last-child](https://www.w3schools.com/cssref/sel_last-child.asp) | p:last-child          | Selects every \<p> elements that is the last child of its parent |
| [:last-of-type](https://www.w3schools.com/cssref/sel_last-of-type.asp) | p:last-of-type        | Selects every \<p> element that is the last \<p> element of its parent |
| [:link](https://www.w3schools.com/cssref/sel_link.asp)       | a:link                | Selects all unvisited links                                  |
| [:not(selector)](https://www.w3schools.com/cssref/sel_not.asp) | :not(p)               | Selects every element that is not a \<p> element             |
| [:nth-child(n)](https://www.w3schools.com/cssref/sel_nth-child.asp) | p:nth-child(2)        | Selects every \<p> element that is the second child of its parent |
| [:nth-last-child(n)](https://www.w3schools.com/cssref/sel_nth-last-child.asp) | p:nth-last-child(2)   | Selects every \<p> element that is the second child of its parent, counting from the last child |
| [:nth-last-of-type(n)](https://www.w3schools.com/cssref/sel_nth-last-of-type.asp) | p:nth-last-of-type(2) | Selects every \<p> element that is the second \<p> element of its parent, counting from the last child |
| [:nth-of-type(n)](https://www.w3schools.com/cssref/sel_nth-of-type.asp) | p:nth-of-type(2)      | Selects every \<p> element that is the second \<p> element of its parent |
| [:only-of-type](https://www.w3schools.com/cssref/sel_only-of-type.asp) | p:only-of-type        | Selects every \<p> element that is the only \<p> element of its parent |
| [:only-child](https://www.w3schools.com/cssref/sel_only-child.asp) | p:only-child          | Selects every \<p> element that is the only child of its parent |
| [:optional](https://www.w3schools.com/cssref/sel_optional.asp) | input:optional        | Selects \<input> elements with no "required" attribute       |
| [:out-of-range](https://www.w3schools.com/cssref/sel_out-of-range.asp) | input:out-of-range    | Selects \<input> elements with a value outside a specified range |
| [:read-only](https://www.w3schools.com/cssref/sel_read-only.asp) | input:read-only       | Selects \<input> elements with a "readonly" attribute specified |
| [:read-write](https://www.w3schools.com/cssref/sel_read-write.asp) | input:read-write      | Selects \<input> elements with no "readonly" attribute       |
| [:required](https://www.w3schools.com/cssref/sel_required.asp) | input:required        | Selects \<input> elements with a "required" attribute specified |
| [:root](https://www.w3schools.com/cssref/sel_root.asp)       | root                  | Selects the document's root element                          |
| [:target](https://www.w3schools.com/cssref/sel_target.asp)   | #news:target          | Selects the current active #news element (clicked on a URL containing that anchor name) |
| [:valid](https://www.w3schools.com/cssref/sel_valid.asp)     | input:valid           | Selects all \<input> elements with a valid value             |

## 29.13 All CSS Pseudo Elements

| Selector                                                     | Example         | Example description                                          |
| ------------------------------------------------------------ | --------------- | ------------------------------------------------------------ |
| [::after](https://www.w3schools.com/cssref/sel_after.asp)    | p::after        | Insert content after every \<p> element                      |
| [::before](https://www.w3schools.com/cssref/sel_before.asp)  | p::before       | Insert content before every \<p> element                     |
| [::first-letter](https://www.w3schools.com/cssref/sel_firstletter.asp) | p::first-letter | Selects the first letter of every \<p> element               |
| [::first-line](https://www.w3schools.com/cssref/sel_firstline.asp) | p::first-line   | Selects the first line of every \<p> element                 |
| [::marker](https://www.w3schools.com/cssref/sel_marker.asp)  | ::marker        | Selects the markers of list items                            |
| [::selection](https://www.w3schools.com/cssref/sel_selection.asp) | p::selection    | Selects the portion of an element that is selected by a user |



# 30. CSS Pseudo-elements

## 30.1 What are Pseudo-Elemnts

​	A CSS pseudo-element is used to style specified parts of an element.

For example, it can be used to:

* Style the first letter, or line, of an element
* Insert content before, or after, the content of an element

## 30.2 Syntax

​	The syntax of psudo-elements:

```
selector::pseudo-element {
	property: value;
}
```

## 30.3 The ::first-line Pseudo-element

​	The <span style="color: red;">::first-line</span> pseudo-element is used to add a specified style to the first line of a text.

The following example formats the first line of the text in all \<p> elements:

```
p.first-line::first-line {
	color: #ff0044;
	font-variant: small-caps;
}
```

<b>Note:</b> The <span style="color: red;">::first-line</span> pseudo-element can only be applied to block-level elements.

The following properties apply to the <span style="color: red;">::first-line</span> pseudo-element:

* font properties
* color properties
* background properties
* word-spacing
* letter-spacing
* text-decoration
* vertical-align
* text-transform
* line-height
* clear

<b>Note:</b> The double colon notation <span style="color: red;">::first-lne</span> versus <span style="color: red;">:first-line</span>

​	The double colon replaced the single-colon notation for pseudo-elements in CSS3. This was an attempt from W3C to distinguish between pseudo-classes and pseudo-elements.

This single-colon syntax was used for both pseudo-classed and pseudo-elements in CSS2 and CSS1. For backward compatibility, the single-colon syntax is acceptable for CSS2 and CSS1 pseudo-elements.

## 30.4 The ::first-letter Pseudo-element

​	Used to add a special style to the first letter, like ::first-line, applied to block-level elements.

```
p::first-letter {
  color: #ff0000;
  font-size: xx-large;
}
```

## 30.5 Pseudo-elements and HTML Classes

​	Pseudo-elements can be combined with HTML classes:

```
p.intro::first-letter {
	color: #ff0044;
	font-size: 200%;
}
```

## 30.6 Multiple Pseudo-elements

​	Several pseudo-elements can also be combined.

In the following example, the first letter of a paragraph will be red, in an xx-large font-size The rest of the first line will blue, and in small-caps. The rest of the paragraph will be the default font size and color:

```
p::first-letter {
	color: #ff0000;
	font-size: xx-large;
}
p::first-line {
	color: #0000ff;
	font-variant: small-caps;
}
```

## 30.7 CSS - The ::before Pseudo-element

​	The <span style="color: red;">::before</span> pseudo-element can be used to insert some content before the content of an element.

The following example inserts an image before the content of each \<h1> element:

```
h1::before {
	content: url("img/image1.jpg");
}
```

## 30.8 CSS - The ::after Pseudo-element

​	Similar to ::before (But test failed).

## 30.9 CSS - The ::marker Pseudo-element

​	The <span style="color: red;">::marker</span> pseudo-element selects the markers of list items.

The following example styles the marker of list items:

```
::marker {
	color: red;
	font-size: 23px;
}
```

## 30.10 CSS - The ::selection Pseudo-element

​	The <span style="color: red;">::selection</span> pseudo-element matches the portion of an element that is selected by a user. The following CSS properties can be applied to <span style="color: red;">::selection</span>: color, background, cursor and outline.

The following example makes the selected text red on a yellow background:

```
::selector {	/*Can assign a selector...*/
	color: red;
	background: yellow;
}
```



# 31. CSS Opacity / Transparency

​	The <span style="color: red;">opacity</span> property specifies the opacity/transparency of an element.

## 31.1 Transparent Image 

​	The <span style="color: red;">opacity</span> property can takes a value from 0.0 - 1.0. The lower the value, the more transparent.

```
img.opacity {
	opacity: 0.5;
}
```

## 31.2 Transparent Hover Effect

​	The <span style="color: red;">opacity</span> property is often used together with the <span style="color: red;">:hover</span> selector to change the opacity on mouse-over:

```
img.opacity {
	opacity: 0.5;
}
img.opacity:hover {
	opacity: 1.0;
}
```

## 31.3 Transparent Box

​	When using the <span style="color: red;">opacity</span> property to add transparency to the background of an element, all of its child element inherit the same. This can make the text inside a fully transparent element hard to read.

## 31.4 Transparency using RGBA

​	If you do not want to apply opacity to child elements, like explained above, use <b>RGBA</b> color values. The following examples sets the opacity for the background color and not the text.

```
div.opacity {
	background: rgba(76, 175, 80, 0.3);
}
```

## 31.5 Text in Transparent Box

```
<html>
<head>
<style>
div.background {
  background: url(klematis.jpg) repeat;
  border: 2px solid black;
}

div.transbox {
  margin: 30px;
  background-color: #ffffff;
  border: 1px solid black;
  opacity: 0.6;
}

div.transbox p {
  margin: 5%;
  font-weight: bold;
  color: #000000;
}
</style>
</head>
<body>

<div class="background">
  <div class="transbox">
    <p>This is some text that is placed in the transparent box.</p>
  </div>
</div>

</body>
</html>
```



# 32.CSS Navigation Bar

## 32.1 Navbar

### 32.1.1 Navigation Bars

​	Having easy-to-use navigation is important for any web site.

​	With CSS you can transform boring HTML menus into good-looking navigation bars.

### 32.1.2 Navigation Bar = List of Links

​	A navigation bar needs standard HTML as a base. In our examples we will build the navigation bar from a standard HTML list. A navigation bar is basically a list of links, so using the \<ul> and \<li> elements makes perfect sense:

```
<ul>
	<li><a href="#home">Home</a></li>
	<li><a href="#news">News</a></li>
	<li><a href="#contact">Contact</a></li>
	<li><a href="#about">About</a></li>
</ul>
```

​	Now let's remove the bullets and the margins and padding from the list:

```
ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
}
```

## 32.2 Vertical Navbar

### 32.2.1 Vertical Navigation Bar

​	To build a vertical navigation var, you can style the \<a> elements inside the list, in addition to the code from the previous page:

```
li a {
	display: block;
	width: 60px;
}
```

Example explained:

* <span style="color: red;">display: block;</span> - Displaying the links as block elements makes the whole link area clickable (not just the next)! And it allows us to specify the width (and padding, margin, height, etc. if you want)
* <span style="color: red;">width: 60px;</span> - Block elements take up the full width available by default. We want to specify a 60 pixels width.

​	You can also set the width of \<ul>, and remove the width of \<a>, as they will take up the full width available when displayed as block elements. This will produce the same result as our previous example:

```
ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
	width: 60px;
}
li a {
	display: block;
}
li a:hover {
	background-color: #555;
	color: white;
}
```

### 32.2.2 Active/Current Navigation Link

​	Add an "active" class to the current link to let the user know which page he/she is on:

```
a.active {
	background-color: #04AA6D;
	color: white;
}
```

### 32.2.3 Center Links & Add Borders

​	Add <span style="color: red;">text-align: center;</span> to \<li> or \<a> to center the links.

​	Add the <span style="color: red;">border</span> property to \<ul> add a border around the navbar. If you also want borders inside the navbar, add a <span style="color: red;">border-bootom</span> to all \<li> elements, except for the last one:

```
ul.navbar {
	list-style-type: none;
	margin: 0;
	padding: 0;
	width: 200px;
	background-color: #f1f1f1;
	border: 1px solid #555;
}
li.navbar {
	margin: 0;
	padding: 0;
	text-align: center;
	border-bottom: 1px solid #555;
}
li.navbar a {
	display: block;
	color: #000;
	padding: 8px 16px;
	text-decoration: none;
}
li.navbar:last-child {
	border-bottom: none;
}
li.navbar a.active {
	background-color: #04AA6D;
	color: white;
}
li.navbar a:hover:not(.active) {
	background-color: #555;
	color: white;
}
```

```
<ul class="navbar">
	<li class="navbar"><a class="active" href="#home">Home</a></li>
	<li class="navbar"><a href="#news">News</a></li>
	<li class="navbar"><a href="#contact">Contact</a></li>
	<li class="navbar"><a href="#about">About</a></li>
</ul>
```

### 32.2.4 Full-height Fixed Vertical Navbar

​	Create a full-height, "sticky" side navigation (left side is navigation, right side is paragraph):

```
ul.side {
	list-style-type: none;
	margin: 0;
	padding: 0;
	width: 25%;
	background-color: #f1f1f1;
	position: absolute;	/*Can't be fixed!! You should add 'top' property to solve this*/
	height: 100%;
	overflow: auto;
}
li.side a {
	display: block;
	color: #000;
	padding: 8px 16px;
	text-decoration: none;
}
li.side a.active {
	background-color: #04AA6D;
	color: white;
}
li.side a:hover:not(.active) {
	background-color: #555;
	color:white;
}
```

## 32.3 Horizontal Navbar

### 32.3.1 Horizontal Navigation Bar

​	There are two ways to create a horizontal navigation bar. Using <b>inline</b> or <b>floating</b> list items.

	1. Inline List Items

​	One way to build a horizontal navigation bar is to specify the \<li> elements as inline, in addition to the "standard" code from the previous page:

```
li.horizon {
	display: inline;
}
```

	2. Floating List Items

​	Another way of creating a horizontal navigation bar is to float the \<li> elements, and specify a layout for the navigation links.

```
ul.float-nav {
	list-style-type: none;
	margin: 0;
	padding: 0;
	overflow: hidden;
}
li.float-nav {
	float: left;
}
li.float-nav a {
	display: block;
	padding: 8px;
	background-color: #dddddd;
}
```

Example explained:

* float: left; - Use float to set block elements to float next to each other
* display: block; - Allows us to specify padding (and height, width, margins, etc. if you want)
* padding: 8px; - Specify some padding between each \<a> element, to make them look good
* background-color: #ffffff; - Add a gray background-color to each \<a> element

### 32.3.2 Horizontal Navigation Bar Examples

1. Active/Current Navigation Link

​		Add an "active" class to the current link to let the user know which page he/she is on:

```
.active {
	background-color: #04AA6D;	/*refer vertical bar example*/
}
```

2. Right-Align Links

​		Right-align links by floating the list items to the right (float: right; ):

```
<ul>
	<li><a href="">link1</a></li>
	<li><a href="">link2</a></li>
	<li><a href="">link3</a></li>
	<li style="float: right;"><a href="">link-right</a></li>
</ul>
```

3. Border Dividers

​		Add the <span style="color: red;">border-right</span> property to \<li> to create link dividers:

```
li {
	border-right: 1px solid #bbb;
}
li:last-child {
	border-right: none;
}
```

4. Fixed Navigation Bar

​		Make the navigation bar stay at the top or bottom of the page, even when the user scroll the page:

```
ul {
	position: fixed;
	top: 0;
	width: 100%;
}
```

5. Gray Horizontal Navbar

​		An example of a gray horizontal navigation bar with a thin gray border:

```
ul {
	border: 1px solid #e7e7e7;
	background-color: #f3f3f3;;
}
li a {
	color: #666;
}
```

6. Sticky Navbar

​		Add <span style="color: red;">position: sticky;</span> to \<ul> to create a sticky navbar.

​		A sticky element toggles between relative and fixed, depending on the scroll position. It is positioned relative until a given offset position is met in the viewport - then it "sticks" in place (like position: fixed).

```
ul {
	position: -webkit-sticky;	/*Safari*/
	position: sticky;
	top: 0;
}
```



# 33. CSS Dropdowns

## 33.1 Basic Dropdown

​	Create a dropdown box that appears when the user moves the mouse over an element.

```
div.dropdown {
	position: relative;
	display: inline-block;
}
.dropdown-content {
	display: none;
	position: absolute;
	background-color: #f9f9f9;
	min-width: 16px;
	box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
	padding: 12px 16px;
	z-index: 1;
}
.dropdown:hover .dropdown-content {
	display: block;
}

<!-- HTML -->
<div class="dropdown">
	<sapn>Mouse over me</span>
	<div class="dropdown-content">
		<p>Dropdown content</p>
	</div>
</div>
```

<span style="font-size: 19px;"> Example Explained</span>

<b>HTML)</b> Use any element to open the dropdown content, e.g. a \<span>, or a \<button> element.

​	Use a container element (like \<div>) to create the dropdown content and add whatever you want inside of it.

Wrap a \<div> element around the elements to position the dropdown content correctly with CSS.

<b>CSS)</b> The <span style="color: red;">.dropdown</span> class uses <span style="color: red;">position: relative;</span>, which is needed when we want the dropdown content to be placed right below the dropdown button (using <span style="color: red;">position: absolute</span>).

​	The <span style="color: red;">.dropdown-content</span> class holds the actual dropdown content. It is hidden by default, and will be displayed on hover (see below). Note the <span style="color: red;">min-width</span> is set to 160px. Feel free to change this. <b>Tip:</b> If you want the width of the dropdown content to be as wide as the dropdown button, set the <span style="color: red;">width</span> to 100% (and <span style="color: red;">overflow: auto;</span> to enable scroll on small screens).

​	Instead of using a border, we have used the CSS <span style="color: red;">box-shadow</span> property to make the dropdown menu look like a "card".

## 33.2 Dropdown Menu

```
.dropbtn {
	background-color: #4CAF50;
	color: white;
	padding: 16px;
	border: none;
	cursor: pointer;
	font-size: 16px;
}
.dropdown2 {
	position: relative;
	display: inline-block;
}
.dropdown-content2 {
	display: none;
	position: absolute;
	background-color: #f9f9f9;
	min-width: 160px;
	box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
	z-index: 1;
}
.dropdown-content2 a {
	color: black;
	padding: 12px 16px;
	text-decoration: none;
	display: block;
}
.dropdown-content2 a:hover {
	background-color: #f1f1f1;	
}
.dropdown2:hover .dropdown-content2 {
	display: block;
}
.dropdown2:hover .dropbtn {
	background-color: #3e8e41;
}
<!-- HTML -->
<div class="dropdown2">
	<button class="dropbtn">Dropdown</button>
	<div class="dropdown-content2">
		<a href="#">Link 1</a>
		<a href="#">Link 2</a>
		<a href="#">Link 3</a>
	</div>
</div>
```

## 33.3 Right-aligned Dropdown Content

​	If you want the dropdown menu to go from right to left, instead of left to right, add <span style="color: red;">right: 0;</span>:

```
.dropdown-content {
	right: 0;
}
```

## 33.4 Dropdown Navbar

```
/*navbar & dropdown*/
ul.dropdown-navbar {
	list-style-type: none;
	margin: 0;
	padding: 0;
	overflow: hidden;
	background-color: #333;
}
li.dropdown-navbar {
	float: left;
}
li.dropdown-navbar a,  .dropbtn3 {
	display: inline-block;
	color: white;
	text-align: center;
	padding: 14px 16px;
	text-decoration: none;
}
li.dropdown-navbar a:hover, .dropdown3:hover .dropbtn3 {
	background-color: red;
}
li.dropdown3 {
	display: inline-block;
}
.dropdown-content3 {
	display: none;
	position: absolute;
	background-color: #f9f9f9;
	min-width: 160px;
	box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
	z-index: 1;
}
.dropdown-content3 a {
	color: black;
	padding: 12px 16px;
	text-decoration: none;
	display: block;
	text-align: left;
}
.dropdown-content3 a:hover {
	background-color: #f1f1f1;
}
.dropdown3:hover .dropdown-content3 {
	display: block;
}
<!-- HTML -->
<ul class="dropdown-navbar">
	<li class="dropdown-navbar"><a href="#home">Home</a></li>
	<li class="dropdown-navbar"><a href="#news">News</a></li>
	<li class="dropdown3">
		<a href="javascript:void(0)" class="dropbtn3">Dropdown</a>
		<div class="dropdown-content3">
			<a href="#">Link 1</a>
			<a href="#">Link 2</a>
		</div>
	</li>
</ul>
```



# 34. CSS Image Gallery

## 34.1 Image Gallery

```
div.gallery {
	margin: 5px;
	border: 1px solid #ccc;
	float: left;
	width: 180px;
}
div.gallery:hover {
	border: 1px solid #777;
}
div.gallery img {
	width: 100%;
	height: auto;
}
div.desc {
	padding: 15px;
	text-align: center;
}
<!-- HTML -->
<div class="gallery">
	<a target="_blank" href="img/gallery1.jpg">
		<img src="img/gallery1.jpg" alt="gallery1" width="600" height="400">
	</a>
	<div class="desc">Add a description of the image here.</div>
</div>
<div class="gallery">
	<a target="_blank" href="img/gallery2.jpg">
		<img src="img/gallery2.jpg" alt="gallery1" width="600" height="400">
	</a>
	<div class="desc">Add a description of the image here.</div>
</div>
<div class="gallery">
	<a target="_blank" href="img/gallery3.jpg">
		<img src="img/gallery3.jpg" alt="gallery1" width="600" height="400">
	</a>
	<div class="desc">Add a description of the image here.</div>
</div>
<div class="gallery">
	<a target="_blank" href="img/gallery4.jpg">
		<img src="img/gallery4.jpg" alt="gallery1" width="600" height="400">
	</a>
	<div class="desc">Add a description of the image here.</div>
</div>
```



# 35. CSS Image Sprites

## 35.1 Image Sprites

​	An image sprite is a collection of images put into a single image.

​	A web page with many images can take a long time to load and generates multiple server requests.

​	Using image sprites will reduce the number of server requests and save bandwidth.

## 35.2 Image Sprites - Simple Example

​	Instead of using three separate images, we use this single image ("img_navsprites.gif"):

<img src="img/img_navsprites.gif" style="align: left;"> 

​	With CSS, we can show just the part of the image we need.

​	In the following example the CSS specifies which part of the "img_navsprirtes.gif" image to show:

```
#home {
	width: 46px;
	height: 44px;
	background: url("../img/img_navsprites.gif") 0 0 ;
}
#next {
	width: 43px;
	height: 44px;
	background: url(../img/img_navsprites.gif) -91px 0;
}
<!-- HTML -->
<div style="clear: left;"><div>	<!-- Not to warp around (in right side) -->
<h3>CSS sprites:</h3>
<img id="home" src="img_trans.gif" width="1" height="1">
<img id="next" src="img_trans.gif" width="1" height="1">
```

<b>Example expalined:</b>

* <span style="color: red;">\<img id="home" src="img_trans.gif"></span> - Only defines a small transparent image because the src attribute cannot be empty. The displayed image will be the background image we specify in CSS.
* <span style="color: red;">width: 46px; height: 44px;</span> - Defines the portion of the image we want to use
* <span style="color: red;">background: url(img_navsprites.gif) 0 0;</span> - Defines the background image and its position (left 0px, top 0px)

​	This is the easiest way to use image sprites, now we want to expand it by using links and hover effects.

## 35.3 Image Sprites - Create a Navigation List

​	We want to use the sprite image to create a navigation list.

​	We will use an HTML list, because it can be a link and also supports a background image:

```
#navlist2 {
	position: relative;
}
#navlist2 li {
	margin: 0;
	padding: 0;
	list-style: none;
	position: absolute;
	top: 0;
}
#navlist2 li, #navlist2 a {
	height: 44px;
	display: block;
}
#home2 {
	left: 0px;
	width: 45px;
	background: url('../img/img_navsprites.gif') 0 0;
}
#prev2 {
	left: 63px;
	width: 43px;
	background: url('../img/img_navsprites.gif') -47px 0;
}
#next2 {
	left: 129px;
	width: 43px;
	background: url('../img/img_navsprites.gif') -91px 0;
}
<!-- HTML -->
<ul id="navlist2">
	<li id="home2"<a href="default.asp"></a></li>
	<li id="prev2"><a href="css_intro.asp"></a></li>
	<li id="next2"><a href="css_syntax.asp"></a></li>
</ul>
```

<b>Example explained:</b>

* #navlist2 {position: relative;} - position is set to relative to allow absolute positioning inside it
* #navlist2 li {margin: 0; padding: 0; lsit-style: none; position: absolute; top:0;} - margin and padding are set to 0, list-style is removed, and all list items are absolute positioned
* #navlist2 li, #navlist2 a {height: 44px; display: block;} - the height of all the images is 44px

Now start to position and style for each specific part:

* #home {left: 0px; width: 46px;} - Positioned all the way to the left, and width of the image is 46px
* #home {background: url(img_navspriteds.gif) 0 0;} - Defines the background image and its position (left 0px, top 0px) ...

## 35.4 Image Sprites - Hover Effect

```
#navlist3 { position: relative; }
#navlist3 li { margin: 0; padding: 0; list-style: none; position: absolute; top:0;}
#navlist3 li, #navlist3 a { height: 44px; display: block;}
#home3 { left: 0px; width: 46px; background: url('../img/img_navsprites_hover.gif') 0 0;}
#prev3 { left: 63px; width: 43px; background: url('../img/img_navsprites_hover.gif') -47px 0;}
#next3 { left: 129px; width: 43px; background: url('../img/img_navsprites_hover.gif') -91px 0;}
#home3 a:hover { background: url('../img/img_navsprites_hover.gif') 0 -45px;}
#prev3 a:hover { background: url('../img/img_navsprites_hover.gif') -47px -45px;}
#next3 a:hover { background: url('../img/img_navsprites_hover.gif') -91px -45px;}
<!-- HTML -->
<ul id="navlist3">
	<li id="home3"><a href="default.asp"></a></li>
	<li id="prev3"><a href="css_intro.asp"></a></li>
	<li id="next3"><a href="css_syntax.asp"></a></li>
</ul>
```



# 36. CSS Attr Selectors

## 36.1 Style HTML Elements With Specific Attributes

​	It is possible to style HTML elements that have specific attributes or attribute values.

## 36.2 CSS [attribute] Selector

​	The <span style="color: red;">[attribute]</span> selector is used to select elements with a specified attribute.

​	The following example selects all \<a> elements with a target attribute:

```
a[target] {
	background-color: yellow;
}
<!-- HTML -->
<a herf="default.html" target="_blank"></a>
```

## 36.3 CSS [attribute="value"] Selector

​	The <span style="color: red;">[attribute="value"]</span> selector is used to select elements with a specified attribute and value. The following example selects all \<a> elements with a target="_blank" attribute (above example):

```
a[target="_blank"] {
	background-color: yellow;
}
```

## 36.4 CSS [attribute~="value"] Selector

​	The <span style="color: red;">[attribuet~="value"]</span> selector is used to select elements with an attribute value containing a specified word. The following example selects all elements with a title attribute that contains a space-separated list of words, one of which is "flower":

```
[title~="flower"] {
	border: 5px solid yellow;
}
```

​	The above example will match elements with title="flower", title="summer flower", and title="flower new", but <b>not</b> title="my-flower" or title="flowers".

## 36.5 CSS [attribute|="value"] Selector

​	The <span style="color: red;">[attribute|="value"]</span> selector is used to select elements with the specified attribute, whose value can be exactly the specified value, or the specified value followed by a hyphen (-).

​	<b>Note: </b>The value has to be a whole word, either alone, like class="top", or followed by a hyphen (-), like class="top-text".

```
[class|="top"] {
	background: yellow;
}
```

## 36.6 CSS [attribute^="value"] Selector 

​	The <span style="color: red;">[attribute^="value"]</span> selector is used to select elements with the specified attribute, whose value starts with the specified value. The following example selects all elements with a class attribute value that starts with "top":

```
[class=^="top"] {
	background: yellow;
}
```

## 36.7 CSS [attribute$="value"] Selector

​	The <span style="color: red;">[attribute$="value"]</span> selector is used to select elements whose attribute value ends with a specified.

## 36.8 CSS [attribute*="value"] Selector

​	The <span style="color: red;">[attribute=*="value"]</span> selector is used to select elements whose attribute value contains a specified value.

## 36.9 Styling Forms

​	The attribute selectors can be useful for styling forms without class or ID:

```
input[type="text"] {
	width: 150px;
	display: block;
	margin-bottom: 10px;
	background-color: yellow;
}
```

<b>Example:</b>

```
input.attr-selector[type="text"] {
	background-color: yellow;
}
<!-- HTML -->
<!-- Avoid overlap with CSS sprites -->
<div style="position: relative; margin-top: 120px;"></div>
<h3>CSS Attr Selectors:</h3>
<form name="input" action="" method="get">
	Firstname:<input class="attr-selector" type="text" name="Name" value="Peter" size="20">
	<input type="button" value="Example btn">
</form>

```



# 37. CSS Forms

## 37.1 Styling Input Fields

​	Use the <span style="color: red;">width</span> property to determine the width of the input field:

```
input {
	width: 50%;
}
```

## 37.2 Padded Inputs

​	Use the <span style="color: red;">padding </span>property to add space inside the text field.

<b>Tip:</b> When you have many inputs after each other, you might also want to add some <span style="color: red;">margin</span>, to add more space outside of them.

```
input[type=text] {
	width: 50%;
	padding: 12px 20px;
	margin: 9px 0;
	box-sizing: border-box;
}
```

<b>Note:</b> We have set the <span style="color: red;">box-sizing</span> property to <span style="color: red;">border-box</span>. This makes sure that the padding and eventually borders are included in the total width and height of the elements. Read more about the <span style="color: red;">box-sizing</span> property in CSS Box Sizing chapter.

## 37.3 Bordered Inputs

​	Use the <span style="color: red;">border</span> property to change the border size and color, and use the <span style="color: red;">border-radius</span> property to add rounded corners.

## 37.4 Colored Inputs

​	Use the <span style="color: red;">background-color</span> property to add a background color to the input, and the <span style="color: red;">color</span> property to change the text color.

## 37.5 Focused Inputs

​	By default, some browsers will add a blue outline around the input when it gets focus (clicked on), You can remove this behavior by adding <span style="color: red;">outline: none;</span> to the input. Use the <span style="color: red;">:focus</span> selector to do something with the input field when it gets focus.

## 37.6 Input with icon/image

​	If you want an icon inside the input, use the <span style="color: red;">background-image</span> property and position it with the <span style="color: red;">background-position</span> property. Also notice that we add a large left padding to reserve the space of the icon:

```
input.icon[type=text] {
	width: 50%;
	box-sizing: border-box;
	border: 2px solid #ccc;
	border-radius: 4px;
	font-size: 16px;
	background-color: white;
	background-image: url('../img/searchicon.png');
	background-position: 5px 5px;
	background-repeat: no-repeat;
	background-size: 40px 40px;
	padding: 12px 20px 12px 40px;
}
<!-- HTML -->
<form>
	<input class="icon" type="text" name="search" placeholder="Search...">
</form>
```

## 37.7 Animated Search Input

​	In this example we use the CSS <span style="color: red;">transition</span> property to animate the width of the search input when it gets focus. You will learn more about the <span style="color: red;">transition</span> property later.

```
input.searchAnimate[type="text"] {
	width: 230px;
	box-sizing: border-box;
	border: 2px solid #ccc;
	border-radius: 4px;
	font-size: 16px;
	background-color: white;
	background-image: url('../img/searchicon.png');
	background-position: 10xp 10px;
	background-repeat: no-repeat;
	padding: 12px 20px 12px 40px;
	transition: width 0.4s ease-in-out;
}
input.searchAnimate[type="text"]:focus {
	width: 100%;
}
<!-- HTML -->
<form>
	<input class="searchAnimate" type="text" name="search" placeholder="Search...">
</form>
```

## 37.8 Styling Textareas

<b>Tip:</b> Use the <span style="color: red;">resize</span> property to prevent textareas from being resized (disable the "grabber" in the bottom right corner):

```
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}
```

## 37.9 Styling Select Menus

```
#country2 {
  width: 100%;
  padding: 16px 20px;
  border: none;
  border-radius: 4px;
  background-color: #f1f1f1;
}
<!-- HTML -->
<form>
	<select id="country2" name="country">
		<option value="au">Australiz</option>
		<option value="ca">Canada</option>
		<option value="usa">USA</option>
	</select>
</form>
```

## 37.10 Styling Input Buttons

```
input[type=button], input[type=submit], input[type=reset] {
  background-color: #04AA6D;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
}
```

## 37.11 Responsive Form

​	Resize the browser window to see the effect. When the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other:

<b>Advanced:</b> The following example uses media queries to create a responsive form. You will learn more about this in a later chapter.

```
input.responsiveForm[type="text"], #country3, #subject {
	width: 100%;
	padding: 12px;
	border: 1px solid #ccc;
	border-radius: 4px;
	resize: vertical;		/*Can only resize vertically*/
}
label.responsiveForm {
	padding: 12px 12px 12px 0;
	display: inline-block;
}
input.responsiveForm[type="submit"] {
	background-color: #04AA6D;
	color: white;
	padding: 12px 20px;
	border: none;
	border-radius: 4px;
	cursor: pointer;
	float: right;
}
input.responsiveForm[type="submit"]:hover {
	background-color: #45a049;
}
.container2 {
	border-radius: 5px;
	background-color: #f2f2f2;
	padding: 20px;
}
.col-25 {
	float: left;
	width: 25%;
	margin-top: 6px;
}
.col-75 {
	float: left;
	width: 75%;	
	margin-top: 6px;
}
.row2::after {
	content: "";
	display: table;
	clear: both;
}
@media screen and (max-width: 600px) {
	.col-25, .col-75, input.responsiveForm[type="submit"] {
		width: 100%;
		margin-top: 0;
	}
}
<!-- HTML -->
<h4>Responsive Form</h4>
<div class="container2">
	<form action="/action_page.php">
		<div class="row2">
			<div class="col-25">
				<label class="responsiveForm" for="fname2">First Name</label>
			</div>
			<div class="col-75">
				<input class="responsiveForm" type="text" id="fname2" name="firstname" placeholder="Your name...">
			</div>
		</div>
		<div class="row2">
			<div class="col-25">
				<label class="responsiveForm" for="country3">Country</label>
			</div>
			<div class="col-75">
				<select id="country3" name="country3">
					<option value="australia">Australia</option>
					<option value="canada">Canada</option>
				</select>
			</div>
		</div>
		<div class="row2">
			<div class="col-25">
				<label class="responsiveForm" for="subject">Subject</label>
			</div>
			<div class="col-75">
				<textarea id="subject" name="subject" placeholder="Write somethind..." style="height: 200px"></textarea>
			</div>
		</div>
		<br>
		<div class="row2">
			<input class=responsiveForm" type="submit" value="Submit">
		</div>
	<form>
</div>
```



# 38. CSS Counters

​	CSS counters are "variables" maintained by CSS whose values can be incremented by CSS rules (to track how many times they are used). Counters let you adjust the appearance of content based on its placement in the document.

## 38.1 Automatic Numbering With Counters

​	CSS counters are like "variables". The variable values can be incremented by CSS rules (which will track how many times they are used).

​	To work with CSS counters we will use the following properties:

* <span style="color: red;">counter-reset</span> - Creates or resets a counter
* <span style="color: red;">counter-increment</span> - Increments a counter value
* <span style="color: red;">content</span> - Inserts generated content
* <span style="color: red;">counter()</span> or <span style="color: red;">counters()</span> function - Adds the value of a counter to an element

​	To use a CSS counter, it must first be created with <span style="color: red;">counter-reset</span>.

​	The following example creates a counter for the page (in the body selector), then increments the counter value for each \<h2> element and adds "Section \<value of the counter>:" to the beginning of each \<h2> element:

```
body {
	counter-reset: section;
}
h2.counter:before {
	counter-increment: section;
	content: "Section" counter(section) ": ";
}
<!-- HTML -->
<h3>CSS counter:<h3>
<h2 class="counter">HTML Tutorial</h2>
<h2 class="counter">CSS Tutorial</h2>
<h2 class="counter">JavaScripte Tutorial</h2>
<h2 class="counter">Python Tutorial</h2>
```

## 38.2 Nesting Counters

​	The following example creates one counter for the page (section) and one counter for each \<h1> element (subsection). The "section" counter will be counted for each \<h1> element with "Section \<value of the section counter>", and the "subsection" counter will be counted for each \<h2> element with "\<value of the section counter>.\<value of the subsection counter>":

```
body {
	counter-reset: section2;
}
h1.counter2 {
	counter-reset: subsection;
}
h1.counter2::before {
	counter-increment: section2;
	content: "Section " counter(section2) ". ";
}
h2.counter2::before {
	counter-increment: subsection;
	content: counter(section2) "." counter(subsection) " ";
}
<!-- HTML -->
<h1 class="counter2">HTML/CSS Tutorials</h1>
<h2 class="counter2">HTML Tutorial</h2>
<h2 class="counter2">CSS Tutorial</h2>
<h2 class="counter2">Bootstrap Tutorial</h2>
<h2 class="counter2">W3.CSS Tutorial</h2>
<h1 class="counter2">Scripting Tutorials</h1>
<h2 class="counter2">jQuery Tutorial</h2>
<h2 class="counter2">React Tutorial</h2>
<h2 class="counter2">JavaScript Tutorial</h2>
```

​	A counter can also be useful to make outlines lists because a new instance of a counter is automatically created in child elements. Here we use the <span style="color: red;">counters()</span> function to insert a string between different levels of nested counters:

```
ol.counter-ol {
	counter-reset: section;
	list-style-type: none;
}
li.counter-li::before {
	counter-increment: section;
	content: counters(section, ".") " ";
}
<!-- HTML -->
<ol class="counter-ol">
	<li class="counter-li">Item1</li>
	<li class="counter-li">Item2
	<ol class="counter-ol">
		<li class="counter-li">Item2.1</li>
		<li class="counter-li">Item2.2</li>
		<li class="counter-li">Item2.3
		<ol class="counter-ol">
			<li class="counter-li">Item2.3.1</li>
			<li class="counter-li">Item2.3.2</li>
			<li class="counter-li">Item2.3.3</li>
		</ol>
		</li>
		<li class="counter-li">Item2.4</li>
	</ol>
	</li>
	<li class="counter-li">Item3</li>
</ol>
<ol class="counter-ol">
	<li class="counter-li">Item1</li>
	<li class="counter-li">Item2</li>
</ol>
```



# 39. CSS Website Layout

## 39.1 Website Layout

​	A website is often divided into headers, menus, content and a footer:

<img src="/img/website.jpg" height="300px"> 

​	There are tons of different layout designs to choose from. However, the structure above, is one of the most common, and we will take a closer look at it in this tutorial.

## 39.2 Header

​	A header is usually located at the top of the website (or right below a top navigation menu). It often contains a logo or the website name:

```
.header {
	background-color: #F1F1F1;
	text-align: center;
	padding: 20px;
}
<!-- HTML -->
<div class="header">
	<h1>Header</h1>
</div>
```

## 39.3 Navigation Bar

​	A navigation bar contains a list of links to help visitors navigating through your website:

```
* {
  box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
  background-color: #f1f1f1;
  padding: 20px;
  text-align: center;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #333;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}
```

## 39.4 Content

​	The layout in this section, often depends on the target users. The most common layout is one (or combining them) of the following:

* <b>1-column </b>(often used for mobile browsers)
* <b>2-column</b> (often used for tablets and laptops)
* <b>3-column layout</b> (only used for desktops)

​	We will create a 2-column layout, and change it to a 1-column layout on smaller screens:

```
* {
	box-sizing: border-box;
}
body {
	margin: 0;
}
.header3 {
	background-color: #f1f1f1;
	padding: 20px;
	text-align: center;
}
.topnav3 {
	overflow: hidden;
	background-color: #333;
}
.topnav3 a {
	float: left;
	display: block;
	color: #f2f2f2;
	text-align: center;
	padding: 14px 16px;
	text-decoration: none;
}
.topnav3 a:hover {
	background-color: #ddd;
	color: black;
}
.column3 {
	float: left;
	width: 33.33%;
	padding: 15px;
}
.row3::after {
	content: "";
	display: table;
	clear: both;
}
@media screen and (max-width: 600px) {
	.column3 {
		width: 100%;
	}
}
<!-- HTML -->
<h3>CSS Website Layout:</h3>
<div class="header3">
	<h1>Header</h1>
	<p>Resize the browser window to see the responsive effect.</p>
</div>
<div class="topnav3">
	<a href="#">Year: 2023</a>
	<a href="#">Month: 4</a>
	<a href="#">Day: 8</a>
</div>
<div class="row3">
	<div class="column3">
		<h2>Column1</h2>
		<p>Sat, 4, 8, 2023. Library floor 2 zone c, number 373.</p>
	</div>
	<div class="column3">
		<h2>Column2</h2>
		<p>Waiting for the thesis result, no matter how, the most important thing is my attitude.</p>
	</div>
	<div class="column3">
		<h2>Column3</h3>
		<p>Alougth I am so tried, but I such state, my fear decreased and I can talk with myself.</p>
	</div>
</div>
```

<b>Tip:</b> To create a 2-column layout, change the width to 50%. To create a 4-column layout, use 25%, etc. A more modern way of creating column layouts, is to use CSS Flexbox. However, it is not supported in Internet Explorer 10 and earlier versions.

## 39.5 Unequal Columns

​	The main content is the biggest and the most important part of your site. It is common with <b>unequal</b> column widths, so that most of the space is reserved for the main content. The side content (if any) is often used as an alternative navigation or to specify information relevant to the main content. Change the widths as you like, only remember that is should add up to 100% in total:

```
.column {
  float: left;
}

/* Left and right column */
.column.side {
  width: 25%;
}

/* Middle column */
.column.middle {
  width: 50%;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column.side, .column.middle {
    width: 100%;
  }
}
```

## 39.6 Footer

​	The footer is placed at the bottom of your page. It often contains information like copyright and contact info:

```
.website-footer {
	background-color: #f1f1f1;
	padding: 10px;
	text-align: center;
}
<!-- HTML -->
<div class="website-footer">
	<p>Footer</p>
</div>
```

## 39.7 Responsive Website Layout

​	By using some of the CSS code above, we have created a responsive website layout, which varies between two columns and full-width columns depending on screen width (refer below code):

```
/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {   
    width: 100%;
    padding: 0;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .topnav a {
    float: none;
    width: 100%;
  }
}
```



# 40. CSS Units

## 40.1 CSS Units

​	CSS has several different units for expressing a length.

​	Many CSS properties take "length" values, such <span style="color: red;">width</span>, <span style="color: red;">margin</span>, <span style="color: red;">padding</span>, <span style="color: red;">font-size</span>, etc.

​	<b>Length</b> is a number followed by a length unit, such as <span style="color: red;">10px</span>, <span style="color: red;">2em</span>, etc.

<b>Note:</b> A whitespace cannot appear between the number and the unit. However, if the value is <span style="color: red;">0</span>, the unit can be omitted.

​	For some CSS properties, negative lengths are allowed. There are two types of length units: <b>absoulte</b> and <b>relative</b>.

1. Absolute Lengths

​	The absolute length units are fixed and a length expressed in any of these will appear as exactly that size.

​	Absolute length units are not recommended for use on screen, because screen sizes vary so much. However, they can be used if the output medium is known, such as for print layout.

| Unit | Description                  |
| ---- | ---------------------------- |
| cm   | centimeters                  |
| mm   | millimeters                  |
| in   | inches (1in = 96px = 2.54cm) |
| px * | pixels (1px = 1/96th of 1in) |
| pt   | points (1pt = 1/72 of 1in)   |
| pc   | picas (1pc = 12 pt)          |

\* Pixels (px) are relative to the viewing device. For low-dpi devices, 1px is one device pixel (dot) of the display. For pointers and high resolution screens 1px implies multiple device pixels.

2. Relative Lengths

​	Relative length units specify a length relative to another length property. Relative length units scale better between different rendering mediums.

| Unit | Description                                                  |
| ---- | ------------------------------------------------------------ |
| em   | Relative to the font-size of the element (2em means 2 times the size of the current font) |
| ex   | Relative to the x-height of the current font (rarely used)   |
| ch   | Relative to width of the "0" (zero)                          |
| rem  | Relative to font-size of the root element                    |
| vw   | Relative to 1% of the width of the viewport*                 |
| vh   | Relative to 1% of the height of the viewport*                |
| vmin | Relative to 1% of viewport's* smaller dimension              |
| vmax | Relative to 1% of viewport's* larger dimension               |
| %    | Relative to the parent element                               |

<b>Tip:</b> The em and rem units are practical in creating perfectly scalable layout!

*Viewport = the browser window size. If the viewport is 50cm wide, 1vm = 0.5cm.



# 41. CSS Specificity

## 41.1 What is Specificity?

​	If there are two or more CSS rules that point to the same element, the selector with the highest specificity value will "win", and its style declaration will be applied to that HTML element.

​	Think of specificity as a score/rank that determines which style declaration is ultimately applied to an element.

​	Look at the following examples:

1. In this example, we have used the 'p' element as selector, and specified a red color for this element. The text will be red:

```
<html>
<head>
<style>
p {color: red;}
</style>
</head>
<body>
<p> No sunshine no you smile I will die.</p> 
</body>
</html>
```

2. In this example, we have added a class selector (named "test"), and specified a green color for this class. The text will now be green (even though we have specified a red color for the element selector 'p'). This is because the class selector is given higher priority:

```
.test {color: green;}
p {color: red;}
<!-- HTML -->
<p classs="test">
```

3. In this example, we have added the id selector (named "demo"). The text will now be blue, because the id selector is given higher prority:

```
#demo {color: blue;}
.test {color: greem;}
p {color: red;}
```

4. In this example, we have added an inline style for the 'p' element. The text will now be pink, because the inline style is given the highest priority:

```
#demo {color: blue;}
.test {color: greem;}
p {color: red;}
<!-- HTML -->
<p id="demo" class="test" style="color: pink;">En </p>
```

## 41.2 Specificity Hierarchy

​	Every CSS selector has its place in the specificity hierarchy.

There are fur categories which define the specificity level of a selector:

1. <b>Inline style</b> 
2. <b>IDs</b>
3. <b>Classes, pseudo-classes, attribute selectors</b>
4. <b>Elements and pseudo-elements</b>

## 41.3 How to Calculate Specificity?

​	Memorize how to calculate specificity!

Start at 0, add 100 for each ID value, add 10 for each class value (or pseudo-class or attribute selector), add 1 for each element selector or pseudo-element.

<b>Note:</b> Inline style gets a specificity value of 1000, and is always given the highest priority.

<b>Note:</b> There is one exception to this rule: if you use <sapn style="color: red;">!important</span> rule, it will even override inline styles!

​	The table below shows some examples on how to calculate specificity values:

| Selector                  | Specificity value | Calculaation  |
| ------------------------- | ----------------- | ------------- |
| p                         | 1                 | 1             |
| p.test                    | 11                | 1 + 10        |
| p#demo                    | 101               | 1 + 100       |
| \<p style="color: pink;"> | 1000              | 1000          |
| #demo                     | 100               | 100           |
| .test                     | 10                | 10            |
| p.test1.test2             | 21                | 1 + 10 + 10   |
| #navbar p#demo            | 201               | 100 + 1 + 100 |
| *                         | 0                 | 0             |

## 41.4 More Specificity Rules Examples

<b>Equaal Specificity: the latest rule wins</b> - If the same rule is written twice into the external style sheet, then the latest rule wins:

```
h1 {background-color: yellow;}
h1 {background-color: red;}		/*win*/
```

<b>ID selectors have a higher specificity than attribute selectors</b> - Look at the following three code lines:

```
div#a {background-color: green;}	/*101,but applied*/
#a {background-color: yellow;}		/*10*/
div[id=a] {background-color: blue;}	/*101*/
```

<b>Contextual selectors are more specific than a single element selector</b> - The embedded style sheet is closer to the element to be styled. So in the following situation

```
/*From external CSS file*/
#content h1 {background-color: red;}
/*In HTML file*/
<style>
#content h1 {background-color: yellow;}	/*applied*/
</style>
```

<b>A class selector beats any number of element selectors</b> - a class selector such as .intro beats h1, p, div, etc:

```
.intro {background-color: yellow;}
h1 {background-color: red;}
```

<b>The universal selector (\*) and inherited values have a specificity of 0</b> - The universal selector (*) ans inherited values are ignored!



# 42. CSS The !important Rule

## 42.1 What is !important

​	The <span style="color: red;">!important</span> rule in CSS is used to add more important to a property/value than normal. In fact, if you use the <span style="color: red;">!important</span> rule, it will override ALL previous styling rules for that specific property on that element!

```
#myid {background-color: blue;}
.myclass {background-color: gray;}
p {background-color: red !important;}
```

## 42.2 Important About !important

​	The only way to override an <span style="color: red;">!important</span> rule is to include another <span style="color: red;">!important</span> rule on a declaration with the same (or higher) specificity in the source code - and here the problem starts! This makes the CSS code confusing and the debugging will be hard, especially if you have a large style sheet!

​	Here we have created a simple example. It is not very clear, when you look at the CSS source code, which color is considered most important:

```
#myid {
  background-color: blue !important;
}

.myclass {
  background-color: gray !important;
}

p {
  background-color: red !important;
}
```

<b>Tip:</b> It is good to know about <span style="color: red;">!important</span> rule. You might see it in some CSS source code. However, do not use it unless you absolutely have to.

## 42.3 Maybe One or Two Fair Uses of !important

​	One way to use <span style="color: red;">!important</span> is if you have to override a style that cannot be overridden in any other way. This could be if you are working on a Content Management System (CMS) and cannot edit the CSS code. Then you can set some custom styles to override some of the CMS styles.

​	Another way to use <span style="color: red;">!important</span> is: Assume you want to special look for all buttons on a page. Here, buttons are styled with a gray background color, white text, and some padding and border:

```
.button {
  background-color: #8c8c8c;
  color: white;
  padding: 5px;
  border: 1px solid black;
}
```

​	The look of a button can sometimes change if we put it inside another element with higher specificity, and the properties get in conflict. Here is an example of this:

```
.button {
  background-color: #8c8c8c;
  color: white;
  padding: 5px;
  border: 1px solid black;
}

#myDiv a {
  color: red;
  background-color: yellow;
}
```

​	To "force" all buttons to have the same look, no matter what, we can add the <span style="color: red;">!important</span> rule to the properties of the button, like this:

```
.button {
  background-color: #8c8c8c !important;
  color: white !important;
  padding: 5px !important;
  border: 1px solid black !important;
}

#myDiv a {
  color: red;
  background-color: yellow;
}
```



# 43. CSS Math Functions

​	The CSS math functions allow mathematical expressions to be used as property values. Here, we will explain the <span style="color: red;">calc()</span>, <span style="color: red;">max()</span>, and <span style="color: red;">min()</span> functions.

## 43.1 The calc() Function

​	The <span style="color: red;">calc()</span> function performs a calculation to be used as the property value

<span style="font-size: 18px; font-weight: bold;">CSS Syntax</span>

​	calc(expression)

```
#div1 {
	position: absolute;
	left: 50px;
	width: calc(100% - 100px);
	border: 1px solid black;
	background-color: yellow;
	padding: 5px;
}
```

## 43.2 The max() & min() Function

​	The <span style="color: red;">max()</span> function uses the largest value, from a comma-separated list of values, as the property value. The <span style="color: red;">min()</span> function uses the minimum value.

max(value1, value2, ..._)

```
#div1 {
	background-color: yellow;
	height: 100px;
	width: max(50%, 200px);
}
```



<span style="font-size: 26px; font-weight: bold;">CSS Advanced</span>

# 44. CSS Rounded Corners

## 44.1 CSS border-radius Property

​	The CSS <span style="color: red;">border-radius</span> property defines the radius of an element's corners.

<b>Tip:</b> This property allows you to add rounded corners to elements!

Here are three examples:

```
#rcorners1 {
	border-radius: 25px;
	background: #73AD21;
	padding: 20px;
	width: 200px;
	height: 150px;
}
#rcorners2 {
	border-radius: 25px;
	border: 2px solid #73AD21;
	padding: 20px;
	width: 200px;
	height: 150px;
}
#rcorners3 {
	border-radius: 26px;
	background: url("../img/image2.jpg");
	background-position: left top;
	background-repeat: repeat;
	background-size: 100px 100px;
	padding: 20px;
	width: 200px;
	height: 150px;
}
<!-- HTML -->
<h3>CSS Rounded Corners:</h3>
<p id="rcorners1">Rounded corners!</p>
<p id="rcorners2">Rounded corners!</p>
<p id="rcorners3">Rounded corners!</p>
```

<b>Tip:</b> The <span style="color: red;">border-radius</span> property is actually a shorthand property for the <span style="color: red;">border-top-left-radius</span>, <span style="color: red;">border-top-right-radius</span>, <span style="color: red;">border-bottom-right-radius</span> and <span style="color: red;">border-bottom-left-radius</span> properties.

## 44.2 CSS border-radius - Specify Each Corner

```
border-radius: 15px 50px 30px;	/*pratice it*/
```



# 45. CSS Border Images

## 45.1 CSS border-image Property

​	The CSS <span style="color: red;">border-image</span> property allows you to specify an image to be used instead of the normal border around an element.

​	The property has three parts:

1. The image to use as the border
2. Where to slice the image
3. Define whether the middle sections should be repeated or stretched

​	The <span style="color: red;">border-image</span> property takes the image and slices it into nine sections, like a tic-tac-toe board. It then places the corners at the corners, and the middle sections are repeated or stretched as you specify.

<b>Note:</b> For <span style="color: red;">border-image</span> to work, the element also needs the <span style="color: red;">border</span> property set!

​	Here, the middle sections of the image are repeated to create the border:

```
#borderimg {
	border: 10px solid transparent;
	padding: 15px;
	border-image: url(../img/border.png) 30 round;
}
<!-- HTML -->
<h3>CSS Border Image:</h3>
<p>Here, the middle sections of the image are repeated to create the border:</p>
<p id="borderimg">border-image: url('border.png') 30 round;</p>
```

<b>Tip:</b> The <span style="color: red;">border-image</span> property is actually a shorthand property for the <span style="color: red;">border-image-source</span>, <span style="color: red;">border-image-slice</span>, <span style="color: red;">border-image-outset</span> and <span style="color: red;">border-image-repeat</span> properties.

## 45.2 CSS border-image - Different Slice Values

​	Different slice values completely changes the look of the border:

```
#borderimg1 {
	border: 10px solid transparent;
	padding: 15px;
	border-image: url('../img/border.png') 50 round;
}
#borderimg2 {
	border: 10px solid transparent;
	padding: 15px;
	border-image: url('../img/border.png') 20% round;
}
#borderimg3 {
	border: 10px solid transparent;
	padding: 15px;
	border-image: url('../img/border.png') 30% round;
}
<!-- HTML -->
<p id="borderimg1">border-image: url('border.png') 50 round;</p>
<p id="borderimg2">border-image: url('border.png') 20% round;</p>
<p id="borderimg3">border-image: url('border.png') 30% round;</p>
```

## 45.3 CSS Border Image Properties

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [border-image](https://www.w3schools.com/cssref/css3_pr_border-image.asp) | A shorthand property for setting all the border-image-* properties |
| [border-image-source](https://www.w3schools.com/cssref/css3_pr_border-image-source.asp) | Specifies the path to the image to be used as a border       |
| [border-image-slice](https://www.w3schools.com/cssref/css3_pr_border-image-slice.asp) | Specifies how to slice the border image                      |
| [border-image-width](https://www.w3schools.com/cssref/css3_pr_border-image-width.asp) | Specifies the widths of the border image                     |
| [border-image-outset](https://www.w3schools.com/cssref/css3_pr_border-image-outset.asp) | Specifies the amount by which the border image area extends beyond the border box |
| [border-image-repeat](https://www.w3schools.com/cssref/css3_pr_border-image-repeat.asp) | Specifies whether the border image should be repeated, rounded or stretched |



# 46. CSS Multiple Backgrounds

## 46.1 CSS Multiple Backgrounds

​	CSS allows you to add multiple background images for an element, through the <span style="color: red;">background-image</span> property.

​	The different background images are separated by commas, and the images are stacked on top of each other, where the first image is closest to the viewer.

​	The following example has two background images, the first image is a flower (aligned to the bottom and right) and the second image is a paper background (aligned to the top-left corner):

```
#mb-example1 {
	background-image: url(../img/img_flwr.gif), url(../img/paper.gif);
	background-position: right bottom, left top;
	background-repeat: no-repeat, repeat;
	padding: 15px;
}
<!-- HTML -->
<h3>CSS Multiple Backgrounds:</h3>
<div id="mb-example1">
	<h1>Lorem Ipsum Dolor</h1>
	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod...</p>
</div>
```

## 46.2 CSS Background Size

​	The CSS <span style="color: red;">background-size</span> property allows you to specify the size of background images.

​	The size can be specified in lengths, percentages, or by using one of the two keywords: contain or cover.

​	The following example resizes a background image to much smaller than the original image (using pixels):

```
#div1 {
  background: url(img_flower.jpg);
  background-size: 100px 80px;
  background-repeat: no-repeat;
}
```

​	The two other possible values for <span style="color: red;">background-size</span> and <span style="color: red;">contain</span> and <span style="color: red;">cover</span>.

​	The <span style="color: red;">contain</span> keyword scales the background image to be as large as possible (but both its width and its height must fit inside the content area). As such, depending on the proportions of the background image and the background positioning area, there may be some areas of the background which are not covered by the background image.

​	The <span style="color: red;">cover</span> keyword scales the background image so that the content area is completely covered by the background image (both its width and height are equal to or exceed the content area). As such, some parts of the background image may not be visible in the background positioning area.

​	The following example illustrates the use of <span style="color: red;">contain</span> and <span style="color: red;">cover</span>:

```
.mb-div1 {
 	border: 1px solid black;
  	height: 120px;
  	width: 150px;
  	background: url(../img/img_flwr.gif);
  	background-repeat: no-repeat;
  	background-size: contain;
}
.mb-div2 {
  	border: 1px solid black;
  	height: 120px;
  	width: 150px;
  	background: url(../img/img_flwr.gif);
  	background-repeat: no-repeat;
  	background-size: cover;
}
.mb-div3 {
  	border: 1px solid black;
  	height: 120px;
  	width: 150px;
  	background: url(../img/img_flwr.gif);
  	background-repeat: no-repeat;
}
<!-- HTML -->
<h4>background-size: contain</h4>
<div class="mb-div1">
</div>
<h4>background-size: cover</h4>
<div class="mb-div2">
</div>
<h4>No background-size defined</h4>
<div class="mb-div3">
</div>
```

## 46.3 Define Sizes of Multiple Background Images

​	The <span style="color: red;">background-size</span> property also accepts multiple values for background size (using comma separated list), when working multiple backgrounds.

```
#mb-example2 {
	background: url(../img/image4.jpg) left top no-repeat, url(../img/img_flwr.gif) right bottom no-repeat, url(../img/paper.gif) left top repeat;
	background-size: 50px, 130px, auto;
	padding: 15px;
}
<!-- HTML -->
<div id="mb-example2">
	<h1>Multiple background size...</h1>
	<p>This is a test for multiple background size...</p>
</div>
```

## 46.4 Full Size Background Image

​	Now we want to have a background image on a website that covers the entire browser window at all time.

​	The requirements are as follows:

* Full the entire page with the image (no white space)
* Scale image as needed
* Center image on paper
* Do not cause scrollbars

​	The following example shows how to do it; Use the \<html> element (the \<html> element is always at least the height of the browser window). Then set a fixed and centered background on it. Then adjust its size with the background-size property:

```
html { 
  background: url(img_man.jpg) no-repeat center fixed; 
  background-size: cover;
}

body { 
  color: white; 
}
```

## 46.5 Hero Image

​	You could also use different background properties on a \<div> to create a hero image (a large image with text), and place it where you want.

```
.hero-image {
	background: url(../img/image6.jpg) no-repeat center;
	background-size: cover;
	height: 300px;
	position: relative;
}
.hero-text {
	text-align: center;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	color: white;
}
<!-- HTML -->
<div class="hero-image">
	<div class="hero-text">
		<h1 style="font-size: 50px;">This is a hero image</h1>
		<p>A hero image is a large image with text...</p>
	</div>
</div>
```

## 46.6 CSS background-origin Property

​	The CSS <span style="color: red;">background-origin</span> property specifies where the background image is positioned.

​	The property takes three different values:

* border-box - the background image starts from the upper left corner of the border
* padding-box - (default) the background image starts from the upper left corner of the padding edge
* context-box - the background image starts from the upper left corner of the content

​	The following example illustrates the <span style="color: red;">background-origin</span> property (practice it):

```
#example1 {
  border: 10px solid black;
  padding: 35px;
  background: url(img_flwr.gif);
  background-repeat: no-repeat;
}

#example2 {
  border: 10px solid black;
  padding: 35px;
  background: url(img_flwr.gif);
  background-repeat: no-repeat;
  background-origin: border-box;
}

#example3 {
  border: 10px solid black;
  padding: 35px;
  background: url(img_flwr.gif);
  background-repeat: no-repeat;
  background-origin: content-box;
}
```

## 46.7 CSS background-clip Property

​	The CSS <span style="color: red;">background-clip</span> property specifies the painting area of the background.

​	The property takes three different values:

* border-box - (default) the background is painted to the outside edge of the border
* padding-box - the background is painted to the outside edge of the padding
* content-box - the background is painted within the content box

```
#bc-example1 {
	border: 5px dotted black;
	padding: 20px;
	background: yellow;
}
#bc-example2 {
	border: 5px dotted black;
	padding: 20px;
	background: yellow;
	background-clip: padding-box;
}
#bc-example3 {
	border: 5px dotted black;
	padding: 20px;
	background: yellow;
	background-clip: content-box;
}
<!-- HTML -->
<p>background-clip: border-box:</P>
<div id="bc-example1">
	<p>Something in here...</p>
</div>
<p>background-clip: padding-box:</P>
<div id="bc-example2">
	<p>Something in here...</p>
</div>
<p>background-clip: content-box:</P>
<div id="bc-example3">
	<p>Something in here...</p>
</div>
```



# 47. CSS Colors

## 47.1 Colors

1. RGBA Colors
2. HSL Colors
3. HSLA Colors
4. Opacity (property)

## 47.2 Color Keywords

## 47.2.1 The transparent Keyword

​	The <span style="color: red;">transparent</span> keyword is used to make a color transparent. This is often used to make a transparent background color for an element.

```
div.ex1 {
	background-color: transparent;
	border: 2px solid black;	/*Equivalent to rgba(0, 0, 0, 0)*/
}
```

### 47.2.2 The currentcolor Keyword

​	The <span style="color: red;">cuttentcolor</span> keyword is like a variable that holds the current value of the color property of an element.

​	This keyword can be useful if you want to a specific color to be consistent in an element or a page.

```
.currentColor {
	color: blue;
	border: 3px dashed currentcolor;
	padding: 10px;
}
<!-- HTML -->
<div class="currentColor">
	This div element has the color same to this text...
</div>
```

### 47.2.3 The inherit Keyword

​	The <span style="color: red;">inherit</span> keyword specifies that a property should inherit its value from its parent element.

​	The <span style="color: red;">inherit</span> keyword can be used for any CSS property, and on any HTML element.

```
<div style="border: 2px dotted blue;">Here the <span style="border: inherit;" >
	span element's</span> border settings will also be inherited from the parent element.
</div>
```



# 48. CSS Gradients

​	CSS gradients let you display smooth transitions between two or more specified colors

​	CSS defines three types of gradients:

* Linear Gradients (goes down/up/left/right/diagonally)
* Radial Gradients (defined by their center)
* Conic Gradients (rotated around a center point)

## 48.2 CSS Linear Gradients

​	To create a linear gradient you must define at least two color stops. Color stops are the colors you want to render smooth transitions among. You can also set a starting point and a direction (or an angle) along with the gradient effect.

<span style="font-size: 20px;"><b>Syntax</b></span>

`background-image: linear-gradient(direction, color-stop1, color-stop2, ...);`

<b>Direction - Top to Bottom (default)</b>

```
#grad-tp {
	height: 100px;
	background-image: linear-gradient(red, yellow);
}
<!-- HTML -->
<div id="grad-tp">
	This a top to bottom gradient image...
</div>
```

<b>Direction - Left to Right</b>

```
#grad-lr {
	background-image: linear-gradient(to right, ted, yellow);
}
```

<b>Direction - Diagonal</b>

```
#grad-tlbr {
	background-image: linear-gradient(to bottom right, red, yellow);
}
```

## 48.3 Using Angles

​	If you want more control over the direction of the gradient, you can define an angle, instead of the predefined directions (to bottom, to top, to right, to left, to bottom right, etc). A value of 0deg is equivalent to "to top". A value of 90deg is equivalent to "to right". A value of 180deg is equivalent to "to bottom".

```
#grad-deg {
	background-image: linear-gradient(230deg, red, yellow);
}
```

## 48.4 Using Multiple Color Stops

```
#grad-mcs {
	background-image: linear-gradient(red, yellow, green);
}
```

## 48.5 Using Transparency

​	CSS gradients also support transparency, which can be used to create fading ellects.

​	To add transparency, we use the rgba() function to define the color stops.

```
#grad-transparency {
	backgroud-image: linear-gradient(to right, rgba(255,0,0,0), rgba(255,0,0,1));
}
```

## 48.6 Repeating a linear-gradient

​	The repeating-linear-gradien() function is used to repeat linear gradients:

```
#grad-repeat {
	background-image: repeating-linear-gradient(red, yellow 10%, green 20%);		/*percentages are their position*/
}
```

## 48.7 CSS Radial Gradients

​	A radial gradient is defined by its center.

​	To create a radial gradient you must also define at least two color stops.

<b>Syntax</b>

`background-image: radial-gradient(shape size at position, start-color, ..., last-color);`

​	By default, shape is ellipse, size is farthest-corner, and position is center.

<b>Radial Gradient - Evenly Spaced Color Stops (default)</b>

```
<div style="background-image: radial-gradient(red, yellow, green); height: 200px;">
	This is a radial gradient image with evenly spaced color stops.
</div>
```

<b>Radial Gradient - Differently Spaced Color Stops</b>

```
#grad-dscs {
	height: 100px;
	background: radial-gradient(red 5%, yellow 15%, green 60%);
}
<div id="grad-dscs">
	This is a radial gradient image with evenly spaced color stops.
</div>
```

## 48.8 Set Shape

​	The shape parameter defines the shape. It can take the value circle or ellipse. The default is ellipse (when take the value of circle, may truncated by the element).

```
<div style="background: radial-gradient(circle, red, yellow 50%, green 80%); height: 160px;">
	This is a radial gradient image with circle shape...
</div>
```

## 48.9 Use of Different Size Keywords

​	The size parameter defines the size of the gradient. It can take four values:

* <b>cloest-side</b>
* <b>farthest-side</b>
* <b>cloest-corner</b>
* <b>farthest-corner</b>

```
#grad-fs {
	height: 150px;
	width: 150px;
	background-color: red;	/*For browsers that do not support gradients*/
	background-image: radial-gradient(farthest-side at 60% 55%, red, yellow, black);
}
<!-- HTML -->
<p>farthest-side:</p>
<div id="grad-fs">
</div>
```

<img src="img/grad-img.jpg"> 

## 48.10 Repeating a radial-gradient

```
#grad-rrg {
	background-image: repeating-radial-gradient(reed, yellow 10%, green 15%);
}
```

## 48.11 CSS Conic Gradients

​	A conic gradient is a gradient with color transitions rotated around a center point.

​	To create a conic gradient you must define at least two colors.

<b>Syntax</b>

`background-image: conic-gradient([from angle] [at position,] color [degree], color [degree], ...);`

​	By default, angle is 0deg and position is center. If no degree is specifies, the color will spread equally around the center point.

<b>Conic Gradient: Three Colors</b>

```
#grad-cgtc {
	background: conic-gradient(red, yellow, green);
}
```

<b>Conic Gradient: Three Colors and Degrees</b>

```
#grad-cgtcd {
	background-image: conic-gradient(red 45deg, yellow 90deg, green 210deg);
}
```

<b>Create Pie Charts</b>

​	Just add <span style="color: red;">border-radius: 50%</span> to make the conic gradient look like a pipe:

```
#grad-cgtcd {
	background-image: conic-gradient(red 45deg, yellow 90deg, green 210deg);
	border-radius: 50%;
}
```

<b>Conic Gradient With Specified From Angle</b>

​	The [from angle] specifies an angle that the entire conic gradient is rotated by.

```
#grad {
  background-image: conic-gradient(from 90deg, red, yellow, green);
}
```

<b>Conic Gradient With Specified Center Position</b>

```
#grad {
  background-image: conic-gradient(at 60% 45%, red, yellow, green);
}
```

<b>Repeating a Conic Gradient</b>

```
#grad1 {
  background-image: repeating-conic-gradient(red 10%, yellow 20%);
  border-radius: 50%;
}
#grad2 {
  background-image: repeating-conic-gradient(red 0deg 10deg, yellow 10deg 20deg, blue 20deg 30deg);
  border-radius: 50%;
}
```



# 49. CSS Shadows

## 49.1 CSS Shadow Effects

### 49.1.1 CSS Shadow Effects

​	With CSS you can add shadow to text and to elements.

​	In these chapters you will learn about the following properties:

* <span style="color: red;">text-shadow</span>
* <span style="color: red;">box-shadow</span>

### 49.1.2 CSS Text Shadow

​	The CSS <span style="color: red;">text-shadow</span> property applies shadow to text.

​	In its simplest use, you only specify th horizontal shadow (2px) and the vertical shadow (2px):

```
.text-shadow {
	text-shadow: 2px 2px;
}
```

​	Next, add a color and a blur effect to the shadow:

```
.text-shadow {
	text-shadow: 2px 2px 5px red;
}
```

### 49.1.3 Multiple Shadows

​	To add more than one shadow to the text, you can add a comma-separated list of shadows. The following example shows a red and blue neon glow shadow:

```
.text-shadow {
	text-shadow: 0 0 3px #FF0000, 0 0 5px #0000ff;
}
```

​	You can also use the text-shadow property to create a plain border around some text (without shadow) :

```
.text-shadow2 {
	color: coral;
	text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black; 
}
<!-- HTML -->
<p class="text-shadow2">This is a plain border around text...</p>
```

## 49.2 CSS Box Shadow

### 49.2.1 CSS box-shadow Property

​	The CSS <span style="color: red;">box-shadow</span> property is used to apply one or more shadows to an element.

### 49.2.2 Specify a Horizontal and a Vertical Shadow

```
div.box-shadow1 {
	box-shadow: 10px 10px;
}
```

### 49.2.3 Specify a Color and Blur Effect for the Shadow

```
div.box-shadow2 {
	box-shadow: 10px 10px 5px lightblue;
}
```

### 49.2.4 Set the Spread Radius of the Shadow

​	The <span style="color: red;">spread</span> parameter defines the spread radius. A positive value increase the size of the shadow, a negative value decreases the size of the shadow.

```
div.box-shadow1 {
	width: 100px;
	height: 100px;
	background-color: coral;
	box-shadow: 10px 10px 5px 19px lightblue;
}
```

### 49.2.5 Set the inset Parameter

​	The <span style="color: red;">inset</span> parameter changes the shadow from an outer shadow (outset) to an inner shadow (the height and width of the element is the shadow w and h) .

```
div.box-shadow2 {
	box-shadow: 10px 10px 5px lightblue inset;
}
```

### 49.2.6 Add Multiple Shadows

​	An element can also have multiple shadows via a comma-separated expression.

```
div.box-shadow1 {
	width: 100px;
	height: 100px;
	background-color: coral;
	box-shadow: 10px 10px 5px 19px lightblue, 25px 25px 3px 20px red;
}
```

### 49.2.7 Cards

```
div.shadow-card {
	position: relative;
	top: 60px;	/*Avoid hide of the last shadow*/
	width: 250px;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	text-align: center;
}
div.shadow-header {
	background-color: #4CAF50;
	color: white;
	padding: 10px;
	font-size: 40px;
}
div.shadow-container {
	padding: 10px;
}
<!-- HTML -->
<div class="shadow-card">
	<div class="shadow-header">
		<h1>1</h1>
	</div>
	<div class="shadow-container">
		<p>April 9, 2023</p>
	</div>
</div>
```



# 50. CSS Text Effects

## 50.1 CSS Text Overflow

​	The CSS <span style="color: red;">text-overflow</span> property specifies how overflowed content that is not displayed should be signaled to the user. It can be clipped, or it can be rendered as an ellipsis (...):

```
p.test1 {
  white-space: nowrap;
  width: 200px;
  border: 1px solid #000000;
  overflow: hidden;
  text-overflow: clip;
}
p.test2 {
  white-space: nowrap;
  width: 200px;
  border: 1px solid #000000;
  overflow: hidden;
  text-overflow: ellipsis;
}
```

​	We can add a effect of when hovering over the element, display the overflowed content:

```
div.test:hover {
	overflow: visible;
}
```

## 50.2 CSS Word Wrapping

​	The CSS <span style="color: red;">word-wrap</span> property allows long words to be able to be broken and wrap onto the next line. If a word is too long to fit within an area, it expands outside. The word-warp property allows you to force the text to wrap - even if it means splitting it in the middle of a word:

```
p.textEffect-wrap {
	position: relative;
	top: 50px;
	width: 11em;
	border: 1px solid #00001;
	word-wrap: break-word;
}
<!-- HTML -->
<p class="textEffect-wrap">Here is a word-wrap property which allows the word
	very looo0oooo0oooooo0oo0oo0ong broken in the middle.</p>
```

## 50.3 CSS Work Breaking

​	The CSS <span style="color: red;">word-break</span> property specifies line breaking rules, like below:

<img src="img/overlap.jpg" height="330px"> 

```
p.textEffect-wrap {
	position: relative;
	top: 30px;
	width: 11em;
	border: 1px solid #000000;
	word-wrap: break-word;
}
p.textEffect-break1 {
	width: 140px;
	border: 1px solid #000001;
	word-break: keep-all;
}
p.textEffect-break2 {
	width: 140px;
	border: 1px solid #000001;
	word-break: break-all;
}
<!-- HTML -->
<h3>CSS Text Effects:</h3>
<p class="textEffect-wrap">Here is a word-wrap property which allows the word
	very looo0oooo0oooooo0oo0oo0ong broken in the middle.</p>
<p class="textEffect-break1">Here is a word-wrap property which allows the word
	very looo0oooo0oooooo0oo0oo0ong broken in the middle.</p>
<p class="textEffect-break2">Here is a word-wrap property which allows the word
	very looo0oooo0oooooo0oo0oo0ong broken in the middle.</p>
```

​	<b>Note:</b> <span style="color: red;">Here, you can find a problem, textEffect-wrap is overlap with textEffect-break1!</span> So, with a relative property, it is necessary to add a <span style="color: red;">margin-bottom</span> to the element?

## 50.4 CSS Writing Mode

​	The CSS <span style="color: red;">writing-mode</span> property specifies whether lines of text are laid out horizontally or vertically. Some text with a span element with a <span style="writing-mode: vertical-rl">vertically</span> writing-mode. The following example shows some different writing modes:

```
p.test1 {
  writing-mode: horizontal-tb;
}

span.test2 {
  writing-mode: vertical-rl;
}

p.test2 {
  writing-mode: vertical-rl;
}
```

## 50.5 CSS Text Effect Properties

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [text-justify](https://www.w3schools.com/cssref/css3_pr_text-justify.asp) | Specifies how justified text should be aligned and spaced    |
| [text-overflow](https://www.w3schools.com/cssref/css3_pr_text-overflow.asp) | Specifies how overflowed content that is not displayed should be signaled to the user |
| [word-break](https://www.w3schools.com/cssref/css3_pr_word-break.asp) | Specifies line breaking rules for non-CJK scripts            |
| [word-wrap](https://www.w3schools.com/cssref/css3_pr_word-wrap.asp) | Allows long words to be able to be broken and wrap onto the next line |
| [writing-mode](https://www.w3schools.com/cssref/css3_pr_writing-mode.asp) | Specifies whether lines of text are laid out horizontally or vertically |



# 51. CSS Web Fonts

## 51.1 The CSS @font-face Rule

​	Web fonts allows Web designer to use fonts that are not installed on the user's computer.

​	When you have found/bought the font you wish to use, just include the font file on your web server, and it will be automatically downloaded to the user when needed.

​	You "own" fonts are defined within the CSS <span style="color: red;">@font-face</span> rule.

## 51.2 Different Font Formats

<b>TrueType Fonts (TTF)</b>

​	TrueType is a font standard developed in the late 1980s, by Apple and Microsoft. TrueType is the most common font format for both the Mac OS and Microsoft Windows operating systems.

<b>OpenType Fonts (OTF)</b>

​	OpenType is a format for scalable computer fonts. It was built on TrueType, and is a registered trademark of Microsoft. OpenType font s are used commonly today on the major computer platforms.

<b>The Web Open Font Format (WOFF)</b>

​	WOFF is a font format for use in web pages. It was developed in 2009, and is now a W3C Recommendation. WOFF is essentially OpenType or TrueType with compression and additional metadata. The goal is to support font distribution from a server to a client over a network with bandwidth constraints.

<b>The Web Open Fon Format (WOFF 2.0)</b>

​	TrueType/OpenType font that provided better compression than WOFF 1.0.

<b>SVG Fonts/Shapes</b>

​	SVG fonts allow SVG to be used as glyphs when displaying text. The SVG 1.1 specification define a font module that allows the creation of fonts within an SVG document. You can also apply CSS to SVG documents, and the @font-face rule can be applied to text in SVG documents.

<b>Embedded OpenType Fonts (EOF)</b>

​	EOT fonts are a compact form of OpenType fonts designed by Microsoft for use as embedded fonts on web pages.

## 51.3 Using The Font You Want

​	In the <span style="color: red;">@font-face</span> rule; first define a name for the font (e.g. myFirstFont) and then point to the font file.

<b>Tip:</b> Always use lowercase letters for the font URL, Uppercase letters can give unexpected results in IE.

​	To use the font for an HTML element, refer to the same name of the font (myFirstFont) through the <span style="color: red;">font-family</span> property.

```
@font-face {
  font-family: myFirstFont;
  src: url(sansation_light.woff);
}

div {
  font-family: myFirstFont;
}
```

## 51.4 Using Bold Text

​	You must add another <span style="color: red;">@font-face</span> rule containing descriptors for bold text:

```
@font-face {
	font-family: myFirstFont;
	src: url(sansation_bold.woff);
	font-weight: bold;
}
```

## 51.5 CSS Font Descriptors

​	The following table lists all the font descriptors that can be defined inside the <span style="color: red;">@font-face</span> rule:

| Descriptor    | Values                                                       | Description                                                  |
| :------------ | :----------------------------------------------------------- | :----------------------------------------------------------- |
| font-family   | *name*                                                       | Required. Defines a name for the font                        |
| src           | *URL*                                                        | Required. Defines the URL of the font file                   |
| font-stretch  | normal condensed ultra-condensed extra-condensed semi-condensed expanded semi-expanded extra-expanded ultra-expanded | Optional. Defines how the font should be stretched. Default is "normal" |
| font-style    | normal italic oblique                                        | Optional. Defines how the font should be styled. Default is "normal" |
| font-weight   | normal bold 100 200 300 400 500 600 700 800 900              | Optional. Defines the boldness of the font. Default is "normal" |
| unicode-range | *unicode-range*                                              | Optional. Defines the range of UNICODE characters the font supports. Default is "U+0-10FFFF" |



# 52. CSS 2D Transforms

## 52.1 CSS 2D Transforms

​	CSS transforms allow you to move, rotate, scale, and skew elements.

​	In this chapter we will learn about the following CSS property:

* <span style="color: red;">transform</span>

## 52.2 CSS 2D Transforms Methods

​	With the CSS <span style="color: red;">transform</span> property you can use the following 2D transformation methods:

* <span style="color: red;">translate()</span>
* <span style="color: red;">rotate()</span>
* <span style="color: red;">scaleX()</span>
* <span style="color: red;">scaleY()</span>
* <span style="color: red;">scale()</span>
* <span style="color: red;">skewX()</span>
* <span style="color: red;">skewY()</span>
* <span style="color: red;">skew()</span>
* <span style="color: red;">matrix()</span>

## 52.3 The translate() Method

​	The <span style="color: red;">translate()</span> method moves an element from its current position (according to the parameters given for the X-axis and the Y-axis).

​	The following example moves the \<div> element 50 pixels to the right, and 100 pixels down from its current position:

```
div.TDtrans-translate {
	border: 1px solid black;
	width: 200px;
	height: 100px;
	background-color: yellow;
}
div.TDtrans-translate:hover {
	transform: translate(50px, 100px);
}
<!-- HTML -->
<h3>CSS 2D Transforms:</h3>
<div class="TDtrans-translate">	<!-- Pay attentation: the first letter can not be a number-->
	This div element is moved via the translate() method...
</div>
```

## 52.4 The rotate() Method

​	The <span style="color: red;">rotate()</span> method rotates an element clockwise or counter-clockwise according to a given degree.

```
div.rotate {
	transform: rotate(-20deg);
}
```

## 52.5 The scale() Method

​	The <span style="color: red;">scale()</span> method increases or decreases the size of en element (according to the parameters given for the width and height).

```
div.TDtrans-scale {
	margin: 80px;
	width: 200px;
	height: 100px;
	background-color: yellow;
	border: 1px solid black;
}
div.TDtrans-scale:hover {
	transform: scale(2, 3);
}
<!-- HTML -->
<div class="TDtrans-scale">
	This div element is two times of its original width, and three times of its 
	original height...
</div>
```

## 52.6 The scaleX() & scaleY() Method

​	The <span style="color: red;">scaleX()</span> method increases or decreases the width of an element, while the <span style="color: red;">scaleY()</span> method increases or decreases the height of an element.

## 52.7 The skewX() & skewY() & skew() Method

​	The <span style="color: red;">skewX()/skewY()</span> mthod skew an element along the X-axis/Y-axis by the given angle. The <span style="color: red;">skew()</span> method skews an element along the X and Y-axis by the given angle.

```
div.TDtrans-skew {
	width: 200px;
	height: 100px;
	background-color: blue;
}
div.TDtrans-skew:hover {
	transform: skew(20deg, 10deg);
}
<!-- HTML -->
<div class="TDtrans-skew">
	This div element is skewed 20 degrees along the X-axis, and 10 degrees 
	along the Y-axis.
</div>
```

## 52.8 The matrix() Method

​	The <span style="color: red;">matrix()</span> method take six parameters, containing mathematic functions, which allows you to rotate, scale, move, and skew elements. The parameters are as follow: matrix(scaleX(), skewY(), skewX(), scalsY(), translateX(), translateY())

## 52.9 CSS Transform Properties

| Property                                                     | Description                                               |
| :----------------------------------------------------------- | :-------------------------------------------------------- |
| [transform](https://www.w3schools.com/cssref/css3_pr_transform.asp) | Applies a 2D or 3D transformation to an element           |
| [transform-origin](https://www.w3schools.com/cssref/css3_pr_transform-origin.asp) | Allows you to change the position on transformed elements |



# 53. CSS 3D Transforms

## 53.1 CSS 3D Transforms Methods

​	With the CSS <span style="color: red;">transform</span> property you can use the following 3D transformation methods:

* <span style="color: red;">rotateX()</span>
* <span style="color: red;">rotateY()</span>
* <span style="color: red;">rotateZ()</span>

## 53.2 The rotateX() & rotateY() & rotateZ() Method

​	The <span style="color: red;">rotateX()</span> method rotates an element around its X-axis at a given degree, the <span style="color: red;">rotateY()</span> method rotates an element around its Y-axis at a given degree, and <span style="color: red;">rotateZ()</span> rotates around Y-axis.

```
#myDIv {
	transform: rotateX(150deg);
}
```

## 53.3 CSS Transform Properties

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [transform](https://www.w3schools.com/cssref/css3_pr_transform.asp) | Applies a 2D or 3D transformation to an element              |
| [transform-origin](https://www.w3schools.com/cssref/css3_pr_transform-origin.asp) | Allows you to change the position on transformed elements    |
| [transform-style](https://www.w3schools.com/cssref/css3_pr_transform-style.asp) | Specifies how nested elements are rendered in 3D space       |
| [perspective](https://www.w3schools.com/cssref/css3_pr_perspective.asp) | Specifies the perspective on how 3D elements are viewed      |
| [perspective-origin](https://www.w3schools.com/cssref/css3_pr_perspective-origin.asp) | Specifies the bottom position of 3D elements                 |
| [backface-visibility](https://www.w3schools.com/cssref/css3_pr_backface-visibility.asp) | Defines whether or not an element should be visible when not facing the screen |

	## 53.4 CSS 3D Transform Methods

| Function                                     | Description                                                  |
| :------------------------------------------- | :----------------------------------------------------------- |
| matrix3d (*n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n*) | Defines a 3D transformation, using a 4x4 matrix of 16 values |
| translate3d(*x,y,z*)                         | Defines a 3D translation                                     |
| translateX(*x*)                              | Defines a 3D translation, using only the value for the X-axis |
| translateY(*y*)                              | Defines a 3D translation, using only the value for the Y-axis |
| translateZ(*z*)                              | Defines a 3D translation, using only the value for the Z-axis |
| scale3d(*x,y,z*)                             | Defines a 3D scale transformation                            |
| scaleX(*x*)                                  | Defines a 3D scale transformation by giving a value for the X-axis |
| scaleY(*y*)                                  | Defines a 3D scale transformation by giving a value for the Y-axis |
| scaleZ(*z*)                                  | Defines a 3D scale transformation by giving a value for the Z-axis |
| rotate3d(*x,y,z,angle*)                      | Defines a 3D rotation                                        |
| rotateX(*angle*)                             | Defines a 3D rotation along the X-axis                       |
| rotateY(*angle*)                             | Defines a 3D rotation along the Y-axis                       |
| rotateZ(*angle*)                             | Defines a 3D rotation along the Z-axis                       |
| perspective(*n*)                             | Defines a perspective view for a 3D transformed element      |



# 54. CSS Transitions

## 54.1 CSS Transitions

​	CSS transitions allows you to change property values smoothly, over a given duration.

In this chapter you will learn about the following properties:

* <span style="color: red;">transition</span>
* <span style="color: red;">transition-delay</span>
* <span style="color: red;">transition-duration</span>
* <span style="color: red;">transition-property</span>
* <span style="color: red;">transition-timing-function</span>

## 54.2 How to Use CSS Transitions?

​	To create a transition effect, you must specify two things:

* the CSS property you want to add an effect to
* the duration of the effect

<b>Note:</b> If the duration part is not specified, the transition will have no effect, because the default value is 0.

​	The following example shows a 100px * 100px red \<div> element. The \<div> element has also specified a transition effect for the width property, with a duration of 2 seconds:

```
div.transition {
	width: 100px;
	height: 100px;
	background: red;
	transition: width 2s;
}
```

​	The transition effect will start when the specified CSS property (width) changes value.

​	Now, let us specify a new value for the width property when a user mouses over the \<div> element:

```
div.transition1 {
	width: 100px;
	height: 100px;
	background: yellow;
	transition: width 2s;
}
div.transition1:hover {
	width: 300px;
}
<!-- HTML -->
<h3>CSS Transition:</h3>
<div class="transition1">
```

## 54.3 Change Several Property Values

​	The following example adds a transition effect for both the width and height property, with a duration of 2 seconds for the width and 4 seconds for the height:

```
div {
	transition: width 2s, height 4s;
}
```

## 54.4 Specify the Speed Curve of the Transition

​	The <span style="color: red;">transition-timing-function</span> property specifies the speed curve of the transition effect.

The transition-timing-function property can have the following values:

* <span style="color: red;">ease</span> - specifies a transition effect with a slow start, then fast, then end slowly (default)
* <span style="color: red;">linear</span> - specifies a transition effect with the same speed from start to end
* <span style="color: red;">ease-in</span> - specifies a transition effect with a slow start
* <span style="color: red;">ease-out</span> - specifies a transition effect with a slow end
* <span style="color: red;">ease-in-out</span> - specifies a transition effect with a slow start and end
* <span style="color: red;">cubic-bezier(n,n,n,n)</span> - lets you define your own values in a cubic-bezier function

```
#div1 {transition-timing-function: linear;}
#div2 {transition-timing-function: ease;}
#div3 {transition-timing-function: ease-in;}
#div4 {transition-timing-function: ease-out;}
#div5 {transition-timing-function: ease-in-out;}
```

## 54.5 Delay the Transition Effect

​	The <span style="color: red;">transition-delay</span> property specifies a delay (in seconds) for the transition effect.

```
div {
	transition-delay: 1s;
}
```

## 54.6 Transition + Transformation

```
div {
	transition: width 2s, height 2s, transform 2s;
}
```

## 54.7 More Transition Examples

```
div {
  transition-property: width;
  transition-duration: 2s;
  transition-timing-function: linear;
  transition-delay: 1s;
}
```



# 55. CSS Animations

## 55.1 CSS Animations

​	CSS allows animation of HTML elements without using JavaScript or Flash!

​	In this chapter we will learn about the following properties:

* <span style="color: red;">@keyframes</span>
* <span style="color: red;">animation-name</span>
* <span style="color: red;">animation-duration</span>
* <span style="color: red;">animation-delay</span>
* <span style="color: red;">animation-iteration-count</span>
* <span style="color: red;">animation-direction</span>
* <span style="color: red;">animation-timing-function</span>
* <span style="color: red;">animation-fill-mode</span>
* <span style="color: red;">animation</span>

## 55.2 What are CSS Animations?

​	An animation lets an element gradually change from one style to another.

​	You can change as many CSS properties you want, as many times as you want.

​	To use CSS animation, you must first specify some keyframes for the animation.

​	Keyframes hold what styles the element will have at certain times.

## 55.3 The @keyframes Rule

​	When you specify CSS styles inside the <span style="color: red;">@keyframes</span> rule, the animation will gradually change from the current style to the new style at certain times.

​	To get an animation to work, you must bind the animation to an element.

​	The following example binds the "example" animation to the \<div> element. The animation will last for 4 seconds, and it will gradually change the background-color of the \<div> element from "yellow" to "red".

```
div.animation1 {
	width: 100px;
	height: 100px;
	background-color: yellow;
	animation-name: example;
	animation-duration: 4s;
}
@keyframes example {
	from {background-color: yellow;}
	to {background-color: red;}
}
<!-- HTML -->
<h3>CSS Animations:</h3>
<div class="animation1"></div>
</div>
```

<b>Note:</b> The <span style="color: red;">animation-duration</span> property defines how long an animation should take to complete. If the <span style="color: red;">animation-duration</span> property is not specified, no animation will occur, because the default value is 0s.

​	It is also possible to use percent. By using percent, you can add as many style changes as you like:

```
div.animation2 {
	width: 100px;
	height: 100px;
	background-color: red;
	position: relative;
	animation-name: example;
	animation-duration: 4s;
}
@keyframes example {
	0% {background-color: red; left: 0px; top: 0px;}
	25% {background-color: yellow; left: 200px; top: 0px;}
	50% {background-color: blue; left: 200px; top: 200px;}
	75% {background-color: green; left: 0px; top: 200px;}
	100% {background-color: red; left: 0px; top: 0px;}
}
<!-- HTML -->
<div class="animation2"></div>
```

## 55.4 Delay an Animation

​	The <span style="color: red;">animation-delay</span> property specifies a delay for the start of an animation.

​	The following example has a 2 seconds delay before starting the animation:

```
div {
  width: 100px;
  height: 100px;
  background-color: red;
  position: relative;
  animation-name: example;
  animation-duration: 4s;
  animation-delay: 2s;
}
```

​	Negative values are also allowed. If using negative values, the animation will start as if it had already been playing for N seconds.

​	In the following example, the animation will start as if it had already been playing for 2 seconds:

```
div {
  width: 100px;
  height: 100px;
  position: relative;
  background-color: red;
  animation-name: example;
  animation-duration: 4s;
  animation-delay: -2s;
}
```

## 55.6 Set How Many Times an Animation Should Run

​	The <span style="color: red;">animation-iteration-count</span> property specifies the number of times an animation should run.

```
div {
	width: 100px;
	height: 100px;
	position: relative;
	background-color: red;
	animation-name: example;
	animation-duration: 4s;
	animation-iteration-count: 3;	/*Can be infinite to make the animation continue for ever*/
}
```

## 55.7 Run Animation in Reverse Direction or Alternate Cycles

​	The <span style="color: red;">animation-direction</span> property specifies whether an animation should be played forwards, backwards or in alternate cycles.

​	The animation-direction property can have the following values:

* <span style="color: red;">normal</span> - The animation is played as normal (forwards). This is default
* <span style="color: red;">reverse</span> - The animation is played in reverse direction (backwards)
* <span style="color: red;">alternate</span> - The animation is played forwards first, then backwards
* <span style="color: red;">alternate-reverse</span> - The animation is played backwards first, then forwards

## 55.8 Specify the Speed Curve of the Animation

​	The <span style="color: red;">animation-timing-function</span> property specifies the speed curve of the animation.

​	The animation-timing-function property can have the following values:

​		<span style="color: red;">ease</span>, <span style="color: red;">linear</span>, <span style="color: red;">ease-in</span>, <span style="color: red;">ease-out</span>, <span style="color: red;">ease-in-out</span>, <span style="color: red;">cubic-bezier(n,n,n,n)</span>.

## 55.9 Specify the fill-mode For an Animation

​	CSS animations do not affect an element before the first keyframe is played or after the last keyframe is played. The animation-fill-mode property can override this behavior.

​	The <span style="color: red;">animation-fill-mode</span> property specifies a style for the target element when the animation is not playing (before it starts, after it ends, or both).

​	The animation-fill-mode property can have the following values:

* <span style="color: red;">none</span> - Default value. Animation will not apply any styles to the element before or after it is executing
* <span style="color: red;">forwards</span> - The element will retain the style values that is set by the last keyframe (depends on animation-direction and animation-iteration-count)
* <span style="color: red;">backwards</span> - The element will get the style values that is set by the first keyframe (depends on animation-direction), and retain this during the animation-delay period
* <span style="color: red;">both</span> - The animation will follow the rules for both forwards and backwards, extending the animation properties in both directions

​	The following example lets the \<div> element retain the style values from the last keyframe when the animation ends:

```
div {
  width: 100px;
  height: 100px;
  background: red;
  position: relative;
  animation-name: example;
  animation-duration: 3s;
  animation-fill-mode: forwards;
}
```

## 55.10 Animation Shorthand Property

​	The example below uses six of the animation properties and achieved by using the shorthand <span style="color: red;">animation</span> property:

```
div {
  animation-name: example;
  animation-duration: 5s;
  animation-timing-function: linear;
  animation-delay: 2s;
  animation-iteration-count: infinite;
  animation-direction: alternate;
}
--->
div {
  animation: example 5s linear 2s infinite alternate;
}
```

## 55.11 CSS Animation Properties

​	The following table lists the @keyframes rule and all the CSS animation properties:

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [@keyframes](https://www.w3schools.com/cssref/css3_pr_animation-keyframes.asp) | Specifies the animation code                                 |
| [animation](https://www.w3schools.com/cssref/css3_pr_animation.asp) | A shorthand property for setting all the animation properties |
| [animation-delay](https://www.w3schools.com/cssref/css3_pr_animation-delay.asp) | Specifies a delay for the start of an animation              |
| [animation-direction](https://www.w3schools.com/cssref/css3_pr_animation-direction.asp) | Specifies whether an animation should be played forwards, backwards or in alternate cycles |
| [animation-duration](https://www.w3schools.com/cssref/css3_pr_animation-duration.asp) | Specifies how long time an animation should take to complete one cycle |
| [animation-fill-mode](https://www.w3schools.com/cssref/css3_pr_animation-fill-mode.asp) | Specifies a style for the element when the animation is not playing (before it starts, after it ends, or both) |
| [animation-iteration-count](https://www.w3schools.com/cssref/css3_pr_animation-iteration-count.asp) | Specifies the number of times an animation should be played  |
| [animation-name](https://www.w3schools.com/cssref/css3_pr_animation-name.asp) | Specifies the name of the @keyframes animation               |
| [animation-play-state](https://www.w3schools.com/cssref/css3_pr_animation-play-state.asp) | Specifies whether the animation is running or paused         |
| [animation-timing-function](https://www.w3schools.com/cssref/css3_pr_animation-timing-function.asp) | Specifies the speed curve of the animation                   |



# 56. CSS Tooltip

​	A tooltip is often used to specify extra information about something when the user moves the mouse pointer over an element.

## 56.1 Basic Tooltip

​	Create a tooltip that appears when the user moves the mouse over an element:

```
.tooltip1 .tooltiptext1 {
	visibility: hidden;
	width: 120px;	
	background-color: black;
	color: #fff;
	text-align: center;
	border-radius: 6px;
	padding: 5px 0;
	/*Position the tooltip*/
	position: absolute;
	z-index: 1;
}
.tooltip1:hover .tooltiptext1 {
	visibility: visible;
}
<!-- HTML -->
<div class="tooltip1">Hover over me <span class="tooltiptext1">Tooltip text</span></div>
```

<span style="font-size: 19px;">Example Explained</span>

<b>HTML:</b> Use a container element (like \<div>) and add the <span style="color: red;">"tooltip"</span> class to it. When the user mouse over this \<div>, it will show the tooltip text.

​	The tooltip text is placed inside and inline element (like \<span>) with <span style="color: red;">class="tooltiptext"</span>.

<b>CSS:</b> The <span style="color: red;">tooltip</span> class use <span style="color: red;">position: relative</span>, which is needed to position the tooltip text (<span style="color: red;">position: absolute</span>). <b>Note:</b> See examples below on how to position the tooltip.

​	The <span style="color: red;">tooltiptext</span> class holds the actual tooltip text. It is hidden by default, and will be visible on hover (see below). We have also added some basic styles to it: 120px width, black background color, white text color, centered text, and 5px top and bottom padding.

​	The CSS <span style="color: red;">border-radius</span> property is used to add rounded corners to the tooltip text.

​	The <span style="color: red;">:hover</span> selector is used to show the tooltip text when the user moves the mouse over the \<div> with <span style="color: red;">class="tooltip"</span>.

## 56.2 Positioning Tooltips

​	In this example, the tooltip is placed to the right (<span style="color: red;">left: 105%</span>) of the "hoverable" text (\<div>). Also note that <span style="color: red;">top: -5px</span> is used to place it in the middle of its container element. We use the number <b>5</b> because the tooltip text has a top and bottom padding of 5px. If youu increase its padding, also increase the value of the <span style="color: red;">top</span> property to ensure that it stays in the middle (if this is something you want). The same applies if you want the tooltip placed to the left.

```
.tooltip .tooltiptext {
	top: -5px;
	left: 105%;	/*right: 105%; when appear on the left*/
}
```

​	If you want the tooltip to appear on top or on the bottom, see examples below. Note that we use the <span style="color: red;">margin-left</span> property with a value of minus 60 pixels. This is to center the tooltip above/below the hoverable text. It is set to the half of the tooltip's width (120/2 = 60).

```
.tooltip1 {
	position: relative;
	display: inline-block;
	border-bottom: 1px dotted black;
}
.tooltip1 .tooltiptext1 {
	visibility: hidden;
	width: 120px;	
	background-color: black;
	color: #fff;
	text-align: center;
	border-radius: 6px;
	padding: 5px 0;
	/*Position the tooltip*/
	position: absolute;
	z-index: 1;
	top: 100%;
	left: 50%;
	margin-left: -60px;
}
.tooltip1:hover .tooltiptext1 {
	visibility: visible;
}
<!-- HTML -->
<div class="tooltip1">Hover over me <span class="tooltiptext1">Tooltip text</span></div>
```

## 56.3 Tooltip Arrows

​	To create an arrow that should appear from a specific side of the tooltip, add "empty" content after tooltip, with the pseudo-element class <span style="color: red;">::after</span> together with the <span style="color: red;">content</span> property. The arrow itself is created using borders. This will make the tooltip look like a speech bubble.

```

.tooltip1, .tooltip2 {
	position: relative;
	display: inline-block;
	border-bottom: 1px dotted black;
}
/*something ... */
.tooltip2 .tooltiptext2 {
	visibility: hidden;
	width: 120px;
	background-color: black;
	color: #fff;
	text-align: center;
	border-radius: 6px;
	padding: 5px 0;
	position: absolute;
	z-index: 1;
	bottom: 150%;
	left: 50%;
	margin-left: -60px;
}
.tooltip2 .tooltiptext2::after {
	content: "";
	position: absolute;
	top: 100%;
	left: 50%;
	margin-left: -5px;
	border-width: 5px;
	border-style: solid;
	border-color: black transparent transparent transparent;
}
.tooltip2:hover .tooltiptext2 {
	visibility: visible;
}
```

<span style="font-size: 19px;">Example Explained</span>

​	Position the arrow inside the tooltip: <span style="color: red;">top: 100%</span> will place the arrow at the bottom of the tooltip. <span style="color: red;">left: 50%</span> will center the arrow.

<b>Note:</b> The <span style="color: red;">border-width</span> property specifies the size of the arrow. If you change this, also change the <span style="color: red;">margin-left</span> value to the same. This will keep the arrow centered.

The <span style="color: red;">border-color</span> is used to transform the content into an arrow. We set the top borderr to black, and the reset to transparent. If all sides were black, you would end up with a <b>black square box</b>.

## 56.4 Fade In Tooltips (Animation)

​	If you want to fade in the tooltip text when it is about to be visible, you can use the CSS <span style="color: red;">transition</span> property together with the <span style="color: red;">opacity</span> property, and go from being completely invisible to 100% visible, in a number of specified seconds (1 second in our example):

```
.tooltip .tooltiptext {
	opcity: 0;
	transition: opacity 1s;
}
.tooltip:hover .tooltiptext {
	opacity: 1;
}
```



# 57. CSS Styling Images

## 57.1 Rounded Images

​	Use the <span style="color: red;">border-radius</span> property to create rounded images:

```
img {
	border-radius: 50%;	//circle
}
```

## 57.2 Thumbnial Images

​	Use the <span style="color: red;">border</span> property to create thumbnail images.

```
.styleImage {
	border: 1px solid #ddd;
	border-radius: 4px;
	padding: 5px;
	width: 150px;
}
.styleImage:hover {
	box-shadow: 0 0 2px 1px rgba(0, 140, 186, 0.5);
}
<!-- HTML -->
<p>Hover over the image and click on it to see the effect.</p>
<a target="_blank" href="styleImage.jpg">
	<img class="styleImage" src="img/styleImage.jpg" alt="III" style="width: 150px">
</a>
```

## 57.3 Responsive Images

​	Responsive images will automatically adjust to fit the size of the screen.

```
img {
	max-width: 100%;
	height: auto;
}
```

## 57.4 Center an Image

​	To center an image, set left and right margin to <span style="color: red;">auto</span> and make it into a <span style="color: red;">block</span> element:

```
img {
	display: block;
	margin-left: auto;
	margin-right: auto;
	width: 50%;
}
```

## 57.5 Polaroid Images / Cards

​	Refer CSS shadow:

```
div.polaroid {
  width: 80%;
  background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

img {width: 100%}

div.container {
  text-align: center;
  padding: 10px 20px;
}
```

## 57.6 Transparent Image

​	The <span style="color: red;">opacity</span> property can take a value from 0.0 - 1.0. The lower value, the more transparent.

## 57.7 Image Text

 	Refer CSS Position.

## 57.8 Image Filters

​	The CSS <span style="color: red;">filter</span> property adds visual effects (like blur and saturation) to an element.

<b>Note: </b>The filter property is not supported in Internet Explorer or Edge 12.

```
img {
	filter: grayscale(100%);
}
```

## 57.9 Image Hover Overlay

```
div.image-container {
	position: relative;
	width: 20%;
}
img.image-overlay {
	opacity: 1;
	display: block;
	width: 100%;
	height: auto;
	transition: .5s ease;
	backface-visibility: hidden;
}
div.image-overlay {
	transition: .5s ease;
	opacity: 0;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
}
div.image-container:hover div.image-overlay {
	opacity: 1.0;
}
div.image-container:hover img.image-overlay {
	opacity: 0.3;
}
div.image-text {
	background-color: #4CAF50;
	color: white;
	font-size: 16px;
	padding: 16px 32px;
}
<!-- HTML -->
<div class="image-container">
	<img src="img/gallery3.jpg" alt="Girl" class="image-overlay" style="width: 100%;">
	<div class="image-overlay">
		<div class="image-text">A Girl</div>
	</div>
</div>
```

## 57.10 Flip an Image

```
img:hover {
	transform: scaleX(-1);
}
```

## 57.11 Responsive Image Gallery

​	Refer CSS Image Gallery chapter.

```
.responsive {
  padding: 0 6px;
  float: left;
  width: 24.99999%;
}

@media only screen and (max-width: 700px){
  .responsive {
    width: 49.99999%;
    margin: 6px 0;
  }
}

@media only screen and (max-width: 500px){
  .responsive {
    width: 100%;
  }
}
```

## 57.11 Image Modal (Advanced)

​	This is an example to demonstrate how CSS and JavaScript can work together.

First, use CSS to create a modal window (dialog box), and hide it by default.

Then, use a JavaScript to show the modal window and to display the image inside the modal, when a user clicks on the image:

```
#modalImage {border-radius: 5px; cursor: pointer; transition: 0.3s;}
#modalImage: hover {opacity: 0.7;}
.modal {display: none; position: fixed; z-index: 1; padding-top: 100px;
	left: 0; top: 0; width: 100%; height: 100%: overflow: auto; 
	background-	color: rgb(0,0,0); background-color:rgba(0,0,0,0.9);}
.modal-content {margin: auto; display: block; width: 80%; max-width: 700px;}
#modalCaption {margin: auto; display: block; width: 80%; max-width: 700px;
	text-align: center; color: #ccc; padding: 10px 0; height: 150px;}
.modal-content, #modalCaption {animation-name: zoom; 
	animation-duration: 0.6s;}
@keyframes zoom {
	from {transform: scale(0.1)}
	to {transform: scale(1)}
}
.modalClose {position: absolute; top: 15px; right: 35px; color: #f1f1f1;
	font-size: 40px; font-weight: bold; transition: 0.5s;}
.modalClose:hover
.modalClose:focus {color: #bbb; text-decoration: none; cursor: pointer;}
@media only screen and (max-width: 700px) {
	.modal-content {
		width: 100%;
	}
}
<!-- HTML -->
<h3>Image Modal</h3>
<img id="modalImage" src="img/imgbox2.jpg" alt="Image Box" width="300" height="200">
<!-- The Modal -->
<div id="imageModal" class="modal">
	<span class="modalClose">&times;</span>
	<img class="modal-content" id="img01">
	<div id="modalCaption"></div>
</div>
<script>
var modal = document.getElementById('imageModal');

var img = document.getElementById('modalImage');
var modalImg = document.getElementById('img01');
var captionText = document.getElementById('modalCaption');
img.onclick = function () {
	modal.style.display = "block";
	modalImg.src = this.src;
	captionText.innerHTML = this.alt;
}
var span = document.getElementsByClassName("modalClose")[0];
span.onclick = function() {
	modal.style.display = "none";
}
</script>
```





# 58. CSS Image Reflection

## 58.1 CSS Image Reflections

​	The <span style="color: red;">box-reflect</span> property is used to create an image reflection.

​	The value of the <span style="color: red;">box-reflect</span> property can be: <span style="color: red;">below</span>, <span style="color: red;">above</span>, <span style="color: red;">left</span>, or <span style="color: red;">right</span>.

```
img {
	-webkit-box-reflect: below;
}
```

## 58.2 CSS Reflection With Offset

​	To specify the gap between the image and the reflection, add the size of the gap to the <span style="color: red;">box-reflect</span> property.

```
img {
	-webkit-box-reflect: below 20px;
}
```

## 58.2 CSS Reflection With Gradient

​	We can also create a fade-out effect on the reflection.

```
img.imageReflect {
	-webkit-box-reflect: right 20px linear-gradient(to right, rgba(0,0,0,0), rgba(0,0,0,0.4));
}
```



# 59. CSS The object-fit Property

The CSS <span style="color: red;">object-fit</span> property is used to specify how an \<img> or \<video> should be resized to fit its container.

## 59.1 The CSS object-fit Property

​	This property tells the content to fill the container in a variety of ways; such as "preserve that aspect ratio" or "stretch up and take up as much space as possible".

​	If we style a image with another size, it will squished to fit the container, and its original aspect ratio is destroyed.

​	Here is where the <span style="color: red;">object-fit</span> property comes in. The <span style="color: red;">object-fit</span> property can take one of the following values:

* <span style="color: red;">fill</span> - This is default. The image is resized to fill the given dimension. If necessary, the image will be stretched or squished to fit
* <span style="color: red;">contain</span> - The image keeps its aspect ratio, but is resized to fit within the given dimension
* <span style="color: red;">cover</span> - The image keeps its aspect ratio and fills the given dimension. The image will be clipped to fit
* <span style="color: red;">none</span> - The image is not resized
* <span style="color: red;">scale-down</span> - The image is scaled down to the smallest version of <span style="color: red;">none</span> or <span style="color: red;">contain</span>

​	Please practice it!

## 59.2 CSS Object-* Properties

​	The following table lists the CSS object-* properties:

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [object-fit](https://www.w3schools.com/cssref/css3_pr_object-fit.asp) | Specifies how an <img> or <video> should be resized to fit its container |
| [object-position](https://www.w3schools.com/cssref/css3_pr_object-position.asp) | Specifies how an <img> or <video> should be positioned with x/y coordinates inside its "own content box" |



# 60. CSS object-position

​	The CSS <span style="color: red;">object-position</span> property is used to specify how a \<img> or \<video> should be positioned within its container.

## 60.1 Using the object-position Property

​	Let's say that the part of the image that is shown, is not positioned as we want. To position the image, we will use the <span style="color: red;">object-position</span> property (the position the image clipped to fit).



# 61. CSS Masking

​	With CSS masking you create a mask layer to place over an element to partially or fully hide portions of the element.

## 61.1 The CSS mask-image Property

​	The CSS <span style="color: red;">mask-image</span> property specifies a mask layer image.

​	The mask layer image can be a PNG image, an SVG image, a CSS gradient, or and SVG \<mask> element.

## 61.2 Use an Image as the Mask Layer

​	To use a PNG or an SVG image as the mask layer, use a url() value to pass in the mask layer image. The mask image needs to have a transparent or semi-transparent area. Black indicates fully transparent (my tests failed).

```
.mask2 {
	-webkit-mask-image: url("../img/mask.png");
	mask-image: url(../img/w3logo.png);
	-webkit-mask-repeat: no-repeat;
	mask-repeat: no-repeat;
}
.mask3 {
	width: 200px;
	height: 200px;
	background-size: contain;					/*pay attentation*/
	background-image: url("../img/mask.png");	/*worked*/
}
<!-- HTML -->
<h3>Mask Image:</h3>
<p>An image with a mask layer image</p>
<div class="mask2">
	<img src="img/img_5terre.jpg" alt="Cinque Terre" width="600" height="400">
</div>
<div class="mask3"></div>
```

## 61.3 Use Gradients as the Mask Layer

<b>Linear Gradient Example</b>

```
div.mask4 p {
	font-size: 20px;
	padding: 20px;
	color: white;
}
div.mask4 {
	max-width: 600px;
	height: 350px;
	overflow-y: scroll;
	background: url(../img/img_5terre.jpg) no-repeat;
	-webkit-mask-image: linear-gradient(black, transparent);
}
<!-- HTML -->
<div class="mask4">
	<p>The Cinque Terre is a coastal area within Linguria, in th northwest of Italy.
	It lies in the west of La Spezia Province, and comprises five villages: Monterosso al Mare,
	Vernazza, Corniglia, Manarola, and Riomaggiore.</p>
</div>
```

<b>Radial Gradient Example</b>

```
div.mask5 {
	width: 300px;
	height: 200px;
	//-webkit-mask-image: radial-gradient(circle, black 50%, rgba(0, 0, 0, 0.5) 50%);
	-webkit-mask-image: radial-gradient(ellipse, black 50%, rgba(0,0,0,0.5) 50%);
}
<!-- HTML -->
<div class="mask5">
	<img src="img/img_5terre.jpg" alt="Cinque Terre" width="300" height="200" style="margin-left: auto; margin-right: auto; display: block;">
</div>
```

## 61.4 Use SVG as the Mask Layer

​	The SVG <span style="color: red;">\<mask></span> element can be used inside and SVG graphic to create masking effects.

​	Here, we use the SVG \<mask> element to create different mask layers for image:

```
<svg width="600" height="400">
	<mask id="svgmask1">
		<polygon fill="#ffffff" points="200 0, 400 400, 0 400"></polygon>
	</mask>
	<image xmlns:xlink="http://www.w3.org/1999/xlink"
		xlink:href="img/img_5terre.jpg" mask="url(#svgmask1)"></image>
</svg>
```

```
<svg width="600" height="400">
  <mask id="svgmask3">
    <circle fill="#ffffff" cx="75" cy="75" r="75"></circle>
    <circle fill="#ffffff" cx="80" cy="260" r="75"></circle>
    <circle fill="#ffffff" cx="270" cy="160" r="75"></circle>
  </mask>
  <image xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="img_5terre.jpg" mask="url(#svgmask3)"></image>
</svg>
```

## 61.5 CSS Masking Properties

​	The following table lists all the CSS masking properties:

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [mask-image](https://www.w3schools.com/cssref/css3_pr_mask-image.asp) | Specifies an image to be used as a mask layer for an element |
| [mask-mode](https://www.w3schools.com/cssref/css3_pr_mask-mode.asp) | Specifies whether the mask layer image is treated as a luminance mask or as an alpha mask |
| [mask-origin](https://www.w3schools.com/cssref/css3_pr_mask-origin.asp) | Specifies the origin position (the mask position area) of a mask layer image |
| [mask-position](https://www.w3schools.com/cssref/css3_pr_mask-position.asp) | Sets the starting position of a mask layer image (relative to the mask position area) |
| [mask-repeat](https://www.w3schools.com/cssref/css3_pr_mask-repeat.asp) | Specifies how the mask layer image is repeated               |
| [mask-size](https://www.w3schools.com/cssref/css3_pr_mask-size.asp) | Specifies the size of a mask layer image                     |



# 62. CSS Buttons

## 62.1 Basic Button Styling

```
.button {background-color: #4CAF50; border: none; color: white;
	padding: 15px 32px; text-align: center; text-decoration: none;
	display: inline-block; font-size: 16px; margin: 4px 2px;cursor: pointer;
}
<button>Default Button</button>
<a href="#" class="button">Link Button</a>
<button class="button">Button</button>
<input type="button" class="button" value="Input Button">
```

## 62.2 Button Colors

​	Use the <span style="color: red;">background-color</span> property to change the background color of a button.

## 62.3 Button Sizes

​	Use the <span style="color: red;">font-size</span> property to change the font size of a button.

​	Use the <span style="color: red;">padding</span> property to change the padding of a button.

## 62.4 Rounded Buttons

​	Use the <span style="color: red;">border-radius</span> property to add rounded corners to a button.

```
.button {
	background-color: #4CAF50; /* Green */
  	border: none; color: white; padding: 20px; text-align: center;
  	text-decoration: none; display: inline-block; font-size: 16px;
  	margin: 4px 2px; cursor: pointer;}
.button1 {border-radius: 50%;}
```

## 62.5 Colored Button Borders

​	Use the <span style="color: red;">border</span> property to add a colored border to a button.

## 62.6 Hoverable Buttons

​	Use the <span style="color: red;">:hover</span> selector to change the style of a button when you move the mouse over it.

​	<b>Tip:</b> Use the <span style="color: red;">transition-duration</span> property to determine the speed of the "hover" effect.

```
.button { background-color: #4CAF50; /* Green */
	border: none; color: white; padding: 16px 32px; text-align: center;
  	text-decoration: none; display: inline-block; font-size: 16px;
  	margin: 4px 2px; transition-duration: 0.4s; cursor: pointer;}
.button1 {background-color: white; color: black; border: 2px solid #4CAF50; }
.button1:hover {background-color: #4CAF50; color: white;}
.button2 {background-color: white; color: black; border: 2px solid #008CBA;}
.button2:hover {background-color: #008CBA; color: white;}
.button3 {background-color: white; color: black; border: 2px solid #f44336;}
.button3:hover {background-color: #f44336; color: white;}
.button4 {background-color: white; color: black; border: 2px solid #e7e7e7;}
.button4:hover {background-color: #e7e7e7;}
.button5 {background-color: white; color: black; border: 2px solid #555555;}
.button5:hover {background-color: #555555; color: white;}
<!-- HTML -->
<button class="button button1">Green</button>
<button class="button button2">Blue</button>
<button class="button button3">Red</button>
<button class="button button4">Gray</button>
<button class="button button5">Black</button>
```

## 62.7 Shadow Buttons

​	Use the <span style="color: red;">box-shadow</span> property to add shadows to a button:

```
.button1 {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
}
.button2:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
}
```

## 62.8 Disabled Buttons

​	Use the <span style="color: red;">opacity</span> property to add transparency to a button (creates a "disabled" look).

<b>Tip:</b> You can also add the <span style="color: red;">cursor</span> property with a value of "not-allowed", which will display a "no parking sign" when you mouse over the button:

```
.disabled {
	opacity: 0.6;
	cursor: not-allowed;
}
```

## 62.9 Button Width

​	By default, the size of the button is determined by its text content (as wide as its content). Use the <span style="color: red;">width</span> property to change the width of a button.

## 62.10 Button Groups

​	Remove margins and add <span style="color: red;">float:left</span> to each button to create a button group:

```
.button {
	float: left;
}
```

## 62.11 Bordered Button Group

​	Use the <span style="color: red;">border</span> property to create a bordered button group:

```
.button {
	float: left;
	border: 1px solid green;
}
```

## 62.12 Vertical Button Group

​	Use <span style="color: red;">display:block</span> instead of <span style="color: red;">float:left</span> to group the buttons below each other, instead of side by side:

```
.button {
	display: block
}
```

## 62.13 Button on Image

```
.container {position: relative; width: 100%; max-width: 400px;}
.container img {width: 100%; height: auto;}
.container .btn {position: absolute; top: 50%; left: 50%; 
	transform: translate(-50%, -50%); -ms-transform: translate(-50%, -50%);
  	background-color: #f1f1f1; color: black; font-size: 16px;
  	padding: 16px 30px; border: none; cursor: pointer;
  	border-radius: 5px; text-align: center;}
.container .btn:hover {background-color: black; color: white;}
<!-- HTML -->
<div class="container">
  <img src="img_lights.jpg" alt="Snow" style="width:100%">
  <button class="btn">Button</button>
</div>
```

## 62.14 Animated Buttons

1. Example 1:

```
.button span:after {content: '\00bb'; position: absolute; opacity: 0;
  	top: 0; right: -20px; transition: 0.5s;}
.button:hover span {padding-right: 25px;}
.button:hover span:after {opacity: 1; right: 0;}
```

<img src="img/animatedButton1.jpg"> 

2. Example 2:

```
.button:hover {background-color: #3e8e41}
.button:active {background-color: #3e8e41; box-shadow: 0 5px #666;
  	transform: translateY(4px);}
```

<img src="img/animatedButton2.jpg"> 

3. Example 3:

```
.animatedButton3 {position: relative; background-color: #4CAF50;
	border: none; font-size: 28px; color: #ffffff; padding: 20px;
	width: 200px; text-align: center; transition-duration: 0.4s;
	text-decoration: none; overflow: hidden; cursor: pointer;}
.animatedButton3:after {content: ""; background: #f1f1f1; display: block;
	position: absolute; padding-top: 300%; padding-left: 350%;
	margin-left: -20px !important; margin-top: -120%; opacity: 0;
	transition: all 3s;}
.animatedButton3:active:after {padding: 0; margin: 0;
	opacity: 1; transition: 0s;}
<!-- HTML -->
<!-- Add type to avoid a 'submit' -->
<button class="animatedButton3" type="button">Click Me</button>
```



# 63. CSS Pagination

## 63.1 Simple Pagination

​	If you have a website with lots of pages, you may wish to add some sort of pagination to each page:

```
.pagination1 {display: inline-block;}
.pagination1 a {
	color: black;
	float: left;
	padding: 8px 16px;
	text-decoration: none;
}
```

## 63.2 Active and Hoverable Pagination

​	Highlight the current page with an <span style="color: red;">.active</span> class, and use the <span style="color: red;">:hover</span> selector to change the color of each page link when moving the mouse over them:

```
.pagination a.active {
	background-color: #4CAF50;
}
.pagination a:hover:not(.ative) {
	background-color: #ddd;
}
```

​	Add the <span style="color: red;">border-radius</span> property if you want a rounded "active" and "hover" button.

## 63.3 Hoverable Transition Effect

​	Add the <span style="color: red;">transition</span> property to the page links to create a transition effect on hover:

```
.pagination1 {
	display: inline-block;
}
.pagination1 a {
	color: black;
	float: left;
	padding: 8px 16px;
	text-decoration: none;
	transition: background-color .3s;
}
.pagination1 a.pagination1Active {
	background-color: #4CAF50;
	color: white;
}
.pagination1 a:hover:not(.pagination1Active) {
	background-color: #ddd;
}
<!-- HTML -->
<h3>CSS Pagination:</h3>
<div class="pagination1">
	<a href="#">&laquo;</a>
	<a href="#">1</a>
	<a href="#" class="pagination1Active">2</a>
	<a href="#">3</a>
	<a href="#">&raquo;</a>
</div>
```

## 63.4 Bordered & Rounded Pagination

​	Use the <span style="color: red;">border</span> property to add borders to the pagination:

```
.pagination a {
	border: 1px solid #ddd;
}
.pagination a:first-child {
	border-top-left-radius: 5px;
	border-bottom-left-radius: 5px;
}
.pagination a:last-child {
	border-top-right-radius: 5px;
	border-bottom-right-radius: 5px;
}
```

## 63.5 Space Between Links

<b>Tip:</b> Add the <span style="color: red;">margin</span> property if you do not want to group the page links.

## 63.6 Pagination Size & Centered Pagination

​	Change the size of the pagination with the <span style="color: red;">font-size</span> property. To center the pagination, wrap a container element (like \<div>) around it with <span style="color: red;">text-align: center</span>.

```
.pagination1Center {
	text-align: center;
}
<!-- THML -->
<div class="pagination1Center">
<div class="pagination1">
	<a href="#">&laquo;</a>
	<a href="#">1</a>
	<a href="#" class="pagination1Active">2</a>
	<a href="#">3</a>
	<a href="#">&raquo;</a>
</div>
</div>
```

## 63.7 Breadcrumbs

​	Another variation of pagination is so-called "breadcrumbs":

```
ul.breadcrumb {
	padding: 8px 16px;
	list-style: none;
	background-color: #eee;
}
ul.breadcrumb li {
	display: inline;
}
ul.breadcrumb li+li:before {	/*li+: expect for the first one.*/
	padding: 8px;
	color: black;
	content: "/\00a0";
}
ul.breadcrumb li a {
	color: green;
}
<!-- HTML -->
<ul class="breadcrumb">
	<li><a href="#">Home</a></li>
	<li><a href="#">Pictures</a></li>
	<li><a href="#">Summer 15</a></li>
	<li>Italy</li>
</ul>
```



## 64. CSS Multiple Columns

## 64.1 CSS Multi-column Properties

​	In this chapter you will learn about the following multi-column properties:

* <span style="color: red;">column-count</span>
* <span style="color: red;">column-gap</span>
* <span style="color: red;">column-rule-style</span>
* <span style="color: red;">column-rule-width</span>
* <span style="color: red;">column-rule-color</span>
* <span style="color: red;">column-rule</span>
* <span style="color: red;">column-span</span>
* <span style="color: red;">column-width</span>

## 64.2 CSS Create Multiple Columns

​	The <span style="color: red;">column-count</span> property specifies the number of columns an element should be divided into.

```
div.newspaper {
	column-count: 3;
}
```

## 64.3 CSS Specify the Gap Between Columns

​	The <span style="color: red;">column-gap</span> property specifies the gap between the columns.

```
div {
	column-gap: 40px;
}
```

## 64.4 CSS Columns Rules

​	The <span style="color: red;">column-rule-style</span> property specifies the style of the rule between columns.

```
div {
	column-rule-style: solid;
}
```

​	The <span style="color: red;">column-rule-width</span> property specifies the width of the rule between columns.

```
div {
	column-rule-width: 2px;
}
```

​	The <span style="color: red;">column-rule-color</span> property specifies the color of the rule between columns. The <span style="color: red;">column-rule</span> property is a shorthand property for setting all the column-rule-* properties above.

```
div {
	column-rule: 2px solid lightblue;
}
```

## 64.5 Specify How Many Columns an Element Should Span

​	The <span style="color: red;">column-span</span> property specifies how many columns an element should span across (usually used in header).

## 64.6 Specify The Column Width

​	The <span style="color: red;">column-width</span> property specifies a suggested, optimal width for the columns.

```
div {
	column-width: 100px;
}
```

## 64.7 CSS Multi-columns Properties

​	The following table lists all the multi-columns properties:

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [column-count](https://www.w3schools.com/cssref/css3_pr_column-count.asp) | Specifies the number of columns an element should be divided into |
| [column-fill](https://www.w3schools.com/cssref/css3_pr_column-fill.asp) | Specifies how to fill columns                                |
| [column-gap](https://www.w3schools.com/cssref/css3_pr_column-gap.asp) | Specifies the gap between the columns                        |
| [column-rule](https://www.w3schools.com/cssref/css3_pr_column-rule.asp) | A shorthand property for setting all the column-rule-* properties |
| [column-rule-color](https://www.w3schools.com/cssref/css3_pr_column-rule-color.asp) | Specifies the color of the rule between columns              |
| [column-rule-style](https://www.w3schools.com/cssref/css3_pr_column-rule-style.asp) | Specifies the style of the rule between columns              |
| [column-rule-width](https://www.w3schools.com/cssref/css3_pr_column-rule-width.asp) | Specifies the width of the rule between columns              |
| [column-span](https://www.w3schools.com/cssref/css3_pr_column-span.asp) | Specifies how many columns an element should span across     |
| [column-width](https://www.w3schools.com/cssref/css3_pr_column-width.asp) | Specifies a suggested, optimal width for the columns         |
| [columns](https://www.w3schools.com/cssref/css3_pr_columns.asp) | A shorthand property for setting column-width and column-count |



# 65. CSS User Interface

## 65.1 CSS User Interface

​	In this chapter you will learn about the following CSS user interface properties:

* <span style="color: red;">resize</span>
* <span style="color: red;">outline-offset</span>

## 65.2 CSS Resizing

​	The <span style="color: red;">resize</span> property specifies if (and how) an element should be resizable by the user.

```
div {
	resize: horizontal;	/*or vertical, both.*/
	overflow: auto;
}
```

​	In many browsers, \<textarea> is resizable by default. Here, we have used the resize property to disable the resizability:

```
textarea {
	resize: none;
}
```

## 65.3 CSS Outline Offset

​	The <span style="color: red;">outline-offset</span> property adds space between an outline and the edge or border of an element.

<b>Note:</b> Outline differs from borders! Unlike border, the outline is drawn outside the element's border, and may overlap other content. Also, the outline is NOT a part of the element's dimensions; the element's total width and height is not affected by the width of the outline.

```
div.ex1 {margin: 20px; border: 1px solid black; 
	outline: 4px solid red; outline-offset: 15px;}
div.ex2 {margin: 10px; border: 1px solid black;
  	outline: 5px dashed blue; outline-offset: 5px;}
```



# 66. CSS Variables - The var() Function

## 66.1 CSS Variables

​	The <span style="color: red;">var()</span> function is used to insert the value of a CSS variable.

​	CSS variables have access to the DOM, which means that you can create variables with local or global scope, change the variables with JavaScript, and change the variables based on media queries.

​	A good way to use CSS variables is when it comes to the colors of your design. Instead of copy and paste the same colors over and over again, you can place them in variables.

## 66.2 The Traditional Way

​	The following examples shows the traditional way of defining some colors in a style sheet (by defining the colors to use, for each specific element):

```
body {background-color: #qe90ff;}
h2 {border-bottom: 2px solid #1e90ff;}
.container {
	color: #1e90ff;
	background-color: #ffffff;
	padding: 15px;
}
button {
	background-color: #ffffff;
	color: #1e90ff;
	border: 1px solid #1e90ff;
	padding: 5px;
}
```

## 66.3 Syntax of the var() Function

​	The syntax of the<span style="color: red;"> var()</span> function is as follows:

`var(--name, value)`

* name: Required. The variable name (must start with two dashed)
* value: Optional. The fallback value (used if the variable is not found)

## 66.4 How var() Workd

​	First of all: CSS variables can have a global or local scope.

​	Global variables can be accessed/used through the entire document, while local variables can be used only inside the selector where it is declared.

​	To create a variable with global scope, declare it inside the <span style="color: red;">:root</span> selector. The <span style="color: red;">:root</span> selector matches the document's root element.

​	To create a variable with local scope, declare it inside the selector that is going to use it.

​	The following example is equal to the above example, but use the <span style="color: red;">var()</span> function. First, we declare two global variables (--blue and --white). Then, we use the <span style="color: red;">var()</span> function to insert the value of the variables later in the style sheet:

```
:root {
	--blue: #1e90ff;
	--white: #ffffff;
}
body {background-color: var(--blue);}
h2 {border-bottom: 2px solid var(--blue);}
.container {
	color: var(--blue);	
	background-color: var(--white);
	padding: 15px;
}
button {
	background-color: var(--white);
	color: var(--blue);
	border: 1px solid var(--blue);
	padding: 5px;
}
```

Advantages of using var() are:

* makes the code easier to read (more understandable)
* makes it much easier to change the color values

## 66.5 Override Global Variable With Local Variable

​	Sometimes we want the variable to change only in a specific section of the page.

​	Assume we want a different color of blue for button elements. Then, we can re-declare the --blue variable inside the button selector. When we use var(--blue) inside this selector, it will use the local --blue variable value declared here.

```
button {
	--blue: #0000ff;
	background-color: var(--white);
	color: var(--blue);
	border: 1px solid var(--blue);
	padding: 5px;
}
```

## 66.6 Add a New Local Variable

​	If a variable is to be used at only one single place, we could also have declared a new local variable, like this:

```
button {
	--button-blue: #0000ff;
	background-color: var(--white);
	color: var(--button-blue);
	border: 1px solid var(--button-blue);
	padding: 5px;
}
```

## 66.7 CSS Change Variables With JavaScript

​	CSS variables have access to the DOM, which means that you can change them with JavaScript.

​	Here is an example of how you can create a script to display and change the --blue variable from the example used in the previous pages. For now, do not worry if you are not familiar with JavaScript. You can learn more about JavaScript in JavaScript Tutorial.

```
:root {
	--blue: #1e90ff;
}
.varContainer {
	color: var(--blue);
}
<!-- HTML -->
<h3>Change Variables With JS</h3>
<div class="varContainer">
	Pay attention to its color...
</div>
<button type="button" onclick="myFunction_get()">Get CSS Variable with JS</button>
<button type="button" onclick="myFunction_set()">Change CSS Variable with JS</button>
<script>
var r = document.querySelector(':root');
function myFunction_get() {
	var rs = getComputedStyle(r);
	alert("The value of --blue is: " + rs.getPropertyValue('--blue'));
}
function myFunction_set() {
	r.style.setProperty('--blue', 'lightblue');
}
</script>
```

## 66.8 CSS Using Variables in Media Queries

​	Now we want to change a variable value inside a media query.

<b>Tip:</b> Media Queries are about defining different styles rules for different devices (scrrens, tablets, mobile phones, etc.). You can learn more Media Queries in Media Queries Chapter.

​	Here, we first declare a new local variable named --fontsize for the <span style="color: red;">container</span> class. We set its value to 25 pixels. Then we use it in the <span style="color: red;">.container</span> class further down. Then, we create a <span style="color: red;">@media</span> rule that says "When the browser's width is 450px or wider, change the --fontsize variable value of the <span style="color: red;">.container</span> class to 50px."

```
.mediaContainer {
	--fontsize: 30px;
	color: var(--blue);
	background-color: var(--white);
	padding: 15px;
	font-size: var(--fontsize);
}
@media screen and (min-width: 450px) {
	.mediaContainer {
		--fontsize: 10px;
	}
}
<!-- THML -->
<p style="font-size: 10px;">Here is font-size: 10px</p>
<div class="mediaContainer">
	<p>When browser's width is less than 450px, the font-size is 30px, or font-szie if 10px.</p>
</div>
```


# 67. CSS Box Sizing

## 67.1 CSS Box Sizing

​	The CSS <span style="color: red;">box-sizing</span> property allows us to include the padding and border in an element's <span style="color: red;">total width and height</span>!

## 67.2 Without the CSS box-sizing Property

​	By default, the width and height of an element is calculated like this:

width + padding + border = actual width of an element

height + padding + border = actual height of an element

​	This means: When you set the width/height of an element, the element often appears bigger than you have set (because the element's border and padding are added to the element's specified width/height):

```
.div1 {
  	width: 300px;
  	height: 100px;
  	border: 1px solid blue;
}
.div2 {
  	width: 300px;
  	height: 100px;
  	padding: 50px;
  	border: 1px solid red;
}
```

## 67.3 With the CSS box-sizing Property

​	If you set <span style="color: red;">box-sizing: border-box;</span> on an element, padding and border are included in the width and height.

​	The code below ensures that all elements are sized in this intuitive way. Many browsers already use <span style="color: red;">box-sizing: border-box;</span> for many form elements (but not all - which is why inputs and text areas look different at width: 100%;).

```
* {
	box-sizing: border-box;
}
```



# 68. CSS Media Queries

## 68.1 CSS2 Introduced Media Types

​	The <span style="color: red;">@media</span> rule, introduced in CSS2, made it possible to define different style rules for different media types.

​	Examples: You can have one set of style rules for computer screens, one for printers, one for handheld, one for television-type devices, and so on.

​	Unfortunately these media types never got a lot of support by devices, other than the print media type.

## 68.2 CSS3 Introduced Media Queries

​	Media queries in CSS3 extended the CSS2 media types idea: Instead of looking for a type of device, they look at the capability of the device.

​	Media queries can be used to check many things, such as:

* width and height of th viewport
* width and height of the device
* orientation (is the tablet/phone in landscape or portrait mode?)
* resolution

​	Using media queries are a popular technique for delivering a tailored style sheet to desktops, laptops, tablets, and mobile phones (such as iPhone and Android phones).

## 68.2 Media Query Syntax

​	A media query consists of a media type and can contain one or more expressions, which resolve to either true or false.

```
@media not|only mediatype and (expressions) {
	CSS-Code;
}
```

​	The result of the query is true if the specified media type matches the type of device the document is being displayed on and all expressions in the media query are true. When a media query is true, the corresponding style sheet or style rules are applied, following the normal cascading rules.

​	Unless you use the not or only operators, the media type is optional and the <span style="color: red;">all</span> type will be implied.

​	You can also have different stylesheets for different media:

```
<link rel="stylesheet" media="mediatype and|not|only (expressions)" href="print.css">
```

## 68.3 CSS3 Media Types

| Value  | Description                                           |
| :----- | :---------------------------------------------------- |
| all    | Used for all media type devices                       |
| print  | Used for printers                                     |
| screen | Used for computer screens, tablets, smart-phones etc. |
| speech | Used for screenreaders that "reads" the page out loud |

## 68.4 Media Queries Simple Examples

​	One way to use media queries is to have an alternate CSS section right inside your style sheet.

​	The following example changes the background-color to lightgreen if the viewport is 480 pixels wide or wider (if the viewport is less than 480 pixels, the background-color will be pink):

```
@media screen and (min-width: 480px) {
	body {
		background-color: lightgreen;
	}
}
```

​	The following example shows a menu that will float to the left of the page if the viewport is 480 pixels wide or wider (if the viewport is less than 480px, the menu will be on top of the content):

```
.wrapper {overflow: auto;}
#maintext {margin-left: 4px;}
#leftsidebar {float: none; width: auto;}
#menulist {margin: 0; padding: 0;}
.menuitem {
	background: #cdf0f6;
	border: 1px solid #d4d4d4;
	border-radius: 4px;
	list-style-type: none;
	margin: 4px;
	padding: 2px;
}
@media screen and (min-width: 480px) {
	#leftsidebar {width: 200px; float: left;
	#maintext {margin-left: 216px;}
}
<!-- HTML -->
<h3>CSS Media Queries:</h3>
<div class="wrapper">
	<div id="leftsidebar">
		<ul id="menulist">
			<li class="menuitem">2023</li>
			<li class="menuitem">April</li>
			<li class="menuitem">10, Mon.</li>
			<li class="menuitem">Library</li>
			<li class="menuitem">floor 2</li>
			<li class="menuitem">zone c, 372.</li>
		</ul>
	</div>
	<div id="maintext">
		<h1>Resize the browser window to see the effect!</h1>
	</div>
</div>
```

## 68.5 CSS MQ Examples

​	Please refer the directory 'mediaQuery'.



# 69. CSS Flexbox

## 69.1 CSS Flexbox Layout Module

​	Before the Flexbox Layout module, there were four layout modes:

* Block, for sections in a webpage
* Inline, for text
* Table, for two-dimensional table data
* Positioned, for explicit position of an element

​	The Flexible Box Layout Module, makes it easier to design flexible responsive layout structure without using float or positioning.

## 69.2 Flexbox Elements

​	To start using the Flexbox model, you need to first define a flex container.

​	The element below represents a flex container (the blue area) with three flex items:

```
.flex-container {
	display: flex;
	background-color: DodgerBlue;
}
.flex-container > div {
	background-color: #f1f1f1;
	margin: 10px;
	padding: 20px;
	font-size: 30px;
}
<!-- HTML -->
<div class="flex-container">
	<div>1</div>
	<div>2</div>
	<div>3</div>
</div>
```

## 69.3 CSS Flex Container

### 69.3.1 Parent Element (Container)

​	Like we specified in the previous chapter, this is a flex <b>container</b> (the blue area) with three flex <b>items</b>. The flex container becomes flexible by setting the <span style="color: red;">display</span> property to <span style="color: red;">flex</span>. The flex container properties are:

* <span style="color: red;">flex-direction</span>
* <span style="color: red;">flex-wrap</span>
* <span style="color: red;">flex-flow</span>
* <span style="color: red;">justify-content</span>
* <span style="color: red;">align-items</span>
* <span style="color: red;">align-content</span>

## 69.3.2 The flex-direction Property

​	The <span style="color: red;">flex-direction</span> property defines in which direction the container wants to stack the flex items.

```
.flex-container {
	display: flex;
	flex-direction: column;	/*or row, row-reverse, column-reverse*/
}
```

### 69.3.3 The flex-wrap Property

​	The <span style="color: red;">flex-wrap</span> property specifies whether the flex items should wrap or not.

​	The value can be wrap, nowrap, and wrap-reverse. Practice it.

### 69.3.4 The flex-flow Property

​	The <span style="color: red;">flex-flow</span> property is a shorthand property for setting both the <span style="color: red;">flex-direction</span> and <span style="color: red;">flex-wrap</span> properties.

```
.flex-container {
	display: flex;
	flex-flow: row wrap;
}
```

### 69.3.5 The justify-content Property

​	The <span style="color: red;">justify-content</span> property is used to align the flex item, this property value can be:

center, flex-start, flex-end, space-around, space-between.

### 69.3.6 The align-items Property

​	The <span style="color: red;">align-items</span> property is used to align the flex items (content). It can be:

center, flex-start, flex-end, stretch, baseline.

### 69.3.7 The align-content Property

​	The <span style="color: red;">align-content</span> property is used to align the flex lines. It can be:

space-between, space-around, stretch, center, flex-start, flex-end.

### 69.3.8 Perfect Centering

```
.flex-container {
  display: flex;
  height: 300px;
  justify-content: center;
  align-items: center;
}
```

### 69.3.9 The CSS Flexbox Container Properties

​	The following table lists all the CSS Flexbox container properties:

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [align-content](https://www.w3schools.com/cssref/css3_pr_align-content.asp) | Modifies the behavior of the flex-wrap property. It is similar to align-items, but instead of aligning flex items, it aligns flex lines |
| [align-items](https://www.w3schools.com/cssref/css3_pr_align-items.asp) | Vertically aligns the flex items when the items do not use all available space on the cross-axis |
| [display](https://www.w3schools.com/cssref/pr_class_display.asp) | Specifies the type of box used for an HTML element           |
| [flex-direction](https://www.w3schools.com/cssref/css3_pr_flex-direction.asp) | Specifies the direction of the flexible items inside a flex container |
| [flex-flow](https://www.w3schools.com/cssref/css3_pr_flex-flow.asp) | A shorthand property for flex-direction and flex-wrap        |
| [flex-wrap](https://www.w3schools.com/cssref/css3_pr_flex-wrap.asp) | Specifies whether the flex items should wrap or not, if there is not enough room for them on one flex line |
| [justify-content](https://www.w3schools.com/cssref/css3_pr_justify-content.asp) | Horizontally aligns the flex items when the items do not use all available space on the main-axis |

## 69.4 CSS Flex Items

### 69.4.1 Child Elements (Items)	

​	The direct child elements of a flex container automatically becomes flexible (flex) items.

​	The flex item properties are:

-  <span style="color: red;">order</span>
- <span style="color: red;">flex-grow</span>
- <span style="color: red;">flex-shrink</span>
- <span style="color: red;">flex-basis</span>
- <span style="color: red;">flex</span>
- <span style="color: red;">align-self</span>

### 69.4.2 The Order Property

​	The <span style="color: red;">order</span> property specifies the order of the flex items.

​	The order value must be a number, default value is 0:

```
<div class="flex-container">
	<div style="order: 3">1</div>
	<div style="order: 1">2</div>
	<div style="order: 2">3</div>
</div>
```

### 69.4.3 The flex-grow Property

​	The <span style="color: red;">flex-grow</span> property specifies how much a flex item will grow relative to the rest of the flex items.

```
<div class="flex-container">
	<div style="flex-grow: 1">1</div>
	<div style="flex-grow: 8">2</div>	<!-- grow eight times faster-->
</div>
```

### 69.4.4 The flex-shrink Property

​	The <span style="color: red;">flex-shrink</span> property specifies how much a flex item will shrink relative to the rest of the flex items. The default value is 1.

```
<div class="flex-container">
  <div>1</div>
  <div>2</div>
  <div style="flex-shrink: 0">3</div>	<!-- Will be larger -->
  <div>4</div>
  <div>5</div>
</div>
```

### 69.4.5 The flex-basis Property

​	The <span style="color: red;">flex-basis</span> property specifies the initial length of a flex item.

```
<div class="flex-container">
  <div>1</div>
  <div>2</div>
  <div style="flex-basis: 200px">3</div>
  <div>4</div>
</div>
```

### 69.4.6 The flex Property

​	The <span style="color: red;">flex</span> property is a shorthand property for the <span style="color: red;">flex-grow</span>, <span style="color: red;">flex-shrink</span>, and <span style="color: red;">flex-basis</span> properties.

```
<div class="flex-container">
  <div>1</div>
  <div>2</div>
  <div style="flex: 0 0 200px">3</div>
  <div>4</div>
</div>
```

### 69.4.7 The align-self Property

​	The <span style="color: red;">align-self</span> property specifies the alignment for the selected item inside the flexible contaienr.

​	The <span style="color: red;">align-self</span> property overrides the default alignment set by the container's <span style="color: red;">align-items</span> property.

```
.flex-container2 {
	display: flex;
	height: 200px;
	background-color: #f1f1f1;
}
.flex-container2 > div {
	background-color: DodgerBlue;
	color: white;
	width: 100px;
	margin: 10px;
	text-align: center;
	line-height: 75px;
	font-size: 30px;
}
<!-- HTML -->
<div class="flex-container2">
	<div>1</div>
	<div style="align-self: flex-start;">2</div>
	<div style="align-self: flex-end">3</div>
	<div>4</div>
</div>
```

### 69.4.8 The CSS Flexbox Items Properties

​	The following table lists all the CSS Flexbox Items properteis:

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [align-self](https://www.w3schools.com/cssref/css3_pr_align-self.asp) | Specifies the alignment for a flex item (overrides the flex container's align-items property) |
| [flex](https://www.w3schools.com/cssref/css3_pr_flex.asp)    | A shorthand property for the flex-grow, flex-shrink, and the flex-basis properties |
| [flex-basis](https://www.w3schools.com/cssref/css3_pr_flex-basis.asp) | Specifies the initial length of a flex item                  |
| [flex-grow](https://www.w3schools.com/cssref/css3_pr_flex-grow.asp) | Specifies how much a flex item will grow relative to the rest of the flex items inside the same container |
| [flex-shrink](https://www.w3schools.com/cssref/css3_pr_flex-shrink.asp) | Specifies how much a flex item will shrink relative to the rest of the flex items inside the same container |
| [order](https://www.w3schools.com/cssref/css3_pr_order.asp)  | Specifies the order of the flex items inside the same container |

## 69.5 CSS Flex Responsive

### 69.5.1 Responsive Flexbox

​	You learned from the CSS Media Queries chapter that you can use media queries to create different layouts for different screen sizes and devices.

​	For example, if you want to create a two-column layout for most screen sizes, and a one-column layout for small screen sizes (such as phones and tablets), you can change the <span style="color: red;">flex-direction</span> form <span style="color: red;">row</span> to <span style="color: red;">column</span> at a specific breakpoint:

```
.flex-container {
  display: flex;
  flex-direction: row;
}

/* Responsive layout - makes a one column layout instead of a two-column layout */
@media (max-width: 800px) {
  .flex-container {
    flex-direction: column;
  }
}
```

​	Another way is to change the percentage of the <span style="color: red;">flex</span> property of the flex items to create different layouts for different screen sizes. Note that we also have to include <span style="color: red;">flex-wrap: wrap;</span> on the flex container for this example to work:

```
.flex-container {
  display: flex;
  flex-wrap: wrap;
}
.flex-item-left {
  flex: 50%;
}
.flex-item-right {
  flex: 50%;
}
/* Responsive layout - makes a one column layout instead of a two-column layout */
@media (max-width: 800px) {
  .flex-item-right, .flex-item-left {
    flex: 100%;
  }
}
```

### 69.5.2 Responsive Image Gallery using Flexbox

​	Use flexbox to create a responsive image gallery that varies between four, two or full-width images, depending on screen size:

```
.row {
  display: flex;
  flex-wrap: wrap;
  padding: 0 4px;
}
/* Create four equal columns that sits next to each other */
.column {
  flex: 25%;
  max-width: 25%;
  padding: 0 4px;
}
.column img {
  margin-top: 8px;
  vertical-align: middle;
}
/* Responsive layout - makes a two column-layout instead of four columns */
@media (max-width: 800px) {
  .column {
    flex: 50%;
    max-width: 50%;
  }
}
```

### 69.5.3 Responsive Website using Flexbox

```
.fb-navbar {display: flex; background-color: #333;}
.fb-navbar a {color: white; padding: 14px 20px;
	text-decoration: none; text-align: center;}
.fb-navbar a:hover {background-color: #ddd; color: black;}
.fb-row {display: flex; flex-wrap: wrap;}
.fb-side {flex: 30%; background-color: #f1f1f1; padding: 20px;}
.fb-main {flex: 70%; background: white; padding: 20px;}
.fb-fakeimg {background-color: #aaa; width: 100%; padding: 20px;}
@media screen and (max-width: 700px) {
	.fb-row, .fb-navbar {
		flex-direction: column;
	}
}
<!-- HTML -->
<div class="fb-navbar">
	<a href="#">Link 1</a>
	<a href="#">Link 1</a>
	<a href="#">Link 1</a>
</div>
<div class="fb-row">
	<div class="fb-side">
		<h2>About me</h2>
		<h5>Photo of me:</h5>
		<div class="fb-fakeimg" style="height: 200px;">Image</div>
		<h3>More text</h3>
		<div class="fb-fakeimg" style="height: 60px;">Image</div>
		<div class="fb-fakeimg" style="height: 60px;">Image</div>
		<div class="fb-fakeimg" style="height: 60px;">Image</div>
	</div>
	<div class="fb-main">
		<h2>TITLE HEADING</h2>
		<div class="fb-fakeimg" style="height: 200px;">Image</div>
	</div>
</div>
```



# 70. CSS Grid

​	The CSS Grid Layout Module offers a grid-based layout system, with rows and columns,, making it easier to design web pages without having to use floats and positioning. Refer the  tutorials when necessary.

<b>All CSS Grid Properties</b>

| Property                                                     | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [column-gap](https://www.w3schools.com/cssref/css3_pr_column-gap.asp) | Specifies the gap between the columns                        |
| [gap](https://www.w3schools.com/cssref/css3_pr_gap.asp)      | A shorthand property for the *row-gap* and the *column-gap* properties |
| [grid](https://www.w3schools.com/cssref/pr_grid.asp)         | A shorthand property for the *grid-template-rows, grid-template-columns, grid-template-areas, grid-auto-rows, grid-auto-columns*, and the *grid-auto-flow* properties |
| [grid-area](https://www.w3schools.com/cssref/pr_grid-area.asp) | Either specifies a name for the grid item, or this property is a shorthand property for the *grid-row-start*, *grid-column-start*, *grid-row-end*, and *grid-column-end* properties |
| [grid-auto-columns](https://www.w3schools.com/cssref/pr_grid-auto-columns.asp) | Specifies a default column size                              |
| [grid-auto-flow](https://www.w3schools.com/cssref/pr_grid-auto-flow.asp) | Specifies how auto-placed items are inserted in the grid     |
| [grid-auto-rows](https://www.w3schools.com/cssref/pr_grid-auto-rows.asp) | Specifies a default row size                                 |
| [grid-column](https://www.w3schools.com/cssref/pr_grid-column.asp) | A shorthand property for the *grid-column-start* and the *grid-column-end* properties |
| [grid-column-end](https://www.w3schools.com/cssref/pr_grid-column-end.asp) | Specifies where to end the grid item                         |
| [grid-column-gap](https://www.w3schools.com/cssref/pr_grid-column-gap.asp) | Specifies the size of the gap between columns                |
| [grid-column-start](https://www.w3schools.com/cssref/pr_grid-column-start.asp) | Specifies where to start the grid item                       |
| [grid-gap](https://www.w3schools.com/cssref/pr_grid-gap.asp) | A shorthand property for the *grid-row-gap* and *grid-column-gap* properties |
| [grid-row](https://www.w3schools.com/cssref/pr_grid-row.asp) | A shorthand property for the *grid-row-start* and the *grid-row-end* properties |
| [grid-row-end](https://www.w3schools.com/cssref/pr_grid-row-end.asp) | Specifies where to end the grid item                         |
| [grid-row-gap](https://www.w3schools.com/cssref/pr_grid-row-gap.asp) | Specifies the size of the gap between rows                   |
| [grid-row-start](https://www.w3schools.com/cssref/pr_grid-row-start.asp) | Specifies where to start the grid item                       |
| [grid-template](https://www.w3schools.com/cssref/pr_grid-template.asp) | A shorthand property for the *grid-template-rows*, *grid-template-columns* and *grid-areas* properties |
| [grid-template-areas](https://www.w3schools.com/cssref/pr_grid-template-areas.asp) | Specifies how to display columns and rows, using named grid items |
| [grid-template-columns](https://www.w3schools.com/cssref/pr_grid-template-columns.asp) | Specifies the size of the columns, and how many columns in a grid layout |
| [grid-template-rows](https://www.w3schools.com/cssref/pr_grid-template-rows.asp) | Specifies the size of the rows in a grid layout              |
| [row-gap](https://www.w3schools.com/cssref/css3_pr_row-gap.asp) | Specifies the gap between the grid rows                      |



# 71. Responsive Website Design (RWD) Frameworks

## 71.1 W3.CSS

## 71.2 Bootstrap

​	Please refer the documents.

20:32, April 10, 2023. Library floor 2 zone c, 372.
