# 1. JavaScript Function Definition

​	JavaScript functions are <b>defined</b> with the <span style="color: red;">function</span> keyword.

​	You can use a function <b>declaration</b> or a function <b>expression</b>.

## 1.1 Function Declarations

​	Earlier in this tutorial, you learned that functions are <b>declared</b> with the following syntax:

```
function functionName(parameters) {
	//...
}
```

​	Declared functions are not executed immediately. They are "saved for later use", and will be executed later, when they are invoked (called upon):

```
function myFunction(a, b) {
	return a * b;
}
```

​	<b>Note:</b> Semicolons are used to separate executable JavaScript statements.

​		Since a function <b>declaration</b> is not an executable statement, it is not common to end it with a semicolon.

## 1.2 Function Expressions

​	A JavaScript function can also be defined using an <b>expression</b>.

​	A function expression can be stored in a variable:

```
const x = function (a, b) {return a * b};
```

​	After a function expression has been stored in a variable, the variable can be used as a function:

```
let z = x(4, 3);	//12
```

​	The function above is actually an <b>anonymous function</b> (a function without a name).

​	Functions stored in variable do not need function names. They are always invoked (called) using the variable name.

<b>Note:</b> The function above ends with a semicolon because it's a part of an executable statement.

## 1.3 The Function() Constructor

​	As you have seen in previous examples, JavaScript functions are defined with the <span style="color: red;">function</span> keyword.

​	Functions can also be defined with a built-in JavaScript function constructor called <span style="color: red;">Function()</span>.

```
const myFunction = new Function("a", "b", "return a * b");
let x = myFunction(5, 6);	//30
```

​	You actually don't have to use the function constructor. The example above is the same as writing:

```
const myFunction = function (a, b) {return a * b};;
```

## 1.4 Function Hoisting

​	Hoisting is JavaScript's default behavior of moving <b>declarations</b> to the top of the current scope.

​	Hoisting applies to variable declarations and to function declarations.

​	Because of this, JavaScript functions can be called before they are declared:

```
myFunction(5);
function myFunction(y) {
	return y * y;
}
```

<b>Note:</b> Functions defined using an expression are not hoisted.

## 1.5 Self-Invoking Functions

​	Function expressions can be made "self-invoking".

​	A self-invoking expression is invoked (started) automatically, without being called.

​	Function expressions will execute automatically if the expression is followed by ().

​	You cannot self-invoke a function declaration. And you have to add parentheses around the function to indicate that it is a function expression:

```
(function () {
	document.getElementById("demo").innerHTML = "Hello";
})();
```

​	The function above is actually an <b>anonymous self-invoking function</b>.

## 1.6 Functions Can Be Used as Values

```
let x = myFunction(4, 3);		//12
let x = myFunction(4, 5) * 2;	//40
```

## 1.7 Functions are Objects

​	The <span style="color: red;">typeof</span> operator in JavaScript returns "function" for functions. But, JavaScript functions can best be described as objects.

​	JavaScript functions have both <b>properties</b> and <b>methods</b>. The <span style="color: red;">arguments.length</span> property returns the number of arguments received when the function was invoked:

```
function myFunction(a, b) {
	return arguments.length;
}
```

​	The <span style="color: red;">toString()</span> method returns the function as a string:

```
let text = myFunction.toString();
```

<b>Note:</b>

​	A function defined as the property of an object, is called a <b>method</b> to the object.

​	A function defined to create new objects, is called an <b>object constructor</b>.

## 1.8 Arrow Functions

​	Arrow functions allow a short syntax for writing function expressions.

​	You don't need the <span style="color: red;">function</span> keyword, the <span style="color: red;">return</span> keyword, and the <b>curly brackets</b>.

```
const x = (x, y) => x * y;
```

​	1. Arrow functions do not have their own <span style="color: red;">this</span>. They are not well suited for defining <b>object methods</b>. 

	2. Arrow functions are not hoisted. They must be defined <b>before</b> they are used.
	2. Using <span style="color: red;">const</span> is safer than using <span style="color: red;">var</span>, because a function expression is always constant value.
	2. You can only omit the <span style="color: red;">return</span> keyword and the curly brackets if the function is a single statement, because of this, it might be a good habit to always keep them:

```
const x = (x, y) =>{ return x * y }; 
```



# 2. JavaScript Function Parameters

​	A JavaScript <span style="color: red;">function</span> does not perform any checking on parameter values (arguments).

## 2.1 Function Parameters and Arguments

​	Earlier in this tutorial, you learned that functions can have parameters:

```
function functionName(parameter1, parameter2, parameter3) {
	//...
}
```

## 2.2 Parameter Rules

1. JavaScript function definitions do not specify data types for parameters.
2. JavaScript functions do not perform type checking on the passed arguments.
3. JavaScript functions do not check the number of arguments received.

## 2.3 Default Parameters

​	If a function is called with <b>missing arguments</b> (less than declared), the missing values are set to <span style="color: red;">undefined</span>.

​	Sometimes this is acceptable, but sometimes it is better to assign a default value to the parameter:

```
function myFunction(x, y) {
	if (y === undefined) {
		y = 2;
	}
}
```

​	ES6 allows function parameters to have default values:

```
function myFunction(x, y = 2) {
	return x * y;
}
```

## 2.4 Function Rest Parameter

​	The rest parameter (...) allows a function to treat an indefinite number of arguments as an array:

```
function sum(...args) {
	let sum = 0;
	for(let arg of args) sum += arg;
	return sum;
}
let x = sum(4, 4.6, 7, 19, 2, 9, 1.8);
```

## 2.5 The Arguments Object

​	JavaScript functions have a built-in object called the arguments object.

​	The arguments object contains an array of the argument used when the functions was called.

​	This way you can simply use a function to find (for instance) the highest value in a list of numbers:

```
x = findMax(1, 34, 29, 88, 60);
function findMax() {
	let max = -Infinity;
	for(let i = 0; i < arguments.length; i++) {
		if(arguments[i] > max) {
			max = arguments[i];
		}
	}
	return max;
}
```

<b>Note:</b> If a function is called with <b>too many arguments</b> (more than declared), these arguments can be reached using <b>the argument object</b>.

## 2.6 Arguments are Passed by Value

​	The parameter, in a function call, are the function's arguments.

​	JavaScript argument are passed by <b>value</b>: The function only gets to know the values, not the argument's locations.

​	If a function changes an argument's value, it does not change the parameter's original value. Changes to arguments are not visible (reflected) outside the function.

## 2.7 Objects are Passed by Reference

​	Because of this, if a function changes an object property, it changes the original value.



# 3. JavaScript Function Invocation

## 3.1 Invoking a JavaScript Function

* The code inside a function is not executed when the function is <b>defined</b>.
* The code inside a function is executed when the function is <b>invoked</b>.
* It is common to use the term "<b>call a function</b>" instead of "<b>invoke a function</b>".
* It is also common to say "call upon a function", "start a function", or "execute a function".
* In this tutorial, we will use <b>invoke</b>, because a JavaScript function can be invoked without being called.

## 3.2 Invoking a Function as a Function

```
function myFunction(x, y) {
	//...
}
myFunction(1, 2);
```

​	The function above does not belong to any object. But in JavaScript there is always a default global object. In HTML the default global object is the HTML page itself, so the function above "belongs" to the HTML page.

​	In a browser the page object is the browser window. The function above automatically becomes a window function.

<b>Note:</b>

​	This is a common way to invoke a JavaScript function, but not a very good practive.

​	Global variables, methods, or functions can easily create name conflicts and bugs in the global object.

```
myFunction(1, 2);
window.myFunction(1, 2);	//They are the same function
```

## 3.3 The Global object

​	When a function is called without an owner object, the value of <span style="color: red;">this</span> <span style="color: blue;">becomes the global object</span>.

​	In a web browser the global object is the browser window.	This example returns the window object as the value of <span style="color: red;">this</span>:

```
let x = myFunction();	//[object Window]
functioon myFunction() {
	return this;
}
```

## 3.4 Invoking a Function as a Method

​	In JavaScript you can define functions as object methods.

​	The following example creates an object (<b>myObject</b>), with two properties (<b>firstName</b> and <b>lastName</b>), and a method (<b>fullName</b>):

```
const myObject = {
	firstName: "John",
	lastName:"Doe",
	fullName: function() {
		return this.firstName + " " + this.lastName;	//this: [object Object]
	}
}
myObject.fullName();
```

​	The <b>fullName</b> belongs to the object, <b>myObject</b> is the owner of the function.

## 3.5 Invoking a Function with a Function Constructor

​	If a function invocation is preceded with the <span style="color: red;">new</span> keyword, it is a constructor invocation.

​	It looks like you create a new function, but since JavaScript functions are objects you actually create a new object:

```
function myFunction(arg1, arg2) {
	this.firstName = arg1;
	this.lastName = arg2;
}
const myObj = new myFunction("John", "Doe");
myObj.firstName;			//"John"
```

<b>Note:</b> A constructor invocation creates a new object. The new object inherits the properties and methods from its constructor.

​	The <span style="color: red;">this</span> keyword in the constructor does not have a value, the value of <span style="color: red;">this</span> will be the new object created when the function is invoked !!



# 4. JavaScript Function call()

​	With the <span style="color: red;">call()</span> method, you can write a method that can be used on different objects.

## 4.1 All Functions are Methods

​	If a function is not a method of a JavaScript object, it is a function of the global object !!

## 4.2 The JavaScript call() Method

​	The <span style="color: red;">call()</span> method is a predefined JavaScript method.

​	It can be used to invoke (call) a method with an owner object as an argument (parameter).

<b>Note:</b> In brief, with <span style="color: red;">call()</span>, an object can use a method belonging to another object.

​	This example calls the <b>fullName</b> method of person, using it on <b>person1</b>:

```
const person = {
	fullName: function() {
		return this.firstName + " " + this.lastName;
	}
}
const person1 = {
	firstName: "John",
	lastName: "Doe"
}
person.fullName.call(person1);	//"John Doe"
```

## 4.3 The call() Method with Arguments

​	The <span style="color: red;">call()</span> method can accept arguments:

```
const person = {
	fullName: function(city, country) {
		return this.firstName + " " + this.lastName + "," + city + "," + country;
	}
}
const person1 = {
	firstName: "Biden",
	lastName: "Joe"
}
person.fullName.call(person1, "Washington", "US");
```



# 5. JavaScript Function apply()

## 5.1 Method Reuse

​	With the <span style="color: red;">apply()</span> method, you can written a method that can be used on different objects.

## 5.2 The JavaScript apply() Method

​	The <span style="color: red;">apply()</span> method is similar to the <span style="color: red;">call()</span> method.

​	In this example the <b>fullName</b> method of <b>person</b> is <b>applied</b> on <b>person1</b>:

```
const person = {
  fullName: function() {
    return this.firstName + " " + this.lastName;
  }
}

const person1 = {
  firstName: "Mary",
  lastName: "Doe"
}

// This will return "Mary Doe":
person.fullName.apply(person1);		//"John Doe"
```

## 5.3 The Difference Between call() and apply()

​	The difference is:

​	The <span style="color: red;">call()</span> method takes arguments separately.

​	The <span style="color: red;">apply()</span> method takes arguments as an array.

<b>Note:</b> The apply() method is very handy if you want to use an array instead of an argument list.

## 5.4 The apply() Method with Arguments

```
const person = {
  fullName: function(city, country) {
    return this.firstName + " " + this.lastName + "," + city + "," + country;
  }
}

const person1 = {
  firstName:"John",
  lastName: "Doe"
}
//The apply() method accepts arguments in an array.
person.fullName.apply(person1, ["Oslo", "Norway"]);
```

## 5.5 Simulate a Max Method on Arrays

​	You can find the largest number (in a list of numbers) using the <span style="color: red;">Math.max()</span> method:

```
Math.max(1,2,3);
```

​	Since JavaScript <b>arrays</b> do not have a max() method, you can apply the <span style="color: red;">Math.max()</span> method instead:

```
Math.max.apply(null, [1,2,3]);
```

​	The first argument (null) does not matter. It is not used in this example.

​	These examples will give the same result:

```
Math.max.apply(Math, [1,2,3]);
Math.max.apply("", [1,2,3]);
Math.max.apply(0, [1,2,3]);
```

## 5.6 JavaScript Strict Mode

​	In JavaScript strict mode, if the first argument of the <span style="color: red;">apply()</span> method is not an object, it becomes the owner (object) of the invoked function. In "non-strict" mode, it becomes the global object.



# 6. JavaScript Function bind()

## 6.1 Function Borrowing

​	With the <span style="color: red;">bind()</span> method, an object can borrow a method from another object.

​	The example below creates 2 objects (person and member).

​	The member object borrows the fullname method from the person object:

```
const person = {
	firstName:"John",
	lastName:"Doe",
	fullName: function() {
		return this.firstName + " " + this.lastName;
	}
}
const member = {
	firstName:"Hege",
	lastName:"Nilsen",
}
let fullName = person.fullName.bind(member);
```

## 6.2 Preserving this

​	Sometimes the <span style="color: red;">bind()</span> method has to be <span style="color: blue;">used to prevent losing</span> <b>this</b>.

​	In the following example, the person object has a display method. In the display method, <b>this</b> refers to the person object:

```
const person = {
	firstName:"John",
	lastName:"Doe",
	display: function() {
		let x = document.getElementById("demo");
		x.innerHTML = this.firstName + " " + this.lastName;
	}
}
person.display();
```

​	When a function is used as a callback, <b>this</b> is lost.

​	This example will try to display the person name after 3 seconds, but it will display <b>undefined</b> instead:

```
setTimeout(person.display, 3000);
```

​	The <span style="color: red;">bind()</span> method solves this problem.

​	In the following example, the <span style="color: red;">bind()</span> method is used to bind person.display to person.

​	This example will display the person name after 3 seconds:

```
let display = person.display.bind(person);
setTimeout(display, 3000);
```



# 7. JavaScript Closures

​	JavaScript variables can belong to the <b>local</b> or <b>global</b> scope.

​	Global variables can be mode local (private) with <b>closures</b>.

## 7.1 Global Variables

​	A <span style="color: red;">function</span> can access all variables defined <b>inside</b> the function, like this:

```
function myFunction() {
	let a = 4;
	return a * a;
}
```

​	But a <span style="color: red;">function</span> can also access variables defined <b>outside</b> the function, like this:

```
let a = 4;
function myFunction() {
	return a * a;
}
```

​	Global variables belong to the page, and can be used (and changed) by all other scripts in the page.

<b>Note:</b>

​	Variables created <b>without</b> a declaration keyword (<span style="color: red;">var</span>, <span style="color: red;">let</span>, or <span style="color: red;">const</span>) are always global, even if they are created inside a function.

## 7.2 Variable Lifetime

​	Global variables live until the page is discarded, like when you navigate to another page or close the window.

​	Local variables have short lives. They are created when the function is invoked, and deleted when the function is finished.

## 7.3 A Counter Dilemma & JavaScript Nested Functions

​	Suppose you want to use a variable for counting something, and you want this counter to be available to all functions.

​	You could use a global variable, and a <span style="color: red;">function</span> to increase the counter:

```
let counter = 0;
function add() {
	counter += 1;
}
add();
add();
//...
```

​	There is a problem with the solution above: Any code on the page can change the counter, without calling add().

​	The counter should be local to the <span style="color: red;">add()</span> function, to prevent other code from changing it:

```
let counter = 0;
function add() {
	let counter = 0;
	counter += 1;
}
add();	
add();	
//...
```

​	Above code did not work for we display the global counter instead of the local one.

​	We can remove the global counter and access the local counter by letting the function return it:

```
function add() {
	let counter = 0;
	counter += 1;
	return counter;
}
add();
add();
//...
```

​	It also didn't work because we reset the local counter every time we call the function.

<b>We'd like a C code  'static' property, here, a JavaScript inner function can solve this.</b>

 	All functions have access to the global scope.

​	In fact, in JavaScript, all functions have access to the scope "above" them.

​	JS supports nested functions, in this example, the inner function <span style="color: red;">plus()</span> has access to the <span style="color: red;">counter</span> variable in the parent function:

```
function add() {
	let counter = 0;
	function plus() {counter += 1};
	plus();
	return counter;
}
```

​	This could have solved the counter dilemma, if we could reach the <span style="color: red;">plus()</span> function from the outside. We also need to find a way to execute <span style="color: red;">counter = 0;</span> only once. Here <b>we need a closure</b>.

## 7.4 JavaScript Closures

​	Remember self-invoking functions? 

```
const add = (function() {
	let counter = 0;
	return function() {counter += 1; return counter;}
})();
add();
add();
//...
```

​	The variable <span style="color: red;">add</span> is assigned to the return value of a self-invoking function. The self-invoking function only runs once. It sets the counter to zero, and returns a function expression.

​	This way add becomes a function, the "wonderful" part is that it can access the counter in ther parent scope. This is called a JavaScript <b>closure</b>. It makes it possible for a function to have "<b>private</b>" variables.

​	The counter is protected by the scope of the anonymous function, and can only be changed using the add function.

<b>Note:</b>

​	<span style="color: blue;"> A closure is a function having access to the parent scope, even after the parent function has close</span>.



<span style="color: red;">