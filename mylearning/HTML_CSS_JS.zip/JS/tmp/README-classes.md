# 1. JavaScript Classes

​	ECMAScript 2015, also known as ES6, introudced JavaScript Classes.

​	JavaScript Classed are templates for JavaScript Objects.

## 1.1 JavaScript Class Syntax

​	Use the keyword <span style="color: red;">class</span> to create a class. Always add a method named <span style="color: red;">constructor()</span>:

Syntax:

```
class ClassName {
	constructor() {...}
}
```

Example:

```
class Car {
	constructor(name, year) {
		this.name = name;
		this.year = year;
	}
}
```

​	The example above creates a class named "Car". The class has two initial properties: "name" and "year".

<b>Note:</b>

​	A JavaScript class is <b>NOT</b> an object. It is a <b>template</b> for JavaScript objects.

## 1.2 Using a Class

​	When you have a class, you can use the class to create objects:

```
const myCar1 = new Car("Ford", 2018);
const myCar2 = new Car("Audi", 2020);
```

<b>Note:</b> The constructor method is called automatically when a new object is created.

## 1.3 The Constructor Method

​	The constructor method is a special method:

* It has to have the exact name "constructor"
* It is expected automatically when a new object is created
* It is used to initialize object properties

​	If you do not define a constructor method, JavaScript will add an empty constructor method.

## 1.4 Class Methods

​	Class methods are created with the same syntax as object methods.

​	Use the keyword <span style="color: red;">class</span> to create a class. Always add a <span style="color: red;">constructor()</span> method. Then add any number of methods.

​	The syntax in classes must be written in "strict mode", you will get an error if you do not follow the "strict mode" rules.

```
class Car {
	constructor(name, year) {
		this.name = name;
		this.year = year;
	}
	age() {
		date = new Date();		//Should be const date = new Date();
		return date.getFullYear() - this.year;
	}
}
```

​	Refer the README-base.md



# 2. JavaScript Class Inheritance

## 2.1  Class Inheritance

​	To create a class inheritance, use the <span style="color: red;">extends</span> keyword.

​	A class created with a class inheritance inherits all the method from another class:

```
class Car {
	constructor(brand) {
		this.carname = brand;
	}
	present() {
		return 'I have a '  + this.carname;
	}
}
class BYD extends Car {
	constructor(brand, mod) {
		super(brand);		//Pay attention to here
		this.model = mod;
	}
	show() {
		return this.present() + ', it is a ' + this.model;
	}
}
let myCar = new BYD("BYD", "han");
document.getElementById("demo").innerHTML = myCar.show();
```

​	The <span style="color: red;">super()</span> method refers to the parent class; By calling the <span style="color: red;">super()</span> method in the constructor, we call the parent constructor method and gets access to the parent's properties and methods.

## 2.2 Getters and Setters

​	Classes also allows you to use getters and setters.

​	It can be smart to use getters and setters for your properties, especially if you want to do something special with the value before returning them, or before you set them.

​	To add getters and setters in the class, use the <span style="color: red;">get</span> and <span style="color: red;">set</span> keywords:

```
//Create a getter and a setter for the "carname" property:
class Car {
	constructor(brand) {
		this.carname = brand;
	}
	get cnam() {
		return this.carname;
	}
	set cnam(x) {
		this.carname = x;
	}
}
const myCar = new Car("BYD");
document.getElementById("demo").innerHTML = myCar.cnam;
```

<b>Note:</b> Even if the getter is a method, you do not use parentheses when you want to get the property value.

​	The name of the getter/setter method cannot be the same as the name of the property, in this case <span style="color: red;">carname</span>.

​	Many programmers use an underscore character _ before the property name to separate the getter/setter from the actual property:

```
class Car {
	constructor(brand) {
		this._carname = brand;
	}
	get carname() {
		return this._carname;
	}
	set carname(x) {
		this._carname = x;
	}
}
```

​	To use a setter, use the same syntax as when you set a property value, without parentheses:

```
const myCar = new Car("BYD");
myCar.carname = "HAN";
```

## 2.3 Hoisting

​	Unlike functions, and other JavaScript declarations, class declarations are not hoisted.

​	That means you must declare a class before you can use it:

```
myCar = new Car("BYD");	//raise an error
class Car {
	constructor() {
		//...
	}
}
```



# 3. JavaScript Static Methods

​	Static class methods are defined on the class itself.

​	You cannot call a <span style="color: red;">static</span> method on an object, only on an object class.

Example:

```
class Car {
	constructor(name) {
		this.name = name;
	}
	static hello() {
		return "Hello!!";
	}
}
const myCar = new Car("BYD");
//You can call 'hello()' on the Car class:
document.getElementById("demo").innerHTML = Car.hello();
//But NOT on a Car object:
document.getElementById("demo").innerHTML = myCar.hello();	//error
```

 	If you want to  use the myCar object inside the <span style="color: red;">static</span> method, you can send it as a parameter:

```
document.getElementById("demo").innerHTML = Car.hello(myCar);
```

​	Please practice it, you will see something interesting!

Sun, April 14, 2013. 19:46.