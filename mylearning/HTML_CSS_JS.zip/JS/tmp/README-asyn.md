# 1. JavaScript Callbacks

 <p style="text-align: center; font-size: 20px">"I will call back later!"</p>

<p style="text-align: center;">A callback is a function passed as an argument to another function</p>

<p style="text-align: center;">This technique allows a function to call another function</p>

<p style="text-align: center;">A callback function can run after another function has finished</p>

## 1.1 Function Sequence

​	JavaScript functions are executed in the sequence they are called. Not in the sequence they are defined.

​	This example will end up displaying "Goodbye" (you wouldn't see the "Hello" displayed):

```
function myFirst() {
	myDisplayer("Hello");
}
function mySecond() {
	myDisplay("Goodbye");
}
myFirst();
mySecond();
```

## 1.2 Sequence Control

​	Sometimes you would like to have better control over when to execute a function.

​	Suppose you want to do a calculation, and then display the result.

​	You could call a calculator function ( <span style="color: red;">myCalculator</span>), save the result, and then call another function ( <span style="color: red;">myDisplayer</span>) to display the result:

```
function myDisplayer(some) {
	document.getElementById("demo").innerHTML = some;
}
function myCalculator(num1, num2) {
	let sum = num1 + num2;
	return sum;
}
let result = myCalculator(5, 6);
myDisplay(result);
```

​	Or, you could call a calculator function (<span style="color: red;">myCalculator</span>), and let the calculator function call the display function(<span style="color: red;">myDisplayer</span>):

```
function myCalculator(num1, num2) {
	myDisplayer(num1 + num2);
}
myCalculator(5, 6);
```

​	The problem with the first example above, is that you have to call two functions to display the result.

​	The problem with the second example, is that you cannot prevent the calculator function from displaying the result.

​	Now it is time to bring in a callback.

## 1.3 JavaScript Callbacks

​	A callback is a function passed as an argument to another function.

​	Using a callback, you could call the calculator function (<span style="color: red;">myCalculator</span>) with a callback (<span style="color: red;">myCallback</span>), and let the calculator function run the callback after the calculation is finished:

```
function myDisplayer(some) {
	document.getElementById("demo").innerHTML = some;
}
function myCalculator(num1, num2, myCallback) {
	let sum = sum1 + sum2;
	myCallback(sum);
}
myCalculator(5, 6, myDisplayer);
```

<b>Note:</b> When you pass a function as a argument, remember not to use parentheses.

​	Another example:

```
// Create an Array
const myNumbers = [4, 1, -20, -7, 5, 9, -6];
// Call removeNeg with a callback
const posNumbers = removeNeg(myNumbers, (x) => x >= 0);
// Display Result
document.getElementById("demo").innerHTML = posNumbers;
// Keep only positive numbers
function removeNeg(numbers, callback) {
  const myArray = [];
  for (const x of numbers) {
    if (callback(x)) {
      myArray.push(x);
    }
  }
  return myArray;
}
```

​	In the example above, <span style="color: red;">(x) => x >= 0 </span> is a <b>callback function</b>.

## 1.4 When to Use a Callback?

​	The examples above are not very exciting. They are simplified to teach you the callback syntax.

​	Where callbacks really shine are in asynchronous functions, where one function has to wait for another function (like waiting for a file to load).



# 2. Asynchronous JavaScript 

 <p style="text-align: center; font-size: 20px">"I will finish later!"</p>

<p style="text-align: center;">Functions running in <b>parallel</b> with other functions are called <b>asynchronous</b></p>

<p style="text-align: center;">A good example is JavaScript setTimeout()</p>

## 2.1 Asynchronous JavaScript

​	The example used in the previous chapter, was very simplified.	

​	In the real world, callbacks are most often used with asynchronous functions.

## 2.2 Waiting for a Timeout

​	When using the JavaScript function  <span style="color: red;">setTimeout()</span>, you can specify a callback function to be executed on time-out:

```
setTimeout(myFunction, 3000);
function myFunction() {
	document.getElementById("demo").innerHTML = "I love you !!";
}
```

​	In the above, <span style="color: red;">myFunction</span> is used as a callback. Instead of passing the name of a function as an argument to another function, you can always pass a whole function instead:

```
setTimeout(function() {myFunction("I love you !!");}, 3000);
function myFunction(value) {
	document.getElementById("demo").innerHTML = value;
}
```

## 2.3 Waiting for Intervals:

​	When using the JavaScript function <span style="color: red;">setInterval()</span>, you can specify a callback function to be executed for each interval:

```
setInterval(myFunction, 1000);
function myFunction() {
	let d = new Date();
	document.getElementById("demo").innerHTML = d.getHours() + ":" +
		d.getMinutes() + ":" +
		d.getSeconds();
}
```

## 2.4 Callback Alternatives

​	With asynchronous programming, JavaScript programs can start long-running tasks, and continue running other tasks in parallel.

​	But, asynchronous programs are difficult to write and difficult to debug.

​	Because of this, most modern asynchronous JavaScript methods don't use callbacks. Instead, in JavaScript, asynchronous programming is solved using <b>Promises</b> instead !!



# 3. JavaScript Promises

 <p style="text-align: center; font-size: 20px">"I Promise a Result!"</p>

<p style="text-align: center;">"Producing code" is code that can take some time</p>

<p style="text-align: center;">"Consuming code" is code that must wait for the result</p>

<p style="text-align: center;">A promise is a JavaScript object that links producing code and consuming code</p>

## 3.1 JavaScript Promise Object

​	A JavaScript Promise object contains both the producing code and calls to the consuming code:

```
//Producing code
let myPromise = new Promise(function(myResolve, myReject) {
	myResolve();	//when successful
	myReject();		//when error
});
//Consuming code
myPromise.then(
	function(value) {//code for success},
	function(error) {//code for failure}
);
```

​	When the producing code obtains the result, it should call one of the two callbacks:

| Result  | Call                    |
| :------ | :---------------------- |
| Success | myResolve(result value) |
| Error   | myReject(error object)  |

## 3.2 Promise Object Properties

​	A JavaScript Promise object can be:

* Pending
* Fulfilled
* Rejected

​	The Promise object supports two properties: <b>state</b> and <b>result</b>.

​	While a Promise object is "pending" (working), the result is undefined.

​	When a Promise object is "fulfilled", the result is a value.

​	When a Promise object is "rejected", the result is an error object.

| myPromise.state | myPromise.result |
| :-------------- | :--------------- |
| "pending"       | undefined        |
| "fulfilled"     | a result value   |
| "rejected"      | an error object  |

<b>Note:</b> You cannot access the Promise properties <b>state</b> and <b>result</b>.

​	You must use a Promise method to handle promises.

## 3.3 Promise How To

​	Here is how to use a Promise:

```
myPromise.then(
	function(value) {//code for success},
	function(value) {//code for failure}
);
```

<b>Note:</b> Promise.then() takes two arguments, a callback for success and another for failure.

​	Both are optional, so you can add a callback for success or failure only.

```
function myDisplayer(some) {
  document.getElementById("demo").innerHTML = some;
}

let myPromise = new Promise(function(myResolve, myReject) {
  let x = 0;

// The producing code (this may take some time)

  if (x == 0) {
    myResolve("OK");
  } else {
    myReject("Error");
  }
});

myPromise.then(
  function(value) {myDisplayer(value);},
  function(error) {myDisplayer(error);}
);
```

## 3.4 JavaScript Promise Examples

​	To demonstrate the use of promises, we will use the callback examples from the previous chapter:

* Waiting for a Timeout
* Waiting for a File

### 3.4.1 Waiting for a Timeout

```
let myPromise = new Promise(function(myResolve, myReject) {
	setTimeout(function(){ myResolve("I love you !!");}, 3000);
});
myPromise.then(function(value) {
	document.getElementById("demo").innerHTML = value;
});
```

## 3.4.2 Waiting for a file

Example using callback (request failed):

```
function myDisplayer(some) {
	document.getElementById("demo").innerHTML = some;
}
function getFile(myCallback) {
	let req = new XMLHttpRequest();
	//req.open('GET', "mycar.html");	or write in below
	req.onload = function() {
		if(req.status == 200) {
			myCallback(this.responseText);	//or req.responseText
		} else {
			myCallback("Error: " + req.status);
		}
	}
	req.open('GET', "mycar.html");
	req.send();
}
getFile(myDisplayer);
```

Example using Promise (not succeed in my test ):

```
function myDisplayer22(some) {
	document.getElementById("demo22").innerHTML = some;
}
function getFile(myCallback) {
	let req = new XMLHttpRequest();
	//req.open('GET', "http://localhost:8080/E:/exper-now/计算机大杂烩/course_parallel_computer_architecture_and_programming/competetions/mygithubwebpage/my_learning/JS/mycar.html");	//or write in below
	//req.open('GET',"mycar.html");
	req.onload = function() {
		if(req.status == 200) {
			myCallback(this.responseText);	//or req.responseText
		} else {
			myCallback("Error: " + req.status);
		}
	}
	req.open('GET', "https://www.w3schools.com/js/mycar.html");
	req.send();
}
getFile(myDisplayer22);
```



# 4. JavaScript Async

 <p style="text-align: center; font-size: 20px">"async and await make promises easier to write"</p>

<p style="text-align: center;"><b>async</b> makes a function return a Promise</p>

<p style="text-align: center;"><b>await</b> makes a function wait for a Promise</p>

## 4.1 Async Syntax

​	The keyword <span style="color: red;">async</span> before a function makes the function return a promise:

```
async function myFunction() {
	return "Hello";
}
```

​	Is the same as:

```
function myFunction() {
	return Promise.resolve("Hello");
}
```

​	This example return Hello (if success):

```
function myDisplayer(some) {
  document.getElementById("demo").innerHTML = some;
}
//The return will be used as the argument to myDisplayer()
async function myFunction() {return "Hello";}

myFunction().then(
  function(value) {myDisplayer(value);},
  function(error) {myDisplayer(error);}
);
```

## 4.2 Await Syntax

​	The <span style="color:red;">await</span> keyword can only be used inside an <span style="color:red;">async</span> function.

​	The <span style="color:red;">await</span> keyword makes the function pause the execution and wait for a resolved promise before it continues:

```
let value = await promise;
```

Example:

```
async function myDisplay() {
  let myPromise = new Promise(function(resolve, reject) {	//can omit the reject
    resolve("I love You !!");
  });
  document.getElementById("demo").innerHTML = await myPromise;
}

myDisplay();
```

Waiting for a Timeout

```
async function myDisplay() {
  let myPromise = new Promise(function(resolve) {
    setTimeout(function() {resolve("I love You !!");}, 3000);
  });
  document.getElementById("demo").innerHTML = await myPromise;
}

myDisplay();
```

Waiting for a File

```
async function getFile() {
  let myPromise = new Promise(function(resolve) {
    let req = new XMLHttpRequest();
    req.open('GET', "mycar.html");
    req.onload = function() {
      if (req.status == 200) {
        resolve(req.response);
      } else {
        resolve("File not Found");
      }
    };
    req.send();
  });
  document.getElementById("demo").innerHTML = await myPromise;
}

getFile();
```

Sun, April 16, 2023. 21:21. Library.

