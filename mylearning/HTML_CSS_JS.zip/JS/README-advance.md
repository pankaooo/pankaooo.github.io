# 1. JavaScript Objects

​	In JavaScript, objects are king. If you understand objects, you understand JavaScript.

​	In JavaScript, almost "everything" is an object.

* Booleans can be objects (if defined with the <span style="color: red;">new</span> keyword)
* Numbers can be objects (if defined with the <span style="color: red;">new</span> keyword)
* Strings can be objects (if defined with the <span style="color: red;">new</span> keyword)
* Dates are always objects
* Maths are always objects
* Regular expressions are always objects
* Array are always objects
* Functions are always objects
* Objects are always objects

​	All JavaScript values, except primitives, are objects.

## 1.1 JavaScript Primitives

​	A <b>primitive value</b> is a value that has no properties or methods.

​	<b>3.14</b> is a primitive value. A <b>primitive data type</b> is data that has a primitive value.

​	JavaScript defines 7 types of primitive data types:

* <span style="color: red;">string</span>
* <span style="color: red;">number</span>
* <span style="color: red;">boolean</span>
* <span style="color: red;">null</span>
* <span style="color: red;">undefined</span>
* <span style="color: red;">symbol</span>
* <span style="color: red;">bigint</span>

<b>Immutable</b>

​	Primitive values are immutable (they are hardcoded and cannot be changed).

​	if x = 3.14, you can change the value of x, bu you cannot change the value of 3.14.

| Value     | Type          | Comment                       |
| :-------- | :------------ | :---------------------------- |
| "Hello"   | string        | "Hello" is always "Hello"     |
| 3.14      | number        | 3.14 is always 3.14           |
| true      | boolean       | true is always true           |
| false     | boolean       | false is always false         |
| null      | null (object) | null is always null           |
| undefined | undefined     | undefined is always undefined |

## 1.2 Objects are Variables

​	JavaScript variables can contain single values:

```
let person = "John  Doe";
```

​	JavaScript variables can also contain many values. Objects are variables too, but they can contain many values. Object values are written as <b>name: value</b> pairs (name and value separated by a colon):

```
let person = {firstName:"John", lastName:"Doe", age:50};
```

​	It is a common practice to declare objects with the <span style="color: red;">const</span> keyword.

## 1.3 Object Properties

​	The named values, in JavaScript objects, are called <b>proerties</b>.

| Property  | Value |
| :-------- | :---- |
| firstName | John  |
| lastName  | Doe   |
| age       | 50    |
| eyeColor  | blue  |

​	Objects written as name value pairs are similar to:

* Associative arrays in PHP
* Dictionaries in Python
* Hash tables in C
* Hash maps in Java
* Hashes in Ruby and Perl

## 1.4 Object Methods

​	Methods are <b>actions</b> that can be performed on objects.

​	Object properties can be both primitive values, other objects, and functions.

​	An <b>object method</b> is an object property containing a <b>function definition</b>.

| Property  | Value                                                     |
| :-------- | :-------------------------------------------------------- |
| firstName | John                                                      |
| lastName  | Doe                                                       |
| age       | 50                                                        |
| eyeColor  | blue                                                      |
| fullName  | function() {return this.firstName + " " + this.lastName;} |

## 1.5 Creating a JavaScript Object

​	With JavaScript, you can define and create your own objects.

​	There are different ways to create new objects:

* Create a single object, using an object literal.
* Create a single object, with the keyword <span style="color: red;">new</span>.
* Define an object constructor, and then create objects of the constructed type.
* Create an object using <span style="color: red;">Object.create()</span>.

## 1.6 JavaScript Objects are Mutable

​	Objects are mutable: They are addressed by reference, not by value.

​	If person is an object, the following statement will not create a copy of person:

```
const x = person;	//x is same to person
```

​	The object x is <b>not a copy</b> of person. It <b>is</b> person. Both x and person are the same object.

​	Any changes to x will also change person:

```
x.age = 20;
person.age;	//20
```



# 2. JavaScript Object Properties

## 2.1 JavaScript Properties

​	Properties are the values associated with a JavaScript object.

​	A JavaScript object is a collection of unordered properties.

​	Properties can usually be changed, added, and deleted, but some are read only.

## 2.2 Accessing JavaScript Properties

​	The syntax for accessing the property of an object is:

```
objectName.property;
```

​	or:

```
objectName["property"];
```

​	or:

```
objectName[expression];	//expression must evaluate to a property name
```

## 2.3 JavaScript for...in Loop

​	The JavaScript <span style="color: red;">for...in</span> statement loops through the properties of an object.

<b>Syntax</b>

```
for (let variable in object) {
	//...
}
```

​	The block of code inside the <span style="color: red;">for...in</span> loop will be executed once for each property.

## 2.4 Adding New Properties

​	You can add new properties to an existing object by simply giving it a value.

​	Assume that the person object already exists - you can then give it new properties:

```
person.nationality = "English";
```

## 2.5 Deleting Properties

​	The <span style="color: red;">delete</span> keyword deletes a property from an object:

```
const person = {
	firstName: "John",
	//...
};
delete person.firstName;
//or:
delete person["firstName"];
```

​	The <span style="color: red;">delete</span> keyword deletes both the value of the property and the property itself. After deletion, the property cannot be used before it is added back again. The <span style="color: red;">delete</span> has no effect on variables or functions, and should not be used on predefined JavaScript object properties (it can crash your application).

## 2.6 Nested Objects

​	Values in an object can be another object:

```
myObj = {
	name: "John",
	cars: {
		car1:"Ford",
		car2: "BYD"
	}
};
```

​	You can access nested objects using the dot notation or the bracket notation:

```
myObj.cars.car2;
myObj.cars["car2"];
myObj["cars"]["car2"];
```

## 2.7 Nested Array and Objects

​	Values in object can be arrays, and values in arrays can be objects:

```
const myObj = {
  name: "John",
  age: 30,
  cars: [
    {name:"Ford", models:["Fiesta", "Focus", "Mustang"]},
    {name:"BMW", models:["320", "X3", "X5"]},
    {name:"Fiat", models:["500", "Panda"]}
  ]
}
```

​	To access arrays inside arrays, use a for-in loop for each array:

```
for(let i in myObj.cars) {
	x += "<h1>" + myObj.cars[i].name + "</h1>";
	for (let j in myObjs.cars[i].models) {
		x += myObj.cars[i].models[j];
	}
}
```

## 2.8 Property Attributes 

​	All properties have a name. In addition they also have a value.

​	The value is one of the property's attributes. Other attributes are: enumerable, configurable, and writable.

​	These attributes define how the property can be accessed (is it readable?, is it writable?)

​	In JavaScript, all attributes can be read, but only the value attribute can be changed (and only if the property is writable).

## 2.9 Prototype Properties

​	JavaScript objects inherit the properties of their prototype.

​	The <span style="color: red;">delete</span> keyword does not delete inherited properties, but if you delete a prototype property, it will affect all objects inherited from the prototype.



# 3. JavaScript Object Methods

```
const person = {
	firstName: "John",
	lastName: "Doe",
	id: 5566,
	fullName: function() {
		return this.firstName + " " + this.lastName;
	}
};
```

## 3.1 What is this?

​	In JavaScript, the <span style="color: red;">this</span> keyword refers to an <b>object</b>.

​	<b>Which</b> object depends on how <span style="color: red;">this</span> is being invoked (used or called). Refer README-base.md.

## 3.2 Adding a Method to an Object

​	Adding a new method to an object is easy:

```
person.name = function() {
	//...
}
```

## 3.3 Using Built-In Methods

​	This example uses the <span style="color: red;">toUpperCase()</span> method of the String object, to convert a text to uppercase:

```
let message = "Heelo World";
let x = message.toUpperCase();		//message is automatically convert to an object (?)
person.name = function() {
	return (this.firsName + " " + this.lastName).toUpperCase();
}
```



# 4. JavaScript Display Objects

## 4.1 How to Display JavaScript Objects?

​	Displaying a JavaScript object will output <b>[object Object]</b>.

```
const person = {
	name: "John",
	age: 20,
	city: "New York"
};
document.getElementById("demo").innerHTML = person;
```

​	Some common solutions to display JavaScript objects are:

* Displaying the Object Properties by name
* Displaying the Object Properties in a Loop
* Displaying the Object using Object.values()
* Displaying the Object using JSON.stringify()

## 4.2 Displaying Object Properties

​	The properties of an object can be displayed as a string:

```
const person = {
  name: "John",
  age: 30,
  city: "New York"
};

document.getElementById("demo").innerHTML =
person.name + "," + person.age + "," + person.city;
```

## 4.3 Displaying the Object in a Loop

​	The properties of an object can be collected in a loop:

```
const person = {
  name: "John",
  age: 30,
  city: "New York"
};
let txt = "";
for (let x in person) {
txt += person[x] + " ";
};
document.getElementById("demo").innerHTML = txt;
```

<b>Note:</b> You must use <b>person[x]</b> in the loop. <b>person.x</b> will not word (Because <b>x</b> is a variable).

## 4.4 Using Object.values()

​	Any JavaScript object can be converted to an array using <span style="color: red;">Object.values()</span>.

```
const person = {
  name: "John",
  age: 30,
  city: "New York"
};
const myArray = Object.values(person);
document.getElementById("demo").innerHTML = myArray;	//John,20,New York
```

## 4.5 Using JSON.stringify()

​	Any JavaScript object can be stringified (converted to a string) with the JavaScript function: <span style="color: red;">JSON.stringify()</span>:

```
const person = {
	name: "John",
	age: 30,
	city: "New York"
};
let myString = JSON.stringify(person); //{"name":"John","age":30,"city":"New York"}  -- JSON notation
```

## 4.6 Stringify Dates

​	<span style="color: red;">JSON.stringify</span> converts dates into strings:

```
const person = {
  name: "John",
  today: new Date()
};

let myString = JSON.stringify(person);
document.getElementById("demo").innerHTML = myString;	//{"name":"John","today":"2023-04-15T13:34:12.685Z"}
```

## 4.7 Stringify Functions

​	<span style="color: red;">JSON.stringify</span> will not stringify functions:

```
const person = {
  name: "John",
  age: function () {return 30;}
};

document.getElementById("demo").innerHTML = JSON.stringify(person);
//{"name":"John"}
```

​	To display the function, convert the functions into strings:

```
const person = {
  name: "John",
  age: function () {return 30;}
};
person.age = person.age.toString();		//!!
document.getElementById("demo").innerHTML = JSON.stringify(person);
//{"name":"John","age":"function () {return 30;}"}
```

## 4.8 Stringify Arrays

​	It is also possible to stringify JavaScript arrays:

```
const arr = ["John", "Peter"];
let myString = JSON.stringify(arr);	//["John", "Peter"]	-- JSON notation
```



# 5. JavaScript Object Accessors

## 5.1 JavaScript Accessors (Getter and Setters)

​	ECMAScript 5 (ES5 2009) introduced Getter and Setter.

​	Getters and setters allow you to define Object Accessors (Computed Properties).

## 5.2 JavaScript Getter (The get Keyword)

​	This example uses <span style="color: red;">lang</span> property tot <span style="color: red;">get</span> the value of the <span style="color: red;">language</span> property:

```
const person = {
	firstName: "John",
	lastName: "Doe",
	language: "en",
	get lang() {
		return this.language;
	}
};
document.getElementById("demo").innerHTML = person.lang;
```

## 5.3 JavaScript Setter (The set Keyword)

​	This example uses a <span style="color: red;">lang</span> property to <span style="color: red;">set</span> the value of the <span style="color: red;">language</span> property:

```
const person = {
	firstName: "John",
	lastName: "Doe",
	language: "",
	set lang(lang) {
		this.language = lang;
	}
};
person.lang = "en";			//person.language === "en"
```

## 5.4 JavaScript Function or Getter?

```
const person = {
  firstName: "John",
  lastName: "Doe",
  fullName: function() {
    return this.firstName + " " + this.lastName;
  }
};
// Display data from the object using a method:
document.getElementById("demo").innerHTML = person.fullName();

//getter:
const person = {
  firstName: "John",
  lastName: "Doe",
  get fullName() {
    return this.firstName + " " + this.lastName;
  }
};
// Display data from the object using a getter:
document.getElementById("demo").innerHTML = person.fullName;
```

<b>Data Quality</b>

​	JavaScript can secure better data quality when using getters and setters.

​	Using the <span style="color: red;">lang</span> property, in this example, returns the value of the <span style="color: red;">language</span> property in upper case:

```
// Create an object:
const person = {
  firstName: "John",
  lastName: "Doe",
  language: "en",
  get lang() {
    return this.language.toUpperCase();
  }
};
// Display data from the object using a getter:
document.getElementById("demo").innerHTML = person.lang;
```

​	Using the <span style="color: red;">lang</span> property, in this example, stores an upper case value in the  <span style="color: red;">language</span> property:

```
const person = {
  firstName: "John",
  lastName: "Doe",
  language: "",
  set lang(lang) {
    this.language = lang.toUpperCase();
  }
};
// Set an object property using a setter:
person.lang = "en";
// Display data from the object:
document.getElementById("demo").innerHTML = person.language;
```

<b>Why Using Getters and Setters?</b>

* It gives simple syntax
* It allow equal syntax for properties and methods
* It can secure better data quality
* It is useful for dong things behind-the-scenes

## 5.5 Object.defineProperty()

​	The <span style="color: red;">Object.defineProperty()</span> method can also be used to add Getters and Setters:

```
// Define object
const obj = {counter : 0};

// Define setters and getters
Object.defineProperty(obj, "reset", {
  get : function () {this.counter = 0;}
});
Object.defineProperty(obj, "increment", {
  get : function () {this.counter++;}
});
Object.defineProperty(obj, "decrement", {
  get : function () {this.counter--;}
});
Object.defineProperty(obj, "add", {
  set : function (value) {this.counter += value;}
});
Object.defineProperty(obj, "subtract", {
  set : function (value) {this.counter -= value;}
});

// Play with the counter:
obj.reset;
obj.add = 5;
obj.subtract = 1;			//Pay attention to the parameter!
obj.increment;
obj.decrement;
```



# 6. JavaScript Object Constructors

```
function Person(first, last, age, eye) {
	this.firstName = first;
	this.lastName = last;
	this.age = age;
	this.eyeColor = eye;
}
const instance = new Person("John", "Doe", 30, "blue");
```

<b>Notes:</b>

​	It is considered good practice to name constructor functions with an upper-case first letter.

<b>About this</b>

​	In a constructor function <span style="color: red;">this</span> does not have a value. It is substitute for the new object. The value of <span style="color: red;">this</span> will become the new object when a new object is created.

## 6.1 Object Types (Blueprints) (Classes)

​	The examples from the previous chapter are limited. They only create single objects.

​	Sometimes we need a "<b>blueprint</b>" for creating many objects of the same "type".

​	The way to create an "object type", is to use an <b>object constructor function</b>.

​	In the example above, <span style="color: red;">function Person()</span> is an object constructor function.

​	Objects of the same type are created by calling the constructor function with the <span style="color: red;">new</span> keyword:

```
const instance1 = new Person(...);
const instance2 = new Person(...);
```

## 6.2 Adding a Property to an Object

```
instance1.nationality = "English";
```

## 6.3 Adding a Method to an Object

```
instance2.name = function() {
	//...
}
```

## 6.4 Adding a Property/Method to a Constructor

​	To add a new property/method to a constructor, we must add it to the constructor function:

```
function Person(first, last, age, eyeColor) {
	//...
	this.nationality = "English";
	this.name = function() {
		//...
	}
}
```

## 6.5 Built-in JavaScript Constructors

```
new String()    // A new String object
new Number()    // A new Number object
new Boolean()   // A new Boolean object
new Object()    // A new Object object
new Array()     // A new Array object
new RegExp()    // A new RegExp object
new Function()  // A new Function object
new Date()      // A new Date object
```

<b>Note:</b> The <span style="color: red;">Math()</span> object is not in the list. <span style="color: red;">Math</span> is a global object. The <span style="color: red;">new</span> keyword cannot be used on <span style="color: red;">Math</span>.

## 6.6 Did You Know ?

​	Refer README-base.md

​	As you can see above, JavaScript has object versions of the primitive data types <span style="color: red;">String</span>, <span style="color: red;">Number</span>, and <span style="color: red;">Boolean</span>. But there is no reason to create complex objects. Primitive values are much faster.



# 7. JavaScript Object Prototypes

​	All JavaScript objects inherit properties and methods from a prototype.

​	In the previous chapter we learned how to use an <b>object constructor</b>.

```
function Person(first, last, age, eyeColor) {
	this.firstName = first;
	this.lastName = last;
	this.age = age;
	this.eyeColor = eyeColor;
}
const instance1 = Person("Trump", "Donald", 77, "unknown");
const instance2 = Person("Biden", "Joe", 81, "unknwon");
```

​	We also learned that you can <b>NOT</b> add a new property to an existing object constructor:

```
Person.nationality = "English";
```

​	You add a new property to a constructor, you must add it to the constructor function:

```
function Person(...) {
	//...
	this.nationality = "English";
}
```

## 7.1 Prototype Inheritance

​	All JavaScript objects inherit properties and methods from a prototype:

* <span style="color: red;">Date</span> object inherit from <span style="color: red;">Date.prototype</span>
* <span style="color: red;">Array</span> object inherit from <span style="color: red;">Array.prototype</span>
* <span style="color: red;">Person</span> object inherit from <span style="color: red;">Person.prototype</span>

​	The <span style="color: red;">Object.prototype</span> is on the top of the prototype inheritance chain:

​	<span style="color: red;">Date</span>/<span style="color: red;">Array</span>/<span style="color: red;">Person</span> objects are both inherit from <span style="color: red;">Object.prototype</span>.

## 7.2 Adding Properties and Methods to Objects

​	Sometimes you want to add new properties (or methods) to all existing objects of a given type.

​	Sometimes you want to add new properties (or methods) to an object constructor.

## 7.3 Using the prototype Property

​	The JavaScript <span style="color: red;">prototype</span> property allows you to add new properties/mthods to object constructors:

```
function Person(...) {
	//...
}
Person.prototype.nationality = "English";
Person.prototype.name = function() {
	//...
}
```

<b>Note:</b> Only modify your <b>own</b> prototypes. Never modify the prototypes of standard JavaScript objects.



# 8. JavaScript Iterables

​	Iterable objects are objects that can be iterated over with <span style="color: red;">for...of</span>.

​	Technically, iterables must implement the <span style="color: red;">Symbol.iterator</span> method.

## 8.1 Iterating Over a String

​	You can use a <span style="color: red;">for...of</span> loop to iterate over the elements of a string:

```
for (const x of "W3Schools") {
	//...
}
```

## 8.2 Iterating Over an Array

​	You can use a <span style="color: red;">for...of</span> loop to iterate over the elements of an Array:

```
for (const x of [1,2,3]) {
	//...
}
```

## 8.3 JavaScript Iterators

​	The <b>iterator protocol</b> defines how to produce a <b>sequence of values</b> from an object.

​	An <span style="color: blue;">object becomes an <b>iterator</b> when it implements a next()</span> method !

​	The <span style="color: red;">next()</span> method must return an object with two properties:

* value (the next value) - The value returned by the iterator, can be omitted if done is true
* done (true or false) -  True if the iterator has completed, false if the iterator has produced a new value

## 8.4 Home Made Iterable

​	This iterable returns never ending: 10,20,30,... Everytim <span style="color: red;">next()</span> is called:

```
function myNumbers() {	//Home Made Iterable
	let n = 0;
	return {
		next: function() {
			n += 10;
			return {value:n, done:false};
		}
	};
}
const n =myNumbers();	//Create Iterable
n.next().value;				//10
n.next().value;				//20
```

<b>Note:</b> The problem with a home made iterable:

​	It does not support the JavaScritp <span style="color: red;">for...of</span> statement.

​	A JavaScrpt iterable is an object that has a <b>Symbol.iteraotr</b>.

​	The <span style="color: blue;">Symbol.iterator</span> is a function that returns a <span style="color: red;">next()</span> function.

​	An iterable can be iterable over with the code: <span style="color: red;">for (const x of iterable) { }</span>.

```
myNumbers = {};		//create an object
myNumbers[Symbol.iterator] = function() {
	let n = 0;
	done = false;
	return {
		next: function() {
			n += 10;
			if (n >= 100) {done = true}
			return {value:n, done: done};
		}
	}
}
```

​	<b>Now you CAN use</b><span style="color: red;">for...of</span>:

```
for (const num of myNumbers) {
	//...
}
```

​	The Symbol.iteraotr method is called automatically by <span style="color: red;">for...of</span>.

​	But we can also do it "manually":

```
let iterator = myNumbers[Symbol.iterator]();
while(true) {
	const result = iterator.next();
	if (result.done) break;
	//...
}
```



# 9. JavaScrip Sets

​	A JavaScript Set is a collection of unique values.

​	Each value can only occur once in a Set.

​	A Set can hold any value of any data type.

## 9.1 Set Methods

| Method    | Description                                                 |
| --------- | ----------------------------------------------------------- |
| new Set() | Creates a new Set                                           |
| add()     | Adds a new element to the Set                               |
| delete()  | Removes an element from a Set                               |
| has()     | Returns true if a value exists                              |
| clear()   | Removes all elements form a Set                             |
| forEach() | Invokes a callback for each element                         |
| values()  | Returns an Iterator with all the values in a Set            |
| keys()    | Same as values()                                            |
| entires() | Returns an Iterator with the [value,value] pairs from a Set |

| Property | Description                          |
| -------- | ------------------------------------ |
| size     | Returns the number elements in a Set |

## 9.2 How to Create a Set

​	You can create a JavaScript Set by:

* Passing an Array to <span style="color: red;">new Set()</span>
* Create a new Set and use <span style="color: red;">add()</span> to add values
* Create a new Set and use <span style="color: red;">add()</span> to add variables

## 9.3 The new Set() Method

​	Pass an Array to the <span style="color: red;">new Set()</span> constructor:

```
const letters = new Set(["a", "b", "c"]);
```

​	Create a Set and add variables:

```
const a = "a";
cosnt b = "b";
const c = "c";
cosnt letters = new Set();
letters.add(a).add(b).add(c);
```

## 9.4. The values() Method

​	The <span style="color: red;">values()</span> returns an Iterator object containing all the values in a Set:

```
const myIterator = letters.values();
let text = "";
for (const entry of myIteraotr) {
	text += entry;				//set elements
}
```

# 9.5 The keys() Method

​	A Set has no keys. <span style="color: red;">keys()</span> returns the same as <span style="color: red;">values()</span>. This makes Set compatible with Maps.

## 9.6 The entries() Method

​	A Set has no keys. <span style="color: red;">entries()</span> returns [value,value] pairs instead of [key,value] pairs.

```
const myIterator = letters.entries();
let text = "";
for (const entry of myIterator) {	//or myIterator.next();
	text += entry;
}
```

## 9.7 Sets are Objects

```
typeof letters;			//object
letters instanceof Set;	//true
```



# 10. JavaScript Maps

​	A Map holds key-value pairs where the keys can be any datatype.

​	A Map remembers the original insertion order of the keys.

​	A Map has a property that represents the size of the map.

## 10.1 Map Methods

| Method    | Description                                                  |
| :-------- | :----------------------------------------------------------- |
| new Map() | Creates a new Map object                                     |
| set()     | Sets the value for a key in a Map                            |
| get()     | Gets the value for a key in a Map                            |
| clear()   | Removes all the elements from a Map                          |
| delete()  | Removes a Map element specified by a key                     |
| has()     | Returns true if a key exists in a Map                        |
| forEach() | Invokes a callback for each key/value pair in a Map          |
| entries() | Returns an iterator object with the [key, value] pairs in a Map |
| keys()    | Returns an iterator object with the keys in a Map            |
| values()  | Returns an iterator object of the values in a Map            |

| Property | Description                        |
| :------- | :--------------------------------- |
| size     | Returns the number of Map elements |

## 10.2 How to Create a Map

​	You can create a JavaScript Map by:

* Passing an Array to <span style="color: red;">new Map()</span>.
* Create a Map and use <span style="color: red;">Map.set()</span>

## 10.3 new Map()

​	You can create a Map by passing an Array to the <span style="color: red;">new Map</span> construcotr:

```
const fruits = new Map([
	["apples", 100],
	["bananas", 200]
]);
```

## 10.4 Map.set()

​	You can add elements to a Map with the <span style="color: red;">set()</span> method:

```
const fruits = new Map();
fruist.set("apples", 100);
```

​	The <span style="color: red;">set()</span> method can also be used to change existing Map values.

## 10.5 Map.get()

​	The <span style="color: red;">get()</span> method gets the value of a key in a Map:

```
fruits.get("apples");	//100
```

## 10.6 Map.size

​	The <span style="color: red;">size</span> property returns the number of elements in a Map.

## 10.7 Maps are Objects

```
typeof fruits;			//object
fruits instanceof Map;	//true
```

## 10.8 JavaScript Objects vs Maps

​	Different between JavaScript Objects and Map:

| Object                           | Map                           |
| -------------------------------- | ----------------------------- |
| Not directly iterable            | Directly iterable             |
| Do not have a size property      | Hava a size property          |
| Key must be Strings (or Symbols) | Key can be any datatype       |
| Key are not well ordered         | Keys are ordered by insertion |
| Have default keys                | Do not have default keys      |

## 10.9 Map.forEach()

​	The <span style="color: red;">forEach()</span> method invokes a callback for each key/value pair in a Map.

```
let text = "";
fruits.forEach(function(value, key) {
	text += key + ' = ' + value;
})
```

## 10.10 Map.entries()

​	The <span style="color: red;">entrites()</span> method returns an iterator object with the [key,value] in a Map:

```
let text = "";
for (const f of fruits.entries()) {
	text += x;
}
```

## 10.11 Map.keys() & Map.values()

​	The <span style="color: red;">keys()</span> method returns an iterator object with the keys in a Map, and <span style="color: red;">values()</span> method returns an iterator object with the values in a Map:

```
const fruits = new Map([
  ["apples", 500],
  ["bananas", 300],
  ["oranges", 200]
]);
let text = "":
for (const x of fruits.keys()) {
	text += x;			//apples, bananas, oranges
}
let text = "";
for (const x of fruits.values()) {
	text += x;			//500, 300, 200
}
```

## 10.12 Objects as Keys

​	Being able to use objects as keys is an important Map feature:

```
const apples = {name: 'Apples'};	//apples is an object
const fruits = new Map();
fruits.set(apples, 500);			//object as key
fruits.get(apples);					
fruits.get("Apples");				//Returns undefined
```



# 11. JavaScript ES5 Object Methods

​	ECMAScript  5(2009) added a lot of new Object Method to JavaScript.

<b>Managing Objects</b>

```
// Create object with an existing object as prototype
Object.create()

// Adding or changing an object property
Object.defineProperty(object, property, descriptor)

// Adding or changing object properties
Object.defineProperties(object, descriptors)

// Accessing Properties
Object.getOwnPropertyDescriptor(object, property)

// Returns all properties as an array
Object.getOwnPropertyNames(object)

// Accessing the prototype
Object.getPrototypeOf(object)

// Returns enumerable properties as an array
Object.keys(object)

```

<b>Protecting Objects</b>

```
// Prevents adding properties to an object
Object.preventExtensions(object)

// Returns true if properties can be added to an object
Object.isExtensible(object)

// Prevents changes of object properties (not values)
Object.seal(object)

// Returns true if object is sealed
Object.isSealed(object)

// Prevents any changes to an object
Object.freeze(object)

// Returns true if object is frozen
Object.isFrozen(object)
```

## 11.1 Changing a Property Value

<b>Syntax</b>

```
Object.defineProperty(object, property, {value: value});E
```

Example:

```
const person = {
	firstName: "John",
	lastName: "Doe",
	language: "EN"
};
Object.defineProperty(person, "language", {value: "NO"});
```

## 11.2 Changing Meta Data

​	ES5 allows the following property meta data to be changed:

* writable, enumerable, configurable

​	ES5 allows getters and setters to be changed:

```
get: function() { return language }
set: function(value) { language = vale }
```

Example:

```
Object.defineProperty(person, "language", {writable: false});
```

## 11.3 Listing All Properties

```
Object.defineProperty(person, "language", {enumerable: false});
Object.getOwnPropertyNames(person);		//firstName,lastName,language
```

## 11.4 Listing Enumerable Properties

​	This example list only the enumerable properties of an object:

```
Object.defineProperty(person, "language", {enumerable:false});
Object.keys(person);  // firstName,lastName
```

## 11.5 Adding a Property

````
Object.defineProperty(person, "year", {value: "2008"});
````

## 11.6 Adding Getters & Setters

​	The <span style="color: red;">Object.defineProperty()</span> method can also be used to add Getters and Setters:

```
Object.defineProperty(person, "fullName", {
	get: function() {return this.firstName + " " + this.lastName;}
});
```

<b>A Counter Example</b>

```
 Define object
const obj = {counter:0};

// Define setters
Object.defineProperty(obj, "reset", {
  get : function () {this.counter = 0;}
});
Object.defineProperty(obj, "increment", {
  get : function () {this.counter++;}
});
Object.defineProperty(obj, "decrement", {
  get : function () {this.counter--;}
});
Object.defineProperty(obj, "add", {
  set : function (value) {this.counter += value;}
});
Object.defineProperty(obj, "subtract", {
  set : function (i) {this.counter -= i;}
});
// Play with the counter:
obj.reset;
obj.add = 5;
obj.subtract = 1;
obj.increment;
obj.decrement;
```

<span style="color: red;">Sun, 16 Apr 2023. 11:40. Library floor 2rd, zone c 392.</span>







# 1. JavaScript Function Definition

​	JavaScript functions are <b>defined</b> with the <span style="color: red;">function</span> keyword.

​	You can use a function <b>declaration</b> or a function <b>expression</b>.

## 1.1 Function Declarations

​	Earlier in this tutorial, you learned that functions are <b>declared</b> with the following syntax:

```
function functionName(parameters) {
	//...
}
```

​	Declared functions are not executed immediately. They are "saved for later use", and will be executed later, when they are invoked (called upon):

```
function myFunction(a, b) {
	return a * b;
}
```

​	<b>Note:</b> Semicolons are used to separate executable JavaScript statements.

​		Since a function <b>declaration</b> is not an executable statement, it is not common to end it with a semicolon.

## 1.2 Function Expressions

​	A JavaScript function can also be defined using an <b>expression</b>.

​	A function expression can be stored in a variable:

```
const x = function (a, b) {return a * b};
```

​	After a function expression has been stored in a variable, the variable can be used as a function:

```
let z = x(4, 3);	//12
```

​	The function above is actually an <b>anonymous function</b> (a function without a name).

​	Functions stored in variable do not need function names. They are always invoked (called) using the variable name.

<b>Note:</b> The function above ends with a semicolon because it's a part of an executable statement.

## 1.3 The Function() Constructor

​	As you have seen in previous examples, JavaScript functions are defined with the <span style="color: red;">function</span> keyword.

​	Functions can also be defined with a built-in JavaScript function constructor called <span style="color: red;">Function()</span>.

```
const myFunction = new Function("a", "b", "return a * b");
let x = myFunction(5, 6);	//30
```

​	You actually don't have to use the function constructor. The example above is the same as writing:

```
const myFunction = function (a, b) {return a * b};;
```

## 1.4 Function Hoisting

​	Hoisting is JavaScript's default behavior of moving <b>declarations</b> to the top of the current scope.

​	Hoisting applies to variable declarations and to function declarations.

​	Because of this, JavaScript functions can be called before they are declared:

```
myFunction(5);
function myFunction(y) {
	return y * y;
}
```

<b>Note:</b> Functions defined using an expression are not hoisted.

## 1.5 Self-Invoking Functions

​	Function expressions can be made "self-invoking".

​	A self-invoking expression is invoked (started) automatically, without being called.

​	Function expressions will execute automatically if the expression is followed by ().

​	You cannot self-invoke a function declaration. And you have to add parentheses around the function to indicate that it is a function expression:

```
(function () {
	document.getElementById("demo").innerHTML = "Hello";
})();
```

​	The function above is actually an <b>anonymous self-invoking function</b>.

## 1.6 Functions Can Be Used as Values

```
let x = myFunction(4, 3);		//12
let x = myFunction(4, 5) * 2;	//40
```

## 1.7 Functions are Objects

​	The <span style="color: red;">typeof</span> operator in JavaScript returns "function" for functions. But, JavaScript functions can best be described as objects.

​	JavaScript functions have both <b>properties</b> and <b>methods</b>. The <span style="color: red;">arguments.length</span> property returns the number of arguments received when the function was invoked:

```
function myFunction(a, b) {
	return arguments.length;
}
```

​	The <span style="color: red;">toString()</span> method returns the function as a string:

```
let text = myFunction.toString();
```

<b>Note:</b>

​	A function defined as the property of an object, is called a <b>method</b> to the object.

​	A function defined to create new objects, is called an <b>object constructor</b>.

## 1.8 Arrow Functions

​	Arrow functions allow a short syntax for writing function expressions.

​	You don't need the <span style="color: red;">function</span> keyword, the <span style="color: red;">return</span> keyword, and the <b>curly brackets</b>.

```
const x = (x, y) => x * y;
```

​	1. Arrow functions do not have their own <span style="color: red;">this</span>. They are not well suited for defining <b>object methods</b>. 

	2. Arrow functions are not hoisted. They must be defined <b>before</b> they are used.
	2. Using <span style="color: red;">const</span> is safer than using <span style="color: red;">var</span>, because a function expression is always constant value.
	2. You can only omit the <span style="color: red;">return</span> keyword and the curly brackets if the function is a single statement, because of this, it might be a good habit to always keep them:

```
const x = (x, y) =>{ return x * y }; 
```



# 2. JavaScript Function Parameters

​	A JavaScript <span style="color: red;">function</span> does not perform any checking on parameter values (arguments).

## 2.1 Function Parameters and Arguments

​	Earlier in this tutorial, you learned that functions can have parameters:

```
function functionName(parameter1, parameter2, parameter3) {
	//...
}
```

## 2.2 Parameter Rules

1. JavaScript function definitions do not specify data types for parameters.
2. JavaScript functions do not perform type checking on the passed arguments.
3. JavaScript functions do not check the number of arguments received.

## 2.3 Default Parameters

​	If a function is called with <b>missing arguments</b> (less than declared), the missing values are set to <span style="color: red;">undefined</span>.

​	Sometimes this is acceptable, but sometimes it is better to assign a default value to the parameter:

```
function myFunction(x, y) {
	if (y === undefined) {
		y = 2;
	}
}
```

​	ES6 allows function parameters to have default values:

```
function myFunction(x, y = 2) {
	return x * y;
}
```

## 2.4 Function Rest Parameter

​	The rest parameter (...) allows a function to treat an indefinite number of arguments as an array:

```
function sum(...args) {
	let sum = 0;
	for(let arg of args) sum += arg;
	return sum;
}
let x = sum(4, 4.6, 7, 19, 2, 9, 1.8);
```

## 2.5 The Arguments Object

​	JavaScript functions have a built-in object called the arguments object.

​	The arguments object contains an array of the argument used when the functions was called.

​	This way you can simply use a function to find (for instance) the highest value in a list of numbers:

```
x = findMax(1, 34, 29, 88, 60);
function findMax() {
	let max = -Infinity;
	for(let i = 0; i < arguments.length; i++) {
		if(arguments[i] > max) {
			max = arguments[i];
		}
	}
	return max;
}
```

<b>Note:</b> If a function is called with <b>too many arguments</b> (more than declared), these arguments can be reached using <b>the argument object</b>.

## 2.6 Arguments are Passed by Value

​	The parameter, in a function call, are the function's arguments.

​	JavaScript argument are passed by <b>value</b>: The function only gets to know the values, not the argument's locations.

​	If a function changes an argument's value, it does not change the parameter's original value. Changes to arguments are not visible (reflected) outside the function.

## 2.7 Objects are Passed by Reference

​	Because of this, if a function changes an object property, it changes the original value.



# 3. JavaScript Function Invocation

## 3.1 Invoking a JavaScript Function

* The code inside a function is not executed when the function is <b>defined</b>.
* The code inside a function is executed when the function is <b>invoked</b>.
* It is common to use the term "<b>call a function</b>" instead of "<b>invoke a function</b>".
* It is also common to say "call upon a function", "start a function", or "execute a function".
* In this tutorial, we will use <b>invoke</b>, because a JavaScript function can be invoked without being called.

## 3.2 Invoking a Function as a Function

```
function myFunction(x, y) {
	//...
}
myFunction(1, 2);
```

​	The function above does not belong to any object. But in JavaScript there is always a default global object. In HTML the default global object is the HTML page itself, so the function above "belongs" to the HTML page.

​	In a browser the page object is the browser window. The function above automatically becomes a window function.

<b>Note:</b>

​	This is a common way to invoke a JavaScript function, but not a very good practive.

​	Global variables, methods, or functions can easily create name conflicts and bugs in the global object.

```
myFunction(1, 2);
window.myFunction(1, 2);	//They are the same function
```

## 3.3 The Global object

​	When a function is called without an owner object, the value of <span style="color: red;">this</span> <span style="color: blue;">becomes the global object</span>.

​	In a web browser the global object is the browser window.	This example returns the window object as the value of <span style="color: red;">this</span>:

```
let x = myFunction();	//[object Window]
functioon myFunction() {
	return this;
}
```

## 3.4 Invoking a Function as a Method

​	In JavaScript you can define functions as object methods.

​	The following example creates an object (<b>myObject</b>), with two properties (<b>firstName</b> and <b>lastName</b>), and a method (<b>fullName</b>):

```
const myObject = {
	firstName: "John",
	lastName:"Doe",
	fullName: function() {
		return this.firstName + " " + this.lastName;	//this: [object Object]
	}
}
myObject.fullName();
```

​	The <b>fullName</b> belongs to the object, <b>myObject</b> is the owner of the function.

## 3.5 Invoking a Function with a Function Constructor

​	If a function invocation is preceded with the <span style="color: red;">new</span> keyword, it is a constructor invocation.

​	It looks like you create a new function, but since JavaScript functions are objects you actually create a new object:

```
function myFunction(arg1, arg2) {
	this.firstName = arg1;
	this.lastName = arg2;
}
const myObj = new myFunction("John", "Doe");
myObj.firstName;			//"John"
```

<b>Note:</b> A constructor invocation creates a new object. The new object inherits the properties and methods from its constructor.

​	The <span style="color: red;">this</span> keyword in the constructor does not have a value, the value of <span style="color: red;">this</span> will be the new object created when the function is invoked !!



# 4. JavaScript Function call()

​	With the <span style="color: red;">call()</span> method, you can write a method that can be used on different objects.

## 4.1 All Functions are Methods

​	If a function is not a method of a JavaScript object, it is a function of the global object !!

## 4.2 The JavaScript call() Method

​	The <span style="color: red;">call()</span> method is a predefined JavaScript method.

​	It can be used to invoke (call) a method with an owner object as an argument (parameter).

<b>Note:</b> In brief, with <span style="color: red;">call()</span>, an object can use a method belonging to another object.

​	This example calls the <b>fullName</b> method of person, using it on <b>person1</b>:

```
const person = {
	fullName: function() {
		return this.firstName + " " + this.lastName;
	}
}
const person1 = {
	firstName: "John",
	lastName: "Doe"
}
person.fullName.call(person1);	//"John Doe"
```

## 4.3 The call() Method with Arguments

​	The <span style="color: red;">call()</span> method can accept arguments:

```
const person = {
	fullName: function(city, country) {
		return this.firstName + " " + this.lastName + "," + city + "," + country;
	}
}
const person1 = {
	firstName: "Biden",
	lastName: "Joe"
}
person.fullName.call(person1, "Washington", "US");
```



# 5. JavaScript Function apply()

## 5.1 Method Reuse

​	With the <span style="color: red;">apply()</span> method, you can written a method that can be used on different objects.

## 5.2 The JavaScript apply() Method

​	The <span style="color: red;">apply()</span> method is similar to the <span style="color: red;">call()</span> method.

​	In this example the <b>fullName</b> method of <b>person</b> is <b>applied</b> on <b>person1</b>:

```
const person = {
  fullName: function() {
    return this.firstName + " " + this.lastName;
  }
}

const person1 = {
  firstName: "Mary",
  lastName: "Doe"
}

// This will return "Mary Doe":
person.fullName.apply(person1);		//"John Doe"
```

## 5.3 The Difference Between call() and apply()

​	The difference is:

​	The <span style="color: red;">call()</span> method takes arguments separately.

​	The <span style="color: red;">apply()</span> method takes arguments as an array.

<b>Note:</b> The apply() method is very handy if you want to use an array instead of an argument list.

## 5.4 The apply() Method with Arguments

```
const person = {
  fullName: function(city, country) {
    return this.firstName + " " + this.lastName + "," + city + "," + country;
  }
}

const person1 = {
  firstName:"John",
  lastName: "Doe"
}
//The apply() method accepts arguments in an array.
person.fullName.apply(person1, ["Oslo", "Norway"]);
```

## 5.5 Simulate a Max Method on Arrays

​	You can find the largest number (in a list of numbers) using the <span style="color: red;">Math.max()</span> method:

```
Math.max(1,2,3);
```

​	Since JavaScript <b>arrays</b> do not have a max() method, you can apply the <span style="color: red;">Math.max()</span> method instead:

```
Math.max.apply(null, [1,2,3]);
```

​	The first argument (null) does not matter. It is not used in this example.

​	These examples will give the same result:

```
Math.max.apply(Math, [1,2,3]);
Math.max.apply("", [1,2,3]);
Math.max.apply(0, [1,2,3]);
```

## 5.6 JavaScript Strict Mode

​	In JavaScript strict mode, if the first argument of the <span style="color: red;">apply()</span> method is not an object, it becomes the owner (object) of the invoked function. In "non-strict" mode, it becomes the global object.



# 6. JavaScript Function bind()

## 6.1 Function Borrowing

​	With the <span style="color: red;">bind()</span> method, an object can borrow a method from another object.

​	The example below creates 2 objects (person and member).

​	The member object borrows the fullname method from the person object:

```
const person = {
	firstName:"John",
	lastName:"Doe",
	fullName: function() {
		return this.firstName + " " + this.lastName;
	}
}
const member = {
	firstName:"Hege",
	lastName:"Nilsen",
}
let fullName = person.fullName.bind(member);
```

## 6.2 Preserving this

​	Sometimes the <span style="color: red;">bind()</span> method has to be <span style="color: blue;">used to prevent losing</span> <b>this</b>.

​	In the following example, the person object has a display method. In the display method, <b>this</b> refers to the person object:

```
const person = {
	firstName:"John",
	lastName:"Doe",
	display: function() {
		let x = document.getElementById("demo");
		x.innerHTML = this.firstName + " " + this.lastName;
	}
}
person.display();
```

​	When a function is used as a callback, <b>this</b> is lost.

​	This example will try to display the person name after 3 seconds, but it will display <b>undefined</b> instead:

```
setTimeout(person.display, 3000);
```

​	The <span style="color: red;">bind()</span> method solves this problem.

​	In the following example, the <span style="color: red;">bind()</span> method is used to bind person.display to person.

​	This example will display the person name after 3 seconds:

```
let display = person.display.bind(person);
setTimeout(display, 3000);
```



# 7. JavaScript Closures

​	JavaScript variables can belong to the <b>local</b> or <b>global</b> scope.

​	Global variables can be mode local (private) with <b>closures</b>.

## 7.1 Global Variables

​	A <span style="color: red;">function</span> can access all variables defined <b>inside</b> the function, like this:

```
function myFunction() {
	let a = 4;
	return a * a;
}
```

​	But a <span style="color: red;">function</span> can also access variables defined <b>outside</b> the function, like this:

```
let a = 4;
function myFunction() {
	return a * a;
}
```

​	Global variables belong to the page, and can be used (and changed) by all other scripts in the page.

<b>Note:</b>

​	Variables created <b>without</b> a declaration keyword (<span style="color: red;">var</span>, <span style="color: red;">let</span>, or <span style="color: red;">const</span>) are always global, even if they are created inside a function.

## 7.2 Variable Lifetime

​	Global variables live until the page is discarded, like when you navigate to another page or close the window.

​	Local variables have short lives. They are created when the function is invoked, and deleted when the function is finished.

## 7.3 A Counter Dilemma & JavaScript Nested Functions

​	Suppose you want to use a variable for counting something, and you want this counter to be available to all functions.

​	You could use a global variable, and a <span style="color: red;">function</span> to increase the counter:

```
let counter = 0;
function add() {
	counter += 1;
}
add();
add();
//...
```

​	There is a problem with the solution above: Any code on the page can change the counter, without calling add().

​	The counter should be local to the <span style="color: red;">add()</span> function, to prevent other code from changing it:

```
let counter = 0;
function add() {
	let counter = 0;
	counter += 1;
}
add();	
add();	
//...
```

​	Above code did not work for we display the global counter instead of the local one.

​	We can remove the global counter and access the local counter by letting the function return it:

```
function add() {
	let counter = 0;
	counter += 1;
	return counter;
}
add();
add();
//...
```

​	It also didn't work because we reset the local counter every time we call the function.

<b>We'd like a C code  'static' property, here, a JavaScript inner function can solve this.</b>

 	All functions have access to the global scope.

​	In fact, in JavaScript, all functions have access to the scope "above" them.

​	JS supports nested functions, in this example, the inner function <span style="color: red;">plus()</span> has access to the <span style="color: red;">counter</span> variable in the parent function:

```
function add() {
	let counter = 0;
	function plus() {counter += 1};
	plus();
	return counter;
}
```

​	This could have solved the counter dilemma, if we could reach the <span style="color: red;">plus()</span> function from the outside. We also need to find a way to execute <span style="color: red;">counter = 0;</span> only once. Here <b>we need a closure</b>.

## 7.4 JavaScript Closures

​	Remember self-invoking functions? 

```
const add = (function() {
	let counter = 0;
	return function() {counter += 1; return counter;}
})();
add();
add();
//...
```

​	The variable <span style="color: red;">add</span> is assigned to the return value of a self-invoking function. The self-invoking function only runs once. It sets the counter to zero, and returns a function expression.

​	This way add becomes a function, the "wonderful" part is that it can access the counter in ther parent scope. This is called a JavaScript <b>closure</b>. It makes it possible for a function to have "<b>private</b>" variables.

​	The counter is protected by the scope of the anonymous function, and can only be changed using the add function.

<b>Note:</b>

​	<span style="color: blue;"> A closure is a function having access to the parent scope, even after the parent function has close</span>.



<span style="color: red;">





# 1. JavaScript Classes

​	ECMAScript 2015, also known as ES6, introudced JavaScript Classes.

​	JavaScript Classed are templates for JavaScript Objects.

## 1.1 JavaScript Class Syntax

​	Use the keyword <span style="color: red;">class</span> to create a class. Always add a method named <span style="color: red;">constructor()</span>:

Syntax:

```
class ClassName {
	constructor() {...}
}
```

Example:

```
class Car {
	constructor(name, year) {
		this.name = name;
		this.year = year;
	}
}
```

​	The example above creates a class named "Car". The class has two initial properties: "name" and "year".

<b>Note:</b>

​	A JavaScript class is <b>NOT</b> an object. It is a <b>template</b> for JavaScript objects.

## 1.2 Using a Class

​	When you have a class, you can use the class to create objects:

```
const myCar1 = new Car("Ford", 2018);
const myCar2 = new Car("Audi", 2020);
```

<b>Note:</b> The constructor method is called automatically when a new object is created.

## 1.3 The Constructor Method

​	The constructor method is a special method:

* It has to have the exact name "constructor"
* It is expected automatically when a new object is created
* It is used to initialize object properties

​	If you do not define a constructor method, JavaScript will add an empty constructor method.

## 1.4 Class Methods

​	Class methods are created with the same syntax as object methods.

​	Use the keyword <span style="color: red;">class</span> to create a class. Always add a <span style="color: red;">constructor()</span> method. Then add any number of methods.

​	The syntax in classes must be written in "strict mode", you will get an error if you do not follow the "strict mode" rules.

```
class Car {
	constructor(name, year) {
		this.name = name;
		this.year = year;
	}
	age() {
		date = new Date();		//Should be const date = new Date();
		return date.getFullYear() - this.year;
	}
}
```

​	Refer the README-base.md



# 2. JavaScript Class Inheritance

## 2.1  Class Inheritance

​	To create a class inheritance, use the <span style="color: red;">extends</span> keyword.

​	A class created with a class inheritance inherits all the method from another class:

```
class Car {
	constructor(brand) {
		this.carname = brand;
	}
	present() {
		return 'I have a '  + this.carname;
	}
}
class BYD extends Car {
	constructor(brand, mod) {
		super(brand);		//Pay attention to here
		this.model = mod;
	}
	show() {
		return this.present() + ', it is a ' + this.model;
	}
}
let myCar = new BYD("BYD", "han");
document.getElementById("demo").innerHTML = myCar.show();
```

​	The <span style="color: red;">super()</span> method refers to the parent class; By calling the <span style="color: red;">super()</span> method in the constructor, we call the parent constructor method and gets access to the parent's properties and methods.

## 2.2 Getters and Setters

​	Classes also allows you to use getters and setters.

​	It can be smart to use getters and setters for your properties, especially if you want to do something special with the value before returning them, or before you set them.

​	To add getters and setters in the class, use the <span style="color: red;">get</span> and <span style="color: red;">set</span> keywords:

```
//Create a getter and a setter for the "carname" property:
class Car {
	constructor(brand) {
		this.carname = brand;
	}
	get cnam() {
		return this.carname;
	}
	set cnam(x) {
		this.carname = x;
	}
}
const myCar = new Car("BYD");
document.getElementById("demo").innerHTML = myCar.cnam;
```

<b>Note:</b> Even if the getter is a method, you do not use parentheses when you want to get the property value.

​	The name of the getter/setter method cannot be the same as the name of the property, in this case <span style="color: red;">carname</span>.

​	Many programmers use an underscore character _ before the property name to separate the getter/setter from the actual property:

```
class Car {
	constructor(brand) {
		this._carname = brand;
	}
	get carname() {
		return this._carname;
	}
	set carname(x) {
		this._carname = x;
	}
}
```

​	To use a setter, use the same syntax as when you set a property value, without parentheses:

```
const myCar = new Car("BYD");
myCar.carname = "HAN";
```

## 2.3 Hoisting

​	Unlike functions, and other JavaScript declarations, class declarations are not hoisted.

​	That means you must declare a class before you can use it:

```
myCar = new Car("BYD");	//raise an error
class Car {
	constructor() {
		//...
	}
}
```



# 3. JavaScript Static Methods

​	Static class methods are defined on the class itself.

​	You cannot call a <span style="color: red;">static</span> method on an object, only on an object class.

Example:

```
class Car {
	constructor(name) {
		this.name = name;
	}
	static hello() {
		return "Hello!!";
	}
}
const myCar = new Car("BYD");
//You can call 'hello()' on the Car class:
document.getElementById("demo").innerHTML = Car.hello();
//But NOT on a Car object:
document.getElementById("demo").innerHTML = myCar.hello();	//error
```

 	If you want to  use the myCar object inside the <span style="color: red;">static</span> method, you can send it as a parameter:

```
document.getElementById("demo").innerHTML = Car.hello(myCar);
```

​	Please practice it, you will see something interesting!

Sun, April 14, 2013. 19:46.







# 1. JavaScript Callbacks

 <p style="text-align: center; font-size: 20px">"I will call back later!"</p>

<p style="text-align: center;">A callback is a function passed as an argument to another function</p>

<p style="text-align: center;">This technique allows a function to call another function</p>

<p style="text-align: center;">A callback function can run after another function has finished</p>

## 1.1 Function Sequence

​	JavaScript functions are executed in the sequence they are called. Not in the sequence they are defined.

​	This example will end up displaying "Goodbye" (you wouldn't see the "Hello" displayed):

```
function myFirst() {
	myDisplayer("Hello");
}
function mySecond() {
	myDisplay("Goodbye");
}
myFirst();
mySecond();
```

## 1.2 Sequence Control

​	Sometimes you would like to have better control over when to execute a function.

​	Suppose you want to do a calculation, and then display the result.

​	You could call a calculator function ( <span style="color: red;">myCalculator</span>), save the result, and then call another function ( <span style="color: red;">myDisplayer</span>) to display the result:

```
function myDisplayer(some) {
	document.getElementById("demo").innerHTML = some;
}
function myCalculator(num1, num2) {
	let sum = num1 + num2;
	return sum;
}
let result = myCalculator(5, 6);
myDisplay(result);
```

​	Or, you could call a calculator function (<span style="color: red;">myCalculator</span>), and let the calculator function call the display function(<span style="color: red;">myDisplayer</span>):

```
function myCalculator(num1, num2) {
	myDisplayer(num1 + num2);
}
myCalculator(5, 6);
```

​	The problem with the first example above, is that you have to call two functions to display the result.

​	The problem with the second example, is that you cannot prevent the calculator function from displaying the result.

​	Now it is time to bring in a callback.

## 1.3 JavaScript Callbacks

​	A callback is a function passed as an argument to another function.

​	Using a callback, you could call the calculator function (<span style="color: red;">myCalculator</span>) with a callback (<span style="color: red;">myCallback</span>), and let the calculator function run the callback after the calculation is finished:

```
function myDisplayer(some) {
	document.getElementById("demo").innerHTML = some;
}
function myCalculator(num1, num2, myCallback) {
	let sum = sum1 + sum2;
	myCallback(sum);
}
myCalculator(5, 6, myDisplayer);
```

<b>Note:</b> When you pass a function as a argument, remember not to use parentheses.

​	Another example:

```
// Create an Array
const myNumbers = [4, 1, -20, -7, 5, 9, -6];
// Call removeNeg with a callback
const posNumbers = removeNeg(myNumbers, (x) => x >= 0);
// Display Result
document.getElementById("demo").innerHTML = posNumbers;
// Keep only positive numbers
function removeNeg(numbers, callback) {
  const myArray = [];
  for (const x of numbers) {
    if (callback(x)) {
      myArray.push(x);
    }
  }
  return myArray;
}
```

​	In the example above, <span style="color: red;">(x) => x >= 0 </span> is a <b>callback function</b>.

## 1.4 When to Use a Callback?

​	The examples above are not very exciting. They are simplified to teach you the callback syntax.

​	Where callbacks really shine are in asynchronous functions, where one function has to wait for another function (like waiting for a file to load).



# 2. Asynchronous JavaScript 

 <p style="text-align: center; font-size: 20px">"I will finish later!"</p>

<p style="text-align: center;">Functions running in <b>parallel</b> with other functions are called <b>asynchronous</b></p>

<p style="text-align: center;">A good example is JavaScript setTimeout()</p>

## 2.1 Asynchronous JavaScript

​	The example used in the previous chapter, was very simplified.	

​	In the real world, callbacks are most often used with asynchronous functions.

## 2.2 Waiting for a Timeout

​	When using the JavaScript function  <span style="color: red;">setTimeout()</span>, you can specify a callback function to be executed on time-out:

```
setTimeout(myFunction, 3000);
function myFunction() {
	document.getElementById("demo").innerHTML = "I love you !!";
}
```

​	In the above, <span style="color: red;">myFunction</span> is used as a callback. Instead of passing the name of a function as an argument to another function, you can always pass a whole function instead:

```
setTimeout(function() {myFunction("I love you !!");}, 3000);
function myFunction(value) {
	document.getElementById("demo").innerHTML = value;
}
```

## 2.3 Waiting for Intervals:

​	When using the JavaScript function <span style="color: red;">setInterval()</span>, you can specify a callback function to be executed for each interval:

```
setInterval(myFunction, 1000);
function myFunction() {
	let d = new Date();
	document.getElementById("demo").innerHTML = d.getHours() + ":" +
		d.getMinutes() + ":" +
		d.getSeconds();
}
```

## 2.4 Callback Alternatives

​	With asynchronous programming, JavaScript programs can start long-running tasks, and continue running other tasks in parallel.

​	But, asynchronous programs are difficult to write and difficult to debug.

​	Because of this, most modern asynchronous JavaScript methods don't use callbacks. Instead, in JavaScript, asynchronous programming is solved using <b>Promises</b> instead !!



# 3. JavaScript Promises

 <p style="text-align: center; font-size: 20px">"I Promise a Result!"</p>

<p style="text-align: center;">"Producing code" is code that can take some time</p>

<p style="text-align: center;">"Consuming code" is code that must wait for the result</p>

<p style="text-align: center;">A promise is a JavaScript object that links producing code and consuming code</p>

## 3.1 JavaScript Promise Object

​	A JavaScript Promise object contains both the producing code and calls to the consuming code:

```
//Producing code
let myPromise = new Promise(function(myResolve, myReject) {
	myResolve();	//when successful
	myReject();		//when error
});
//Consuming code
myPromise.then(
	function(value) {//code for success},
	function(error) {//code for failure}
);
```

​	When the producing code obtains the result, it should call one of the two callbacks:

| Result  | Call                    |
| :------ | :---------------------- |
| Success | myResolve(result value) |
| Error   | myReject(error object)  |

## 3.2 Promise Object Properties

​	A JavaScript Promise object can be:

* Pending
* Fulfilled
* Rejected

​	The Promise object supports two properties: <b>state</b> and <b>result</b>.

​	While a Promise object is "pending" (working), the result is undefined.

​	When a Promise object is "fulfilled", the result is a value.

​	When a Promise object is "rejected", the result is an error object.

| myPromise.state | myPromise.result |
| :-------------- | :--------------- |
| "pending"       | undefined        |
| "fulfilled"     | a result value   |
| "rejected"      | an error object  |

<b>Note:</b> You cannot access the Promise properties <b>state</b> and <b>result</b>.

​	You must use a Promise method to handle promises.

## 3.3 Promise How To

​	Here is how to use a Promise:

```
myPromise.then(
	function(value) {//code for success},
	function(value) {//code for failure}
);
```

<b>Note:</b> Promise.then() takes two arguments, a callback for success and another for failure.

​	Both are optional, so you can add a callback for success or failure only.

```
function myDisplayer(some) {
  document.getElementById("demo").innerHTML = some;
}

let myPromise = new Promise(function(myResolve, myReject) {
  let x = 0;

// The producing code (this may take some time)

  if (x == 0) {
    myResolve("OK");
  } else {
    myReject("Error");
  }
});

myPromise.then(
  function(value) {myDisplayer(value);},
  function(error) {myDisplayer(error);}
);
```

## 3.4 JavaScript Promise Examples

​	To demonstrate the use of promises, we will use the callback examples from the previous chapter:

* Waiting for a Timeout
* Waiting for a File

### 3.4.1 Waiting for a Timeout

```
let myPromise = new Promise(function(myResolve, myReject) {
	setTimeout(function(){ myResolve("I love you !!");}, 3000);
});
myPromise.then(function(value) {
	document.getElementById("demo").innerHTML = value;
});
```

## 3.4.2 Waiting for a file

Example using callback (request failed):

```
function myDisplayer(some) {
	document.getElementById("demo").innerHTML = some;
}
function getFile(myCallback) {
	let req = new XMLHttpRequest();
	//req.open('GET', "mycar.html");	or write in below
	req.onload = function() {
		if(req.status == 200) {
			myCallback(this.responseText);	//or req.responseText
		} else {
			myCallback("Error: " + req.status);
		}
	}
	req.open('GET', "mycar.html");
	req.send();
}
getFile(myDisplayer);
```

Example using Promise (not succeed in my test ):

```
function myDisplayer22(some) {
	document.getElementById("demo22").innerHTML = some;
}
function getFile(myCallback) {
	let req = new XMLHttpRequest();
	//req.open('GET', "http://localhost:8080/E:/exper-now/计算机大杂烩/course_parallel_computer_architecture_and_programming/competetions/mygithubwebpage/my_learning/JS/mycar.html");	//or write in below
	//req.open('GET',"mycar.html");
	req.onload = function() {
		if(req.status == 200) {
			myCallback(this.responseText);	//or req.responseText
		} else {
			myCallback("Error: " + req.status);
		}
	}
	req.open('GET', "https://www.w3schools.com/js/mycar.html");
	req.send();
}
getFile(myDisplayer22);
```



# 4. JavaScript Async

 <p style="text-align: center; font-size: 20px">"async and await make promises easier to write"</p>

<p style="text-align: center;"><b>async</b> makes a function return a Promise</p>

<p style="text-align: center;"><b>await</b> makes a function wait for a Promise</p>

## 4.1 Async Syntax

​	The keyword <span style="color: red;">async</span> before a function makes the function return a promise:

```
async function myFunction() {
	return "Hello";
}
```

​	Is the same as:

```
function myFunction() {
	return Promise.resolve("Hello");
}
```

​	This example return Hello (if success):

```
function myDisplayer(some) {
  document.getElementById("demo").innerHTML = some;
}
//The return will be used as the argument to myDisplayer()
async function myFunction() {return "Hello";}

myFunction().then(
  function(value) {myDisplayer(value);},
  function(error) {myDisplayer(error);}
);
```

## 4.2 Await Syntax

​	The <span style="color:red;">await</span> keyword can only be used inside an <span style="color:red;">async</span> function.

​	The <span style="color:red;">await</span> keyword makes the function pause the execution and wait for a resolved promise before it continues:

```
let value = await promise;
```

Example:

```
async function myDisplay() {
  let myPromise = new Promise(function(resolve, reject) {	//can omit the reject
    resolve("I love You !!");
  });
  document.getElementById("demo").innerHTML = await myPromise;
}

myDisplay();
```

Waiting for a Timeout

```
async function myDisplay() {
  let myPromise = new Promise(function(resolve) {
    setTimeout(function() {resolve("I love You !!");}, 3000);
  });
  document.getElementById("demo").innerHTML = await myPromise;
}

myDisplay();
```

Waiting for a File

```
async function getFile() {
  let myPromise = new Promise(function(resolve) {
    let req = new XMLHttpRequest();
    req.open('GET', "mycar.html");
    req.onload = function() {
      if (req.status == 200) {
        resolve(req.response);
      } else {
        resolve("File not Found");
      }
    };
    req.send();
  });
  document.getElementById("demo").innerHTML = await myPromise;
}

getFile();
```

Sun, April 16, 2023. 21:21. Library.





