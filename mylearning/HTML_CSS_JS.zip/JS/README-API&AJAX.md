# 1. Web APIs - Introduction

A Web API is a developer's dream.

* It can extend the functionality of the browser
* It can greatly simplify complex functions
* It can provide easy syntax to complex code

## 1.1 What is Web API?

​	API stands for Application Programming Interface.

​	A Web API is an application programming interface for the Web. A Browser API can extend the functionality of a web browser. A Server API can extend the functionality of a web server.

## 1.2 Browser APIs

​	All browsers have a set of built-in Web APIs to support complex operations, and to help accessing data. For example, the Geolocation API can return the coordinates of where the browser is located.

Example:

```
//Get the latitude and longtitude of the user's position
const myElement = document.getElementById("demo");
function getLocation() {
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(showPosition);
	} else {
		myElement.innerHTML = "Geolocation is not supported by this browser.";
	}
}
function showPosition(position) {
	myElement.innerHTML = "Latitude: " + position.coords.latitude +
	"<br>Longitude: " + position.coords.longitude;
}
```

## 1.3 Third Party APIs

​	Third party APIs are not built into your browser.

​	To use these APIs, you will have to download the code from the Web.

Examples:

* YouTube API - Allows you to display videos on a web site.
* Twitter API - Allows you to display Tweets on a web site.
* Facebook API - Allows you to display Facebook info on a web site.



# 2. JavaScript Validation API

## 2.1 Constraint Validation DOM Methods

| Property            | Description                                              |
| ------------------- | -------------------------------------------------------- |
| checkValidity()     | Returns true if an input element contains valid data.    |
| setCustomValidaty() | Sets the validationMessage property of an input element. |

​	If an input field contains invalid data, display a message:

```
<h3>JavaScript Web APIs:</h3>
<input id="id27" type="number" min="100" max="300" required>
<button type="button" onclick="myFunction27()">OK</button>
<p id="demo27"></p>
<!-- JS code -->
function myFunction27() {
	const inpObj = document.getElementById("id27");
	if (!inpObj.checkValidity()) {
		document.getElementById("demo27").innerHTML = 
			inpObj.validationMessage;
	} else {
		document.getElementById("demo27").innerHTML = "Input OK";
	}
}
```

## 2.2 Constraint Validation DOM Properties

| Property          | Description                                                  |
| ----------------- | ------------------------------------------------------------ |
| validaty          | Contains boolean properties related to the validity of an input element. |
| validationMessage | Contains the message a browser will display when the validity is false. |
| willValidate      | Indicates if an input element will be validated.             |

## 2.3 Validity Properties

​	The <b>validity property</b> of an input element contains a number of properties related to the validity of data:

| Property        | Description                                                  |
| --------------- | ------------------------------------------------------------ |
| customError     | Set to true, if a custom validity message is set.            |
| patternMismatch | Set to true, if an element's value does not match its pattern attribute. |
| rangeOverflow   | Set to true, if an element's value is greater than its max attribute. |
| rangeUnderflow  | Set to true, if an element's value is less than its min attribute. |
| stepMismatch    | Set to true, if an element's value is invalid per its step attribute. |
| tooLong         | Set to true, if an element's value exceeds its maxLength attribute. |
| typeMismatch    | Set to true, if an element's value is invalid per its type attribute. |
| valueMissing    | Set to true, if an element (with a required attribute) has no value. |
| valid           | Set to true, if an element's value is valid.                 |

<span style="font-size: 20px;">Examples</span>

​	If the number in an input field is greater than 100 (the input's <span style="color:red;">max</span> attribute), display a message:

```
<input id="id1" type="number" max="100">
<button onclick="myFunction()">OK</button>
<p id="demo"></p>
<script>
function myFunction() {
	let text = "Value OK";
	if (document.getElementById("id1").validity.rangeOverflow) {
		text = "Value too large";
	}
}
</script>
```

​	If the number in an input field is less than 100 (the input's <span style="color:red;">min</span> attribute), display a message:

```
<input id="id1" type="number" min="100">
<button onclick="myFunction()">OK</button>
<p id="demo"></p>
<script>
function myFunction() {
  let text = "Value OK";
  if (document.getElementById("id1").validity.rangeUnderflow) {
    text = "Value too small";
  }
}
</script>
```



# 3. Web History API

​	The Web History API provides easy methods to access the window.history object.

​	The window.history object contains the URLs (Web Sites) visited by the user.

## 3.1 The History back() Method

​	The back() method loads the previous URL in the window.history list.

​	It is the same as clicking the "back arrow" in your browser:

```
<button onclick="myFunction()">Go Back</button>
<script>
function myFunction() {
	windown.history.back();
}
</script>
```

## 3.2 The History go() Method

​	The go() method loads a specific URL from the history list:

```
<button onclick="myFunction()">Go Back 2 Pages</button>
<script>
function myFunction() {
  window.history.go(-2);
}
</script>
```

## 3.3 History Object Properties

| Property | Description                                    |
| -------- | ---------------------------------------------- |
| length   | Returns the number of URLs in the history list |

## 3.4 History Object Methods

| Method    | Description                                |
| --------- | ------------------------------------------ |
| back()    | Loads the previous URL in the history list |
| forward() | Loads the next URL in the history list     |
| go()      | Loads a specific URL from the history list |



# 4.  Web Storage API

​	The Web Storage API is a simple syntax for storing and retrieving data in the browser. It is very easy to use:

```
localStorage.setItem("name", "Joe Biden");
localStorage.getItem("name");	//Joe Biden;
```

## 4.1 The localStorage Object

​	The localStorage object provides access to a local storage for a particular Web Site. It allows you to store, read, add, modify, and delete data items for that domain.

​	The data is stored with no expiration date, and will not be deleted when the browser is closed. The data will be available for days, weeks, and years.

## 4.2 The setItem() Method

​	The localstorage.setItem() method stores a data item in a storage.

​	It takes a name and a value as parameter:

```
localStorage.setItem("name", "Donald Trump");
```

## 4.3 The getItem() Method

​	The localstorage.getItem() method retrieves a data item from the storage.

​	It takes a name as parameter:

```
localStorage.getItem("name");	//Donald Trump
```

## 4.4 The sessionStorage Object

​	The sessionStorage object is identical to the localStorage object.

​	The difference is that the sessionStorage object stores data for one session.

​	The data is deleted when the browser is closed:

```
sessionStorage.getItem("name");
```

## 4.5 Storage Object Properties and Methods

| Property/Method         | Description                                                  |
| ----------------------- | ------------------------------------------------------------ |
| key(n)                  | Returns the name of the nth key in the storage               |
| length                  | Returns the number of data items stored in the Storage object |
| getItem(keyname)        | Returns the value of the specified key name                  |
| setItem(keyname, value) | Adds a key to the storage, or updates a key value (if it already exists) |
| removeItem(keyname)     | Removes that key from the storage                            |
| clear()                 | Empty all key out of the storage                             |

## 4.6 Related Pages for Web Storage API

| Property              | Description                                                  |
| --------------------- | ------------------------------------------------------------ |
| window.localStorage   | Allows to save key/value pairs in a web browser. Stores the data with no expiration date |
| window.sessionStorage | Allows to save key/value pairs in a web browser. Stores the data for one session |



# 5. Web Workers API

​	A web worker is a JavaScript running in the background, without affecting the performance of the page.

## 5.1 What is a Web Worker?

​	When executing scripts in an HTML page, the page becomes unresponsive until the script is finished.

​	A web worker is a JavaScript that runs in the background, independently of other scripts, without affecting the performance of the page. You can continue to do whatever you want: clicking, selecting things, etc., while the web worker runs in the background.

## 5.2 Web Worker Example

​	The example below creates a simple web worker that count numbers in the background:

```
<p>Count number: <output id="result"></output></p>
<button onclick="startWorker()">Start Worker</button>
<button onclick="stopWorker()">Stop Worker</button>
<script>
let w;
function startWorker() {
	if(typeof(w) == "undefined") {
		w = new Worker("demo_worker.js");
	}
	w.onmessage = function(event) {
		document.getElementById("result").innerHTML = event.data;
	};
}
function stopWorker() {
	w.terminate();
	w = undefined;
}
</script>
```

## 5.3 Check Web Worker Support

​	Before creating a web worker, check whether the user's browser supports it:

```
if (typeof(Worker) !== "undefiend") {
	//Yes! Web worker support!
} else {
	//No Web Worker support ...
}
```

## 5.4 Create a Web Worker File

​	Now, let's create our web worker in an external JavaScript.

​	Here, we create a script that counts. The script is stored in the "demo_worker.js" file:

```
let i = 0;
function timedCount() {
	i++;
	posstMessage(i);
	setTimeout("timedCount()", 500);
}
timedCount();
```

​	The important part of the code above is the <span style="color:red;">postMessage()</span> method - which is used to post a message back to the HTML page.

<b>Note:</b> Normally web workers are not used for such simple scripts, but for more CPU intensive tasks.

## 5.5 Create a Web Worker Object

​	Now that we have the web worker file, we need to call it from an HTML page.

​	First checks if the worker already exists, if not, creates a new web worker object:

```
if (typeof(w) == "undefined") {
	w = new Worker("demo_workers.js");
}
```

​	Then we can send and receive messages from the web worker.

​	Add an "onmessage" event listener to the web worker :

```
w.onmessage = function(event) {
 document.getElementById("result").innerHTML = event.data;
} 
```

​	<span style="color:blue;"> When the web worker posts a message, the code within the event listener is executed</span>. The data from the web worker is stored in event.data.

## 5.6 Terminate a Web Worker

​	When a web worker object is created, it will continue to listen for messages (even after the external script is finished) until it's terminated.

​	To terminate a web worker, and free browser/computer resources, use the <span style="color:red;">terminate()</span> method:

```
w.terminate();
```

## 5.6 Reuse the Web Worker

​	If you set the worker variable to undefined, after it has been terminated, you can reuse the code:

```
w = undefined;
```

## 5.7 Full Web Worker Example Code

​	We have already seen the Worker code in the .js file. Below is the code for the HTML page (demo_workers.js at above): 

```
<!DOCTYPE html>
<html>
<body>
<p>Count numbers: <output id="result"></output></p>
<button onclick="startWorker()">Start Worker</button>
<button onclick="stopWorker()">Stop Worker</button>
<script>
let w;
function startWorker() {
  if (typeof(w) == "undefined") {
    w = new Worker("demo_workers.js");
  }
  w.onmessage = function(event) {
    document.getElementById("result").innerHTML = event.data;
  };
}
function stopWorker() {
  w.terminate();
  w = undefined;
}
</script>
</body>
</html>
```

## 5.8 Web Workers and the DOM

​	Since web workers are in external files, they do not have access to the following JavaScript objects:

* The window object
* The document object
* The parent object



# 6. JavaScript Fetch API

​	The Fetch API interface allows web browser to make HTTP requests to web servers. No need for XMLHttpRequest anymore.

## 6.1 A Fetch API Example

​	The example below fetches a file and display the content:

```
<script>
let file = "fetch_info.txt"
fetch(file)
.then(x => x.text())
.then(y => document.getElementById("demo").innerHTML = y);
</script>
```

​	Since Fetch is based on async and await, the example above might be easier to understand like this:

```
<script>
getText("fetch_info.txt");
asyn function getText(file) {
	let x = await fetch(file);
	let y = await x.text();
	document.getElementById("demo").innerHTML = y;
}
</script>
```

​	Or even better: Use understandable names instead of x and y:

```
<script>
getText("fetch_info.txt");
async function getText(file) {
  let myObject = await fetch(file);
  let myText = await myObject.text();
  document.getElementById("demo").innerHTML = myText;
}
</script>
```



# 7. Web Geolocation API

## 7.1 Locate the User's Position

​	The HTML Geolocation API is used to get the geographical position of a user.

​	Since this can compromise privacy, the position is not available unless the user approves it.

<b>Note:</b> Geolocation is most accurate for devices with GPS, like smartphones.

​	And Geolocation API will only work on secure contexts such as HTTPS.

## 7.2 Using the Geolocation API

​	The <span style="color:red;">getCurrentPosition()</span> method is used to return the user's position.

​	The example below returns the latitude and longitude of the user's positon:

```
<script>
const x = document.getElementById("demo");
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude +
  "<br>Longitude: " + position.coords.longitude;
}
</script>
```

## 7.3 Handling Errors and Rejections

​	The second parameter of the <span style="color:red;">getCurrentPosition()</span> method is used to handle errors. It specifies a function to run if it fails to get the user's location:

```
<script>
const x = document.getElementById("demo");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition, showError);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude + 
  "<br>Longitude: " + position.coords.longitude;
}

function showError(error) {
  switch(error.code) {
    case error.PERMISSION_DENIED:
      x.innerHTML = "User denied the request for Geolocation."
      break;
    case error.POSITION_UNAVAILABLE:
      x.innerHTML = "Location information is unavailable."
      break;
    case error.TIMEOUT:
      x.innerHTML = "The request to get user location timed out."
      break;
    case error.UNKNOWN_ERROR:
      x.innerHTML = "An unknown error occurred."
      break;
  }
}
</script>
```

## 7.4 Display the Result in a Map

​	To display the result in a map, you need access to a map service, like Google Maps.

​	In the example below, the returned latitude and longitude is used to show the location in a Google Map (using a static image). Practice it:

 ```
 function showPosition(position) {
   let latlon = position.coords.latitude + "," + position.coords.longitude;
 
   let img_url = "https://maps.googleapis.com/maps/api/staticmap?center=
   "+latlon+"&zoom=14&size=400x300&sensor=false&key=YOUR_KEY";
 
   document.getElementById("mapholder").innerHTML = "<img src='"+img_url+"'>";
 }
 ```

## 7.5 Location-specific Information

​	This page has demonstrated how to show a user's position on a map.

​	Geolocation is also very useful for location-specific information, like:

* Up-to-date local information
* Showing Points-of-interest near the user
* Turn-by-turn navigation (GPS)

## 7.6 The getCurrentPosition() Method - Return Data

​	The <span style="color:red;">getCurrentPosition()</span> method returns an object on success. The latitude, longitude and accuracy properties are always returned. The other properties are returned if available:

| roperty                 | Returns                                                      |
| :---------------------- | :----------------------------------------------------------- |
| coords.latitude         | The latitude as a decimal number (always returned)           |
| coords.longitude        | The longitude as a decimal number (always returned)          |
| coords.accuracy         | The accuracy of position (always returned)                   |
| coords.altitude         | The altitude in meters above the mean sea level (returned if available) |
| coords.altitudeAccuracy | The altitude accuracy of position (returned if available)    |
| coords.heading          | The heading as degrees clockwise from North (returned if available) |
| coords.speed            | The speed in meters per second (returned if available)       |
| timestamp               | The date/time of the response (returned if available)        |

## 7.7 Geolocation Object - Other interesting Methods

​	The Geolocation object also has other interesting methods:

* <span style="color:red;">watchPosition()</span> - Returns the current positon of the user and continues to return updated position as the user moves (like the GPS in car).
* <span style="color:red;">clearWatch()</span> - Stops the <span style="color:red;">watchPosition()</span> method

​	The example below show the <span style="color:red;">watchPosition</span> method. You need an accurate GPS device to test this:

```
<button onclick="getLocation()">Try It</button>
<p id="demo"></p>
<script>
const x = document.getElementById("demo");
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.watchPosition(showPosition);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}
function showPosition(position) {
    x.innerHTML="Latitude: " + position.coords.latitude + 
    "<br>Longitude: " + position.coords.longitude;
}
</script>
```



# 8. AJAX Introduction

​	AJAX is a developer's dream, because you can:

* Read data from a web server - after the page has loaded
* Update a web page without reloading the page
* Send data to a web server - in the background

AJAX Example:

```
<h3>The XMLHttpRequest Object</h3>
<button type="button" onclick="loadDoc()">Change Content</button>
<script>
function loadDoc() {
	const xhttp = new XMLHttpRequest();
	xhttp.onload = function() {
		document.getElementById("demo").innerHTML = 
			this.responseText;
	}
	xhttp.open("GET", "ajax_info.txt");
	xhttp.send();
}
</script>
```

## 8.1 What is AJAX

​	AJAX = Asynchronous JavaScript And XML

​	AJAX is not a programming language. AJAX just uses a combination of:

* A browser built-in <span style="color:red;">XMLHttpRequest</span> object (to request data from a web server)
* JavaScript and HTML DOM (to display or use the data)

<b>NOTE:</b> AJAX is a misleading name. AJAX applications might use XML to transport data, but ti is equally common to transport data as plain text or JSON text.

​	AJAX allows web pages to be updated asynchronously be exchanging data with a web server behind the scenes. This means that it is possible to update parts of a web page, without reloading the whole page.

## 8.2 How AJAX Works

<img src="img/pic_ajax.gif">

1. An event occurs in a web page (the page is loaded, a button is clicked, etc.)
2. An XMLHttpRequest object is created by JavaScript
3. The XMLHttpRequest object sends a request to a web server
4. The server processes the request
5. The server sends a response back to the web page
6. The response is read by JavaScript
7. Proper action (like page update) is performed by JavaScript

## 8.3 Modern Browsers (Fetch API)

​	Modern Borwsers can use Fetch API instead of the XMLHttpRequest Object.

​	The Fetch API Interface allows web browser to make HTTP requests to web servers.

​	If you use the XMLHttpRequest object, Fetch can do the same in a simpler way.



# 9. AJAX - The XMLHttpRequest Object

​	The keystone of AJAX is the XMLHttpRequest object.

1. Create an XMLHttpRequest object
2. Define a callback function
3. Open the XMLHttpRequest object
4. Send a Request to a server

## 9.1 The XMLHttpRequest Object

​	All modern browser support the <span style="color:red;">XMLHttpRequest</span> object.

​	The <span style="color:red;">XMLHttpRequest</span> object can be used to exchange data with a web server behind the scenes. This means that it is possible to update parts of a web page.

## 9.2 Create an XMLHttpRequest Object

​	All modern browsers (Chrome, Firefox, IE, Edge, Safari, Opera) have a built-in <span style="color:red;">XMLHttpRequest</span> object. Syntax for creating an <span style="color:red;">XMLHttpRequest</span> object is:

```
variable = new XMLHttpRequest();
```

## 9.3 Define a Callback Function

​	A callback function is a function passed as a parameter to another function.

​	In this case, the callback function should contain the code to execute when the response is ready:

```
xhttp.onload = function() {
	//code block
}
```

## 9.4 Send a Request

​	To send a request to a server,, you can use the open() and send() methods of the <span style="color:red;">XMLHttpRequest</span> object:

```
xhttp.open("GET", "ajax_info.txt");
xhttp.send();
```

## 9.5 Access Across Domains

​	For security reasons, modern browsers do not allow access across domains.

​	This means that both the web page and XML file it tries to load, must be located on the same server. If you want to use the example above on one of your own web pages, the XML files you load must be located on your own server (No, despite on the same server, I can't load the file).

## 9.6 XMLHttpRequest Object Methods

| Method                              | Description                                                  |
| ----------------------------------- | ------------------------------------------------------------ |
| new XMLHttpRequest()                | Creates a new XMLHttpRequest object                          |
| abort()                             | Cancels the current request                                  |
| getAllResponseHeaders()             | Returns header information                                   |
| open(method, url, async, user, psw) | Specified the request<br>method: request type, GET or POST<br>async: true or false<br>user: optional user name<br>psw: optional password |
| send()                              | Sends the request to the server<br>Used for GET requests     |
| send(string)                        | Sends the request to the server<br>Used for POST request     |
| getResponseHeader()                 | Returns specific header information                          |
| setRequestHeader()                  | Adds a label/value pair to the header to sent                |

## 9.7 XMLHttpRequest Object Properties

| Property           | Description                                                  |
| ------------------ | ------------------------------------------------------------ |
| onload             | Defines a function to be called when the request is recieved (loaded) |
| onreadystatechange | Defines a function to be called when the readyState property changes |
| readyState         | Holds the status of the XMLHttpRequest.<br>0: request not initialized<br>1: server connection established<br>2: request received<br>3: processing request<br>4: request finished and response is ready |
| responseText       | Returns the response data as a string                        |
| responseXML        | Returns the response data as XML data                        |
| status             | Returns the status-number of a request<br>200: "OK"<br>403: "Forbidden"<br>404: "Not Found"<br>For a complete list go to the [Http Messages Reference](https://www.w3schools.com/tags/ref_httpmessages.asp) |
| statusText         | Returns the status-text (e.g. "OK" or "Not Found")           |

## 9.8 The onload Property

​	With the <span style="color:red;">XMLHttpRequest</span> object you can define a callback function to be executed when the request receives an answer.

​	The function is define in the <span style="color:red;">onload</span> property of the <span style="color:red;">XMLHttpRequest</span> object:

## 9.9 Multiple Callback Functions

​	If you have more than one AJAX task in a website, you should create one function for executing thhe <span style="color:red;">XMLHttpRequest</span> object, and one callback function for each AJAX task.

​	The function call should contain the URL and what function to call when the response is ready:

```
loadDoc("url-1", myFunction1);
loadDoc("url-2", myFunction2);
function loadDoc(url, cFunction) {
	const xhttp = new XMLHHttpRequest();
	xhttp.onload = function() {cFunction(this);}
	xhttp.open("GET", url);
	xhttp.send();
}
//... myFunction1() and myFunction2()
```

## 9.10 The onreadystatechange Property

​	The <span style="color:red;">readyState</span> property holds the status of the XMLHttpRequest.

​	The <span style="color:red;">onreadystatechange</span> property defines a callback function to be executed when the readState changes. The <span style="color:red;">onreadystatechange</span> function is called every time the readyState changes. When <span style="color:red;">readyState</span> is 4 and status is 200, the response is ready:

```
function loadDoc() {
  const xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", "ajax_info.txt");
  xhttp.send();
}
```

<b>Note:</b> The <span style="color:red;">onreadystatechange</span> event is triggered four times (1-4), one time for each change in the readyState.



# 10. AJAX - XMLHttpRequest

​	The XMLHttpRequest object is used to request data from a server.

## 10.1 Send a Request To a Server

​	To send a request to a server, we use the open() and send() method of the <span style="color:red;">XMLHttpRequest</span> object:

```
xhttp.open("GET", "ajax_info.txt", true);
xhttp.send();
```

## 10.2 Asynchronous - True of False?

​	Server requests should be sent asynchronously.

​	The asyn parameter of the open() method should be set to true.

​	By sending asynchronously, the JavaScript does not have to wait for the  server response, but can instead:

* execute other scripts while waiting for server response
* deal with the response after the response is read

<b>Note:</b>

​	The default value for the async parameter is async = true. You can safely remove the third parameter from your code. Synchronous XMLHttpRequest is not recommended because the JavaScript will stop executing until the server response is ready. If the server is busy or slow, the application will hang or stop.

## 10.3 GET or POST?

​	<span style="color:red;">GET</span> is simpler and faster than <span style="color:red;">POST</span>, and can be used in most cases.

​	However, always use POST request when:

* A cached file is not an option (update a file or database on the server)).
* Sending a large amount of data to server (POST has no size limitations)
* Sending user input (which can contain unknown character), POST is more robust and secure than GET.

## 10.4 GET Requests

​	A simple <span style="color:red;">GET</span> request:

```
xhttp.open("GET", "demo_get.asp");
xhttp.send();
```

​	In the example above, you may get a cached result. To avoid this, add a unique ID to the URL:

```
xhttp.open("GET", "demo_get.asp?t=" + Math.random());
xhttp.send();
```

​	If you want to send information with the <span style="color:red;">GET</span> method, add the information to the URL:

```
xhttp.open("GET", "demo_get2.asp?fname=Henry&lname=Ford");
xhttp.send();
```

​	How the server uses the input and how the server responds to a request, is explained in a later chapter.

## 10.5 POST Requests

​	A simple <span style="color:red;">POST</span> request:

```
xhttp.open("POST", "demo_post.asp");
xhttp.send();
```

​	To POST data like an HTML form, add an HTTP header with <span style="color:red;">setRequestsHeader()</span>. Specify the data you want to send in the <span style="color:red;">send()</span> method:

```
xhttp.open("POST", "ajax_test.asp");
xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhttp.send("fname=Henry&lname=Ford");
```

## 10.6 Synchronous Request

​	To execute a synchronous request, change the third parameter in the <span style="color:red;">open()</span> method to <b>false</b>:

```
xhttp.open("GET", "ajax_info.txt", false);
```

​	Sometimes async = false are used for quick testing. Sine the code will wait for server completion, there is no need for an <span style="color:red;">onreadystatechange</span> function:

```
xhttp.open("GET", "ajax_info.txt", false);
xhttp.send();
document.getElementById("demo").innerHTML = xhttp.responseText;
```

<b>NOTE:</b> Synchhronous XMLHttpRequest is not recommended because the JavaScript will stop executing until the server response is ready. If the server is busy or slow, the application will hang or stop.

​	Modern developer tools are encouraged to warn about using synchronous requests and may throw an InvalidAccessError exception when it occurs.



# 11. AJAX - Server Response

## 11.1 Server Response Properties

| Property     | Description                       |
| :----------- | :-------------------------------- |
| responseText | get the response data as a string |
| responseXML  | get the response data as XML data |

### 11.1.1 The responseText Property

​	The <span style="color:red;">responseText</span> property returns he server response as a JavaScript string, and you can use it accordingly:

```
<button type="button" onclick="loadDoc()">Change Content</button>
</div>
<script>
function loadDoc() {
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("demo").innerHTML =
    this.responseText;
  }
  xhttp.open("GET", "ajax_info.txt");
  xhttp.send();
}
</script>
```

### 11.1.2 The responseXML Property

​	The XMLHttpRequest object has an in-built XML parser.

​	The <span style="color:red;">responseXML</span> property returns the server response as an XML DOM object.

​	Using this property you can parse the response as an XML DOM object:

```
const xmlDoc = xhttp.responseXML;
const x = xmlDoc.getElementsByTagName("ARTIST");

let txt = "";
for (let i = 0; i < x.length; i++) {
  txt += x[i].childNodes[0].nodeValue + "<br>";
}
document.getElementById("demo").innerHTML = txt;

xhttp.open("GET", "cd_catalog.xml");
xhttp.send();
```

## 11.2 Server Response Methods

| Method                  | Description                                                  |
| :---------------------- | :----------------------------------------------------------- |
| getResponseHeader()     | Returns specific header information from the server resource |
| getAllResponseHeaders() | Returns all the header information from the server resource  |

### 11.2.1 The getAllResponseHeaders() Method

​	The <span style="color:red;">getAllResponseHeader()</span> method returns all header information from the server response:

```
const xhttp = new XMLHttpRequest();
xhttp.onload = function() {
    document.getElementById("demo").innerHTML =
    this.getAllResponseHeaders();
}
xhttp.open("GET", "ajax_info.txt");
xhttp.send();
```

### 11.2.2 The getResponseHeader() Method

​	The <span style="color:red;">getResponseHeader()</span> method returns specific header information from the server response:

```
const xhttp = new XMLHttpRequest();
xhttp.onload = function() {
    document.getElementById("demo").innerHTML =
    this.getResponseHeader("Last-Modified");
}
xhttp.open("GET", "ajax_info.txt");
xhttp.send();
```



# 12. AJAX XML Example

​	AJAX can be used for interactive communication with an XML file.

## 12.1 AJAX XML Example

​	The following example will demonstrate how a web page can fetch information from an XML file with AJAX:

```
<!DOCTYPE html>
<html>
<style>
table,th,td {
  border : 1px solid black;
  border-collapse: collapse;
}
th,td {
  padding: 5px;
}
</style>
<body>

<h2>The XMLHttpRequest Object</h2>

<button type="button" onclick="loadDoc()">Get my CD collection</button>
<br><br>
<table id="demo"></table>

<script>
function loadDoc() {
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    myFunction(this);
  }
  xhttp.open("GET", "cd_catalog.xml");
  xhttp.send();
}
function myFunction(xml) {
  const xmlDoc = xml.responseXML;
  const x = xmlDoc.getElementsByTagName("CD");
  let table="<tr><th>Artist</th><th>Title</th></tr>";
  for (let i = 0; i <x.length; i++) { 
    table += "<tr><td>" +
    x[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue +
    "</td><td>" +
    x[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue +
    "</td></tr>";
  }
  document.getElementById("demo").innerHTML = table;
}
</script>

</body>
</html>
```

Example Explained:

​	When a user clicks on the "GET CD info" button above, the <span style="color:red;">loadDoc()</span> function is exectued; The <span style="color:red;">loadDoc()</span> function creates an <span style="color:red;">XMLHttpRequest</span> object, adds the function to be executed when the server response is ready, and sends the request off to the server.

​	When the server response is ready, and HTML table is built, nodes (elements) are extracted from the XML file, and it finally updates the element "demo" with the HTML table filled with XML data:

```
function loadDoc() {
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {myFunction(this);}
  xhttp.open("GET", "cd_catalog.xml");
  xhttp.send();
}
function myFunction(xml) {
  const xmlDoc = xml.responseXML;
  const x = xmlDoc.getElementsByTagName("CD");
  let table="<tr><th>Artist</th><th>Title</th></tr>";
  for (let i = 0; i <x.length; i++) {
    table += "<tr><td>" +
    x[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue +
    "</td><td>" +
    x[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue +
    "</td></tr>";
  }
  document.getElementById("demo").innerHTML = table;
}
```



# 13. AJAX PHP Example

​	AJAX is used to create more interactive applications.

## 13.1 AJAX PHP Example

​	The following example demonstrates how a web page can communicate with a web server while a user types characters in an input field:

```
<h3>Start typing a name in the input field below:</h3>

<p>Suggestions: <span id="txtHint"></span></p> 
<p>First name: <input type="text" id="txt1" onkeyup="showHint(this.value)"></p>

<script>
function showHint(str) {
  if (str.length == 0) { 
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("txtHint").innerHTML =
    this.responseText;
  }
  xhttp.open("GET", "gethint.php?q="+str);
  xhttp.send();   
}
</script>
```

​	In the example above, when a user types a character in the input field, a function called <span style="color:red;">showHint()</span> is executed, the function is triggered by the <span style="color:red;">onkeyup</span> event.

​	The code first check if the input field is empty (str.length == 0). If it is, clear the content of the txtHint placeholder and exit the function.

​	However, if the input field is not empty, do the following:

* Create an XMLHttpRequest object
* Create the function to be executed when the server response is ready
* Send the request off to a PHP (gethit.php) on the server
* Notice that q parameter is added gethit.php?p="+str
* The str variable holds the content of the input field

## 13.2 The PHP File - "gethint.php"

​	The PHP file checks an array of names, and returns the corresponding name(s) to the browser:

```
<?php
// Array with names
$a[] = "Anna";
$a[] = "Brittany";
$a[] = "Cinderella";
$a[] = "Diana";
$a[] = "Eva";
$a[] = "Fiona";
$a[] = "Gunda";
$a[] = "Hege";
$a[] = "Inga";
$a[] = "Johanna";
$a[] = "Kitty";
$a[] = "Linda";
$a[] = "Nina";
$a[] = "Ophelia";
$a[] = "Petunia";
$a[] = "Amanda";
$a[] = "Raquel";
$a[] = "Cindy";
$a[] = "Doris";
$a[] = "Eve";
$a[] = "Evita";
$a[] = "Sunniva";
$a[] = "Tove";
$a[] = "Unni";
$a[] = "Violet";
$a[] = "Liza";
$a[] = "Elizabeth";
$a[] = "Ellen";
$a[] = "Wenche";
$a[] = "Vicky";

// get the q parameter from URL
$q = $_REQUEST["q"];

$hint = "";

// lookup all hints from array if $q is different from ""
if ($q !== "") {
  $q = strtolower($q);
  $len=strlen($q);
  foreach($a as $name) {
    if (stristr($q, substr($name, 0, $len))) {
      if ($hint === "") {
        $hint = $name;
      } else {
        $hint .= ", $name";
      }
    }
  }
}

// Output "no suggestion" if no hint was found or output correct values
echo $hint === "" ? "no suggestion" : $hint;
?>
```



# 14. AJAX ASP Example

## 14.1 AJAX ASP Example

​	The following example will demonstrate how a web page can communicate with a web server while a user type character in an input filed:

```
<!DOCTYPE html>
<html>
<body>

<h2>The XMLHttpRequest Object</h2>
<h3>Start typing a name in the input field below:</h3>

<p>Suggestions: <span id="txtHint"></span></p> 
<p>First name: <input type="text" id="txt1" onkeyup="showHint(this.value)"></p>

<script>
function showHint(str) {
  if (str.length == 0) { 
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("txtHint").innerHTML =
    this.responseText;
  }
  xhttp.open("GET", "gethint.asp?q="+str);
  xhttp.send();
}
</script>

</body>
</html>
```

​	This code is similar to previous chapter, and what it do are also similar.

## 14.2 The ASP File

```
<%
response.expires=-1
dim a(30)
'Fill up array with names
a(1)="Anna"
a(2)="Brittany"
a(3)="Cinderella"
a(4)="Diana"
a(5)="Eva"
a(6)="Fiona"
a(7)="Gunda"
a(8)="Hege"
a(9)="Inga"
a(10)="Johanna"
a(11)="Kitty"
a(12)="Linda"
a(13)="Nina"
a(14)="Ophelia"
a(15)="Petunia"
a(16)="Amanda"
a(17)="Raquel"
a(18)="Cindy"
a(19)="Doris"
a(20)="Eve"
a(21)="Evita"
a(22)="Sunniva"
a(23)="Tove"
a(24)="Unni"
a(25)="Violet"
a(26)="Liza"
a(27)="Elizabeth"
a(28)="Ellen"
a(29)="Wenche"
a(30)="Vicky"

'get the q parameter from URL
q=ucase(request.querystring("q"))

'lookup all hints from array if length of q>0
if len(q)>0 then
  hint=""
  for i=1 to 30
    if q=ucase(mid(a(i),1,len(q))) then
      if hint="" then
        hint=a(i)
      else
        hint=hint & " , " & a(i)
      end if
    end if
  next
end if

'Output "no suggestion" if no hint were found
'or output the correct values
if hint="" then
  response.write("no suggestion")
else
  response.write(hint)
end if
%>
```



# 15. AJAX Database Example

## 15.1 AJAX Database Example

​	The following example will demonstrate how a web page can fetch information from a database with AJAX:

```
<!DOCTYPE html>
<html>
<style>
th,td {
  padding: 5px;
}
</style>
<body>

<h2>The XMLHttpRequest Object</h2>

<form action=""> 
  <select name="customers" onchange="showCustomer(this.value)">
    <option value="">Select a customer:</option>
    <option value="ALFKI">Alfreds Futterkiste</option>
    <option value="NORTS ">North/South</option>
    <option value="WOLZA">Wolski Zajazd</option>
  </select>
</form>
<br>
<div id="txtHint">Customer info will be listed here...</div>

<script>
function showCustomer(str) {
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("txtHint").innerHTML = this.responseText;
  }
  xhttp.open("GET", "getcustomer.php?q="+str);
  xhttp.send();
}
</script>
</body>
</html>
```

​	When a user selects a customer in the dropdown list above, a function called <span style="color:red;">showCustomer()</span> is executed. The function is triggered by the <span style="color:red;">onchange</span> event. The <span style="color:red;">showCustomer()</span> function does the following:

* Check is a customer is selected
* Create an XMLHttpRequest Object
* Create the function to be executed when the server response is ready
* Send the request off to a file on the server
* Notice that a parameter (q) is added to the URL (with the content of the dropdown list)

## 15.2 The AJAX Serverr Page

​	The page on the server called by the JavaScript above is a PHP file called "getcustomer.php". The source code in this file runs a query against a database, and returns the result in an HTML table:

```
<?php
$mysqli = new mysqli("servername", "username", "password", "dbname");
if($mysqli->connect_error) {
  exit('Could not connect');
}

$sql = "SELECT customerid, companyname, contactname, address, city, postalcode, country
FROM customers WHERE customerid = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $_GET['q']);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($cid, $cname, $name, $adr, $city, $pcode, $country);
$stmt->fetch();
$stmt->close();

echo "<table>";
echo "<tr>";
echo "<th>CustomerID</th>";
echo "<td>" . $cid . "</td>";
echo "<th>CompanyName</th>";
echo "<td>" . $cname . "</td>";
echo "<th>ContactName</th>";
echo "<td>" . $name . "</td>";
echo "<th>Address</th>";
echo "<td>" . $adr . "</td>";
echo "<th>City</th>";
echo "<td>" . $city . "</td>";
echo "<th>PostalCode</th>";
echo "<td>" . $pcode . "</td>";
echo "<th>Country</th>";
echo "<td>" . $country . "</td>";
echo "</tr>";
echo "</table>";
?>
```



# 16. XML Applications

​	This chapter demonstrates some HTML applications using XML, HTTP, DOM, and JavaScript.

## 16.1 Display XML Data in an HTML Table

​	This example loops through each \<CD> element, and displays the values of the \<ARTIST> and the \<TITLE> element in an HTML table:

```
<table id="demo"></table>
<script>
function loadXMLDoc() {
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    const xmlDoc = xhttp.responseXML;
    const cd = xmlDoc.getElementsByTagName("CD");
    myFunction(cd);
  }
  xhttp.open("GET", "cd_catalog.xml");
  xhttp.send();
}
function myFunction(cd) {
  let table="<tr><th>Artist</th><th>Title</th></tr>";
  for (let i = 0; i < cd.length; i++) {
    table += "<tr><td>" +
    cd[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue +
    "</td><td>" +
    cd[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue +
    "</td></tr>";
  }
  document.getElementById("demo").innerHTML = table;
}
</script>
</body>
</html>
```

## 16.2 Display the First CD in an HTML div Element

​	This example uses a function to display the first CD element in an HTML element with id="showCD":

```
const xhttp = new XMLHttpRequest();
xhttp.onload = function() {
	const xmlDoc = xhttp.responseXML;
	const cd = cxmlDoc.getElementByTagName("CD");
	myFunction(cd, 0);
}
xhttp.open("GET", "cd_catalog.xml");
xhttp.send();
function myFunction(cd, i) {
	document.getElementById("showCD").innerHTML = 
	"Artist: " +
	cd[i].getElementByTagName("ARTIST")[0].childNodes[0].nodeValue +
	"<br>Title: " + 
	cd[i].getElementByTagName("TITLE")[0].childNodes[0].nodeValue +
	"<br>Year: " +
	cd[i].getElementByTagName("YEAR")[0].childNodes[0].nodeValue;
}
```

## 16.3 Navigate Between the CDs

​	To navigate between the CDs in the example above, create a <span style="color:red;">next()</span> and <span style="color:red;">previous()</span> function:

```
function next() {
  if (i < len-1) {
    i++;
    displayCD(i);
  }
}
function previous() {
  if (i > 0) {
    i--;
    displayCD(i);
  }
}
```

## 16.4 Show Album Information When Clicking On a CD

​	The last example shows how you can show album information when the user clicks on a CD:

```
function displayCD(i) {
  document.getElementById("showCD").innerHTML =
  "Artist: " +
  cd[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue +
  "<br>Title: " +
  cd[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue +
  "<br>Year: " +
  cd[i].getElementsByTagName("YEAR")[0].childNodes[0].nodeValue;
}
```



# 17. AJAX Examples

​	Refer the directory "examples".





<span style="color:red;">
