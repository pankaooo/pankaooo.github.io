function toCelsius(fahrenheit) {
	return (5/9) * (fahrenheit-32);
}
document.getElementById("demo3").innerHTML = toCelsius;

let text = "Apple, Banana, Kiwi";
let part = text.slice(7, 13);
document.getElementById("demo4").innerHTML = part; 

let text5 = "They are gone...";
judge5 = text5.startsWith("gone", 9);
document.getElementById("demo5").innerHTML = judge5;

let header = "Templates Literals";
let tags = ["template literals", "javascript", "es6"];
let html = `<h2>${header}</h2><ul>`;
for (const x of tags) {
	html += `<li>${x}</li>`;
}
html += `</ul>`;
document.getElementById("demo6").innerHTML = html;

let myNumber = 2;
let txt = "";
while (myNumber != Infinity) {
	myNumber = myNumber * myNumber;
	txt = txt + myNumber + "<br>";
}
document.getElementById("demo7").innerHTML = txt;


const fruits = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo8").innerHTML = fruits.join(" * ");

document.getElementById("demo8-1").innerHTML = "Original Array:<br>" + fruits;
let removed = fruits.splice(2, 2, "Lemon", "Kiwi");
document.getElementById("demo8-2").innerHTML = "New Array:<br>" + fruits;
document.getElementById("demo8-3").innerHTML = "Removed Items:<br>" + removed;


const fruits9 = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo9-1").innerHTML = "Original array:<br>" +fruits9;
fruits9.sort().reverse();
document.getElementById("demo9-2").innerHTML = "After sort() and reverse():<br>" + fruits9;


const points10 = [10, 100, 1, 5, 4, 24, 32];
document.getElementById("demo10-1").innerHTML = points10;
points10.sort(function(a, b){return a - b;});
document.getElementById("demo10-2").innerHTML = points10;


const numbers = [12, 28, 41, 33, 56, 77, 21, 18, 17, 30, 22];
const over18 = numbers.filter(arrayFilter);
function arrayFilter(value, index, array) {
	return value >= 18;
}
document.getElementById("demo11").innerHTML = "Original arrays is: <br>" + 
	numbers + "<br>" + "filtered array is: " + "<br>" + over18;
const q1 = ["Jan", "Feb", "Mar"];
const q2 = ["Apr", "May", "Jun"];
const q3 = ["Jul", "Aug", "Sep"];
const q4 = ["Oct", "Nov", "May"];
const year = [...q1, ...q2, ...q3, ...q4];
document.getElementById("demo11-2").innerHTML = year;


const date = new Date(013, 4, 5);
document.getElementById("demo12").innerHTML = date;


const d13 = new Date();
document.getElementById("demo13").innerHTML = d13.getTimezoneOffset();


document.getElementById("demo14").innerHTML = "Boolean(0), Boolean(\"false\") is " + Boolean(0) + "," + Boolean("false");


const fruits15 = ["Banana", "Orange", "Apple"];
document.getElementById("demo15").innerHTML = isArray(fruits15);
function isArray(myArray) {
	return myArray.constructor.toString().indexOf("Array") > -1;
}

const bitwise1 = ~5;
document.getElementById("demo16").innerHTML = bitwise1;

function myFunction17() {
	const message = document.getElementById("demo17-2");
	message.innerHTML = "";
	let x = document.getElementById("demo17-1").value;
	try {
		if(x.trim() == "") throw "empty";
		if(isNaN(x)) throw "not a number";
		x = Number(x);
		if(x < 5) throw "too low";
		if(x > 10) throw "too high";
	} catch(err) {
		message.innerHTML = "Input is " + err;
	}
}

try {
	carName = "Volvo";
	let carName = "BYD";
} catch(err) {
	document.getElementById("demo18").innerHTML = err;
}


let text19 = '{"employees": [' +
	'{"firstName":"John", "lastName":"Doe"},' +
	'{"firstName":"Anna", "lastName":"Smith"}' +
	']}';
//alert(text19); 	don't save redundant comma in array
//const obj19 = JSON.parse(text19);
var obj19;
try {
	obj19 = JSON.parse(text19);
} catch(err) {
	alert(err);
}


document.getElementById("demo19").innerHTML = 
obj19.employees[1].firstName + " " + obj19.employees[1].lastName;


const letters20 = new Set();
const a = "a", b = "b", c = "c";
letters20.add(a).add(b).add(c);
document.getElementById("demo20").innerHTML = letters20.size;


class Car21 {
	constructor(brand) {
		this.carname = brand;
	}
	present() {
		return 'I have a ' + this.carname;
	}
}
class BYD extends Car21 {
	constructor(brand, mod) {
		super(brand);
		this.model = mod;
	}
	show() {
		return this.present() +', it has a ' + this.model;
	}
}
try {
	const myCar21 = new BYD("BYD", "Han");
	document.getElementById("demo21").innerHTML = myCar21.show();
} catch(err) {
	alert(err);
}

function myDisplayer22(some) {
	document.getElementById("demo22").innerHTML = some;
}
function getFile(myCallback) {
	let req = new XMLHttpRequest();
	//req.open('GET', "http://localhost:8080/E:/exper-now/计算机大杂烩/course_parallel_computer_architecture_and_programming/competetions/mygithubwebpage/my_learning/JS/mycar.html");	//or write in below
	//req.open('GET',"mycar.html");
	req.onload = function() {
		if(req.status == 200) {
			myCallback(this.responseText);	//or req.responseText
		} else {
			myCallback("Error: " + req.status);
		}
	}
	req.open('GET', "https://www.w3schools.com/js/mycar.html");
	req.send();
}
getFile(myDisplayer22);


setTimeout(myDOMimage, 3000);
function myDOMimage() {
	document.getElementById("myImage23").src = "img/lovely.jpg";
}

function validationForm() {
	let x = document.forms["myForm"]["fname"].value;
	if (x == "") {
		alert("Name must be filled out");
		return false;
	}
}

function validationNum() {
	let x = document.getElementById("numb").value;
	let text;
	if (isNaN(x) || x < 1 || x > 10) {
		text = "Input not valid .....";
	} else {
		text = "Input OK";
	}
	document.getElementById("numb-result").innerHTML = text;
}

function myMove() {
	let id = null;
	const elem = document.getElementById("animate1");
	let pos = 0;
	clearInterval(id);
	id = setInterval(frame, 5);
	function frame() {
		if(pos >= 175) {
			clearInterval(id);
		} else {
			pos += 2;
			elem.style.top = pos + "px";
			elem.style.left = pos + "px";
		}
	}
}

try {
	document.getElementsByTagName("body").onload = "checkCookies()";
} catch(err) {
	alert(err);
}
function checkCookies() {
	alert("Heldfsoidiosd");
	var text = "";
	if (navigator.cookieEnabled == true) {
		text = "Cookies are enabled.";
	} else {
		text = "Cookies are not enabled.";
	}
	document.getElementById("demo24").innerHTML = text;
}

window.addEventListener("resize", function() {
	document.getElementById("demo25").innerHTML = "You have resized the window!";
});


document.getElementById("demo26").innerHTML = "VALUE:" + location.href + "," + location.hostname
+ "," + location.pathname + "," + location.protocol + "," + location.port;


function myFunction27() {
	const inpObj = document.getElementById("id27");
	if (!inpObj.checkValidity()) {
		document.getElementById("demo27").innerHTML = 
			inpObj.validationMessage;
	} else {
		document.getElementById("demo27").innerHTML = "Input OK";
	}
}


function loadDoc() {
	const xhttp = new XMLHttpRequest();
	xhttp.onload = function() {
		document.getElementById("demo").innerHTML = 
			this.responseText;
	}
	xhttp.open("POST", "ajax_info.txt");
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send();
}
