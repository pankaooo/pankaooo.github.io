# 1. JavaScrip HTML DOM

​	With the HTML DOM, JavaScript can access and change all the elements of an HTML document.

## 1.1 The HTML DOM (Document Object Model)

​	When a web page is loaded, the browser creates a Document Object Model of the page.

​	The <b>HTML DOM</b> is constructed as a tree of <b>Objects</b>:

<p style="text-align: center; font-size: 20px;">Img 1: The HTML DOM Tree of Objects</p>

<img src="./img/pic_htmltree.gif">

​	With the object model, JavaScript gets all the power it needs to create dynamic HTML:

* JS can change all the HTML elements in the page
* JS can change all the HTML attributes in the page
* JS can change all the CSS style in the page
* JS can add new HTML elements and attributes
* JS can react to all existing HTML events in the page
* JS can create new HTML events in the page

## 1.2 What You Will Learn

​	In the next chapter of this tutorial you will leran:

* How to change the content of HTML elements
* How to change the style (CSS) of HTML elements
* How to react to HTML DOM events
* How to add and delete HTML elements

## 1.3 What is the DOM?

​	The DOM is a W3C (World Wide Web Consortium) standard

​	The DOM defines a standard for accessing document:

​	<i>"The W3C Document Object Model (DOM) is a platform and language-neutral interface that allows programs and scripts to dynamically access and update the content, structure, and style of a document."</i>

​	The W3C DOM standard is separated into 3 different parts:

* Core DOM - standard model for all document types
* XML DOM - standard model for XML documents
* HTML DOM - standard model for HTML documents

## 1.4 What is the HTML DOM?

​	The HTML DOM is a standard <b>object</b> model and <b>programming interface</b> for HTML. It defines:

* The HTML elements as <b>objects</b>
* The <b>properties</b> of all HTML elements
* The <b>methods</b> to access all HTML elements
* The <b>events</b> for all HTML elements

​	In other words: <b>The HTML DOM is a standard for how to get, change, add, or delete HTML elements</b>.



# 2. JavaScript - HTML DOM Methods

​	HTML DOM methods are <b>actions</b> you can perform (on HTML Elements).

​	HTML DOM properties are <b>values</b> (of HTML Elements) that you can set or change.

## 2.1 The DOM Programming Interface

​	The HTML DOM can be accessed with JavaScript (and with other programming languages).

​	In the DOM, all HTML elements are defined as <b>objects</b>.

​	The programming interface is the properties and methods of each object.

​	A <b>property</b> is a value that you can get or set (like changing the content of an HTML element).

​	A <b>method</b> is an action you can do (like add or delete an HTML element).

Example:

```
document.getElementById("demo").innerHTML = "Hello !!";
```

​	Above, <span style="color:red;">getElementById</span> is a <b>method</b>, while <span style="color:red;">innerHTML</span> is a <b>property</b>.

## 2.2 The getElementById Method

​	The most common way to access an HTML element is to use the <span style="color:red;">id</span> of the element.

## 2.3 The innerHTML Property

​	The easiest way to get the content of an element is by using the <span style="color:red;">innerHTML</span> property.

<b>Note:</b> The <span style="color:red;">innerHTML</span> property can be used to get or change any HTML element, including <span style="color:red;">\<html></span> and <span style="color:red;">\<body></span>.



# 3. JavaScript HTML DOM Document

​	The HTML DOM document object is the owner of all other objects in your web page.

## 3.1 The HTML DOM Document Object

​	The document object represents your web page.

​	If you want to access any element in an HTML page, you always start with accessing the document object.

​	Below are some examples of how you can use the document object to access and manipulate HTML.

## 3.2 Find HTML Elements

| Method                                  | Description                   |
| :-------------------------------------- | :---------------------------- |
| document.getElementById(*id*)           | Find an element by element id |
| document.getElementsByTagName(*name*)   | Find elements by tag name     |
| document.getElementsByClassName(*name*) | Find elements by class name   |

## 3.3 Changing HTML Elements

| Property                                   | Description                                   |
| :----------------------------------------- | :-------------------------------------------- |
| *element*.innerHTML = *new html content*   | Change the inner HTML of an element           |
| *element*.*attribute = new value*          | Change the attribute value of an HTML element |
| *element*.style.*property = new style*     | Change the style of an HTML element           |
| <b>Method</b>                              | <b>Description</b>                            |
| *element*.setAttribute*(attribute, value)* | Change the attribute value of an HTML element |

## 3.4 Adding and Deleting Elements

| Method                            | Description                       |
| :-------------------------------- | :-------------------------------- |
| document.createElement(*element*) | Create an HTML element            |
| document.removeChild(*element*)   | Remove an HTML element            |
| document.appendChild(*element*)   | Add an HTML element               |
| document.replaceChild(*new, old*) | Replace an HTML element           |
| document.write(*text*)            | Write into the HTML output stream |

## 3.5 Adding Events Handlers

| Method                                                     | Description                                   |
| :--------------------------------------------------------- | :-------------------------------------------- |
| document.getElementById(*id*).onclick = function(){*code*} | Adding event handler code to an onclick event |

## 3.6 Find HTML Objects

​	The first HTML DOM Level 1 (1998), defined 11 HTML objects, object collections, and properties. These are still valid in THML5. Later, in HTML DOM Level 3, more objects, collections, and properties were added.

| Property                     | Description                                                  | DOM  |
| :--------------------------- | :----------------------------------------------------------- | :--- |
| document.anchors             | Returns all <a> elements that have a name attribute          | 1    |
| document.applets             | Deprecated                                                   | 1    |
| document.baseURI             | Returns the absolute base URI of the document                | 3    |
| document.body                | Returns the <body> element                                   | 1    |
| document.cookie              | Returns the document's cookie                                | 1    |
| document.doctype             | Returns the document's doctype                               | 3    |
| document.documentElement     | Returns the <html> element                                   | 3    |
| document.documentMode        | Returns the mode used by the browser                         | 3    |
| document.documentURI         | Returns the URI of the document                              | 3    |
| document.domain              | Returns the domain name of the document server               | 1    |
| document.domConfig           | Obsolete.                                                    | 3    |
| document.embeds              | Returns all <embed> elements                                 | 3    |
| document.forms               | Returns all <form> elements                                  | 1    |
| document.head                | Returns the <head> element                                   | 3    |
| document.images              | Returns all <img> elements                                   | 1    |
| document.implementation      | Returns the DOM implementation                               | 3    |
| document.inputEncoding       | Returns the document's encoding (character set)              | 3    |
| document.lastModified        | Returns the date and time the document was updated           | 3    |
| document.links               | Returns all <area> and <a> elements that have a href attribute | 1    |
| document.readyState          | Returns the (loading) status of the document                 | 3    |
| document.referrer            | Returns the URI of the referrer (the linking document)       | 1    |
| document.scripts             | Returns all <script> elements                                | 3    |
| document.strictErrorChecking | Returns if error checking is enforced                        | 3    |
| document.title               | Returns the <title> element                                  | 1    |
| document.URL                 | Returns the complete URL of the document                     | 1    |



# 4. JavaScript HTML DOM Elements

## 4.1 Find HTML Elements

​	Often, with JavaScript, you want to manipulate HTML elements.

​	To do so, you have to find the elements first. These are several ways to do this:

* Finding HTML elements by id
* Finding HTML elements by tag name
* Finding HTML elements by class name
* Finding HTML elements by CSS selectors
* Finding HTML elements by HTML object collections

## 4.2 Finding HTML Element by Id

​	The easiest way to find an HTML element in the DOM, is by using the element id.

​	This example finds the element with <span style="color:red;">id="intro"</span>:

```
const element = document.getElementById("intro");
```

​	If the element is found, the method will return the element as an object (in element).

​	If the element is not found, element will contain <span style="color:red;">null</span>.

## 4.3 Finding HTML Elements by Tag Name

​	Finds all <span style="color:red;">\<p></span> elements:

```
cosnt element = document.getElementByTagName("p");
```

​	Finds the element with <span style="color:red;">id="main"</span>, and then finds all <span style="color:red;">\<p></span> elements inside <span style="color:red;">"main"</span>, we can access a single object via [ ], like y[0].innerHTML:

```
const x = document.getElementById("main");
const y = x.getElementByTagName("p");
y[0].innerHTML;				//The first element's content
```

## 4.4 Finding HTML Elements by Class Name

​	If you want to find all HTML elements with the same class name, use <span style="color:red;">getElementByClassName()</span>.

```
const x = document.getElementByClassName("intro");
```

## 4.5 Finding HTML Elements by CSS Selectors

​	If you want to find all HTML elements that match a specified CSS selector (id, class name, types, attributes, values of attributes, etc), use the <span style="color:red;">querySelectorAll()</span> method.

​	This example returns a list of all <span style="color:red;">\<p></span> elements with <span style="color:red;">class="intro"</span>:

```
const x = document.querySelectorAll("p.intro");
document.getElementById("demo").innerHTML = 
'The first paragraph (index 0) with class="intro" is: ' + x[0].innerHTML;
```

## 4.6 Finding HTML Elements by HTML Object Collections

​	This example finds the form element with <span style="color:red;">id="frm1"</span>, in the forms collection, and displays all element values:

```
<form id="frm1" action="/action_page.php">
  First name: <input type="text" name="fname" value="Donald"><br>
  Last name: <input type="text" name="lname" value="Duck"><br><br>
  <input type="submit" value="Submit">
</form> 

<p>These are the values of each element in the form:</p>

<p id="demo"></p>

<script>
const x = document.forms["frm1"];
let text = "";
for (let i = 0; i < x.length ;i++) {
  text += x.elements[i].value + "<br>";
}
document.getElementById("demo").innerHTML = text;
</script>
```

Result:

```
Donald 
Duck
Submit
```

​	The following HTML objects (and object collections) are also accessible:

* document.anchors
* document.body
* document.documentElement
* document.embeds
* document.forms
* document.head
* document.images
* document.links
* document.scripts
* document.title



# 5. JavaScript HTML DOM - Changing HTML

## 5.1 Changing HTML Content

​	The easiest way to modify the content of an HTML element is by using the <span style="color:red;">innerHTML</span> property.

​	To change the content of an HTML element, use this syntax:

```
document.getElementById(id).innerHTML = new HTML;
```

## 5.2 Changing the Value of an Attribute

​	To change the value of an HTML attribute, use this syntax:

```
document.getElementById(id).attribute = new value;
```

​	This example change the value of the src attribute of an <span style="color:red;">\<img> element:

```
<h3>JavaScript DOM:</h3>
<img id="myImage23" src="img/breakpoint.jpg" height="100">
<!-- JS code -->
setTimeout(myDOMimage, 3000);
function myDOMimage() {
	document.getElementById("myImage23").src = "img/lovely.jpg";
}
```

## 5.3 Dynamic HTML content

```
document.getElementById("demo").innerHTML = "Date: " + Date();
```

## 5.4 document.write()

​	In JavaScript, <span style="color:red;">document.write()</span> can be used to write directly to the HTML output stream:

```
<p>Before the output</p>
<script>
	document.write(Date());
</script>
<p>After the output</p>
```

​	<b>Note:</b> Never use <span style="color:red;">document.write()</span> after the document is loaded. It will overwrite the document.



# 6. JavaScript Forms

## 6.1 Form Validation

​	HTML form validation can be done by JavaScript.

​	If a form field (fname) is empty, this function alerts a message, and returns false, to prevent the form from being submitted:

```
<form name="myForm" action="#" onsubmit="return validationForm()"
	method="post">
	Name: <input type="text" name="fname">
		<input type="submit" value="Submit">
</from>
<!-- JS code -->
function validationForm() {
	let x = document.forms["myForm"]["fname"].value;
	if (x == "") {
		alert("Name must be filled out");
		return false;
	}
}
```

## 6.2 JavaScript Can Validate Numeric Input

```
<p>Please input a number between 1 and 10</p>
<input id="numb">
<button type="button" onclick="validationNum()">Submit</button>
<p id="numb-result"></p>
<!-- JS code -->
function validationNum() {
	let x = document.getElementById("numb").value;
	let text;
	if (isNaN(x) || x < 1 || x > 10) {
		text = "Input not valid .....";
	} else {
		text = "Input OK";
	}
	document.getElementById("numb-result").innerHTML = text;
}
```

## 6.3 Automatic HTML Form Validation

​	HTML form validation can be performed automatically by the browser:

​	If a form field (fname) is empty, the <span style="color:red;">required</span> attribute prevents this form from being submitted:

```
<form action="#" method="post">
	<input type="text" name="fname" required>
	<input type="submit" value="Submit">
</form>
```

## 6.4 Data Validation

​	Data validation is the process of ensuring that user input is clean, correct, and useful.

​	Typical validation tasks are:

	* has the user filled in all required fields
	* has the user entered a valid data
	* has the user entered text in a numeric field

​	Most often, the purpose of data validation is to ensure correct user input. Validation can be defined by many different methods, and deployed in many different ways.

​	<b>Server side validation</b> is performed by a web server, after input has been sent to the server.

​	<b>Client side validation</b> is performed by a web browser, before input is sent to a web server.

## 6.5 HTML Constraint Validation

​	HTML5 introduced a new HTML validation concept called <b>constraint validation</b>.

​	HTML constraint validation is based on:

* Constraint validation <b>HTML Input Attributes</b>
* Constraint validation <b>CSS Pseudo Selectors</b>
* Constraint validation <b>DOM Properties and Methods</b>

## 6.6 Constraint Validation HTML Input Attributes

| Attribute | Description                                         |
| :-------- | :-------------------------------------------------- |
| disabled  | Specifies that the input element should be disabled |
| max       | Specifies the maximum value of an input element     |
| min       | Specifies the minimum value of an input element     |
| pattern   | Specifies the value pattern of an input element     |
| required  | Specifies that the input field requires an element  |
| type      | Specifies the type of an input element              |

```
<form>
  <label for="datemax">Enter a date before 1980-01-01:</label>
  <input type="date" id="datemax" name="datemax" max="1979-12-31"><br><br>

  <label for="datemin">Enter a date after 2000-01-01:</label>
  <input type="date" id="datemin" name="datemin" min="2000-01-02"><br><br>

  <label for="quantity">Quantity (between 1 and 5):</label>
  <input type="number" id="quantity" name="quantity" min="1" max="5">
</form>
```

## 6.7 Constraint Validation CSS Pseudo Selectors

| Selector  | Description                                                  |
| :-------- | :----------------------------------------------------------- |
| :disabled | Selects input elements with the "disabled" attribute specified |
| :invalid  | Selects input elements with invalid values                   |
| :optional | Selects input elements with no "required" attribute specified |
| :required | Selects input elements with the "required" attribute specified |
| :valid    | Selects input elements with valid values                     |

```
div:required i {
	color: blue;
}
```



# 7. JavaScript HTML DOM - Changing CSS

## 7.1 Changing HTML Style

​	To change the style of an HTML element, use this syntax:

```
document.getElementById(id).style.property = new style;
```

​	The following example changes the style of a <span style="color:red;">\<p></span> element:

```
<p id="p2">Hello</p>
<script>
	document.getElementById("p2").style.color = "blue";
</script>
```

## 7.2 Using Events

​	The HTML DOM allows you to execute code when an event occurs.

​	Events are generated by the browser when "things happen" to HTML elements:

* An element is clicked on
* The page has loaded
* Input fields are changed

​	You will learn more about events in the next chapter of this tutorial.

​	This example changes the style of the HTML element with <span style="color:red;">id="id1"</span>, when the user clicks a button:

```
<h1 id="id1">My Heading 1</h1>
<button type="button"
onclick="document.getElementById('id1').style.color = 'red'">
Click Me!</button>
```



# 8. JavaScript HTML DOM Animation

## 8.1 A Basic Web Page

​	To demonstrate how to create HTML animations with JavaScript, we will use a simple web page:

```
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<h1>My First JavaScript Animation</h1>
<div id="animation1">My animation will go here</div>
</body>
</html>
```

## 8.2 Create an Animation Container

​	All animations should be relative to a container element:

```
<div id="container1">
	<div id="animate1">My animation will go here</div>
</div>
```

## 8.3 Style the Elements

​	The container element should be created with style = "<span style="color:red;">position: relative</span>".

​	The animation element should be created with style = "<span style="color:red;">position: absolute</span>".

## 8.4 Animation Code

​	JavaScript animations are done by programming gradual changes in an element's style.

​	The changes are called by a timer. When the timer interval is small, the animation looks continuous. The basic code is:

```
is = setInterval(fram, 5);
function frame() {
	if(/*test for finished*/) {
		clearInterval(id);
	} else {
		/*Change the element style*/
	}
}
```

## 8.5 Create the Full Animation Using JavaScript

```
<style>
#container1 {
	width: 200px;
	height: 200px;
	position: relative;
	background: yellow;
}
#animate1 {
	width: 25px;
	height: 25px;
	position: absolute;
	background-color: blue;
}
</style>
<p><button onclick="myMove()" type="button">Click me...</button></p>
<div id="container1">
	<div id="animate1"></div>
</div>
<!-- JS code -->
function myMove() {
	let id = null;
	const elem = document.getElementById("animate1");
	let pos = 0;
	clearInterval(id);
	id = setInterval(frame, 5);
	function frame() {
		if(pos >= 175) {
			clearInterval(id);
		} else {
			pos += 2;
			elem.style.top = pos + "px";
			elem.style.left = pos + "px";
		}
	}
}
```



# 9. JavaScript HTML DOM Events

## 9.1 Reacting to Events

​	A JavaScript can be executed when an event occurs, like when a user clicks on an HTML element. To execute code when a user clicks on an element, add JavaScript code to an HTML event attribute:

```
onclick=JavaScrpt;
```

Examples of HTML events:

* User clicks the mouse
* Web page has loaded
* An image has been loaded
* The mouse moves over an element
* An input field is changed
* An HTML form is submitedd
* A user strokes a key

## 9.2 HTML Event Attributes

​	To assign events to HTML elements you can use event attributes:

```
<!-- Assign an onclick event to a button element: -->
<button onclick="displayDate()">Try it</button>
```

## 9.3 Assign Events Using the HTML DOM

​	The HTML DOM allows you to assign events to HTML events using JavaScript:

```
<script>
	document.getElementById("myBtn").onclick = displayDate;
</script>
```

## 9.4 The onload and onunload Events

​	The <span style="color:red;">onload</span> and <span style="color:red;">onunload</span> events are triggered when the user enters or leaves the page.

​	The <span style="color:red;">onload</span> event can be used to check the visitor's browser type and browser version, and load the proper version of the web page based on the information.

​	The <span style="color:red;">onload</span> and <span style="color:red;">onunload</span> events can be used to deal with cookies:

```
<body onload="checkCookies()">
<h4>Check cookies</h4>
<p id="demo24"></p>
<!-- JS code -->
try {
	//This statements not work, because it executed after loading.
	document.getElementsByTagName("body").onload = "checkCookies()";
} catch(err) {
	alert(err);
}
function checkCookies() {
	alert("Heldfsoidiosd");
	var text = "";
	if (navigator.cookieEnabled == true) {
		text = "Cookies are enabled.";
	} else {
		text = "Cookies are not enabled.";
	}
	document.getElementById("demo24").innerHTML = text;
}
```

## 9.5 The onchange Event

​	The <span style="color:red;">onchange</span> event is often used in combination with validation of input fields.

​	Below is a example of how to use the onchange. The <span style="color:red;">upperCase()</span> function will be called when a user changes the content of an input field:

```
<p>Enter your name:<input type="text" id="fname2"
onchange="upperCase()">
</p>
<script>
function upperCase() {
	const x = document.getElementById("fname2");
	x.value = x.value.toUpperCase();
}
</script>
```

## 9.6 The onmouseover and onmouseout Events

​	The <span style="color:red;">onmouseover</span> and <span style="color:red;">onmouseout</span> events can be used to trigger a function when the user mouses over, or out of, an HTML element:

## 9.7 The onmousedown, onmouseup and onclick Events

​	The <span style="color:red;">onmousedown</span>, <span style="color:red;">onmouseup</span>, and <span style="color:red;">onclick</span> events are all parts of a mouse-click, First when a mouse-button is clicked, the onmousedown event is triggered, the, when the mouse-button is released, the onmouseup event is triggered, finally, when the mouse-click is completed, the onclick event is triggerd.



# 10. JavaScript HTML DOM EventListener

## 10.1 The addEventListener() method

Example

​	Add an event listener that fires when a user clicks a button:

```
<button id="myBtn">Try it</button>
<p id="demo"></p>
<!-- JS code -->
document.getElementById("myBtn").addEventListener("click", displayDate);
function displayDate() {
	document.getElementById("demo").innerHTML = Date();
}
```

1.  The <span style="color:red;">addEventListener()</span> method attaches an event handler to an element <b>without</b> overwriting existing event handlers.

2. You can add many event handlers to one element, even with the same type.

3. You can add event listeners to any DOM object, not only HTML elements. i.e the window object.

4. The <span style="color:red;">addEventListener()</span> method makes it easier to control how the event reacts to bubbing. When using the <span style="color:red;">addEventListener()</span> method, the JavaScript is separated from the HTML markup, for better readability and allows you to add event listeners even when you do not control the HTML markup.
5. You can easily remove an event listener by using the <span style="color:red;">removeEventListener()</span> method.

<span style="font-size: 20px;">Syntax</span>

```
element.addEventListener(event, function, useCapture);
```

## 10.2 Add an Event Handler to an Element

Example

```
element.addEventListener("click", function() {alert("Hello world!");});
```

## 10.3 Add Many Event Handlers to the Same Element

​	The <span style="color:red;">addEventListener()</span> method allows you to add many events to the same element, without overwriting existing events:

```
element.addEventListener("click", myFunction);
element.addEventListener("click", mySecondFunction);
```

​	You can add events of different types to the same element:

```
element.addEventListener("mouseover", myFunction);
element.addEventListener("click", mySecondFunction);
element.addEventListener("mouseout", myThirdFunction);
```

## 10.4 Add an Event Handler to the window Object

​	The <span style="color:red;">addEventHandler()</span> method allows you to add event listeners on any HTML DOM object such as HTML elements, the HTML document, the window object, or other objects that support events, like the <span style="color:red;">xmlHttpRequest</span> object.

```
//Add an event listener that fires when a user resizes the window
window.addEventListener("resize", function() {
	document.getElementById("demo").innerHTML = sometext;
});
```

## 10.5 Passing Parameters

​	When passing parameter values, use an "anonymous function" that calls the specified function with the parameters:

```
let p1 = 5;
let p2 = 7;
element.addEventListener("click", function(){myFunction(p1, p2);});
```

## 10.6 Event Bubbling or Event Capturing

​	There are two ways of event propagation in the HTML DOM, bubbling and capturing.

​	Event propagation is a way of defining the element order when an event occurs. If you have a \<p> element inside a \<div> element, and the user clicks on the \<p> element, which element's "click" event should be handled first?

​	In bubbling the inner most element's event is handled first and the the outer.

​	In capturing the outer most element's event is handled first and then the inner.

​	(For many events with same type on the same element, the first defined listener handled first, ...)

```
document.getElementById("myP").addEventListener("click", myFunction, true);		//When true, event uses the capturing propagation
document.getElementById("myDiv").addEventListener("click", myFunction, true);	//when false, event uses the bubbling propagation
```

## 10.7 The removeEventListener() method

​	The <span style="color:red;">removeEventListener()</span> method removes event handlers that have been attached with the addEventListener() method.



# 11. JavaScript HTML DOM Navigation

​	With the HTML DOM, you can navigate the node tree using node relationships.

## 11.1 DOM Nodes

​	According to the W3C HTML DOM standard, everything in an HTML document is a node:

* The entire document is a document node
* Every HTML element is an element node
* The text inside HTML elements are text nodes
* Every HTML attribute is an attribute node (deprecated)
* All comments are comment nodes

<img src="img/pic_htmltree.gif">

​	With the HTML DOM, all nodes in the node tree can be accessed by JavaScript. New nodes can be created, and all nodes can be modified or deleted.

## 11.2 Node Relationships

​	The node in the node tree have a hierarchical relationship to each other.

​	The terms parent, child, and sibling are used to describe the relationships.

* In a node tree, the top node is called the root (or root node)
* Every node has exactly one parent, except the root (which has no parent)
* A node can have a number of children
* Siblings (brothers or sisters) are nodes with the same parent

```
<html>
	<head>
		<title>DOM Tutorial</title>
	</head>
	<body>
		<h1>DOM Lesson one</h1>
		<p>DOM Navigation</p>
	</body>
</html>
```

<img src="img/pic_navigate.gif">

​	From the HTML above you can read:

* <span style="color:red;">\<html></span> is the roo node, and it has no parents
* <span style="color:red;">\<html></span> is the parent of <span style="color:red;">\<head></span> and <span style="color:red;">\<body></span>
* <span style="color:red;">\<head></span> is the first child of <span style="color:red;">\<html></span>
* <span style="color:red;">\<head></span> is the last child of <span style="color:red;">\<html></span>

​	and:

* <span style="color:red;">\<head></span> has one child: <span style="color:red;">\<title></span>
* <span style="color:red;">\<title\></span> has one child (a text node): "DOM Tutorial"
* <span style="color:red;">\<body></span> has two children: <span style="color:red;">\<h1></span> and <span style="color:red;">\<p></span>
* <span style="color:red;">\<h1></span> and <span style="color:red;">\<p></span> are siblings ...

## 11.3 Navigating Between Nodes

​	You can use the following node properties to navigate between nodes with JavaScript:

* <span style="color:red;">parentNode</span>
* <span style="color:red;">childNodes[nodeNumber]</span>
* <span style="color:red;">firstChild</span>
* <span style="color:red;">lastChild</span>
* <span style="color:red;">nextSibling</span>
* <span style="color:red;">previousSibling</span>

## 11.4 Child Nodes and Node Values

<b>Note:</b> A common error in DOM processing is to export an element node to contain text.

```
<title id="demo">DOM Tutorial</title>
```

​	The element node <span style="color:red;">\<title></span> does <b>NOT</b> contain text.

​	It contains a <b>text node</b> with the value of "DOM Tutorial".

​	The value of the text node should be accessed by the node's <span style="color:red;">innerHTML</span> property:

```
myTitle = document.getElementById("demo").innerHTML;
```

​	Accessing the innerHTML property is the same as accessing the <span style="color:red;">nodeValue</span> of the first child:

```
myTitle = document.getElementById("demo").firstChild.nodeValue;
//OR:
myTitle = document.getElementById("demo").childNodes[0].nodeValue;
```

## 11.5 InnerHTML

​	In this tutorial we use the innerHTML property to retrieve the content of an HTML element. However, learning the other methods above is useful for understanding the tree structure and the navigation of the DOM.

## 11.6 DOM Root Nodes

​	There are two special properties that allow access to the full document:

* <span style="color:red;">document.body</span> - The body of the document
* <span style="color:red;">document.documentElement</span> - The full document

```
<p>Displaying document.body</p>
<p id="demo"></p>
<script>
document.getElementById("demo").innerHTML = 
document.body.innerHTML;	//or document.documentElement.innerHTML;
</script>
```

## 11.7 The nodeName Property

​	The <span style="color:red;">nodeName</span> proeprty specifies the name of a node:

* nodeName is read-only
* nodeName of an element node is the same as the tag name
* nodeName of an attribute node is the attribute name
* nodeName of a text node is always #text
* nodeName of the document node is always #document

```
<h1 id="id01">My First Page</h1>
<p id="id02"></p>

<script>
document.getElementById("id02").innerHTML = document.getElementById("id01").nodeName;	//H1
//document.getElementById("id01").firstChild.nodeName; is #text
</script>
```

<b>Note:</b> <span style="color:red;">nodeName</span> always contains the uppercase tag name of an HTML element.

## 11.8 The nodeValue Property

​	The <span style="color:red;">nodeValue</span> property specifies the value of a node:

* nodeValue of element nodes is <span style="color:red;">null</span>
* nodeValue of text node is the text itself
* nodeValue for attribute nodes is the attribute value

## 11.9 The nodeType Property

​	The <span style="color:red;">nodeType</span> property is read only. It returns the type of a node:

```
<h1 id="id01">My First Page</h1>
<p id="id02"></p>

<script>
document.getElementById("id02").innerHTML = document.getElementById("id01").nodeType;		//1
```

​	The most important nodeType properties are:

| Node               | Type | Example                                         |
| :----------------- | :--- | :---------------------------------------------- |
| ELEMENT_NODE       | 1    | <h1 class="heading">W3Schools</h1>              |
| ATTRIBUTE_NODE     | 2    | class = "heading" (deprecated)                  |
| TEXT_NODE          | 3    | W3Schools                                       |
| COMMENT_NODE       | 8    | <!-- This is a comment -->                      |
| DOCUMENT_NODE      | 9    | The HTML document itself (the parent of <html>) |
| DOCUMENT_TYPE_NODE | 10   | <!Doctype html>                                 |



# 12. JavaScript HTML DOM Elements (Nodes)

​	Adding and Removing Nodes (HTML Elements)

## 12.1 Creating New HTML Elements (Nodes)

​	To add a new element to the HTML DOM, you must create the element (element node)f first, and then append it to an existing element:

```
<div id="div1">
	<p id="p1">This is a paragraph.</p>
	<p id="p2">This is another paragraph.</p>
	//Will add here
</div>
<script>
const para = document.createElement("p");
const node = document.createTextNode("This is new.");
para.appendChild(node);
const element = document.getElementById("div1");
element.appendChild(para);		//<p>This is new.</p>
</script>
```

Example explained:

​	This code creates a new <span style="color:red;">\<p></span> element:

```
const para = document.createElement("p");
```

​	To add text to the <span style="color:red;">\<p></span> element, you must create a text node first. This code creates a text node:

```
const node = document.createTextNode("This is new.");
```

​	Then you must append the text node to the <span style="color:red;">\<p></span> element:

```
para.appendChild(node);
```

​	Finally you must append the new element to an existing element.

​	This code finds an existing element:

```
const element = document.getElementById("div1");
```

​	This code appends the new element to the existing element:

```
element.appendChilde(para);
```

## 12.2 Creating new HTML Elements - insertBefore()

​	The <span style="color:red;">appendChild()</span> method in the previous example, appended the new element as the last child of the parent. If you don't want that you can use the <span style="color:red;">insertBefore()</span> method:

```
<div id="div1">
  <p id="p1">This is a paragraph.</p>
  <p id="p2">This is another paragraph.</p>
</div>

<script>
const para = document.createElement("p");
const node = document.createTextNode("This is new.");
para.appendChild(node);

const element = document.getElementById("div1");
const child = document.getElementById("p1");
element.insertBefore(para, child);
</script>
```

## 12.3 Removing Existing HTML Elements

​	To remove an HTML element, use the <span style="color:red;">remove()</span> method:

```
<div>
  <p id="p1">This is a paragraph.</p>		//will be removed
  <p id="p2">This is another paragraph.</p>
</div>
<script>
const elmnt = document.getElementById("p1"); elmnt.remove();
</script>
```

## 12.4 Removing a Child Node

​	For browsers that does not support <span style="color:red;">remove()</span> method, you have to find the parent node to remove an element:

```
<div id="div1">
  <p id="p1">This is a paragraph.</p>
  <p id="p2">This is another paragraph.</p>
</div>

<script>
const parent = document.getElementById("div1");
const child = document.getElementById("p1");
parent.removeChild(child);				//should find the removed element and the parent element
</script>
```

​	Here is a common workaround: find the child you want to remove, and use its <span style="color:red;">parentNode</span> property to find the parent:

```
const child = document.getElementById("p1");	//find the element to be removed
child.parentNode.removeChild(child);
```

## 12.5 Replacing HTML Elements

​	To replace an element to the HTML DOM, use the <span style="color:red;">replaceChild()</span> method:

```
<div id="div1">
  <p id="p1">This is a paragraph.</p>		//Will be replaced
  <p id="p2">This is another paragraph.</p>
</div>

<script>
const para = document.createElement("p");
const node = document.createTextNode("This is new.");
para.appendChild(node);

const parent = document.getElementById("div1");
const child = document.getElementById("p1");
parent.replaceChild(para, child);		//Need the parent
</script>
```



# 13. JavaScript HTML DOM Collections

## 13.1 The HTMLCollection Object

​	The <span style="color:red;">getElementByTagName()</span> method returns an <span style="color:red;">HTMLCollection</span> object.

​	An <span style="color:red;">HTMLCollection</span> object is an array-like list (collection) of HTML elements.

​	The following code selects all <span style="color:red;">\<p></span> elements in a documents:

```
const myCollectoin = document.getElementByTagName("p");
```

​	The elements in the collection can be accessed by an index number:

```
myCollection[0];
```

## 13.2 HTML HTMLCollection Length

​	The <span style="color:red;">length</span> property defines the number of elements in an <span style="color:red;">HTMLCollection</span>:

```
myCollection.length;
```

​	The <span style="color: red;">length</span> property is useful when you want to loop through the elements in a collection:

```
const myCollection = document.getElementsByTagName("p");
for (let i = 0; i < myCollection.length; i++) {
  myCollection[i].style.color = "red";
}
```

<b>NOTE:</b>

​	<b>An HTMLCollection is NOT an array!</b>

​	You cannot use array methods like valueOf(), pop(), push(), or join() on an HTMLCollection.

​	

# 14. JavaScript HTML DOM Node Lists

## 14.1 The HTML DOM NodeList Object

​	A <span style="color:red;">NodeList</span> object is a list (collection) of nodes extracted from a document.

​	A <span style="color:red;">NodeList</span> object is almost the same as an <span style="color:red;">HTMLCollection<</span> object.

​	Some (older) browsers return a NodeList object instead of an HTMLCollection for methods like <span style="color:red;">getElementByClassName()</span>.

​	All browsers return a NodeList object for the property <span style="color:red;">childNodes</span>.

​	Most browsers return a NodeList object for the method <span style="color:red;">querySelectorAll()</span>.

​	The following code selects all <span style="color:red;">\<p></span> nodes in a document:

```
const myNodeList = document.querySelectorALL("p");
```

​	The element in the NodeList can also be accessed by an index number.

## 14.2 HTML DOM Node List Length

```
myNodeList.length;
//loop through the nodes in a node list:
const myNodelist = document.querySelectorAll("p");
for (let i = 0; i < myNodelist.length; i++) {
  myNodelist[i].style.color = "red";
}
```

## 14.3 The Difference Between an HTMLCollection and a NodeList

​	A <b>NodeList</b> and an <b>HTMLCollection</b> is very much the same thing.

​	Both are array-like collections (list) of nodes (elements) extracted from a document. The nodes can be accessed by index numbers. Both the <b>length</b> property returns the number of elements in the list (collection).

​	But an HTMLCollection is a collection of <b>document elements</b>, and NodeList is a collection of <b>document nodes</b> (element nodes, attribute nodes, and text nodes).

​	So, HTMLCollection items can be accessed by their name, id, or index number. NodeList items can only be accessed by their index number.

​	An HTMLCollection is also always a <b>live</b> collection. i.e, If you add a \<li> element to a list in the DOM, the list in the HTMLCollection will asl change. But a NodeList is most often a <b>static</b> collection.

​	<span style="color:red;">getElementsByClassName()</span> and <span style="color:red;">getElementsByTagName()</span> methods returns a live HTMLCollectin. The <span style="color:red;">querySelectorAll()</span> method reutrns a static NodeList, the <span style="color:red;">childNodes</span> property returns a live NodeList (NOT static!).

<span style="color:red;">



# 15. JavaScript Window - The Browser Object Model

​	The Browser Object Model (BOM) allows JavaScript to "talk to" the browser.

## 15.1 The Browser Object Model (BOM)

​	There are no official standard for the Browser Object Mode (BOM).

​	Since modern browsers have implemented (almost) the same methods and properties for JavaScript interactivity, it is often referred to, as methods and properties of the BOM.

## 15.2 The Window Object

​	The <span style="color:red;">window</span> object is supported by all browsers. It represents the browser's window.

​	All global JavaScript objects, functions, and variables automatically become members of the window object.

​	<span style="color: blue;">Global variables are properties of the window object. Global functions are methods of the window object</span>.

​	Even the document object (of the HTML DOM) is a property of the window:

```
window.document.getElementById("header");
```

​	this is the same as:

```
document.getElementById("header");
```

## 15.3 Window Size

​	Two properties can be used to determine the size of the browser window.

​	Both properties return the sizes in pixels:

* <span style="color:red;">window.innerHeight</span> - the inner height of the browser window (in pixels)
* <span style="color:red;">window.innerWidth</span> - the inner width of the browser window (in pixels)

<b>Note:</b> The browser window (thee browser viewport) is NOT including toolbars and scrollbars.

```
let h = window.innerHeight;
let w = window.innerWidth;
```

## 15.4 Other Window Methods

​	Some other methods:

* <span style="color:red;">window.open()</span> - open a new window
* <span style="color:red;">window.close()</span> - close the current window
* <span style="color:red;">window.moveTo()</span> - move the current window
* <span style="color:red;">window.resizeTo()</span> - resize the current window



# 16. JavaScript Window Screen

​	The window.screen object contains information about the user's screen.

## 16.1 Window Screen

​	The <span style="color:red;">window.screen</span> object can be written without the window prefix.

​	Properties:

* <span style="color:red;">screen.width</span>
* <span style="color:red;">screen.height</span>
* <span style="color:red;">screen.availWidth</span>
* <span style="color:red;">screen.availHeight</span>
* <span style="color:red;">screen.colorDepth</span>
* <span style="color:red;">screen.pixelDepth</span>

## 16.2 Window Screen Width & Screen Height

​	The <span style="color:red;">screen.width</span> property returns the width of the visitor's screen in pixels:

```
document.getElementById("demo").innerHTML = 
"Screen Width: " + screen.width;
```

​	The <span style="color:red;">screen.height</span> property returns the height of the visitor's screen.

## 16.3 Window Screen Available Width & Height

​	The <span style="color:red;">screen.availWidth/screen.availHeight</span> property returns the width/height of the visitor's screen (minus interface features like the Windows Taskbar).

## 16.4 Window Screen Color Depth

​	The <span style="color:red;">screen.colorDepth</span> property returns the number of bits used to display one color.

​	All modern computers use 24 bit or 32 bit hardware for color resolution:

* 24 bits = 16,777,216 different "True Colors"
* 32 bits = 4,294,967,296 different "Deep Colors"

​	Older computers used 16 bits (65,536 different "High Colors"). Very old computers, and old cell phones used 8 bits (256 different "VGA colors").

```
let x = screen.colorDepth;
```

## 16.5 Window Screen Pixel Depth

​	The <span style="color:red;">screen.pixelDepth</span> property returns the pixel depth of the screen.

​	For moder computers, Color Depth and Pixel Depth are equal.

```
let x = screen.pixelDepth;
```



# 17. JavaScript Window Location

​	The <span style="color:red;">window.location</span> object can be used to get the current page address (URL) and to redirect the browser to a new page.

## 17 .1 Window Location

​	The <span style="color:red;">window.location</span> object can be written without the window prefix. Some examples:

* <span style="color:red;">window.location.href</span> returns the href (RUL) of the current page
* <span style="color:red;">window.location.hostname</span> returns the domain name of the web host
* <span style="color:red;">window.location.pathname</span> returns the path and filename of the current page
* <span style="color:red;">window.location.protocol</span> returns the web protocol used (http: or https:)
* <span style="color:red;">window.location.assign()</span> loads a new document

## 17.2 Window Location Href

​	The <span style="color:red;">window.location.href</span> property returns the URL of the current page.

```
let x = window.location.href;
```

## 17.3 Window Location Port

​	The <span style="color:red;">window.location.port</span> property returns the number of the internet host port (of the current page, may be undefined).

```
let x = window.location.port;
```

## 17.4 Window Location Assign

​	The <span style="color:red;">window.location.assign()</span> method loads a new document:

```
<html>
<head>
<script>
function newDoc() {
  window.location.assign("https://www.w3schools.com")
}
</script>
</head>
<body>
<input type="button" value="Load new document" onclick="newDoc()">
</body>
</html>
```



# 18. JavaScript Window History

​	The <span style="color:red;">window.history</span> object contains the browsers history.

## 18.1 Window History

​	The <span style="color:red;">window.history</span> can be written without the window prefix.

​	To protect the privacy of the user, there are limitations to how JavaScript can access this object.

​	Some methods:

*  <span style="color:red;">history.back()</span> - same as clicking back in the browser
* <span style="color:red;">history.forwar)()</span> - same as clicking forward in the browser

## 18.2 Window History Back

​	The <span style="color:red;">history.back()</span> method loads the previous URL in the history list.

```
<html>
<head>
<script>
function goBack() {
  window.history.back()
}
</script>
</head>
<body>
<input type="button" value="Back" onclick="goBack()">
</body>
</html>
```

## 18.3 Window History Forwar

```
<html>
<head>
<script>
function goForward() {
  window.history.forward()
}
</script>
</head>
<body>
<input type="button" value="Forward" onclick="goForward()">
</body>
</html>
```



# 19. JavaScript Window Navigator

​	The <span style="color:red;">window.navigator</span> object contains information about the visitor's browser.

## 19.1 Window Navigator

​	Some examples:

* navigator.cookieEnabled
* navigator.appCodeName
* navigator.platform

## 19.2 Browser Cookies

​	The <span style="color:red;">cookieEnabled</span> property returns true if cookies are enabled:

```
<p id="demo"></p>
<script>
document.getElementById("demo").innerHTML = 
"cookieEnabled is " + navigator.cookieEnabled;
</script>
```

## 19.3 Browser Application Name

​	The <span style="color:red;">appName</span> property returns the application name of the browser:

```
let x = navigator.appName;	//Netscape

//Strange enough, "Netscape" is the application name for IE11, Chrome, //Firefox, and Safari.
```

<b>Note:</b> This property is removed (deprecated) in the latest web standard. Most browsers returns <b>Netscape</b> as appName.

## 19.4 Browser Application Code Name

​	The <span style="color:red;">appCodeName</span> property returns the application code name of the browser:

```
let x = navigator.appCodeName;	//Mozilla
```

<b>Note:</b> This property is deprecated in the latest web standard. Most browsers returns <b>Mozilla</b> as appCodeName.

## 19.5 The Browser Engine

​	The <span style="color:red;">product</span> property returns the product name of the browser engine:

```
let x = navigator.product;	//Gecko
```

<b>Note:</b> This property is deprecated in the latest standard. Most browsers returns <b>Gecko</b> as product.

## 19.6 The Browser Version

​	The <span style="color:red;">appVersion</span> property returns version information about the browser:

```
let x = navigator.appVersion;	//5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 SLBrowser/8.0.1.3162 SLBChan/103
```

## 19.7 The Browser Agent

​	The <span style="color:red;">userAgent</span> property returns the user-agent header sent by the browser to the server:

```
let x = navigator.userAgent;	//Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 SLBrowser/8.0.1.3162 SLBChan/103
```

<span style="font-size: 20px;">Warning</span>

​	The information from the navigator object can often be misleading.

​	The navigator object should <b>not be used to detect browser versions</b> because:

* Different browsers can use the same name
* The navigator data can be changed by the browser owner
* Some browsers misidentify themselves to bypass site tests
* Browsers cannot report new operating systems, released later than the browser

## 19.8 The Browser Platform

​	The <span style="color:red;">platform</span> property returns the browser platform (operation system):

```
let x = navigator.platform;	//Win32
```

## 19.9 The Browser Language

```
let x = navigator.language;	//zh-CN
```

## 19.10 Is The Browser Online?

```
let x = navigator.onLine;	//true
```

## 19.11 Is Java Enabled?

​	The <span style="color:red;">javaEnabled()</span> method returns true if Java is enabled:

```
let x = navigator.javaEnabled();	//false
```



# 20. JavaScript Popup Boxes

​	JavaScript has three kind of popup boxes: Alert box, Confirm box, and Prompt box.

## 20.1 Alert Box

​	An alert box is often used if you want to make sure information comes through to the user.

​	When an alert box pops up, the user will have to click "OK" to proceed.

Syntax:

```
window.alert("sometext");
```

```
alert("I am an alert box!");
```

## 20.2 Confirm Box

​	A confirm box is often used if you want the user to verify or accept something.

​	When a confirm box pops up, the user will have to click either "OK" or "Cancel" to proceed. If the user clicks "OK", the box returns <b>true</b>, otherwise <b>false</b>.

```
if(confirm("Press a button!")) {
	txt = "OK";
} else {
	txt = "Cancel";
}
```

## 20.3 Prompt Box

​	A prompt box is often used if you want the user to input a value before entering a page. When a prompt box pops up, the user will have to click either "OK" or "Cancel" to proceed after entering an input value.

​	If the user clicks "OK" the box returns the input value. If the user clicks "Cancel" the box returns null:

```
let person = prompt("Please enter your name", "Harry Potter");
let text;
if(person == null || person == "") {
	text = "User cancelled the prompt";
} else {
	text = "Hello " + person;
}
```

## 20.4 Line Breaks

​	To display line breaks inside a popup box, use a back-slash followed by the character n:

```
alert("Hello \nHow are you?");
```



# 21. JavaScript Timing Events

​	JavaScript can be executed in time-intervals. This is called timing events.

## 21.1 Timing Events

​	The <span style="color:red;">window</span> object allows execution of code at specified time intervals.

​	These time intervals are called timing events.

​	The two key methods to use with JavaScript are:

* <span style="color:red;">setTimeout(function, milliseconds)

​		Executes a function, after waiting a specified number of milliseconds.

* <span style="color:red;">setInterval(function, milliseconds)

​		Same as setTimeout(), but repeats the execution of the function continuously.

<b>Note:</b> The <span style="color:red;">setTimeout()</span> and <span style="color:red;">setInterval()</span> are both methods of the HTML DOM Window object.

## 21.2 The setTimeout() Method

```
window.setTimeout(function, milliseconds);
```

​	The <span style="color:red;">window.setTimeout()</span> method can be written without the window prefix.

​	The first parameter is a function to be executed.

​	The second parameter indicates the number of milliseconds before execution.

```
<button onclick="setTimeout(myFunction, 3000)">Try it</button>
<script>
function myFunction() {
	alert('Hello');
}
</script>
```

## 21.3 How to Stop the Execution?

​	The <span style="color:red;">clearTimeout()</span> method stops the execution of the function specified in setTimeout().

```
window.clearTimeout(timeoutVariable);
```

​	The <span style="color:red;">window.clearTimeout()</span> method can be written without the window prefix.

​	The <span style="color:red;">clearTimeout()</span> method uses the variable returned from <span style="color:red;">setTimeout()</span>:

```
myVar = setTimeout(function, milliseconds);
clearTimeout(myVar);
```

​	If the function has not already been executed, you can stop the execution by calling the <span style="color:red;">clearTimeout()</span> method:

```
<button onclick="myVar = setTimeout(myFunction, 3000)">Try it</button>

<button onclick="clearTimeout(myVar)">Stop it</button>
```

## 21.4 The setInterval() Method

​	The <span style="color:red;">setInterval()</span> method repeats a given function at every given time-interval.

```
window.setInterval(function, milliseconds);
```

​	The <span style="color:red;">window.setInterval()</span> method can be written without the window prefix.

​	The first parameter is the function to be executed.

​	The second parameter indicates the length of the time-interval between each execution. This example executes a function called "myTimer" once every second (like a digital watch):

```
setInterval(myTimer, 1000);
function myTimer() {
	const d = new Date();
	document.getElementById("demo").innerHTML = d.toLocalTimeString();
}
```

## 21.5 How to Stop the Execution?

​	The <span style="color:red;">clearInterval()</span> method stops the executions of the function specified in the setInterval() method:

```
window.clearInterval(timerVariable);
```

​	The <span style="color:red;">window.clearInterval()</span> method can be written without the window prefix.

​	The <span style="color:red;">clearInterval()</span> method uses the variable returned from <span style="color:red;">setInterval()</span>:

```
let myVar = setInterval(function, milliseconds);
clearInterval(myVar);
```

```
<p id="demo"></p>
<button onclick="clearInterval(myVar)">Stop time</button>
<script>
let myVar = setInterval(myTimer, 1000);
function myTimer() {
  const d = new Date();
  document.getElementById("demo").innerHTML = d.toLocaleTimeString();
}
</script>
```



# 22. JavaScript Cookies

​	Cookies let you store user information in web pages.

## 22.1 What are Cookies?

​	Cookies are data, stored in small text files, on your computer.

​	<span style="color:blue;">When a web server has sent a web page to a browser, the connection is shut down, and the server forgets everything about the user</span>.

​	Cookies were invented to solve the problem "how to remember information about the user":

* When a user visits a web page, his/her name can be stored in a cookie.
* Next time the user visits the page, the cookies "remembers" his/her name.

​	Cookies are saved in name-value pairs like:

```
username = John Doe
```

​	When a browser requests a web page from a server, cookies belonging to the page are added to the request. This way the server gets the necessary data to "remember" information about users.

<b>Note:</b> None of the examples below will work if your browser has local cookies support turned off.

## 22.2 Create a Cookie with JavaScript

​	JavaScript can create, read, and delete cookies with the <span style="color:red;">document.cookie</span> property.

​	With JavaScript, a cookie can be created like this:

```
document.cookie = "username=John Doe";
```

​	You can also add an expiry date (in UTC time). By default, the cookie is deleted when the browser is closed:

```
document.cookie = "username=John Doe; expires=Thu,, 18 Dec 2013 12:00:00 UTC";
```

​	With a path parameter, you can tell the browser what path the cookie belongs to. By default, the cookie belongs to the current page.

```
document.cookie = "username=John Doe; expires=Thu, 18 Dec 2013 12:00:00 UTC; path=/";
```

## 22.3 Read a Cookie with JavaScript

​	With JavaScript, cookies can be read like this:

```
let x = document.cookie;
```

<b>Note:</b> <span style="color:red;">document.cookie</span> will return all cookies in one string much lie: cookie1=value; cookie2=value; cookie3=value;

## 22.4 Change a Cookie with JavaScript

​	With JavaScript, you can change a cookie the same way as you create it:

```
document.cookie = "username=John Smith; expires=Thu, 18 Dec 2013 12:00:00 UTC; path=/";
```

​	This way, the old cookie is overwritten.

## 22.5 Delete a Cookie with JavaScript

​	Deleting a cookie is very simple. You don't have to specify a cookie value when you delete a cookie. Just set the expires parameter to a past date:

```
document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
```

<b>Note:</b> You should define the cookie path to ensure that you delete the right cookie. Some  browsers will not let you delete a cookie if you don't specify the path.

## 22.6 The Cookie String

​	The <span style="color:red;">document.cookie</span> property looks like a normal text string. But it is not.

​	Even if you write a whole cookie string to document.cookie, when you read it out again, you can only see the name-value pair of it.

​	If you set a new cookie, older cookies are not overwritten. The new cookie is added to document.cookie, so if you read document.cookie again you will get something like:

cookie1 = value; cookie2 = value;

​	If you want to find the value of one specified cookie, you must write a JavaScript function that searches for the cookie value in the cookie string.

## 22.7 JavaScript Cookie Example

​	In the example to follow, we will create a cookie that stores the name of a visitor.

​	The first time a visitor arrives to the web page, he/she will be asked to fill in his/her name. The name is then stored in a cookie.

​	The next time the visitor arrives at the same page, he/she will get a welcome message.

​	For the example we will create 3 JavaScript functions:

1. A function to set a cookie value
2. A function to get a cookie value
3. A function to check a cookie value

## 22.8 A Function to Set a Cookie

​	First, we create a <span style="color:red;">function</span> that stores the name of the visitor in a cookie variable:

```
function setCookie(cnam, cvalue, exdays) {
	const d = new Date();
	d.setTime(d.getTime() + (exdays*24*60*60*1000));
	let expires = "expires=" + d.toUTCString();
	document.cookie = cname + "=" + cvalue +";" + expires + ";path=/";
}
```

<b>Example explained:</b>

​	The parameters of the function above are the name of the cookie (cname), the value of the cookie (cvalue), and the number of days until the cookie should expire (exdays).

​	The function sets a cookie by adding together the cookiename, the cookie value, and the expires string.

## 22.9 A Function to Get a Cookie

​	Then, we create a <span style="color:red;">function</span> that returns the value of a specified cookie:

```
function getCookie(cname) {
	let name = cname + "=";
	let decodedCookie = decodeURIComponent(document.cookie);
	let ca = decodedCookie.split(';');
	for (let i = 0; i < ca.length; i++) {
		let c = ca[i];
		while (c.charAt(0) == ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) == 0) {
			return c.substring(name.length, c.length);
		}
	}
	return "";
}
```

<b>Function explained:</b>

​	Take the cookiename as parameter (cname).

​	Create a variable (name) with the text to search for (cname + "=").

​	Decode the cookie string, to handle cookies with special characters, e.g. '$'

​	Split document.cookie on semicolons into an array called ca (ca = decodeCookie.split(';')).

​	Loop through the ca array (i = 0; i < ca.length; i++), and read out each value c = ca[i].

​	If the cookie is found (c.indexOf(name) == 0), return the value of the cookie (c.substring(name.length, c.length)).

​	If the cookie is not found, return "".

## 22.10 A Function to Check a Cookie

​	Last, we create the function that checks if a cookie is set.

​	If the cookie is set it will display a greeting.

​	If the cookie is not set, it will display a prompt box, asking for the name of the user, and stores the username cookie for 365 days, by calling the <span style="color:red;">setCookie</span> functin:

```
function checkCookie() {
	let username = getCookie("uername");
	if (username != "") {
		alert("Welcome again " + username);
	} else {
		username = prompt("Please enter your name:", "");
		if (username != "" && username != null) {
			setCookie("username", username, 365);
		}
	}
}
```

<b>All Together Now</b>:

```
function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  let expires = "expires="+d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
function checkCookie() {
  let user = getCookie("username");
  if (user != "") {
    alert("Welcome again " + user);
  } else {
    user = prompt("Please enter your name:", "");
    if (user != "" && user != null) {
      setCookie("username", user, 365);
    }
  }
}
```

Mon, April 17, 2023. 21:08. Library 2rd floor, zone c, 392.



<span style="color:red;">