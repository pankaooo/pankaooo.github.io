# 1. JavaScript Introduction

## 1.1 JavaScript Can Change HTML Content

​	One of many JavaScript HTML HTML methods is <span style="color: red;">getElementById()</span>.

​	The example below "finds" an HTML element (with id="demo"), and changes the element content (innerHTML) to "Hello JavaScript".

```
<!DOCTYPE html>
<html>
<body>
<p id="demo">JavaScript can change HTML content.</p>
<button type="button" onclick='document.getElementById("demo").innerHTML = 
	"Hello JavaScript"'>Clike me!</button>
</body>
</html>
```

<b>Note:</b> JavaScript accepts both double and single quotes.

## 1.2 JavaScript Can Change HTML Attribute Values

​	In this example JavaScript changes the value of the <span style="color: red;">src</span> (source) attribute of an <span style="color: red;">\<img></span> tag:

```
<button onclick="document.getElementById('myImage').src='pic_bulbon.gif'">
	Turn on the light
</button>
<img id="myImage" src="pic_bulboff.gif" style="width: 100px;">
```

## 1.3 JavaScript Can Change HTML Styles (CSS)

​	Changing the style of an HTML element, is a variant of changing an HTML attribute:

```
<p id="demo">JavaScript can change the style of an HTML element.</p>
<button type="button" onclick="document.getElementById("demo").style.fontSize='35px'">
Click Me!</button>
```

## 1.4 JavaScript Can Hide HTML Elements

​	Hiding HTML elements can be done by changing the <span style="color: red;">display</span> style:

```
<p id="demo">JavaScript can hide HTML elements.</p>
<buton type="button" 
onclick="document.getElementById('demo').style.display='none'">
Click Me!</button>
```

## 1.5 JavaScript Can Show HTML Elements

​	Showing hidden HTML elements can also be changing the <span style="color: red;">display</span> style:

`document.getElementById("demo").style.display="block";`

<span style="font-size: 22px;">Did You Know?</span>

​	JavaScript and Java are completely different languages, both in concept and design.

​	JavaScript was invented by Brendan Eich in 1995, and became an ECMA standared in 1997.

​	ECMA-262 is the official name of the standard. ECMAScript is the official name of the language.



# 2. JavaScript Where To

## 2.1 The \<script> Tag

​	In HTML, JavaScript code is inserted between <span style="color: red;">\<script></span> and <span style="color: red;">\<script></span> tags.

<b>Note:</b> Old JavaScript examples may use a type attribute: \<script type="text/javascript">. The type attribute is not required. JavaScript is the default scripting language in HTML.

## 2.2 JavaScript Functions and Events

​	A JavaScript <span style="color: red;">function</span> is a block of JavaScript code, that can be executed when "called" for.

​	For example, a function can be called when an <b> event</b> occurs, like when the user clicks a button.

## 2.3 JavaScript in \<head> or \<body>

​	You can place any number of scripts in an HTML document.

​	Scripts can be placed in the <span style="color: red;">\<body></span>, or in the <span style="color: red;">\<head></span> section of an HTML page, or in both.

## 2.4 External JavaScript

​	Scripts can also be placed in external files:

```
/*myScript.js*/
function myFunction {
	document.getElementById("demo").innerHTML = "Paragraph changed.";
}
```

​	External scripts are practical when the same code is used in many different web pages. JavaScript files have the file extension <b>.js</b>.

​	To use an external script, put the name of the script file in the <span style="color: red;">src</span> (source) attribute of a <span style="color: red;">\<script></span> tag:

```
<script src="myScript.js"></script>
```

​	You can place an external script reference in <span style="color: red;">\<head></span> or <span style="color: red;">\<body></span> as you like.

​	The script will behave as if it was located exactly where the <span style="color: red;">\<script?</span> tag is located.

<b>Note:</b> External scripts cannot contain <span style="color: red;">\<script></span> tags.

## 2.5 External JavaScript Advantages

​	Placing scripts in external files has some advantages:

* It separates HTML and code
* It makes HTML and JavaScript easier to read and maintain
* Cached JavaScript files can speed up page loads

​	To add several script files to one page - use several script tags:

```
<script src="myScript1.js"></script>
<script src="myScript2.js"></script>
```

## 2.6 External References

​	An external script can be referenced in 3 different ways:

* With a full URL (a full web address)
* With a file path (link /js/)
* Without any path

​	This example uses a <b>full URL</b> to link to myScript .js:

```
<script src="https://www.w3schools.com/js/myScript.js"></script>
```

​	This example uses a <b>file path</b> to link to myScript.js:

```
<script src="/js/myScript.js"></script>
```



# 3. JavaScript Output

## 3.1 JavaScript Display Possibilities

​	JavaScript can "display" data in different ways:

* Writing into an HTML element, using <span style="color: red;">innerHTML</span>.
* Writing into the HTML output using <span style="color: red;">document.write()</span>.
* Writing into an alert box, using <span style="color: red;">window.alert()</span>.
* Writing into the browser console, using <span style="color: red;">console.log()</span>.

## 3.2 Using innerHTML

​	To access an HTML element, JavaScript can use the <span style="color: red;">document.getElementById(id)</span> method.

​	The <span style="color: red;">id</span> attribute defines the HTML element. The <span style="color: red;">innerHTML</span> property defines the HTML content:

````
<p id="demo"></p>
<script>
document.getElementById("demo").innerHTML = 5 + 6;
</script>
````

## 3.3 Using document.write()

​	For testing purpose, it it convenient to use <span style="color: red;">document.write()</span> (and should only be used for testing):

```
<!DOCTYPE html>
<html>
<p>Never call document.write after the document has finished loading.</p>
<script>document.write(5 + 6);</script>
</html>
```

<span style="color: blue">Using document.write() after an HTML document is loaded will <b>delete all existing HTML</b></span>:

```
<p>This is a test</p>
<button type="button" onclick="document.write(5 + 6)">Try it</button>
```

## 3.4 Using window.alert()

​	You can use an alert box to display data:

```
<script>window.alert(5 + 6);</script>
```

​	You can skip the <span style="color: red;">window</span> keyword.

​	In JavaScript, the window object is the global scope object. This means that variables, properties, and methods by default belong to the window object. This also means that specifying the <span style="color: red;">window</span> keyword is optional:

```
<script>alert(5 + 6);</script>
```

## 3.5 Using console.log()

​	For debugging purpose, you can call the <span style="color: red;">console.log()</span> method in the browser to display data.

```
<script>console.log(5 + 6);</script>
```

## 3.6 JavaScript Print

​	JavaScript does not have any print object or print methods.

​	You cannot access output devices from JavaScript.

​	The only exception is that you can call the <span style="color: red;">window.print()</span> method in the browser to print the content of the current window.

```
<button onclick="window.print()">Print this page</button>
```



# 4. JavaScript Statements

<span style="font-size: 21px;">Example</span>

```
let x, y, z;
x = 5;
y = 6;
z = x + y;
```

## 4.1 JavaScript Programs

​	<span style="color: blue">A <b>computer program</b> is a list of "instructions" to be "executed" by a computer</span>.

​	In a programming language, these programming instructions are called <b>statements</b>.

​	A <b>JavaScript program</b> is a list of programming <b>statements</b>.

<b>Note:</b> In HTML, JavaScript programs are executed by the web browser.

## 4.2 JavaScript Statements

​	JavaScript Statements are composed of:

​	Values, Operators, Expressions, Keywords, and Comments.

​	This statement tells the browser to write "Hello Dolly." inside an HTML element with id="demo3".

```
<p id="demo3"></p>
<script>
document.getElementById("demo3").innerHTML = "Hello Dolly.";
</script>
```

​	Most JavaScript programs contain many JavaScript statements. The statements are executed, one by one, in the same order as they are written.

<b>Note:</b> JavaScript programs (and JavaScript statements) are often called JavaScript code.

## 4.3 Semicolons ;

​	Semicolons separate JavaScript statements. When separated by semicolons, multiple statements on one line are allowed:

`a = 5; b = 6; c = a + b;`

<b>Note:</b> On the web, you might see examples without semicolons. Ending statements with semicolon is not required, but highly recommended.

## 4.4 JavaScript White Space

​	JavaScript ignores multiple spaces. You can add white space to your script to make it more readable. A good practice is to put spaces around operators (= + = * /).

## 4.5 JavaScript Line Length and Line Breaks

​	For best readability, programmers often like to avoid code lines longer than 80 characters.

​	If a JavaScript statement does not fit on one line, the best place to break it is after an operator.

```
document.getElementById("demo").innerHTML =
"Hello Dolly!";
```

## 4.6 JavaScript Code Blocks

​	JavaScript statements can be grouped together in code blocks, inside curly brackets {...}.

​	The purpose of code blocks is to define statements to be executed together.

​	One place you will find statements grouped together in blocks, is in JavaScript functions:

```
function myFunction() {
	document.getElementById("demo1").innerHTML = "Hello Dolly!";
	document.getElementById("demo2").innerHTML = "How are you?";
}
```

## 4.7 JavaScript Keywords

​	JavaScript statements often start with a <b>keyword</b> to identify the JavaScript action to be performed. Here is a list of some of the keywords you will learn about in this tutorial:

| Keyword  | Description                                                  |
| -------- | ------------------------------------------------------------ |
| var      | Declares a variable                                          |
| let      | Declares a block variable                                    |
| const    | Declares a block constant                                    |
| if       | Marks a block of statements to be executed on a condition    |
| switch   | Marks a block of statements to be executed in different cases |
| for      | Marks a block of statements to be executed in a loop         |
| function | Declares a function                                          |
| return   | Exits a function                                             |
| try      | Implements error handling to a block of statements           |

<b>Note:</b> JavaScript keywords are reserved words. Reserved words cannot be used as names for variables.



# 5. JavaScript Syntax

​	JavaScript syntax is the set of rules, how JavaScript programs are constructed.

## 5.1 JavaScript Values

​	The JavaScript syntax defines two types of values:

* Fixed values
* Variable values

​	Fixed values are called <b>Literals</b>.

​	Variable values are called <b>Variables</b>.

## 5.2 JavaScript Literals

​	The two most important syntax rules for fixed values are:

1. <b>Numbers</b> are written with or without decimals.
2. <b>Strings</b> are text, written within double or single quotes.

## 5.3 JavaScript Operators

​	JavaScript uses <b>arithmetic operators</b> ( + - * /) to <b>compute</b> values.

​	JavaScript uses an <b>assignment operator</b> (=) to <b>assign</b> values to variables.

## 5.4 JavaScript Expressions

​	An expression is a combination of values, variables, and operators, which computes to a value.

​	The computation is called an evaluation. For example, 5 * 10 evaluates to 50.

​	Expressions can also contain variable values:

```
x * 10
```

​	The values can be of various types, such as numbers and strings.

​	For example, "John" + "" + "Doe", evaluates to "John Doe".

## 5.5 JavaScript Keywords

​	JavaScript <b>keywords</b> are used to identify actions to be performed.

​	The <span style="color: red;">let</span> keyword tells the browser to create variables:

```
let x,y;
x = 5 + 6;
```

​	The <span style="color: red;">var</span> keyword also tells the browser to create variables:

```
var x,y;
x = 5 + 6;
```

## 5.6 JavaScript Comments

​	Not all JavaScript statements are "executed".

​	Code after double slashes <span style="color: red;">//</span> or between <span style="color: red;">/\*</span> and <span style="color: red;">*/</span> is created as a <b>comment</b>.

​	Comments are ignored, and will not be executed.

## 5.7 JavaScript Identifiers / Names

​	Identifiers are JavaScript names. Identifiers are used to name variables and keywords, and functions. The rule for legal names are the same in most programming languages. A JavaScript name must begin with:

* A letter (A-Z or a-z)
* A dollar sign ($)
* Or an underscore (_)

​	Subsequent characters may be letters, digits, underscores, or dollar signs.

## 5.8 JavaScript is Case Sensitive

​	All JavaScript identifiers are <b>case sensitive</b>. JavaScript does not interpret <b>LET</b> or <b>Let</b> as the keyword <b>let</b>.

## 5.9 JavaScript and Camel Case

​	Historically, programmers have used different ways of joining multiple words into one variable name:

<b>Hyphens:</b>

first-name, last-name, master-card, inter-city.

<b>Note:</b> Hyphens are not allowed in JavaScript. They are reserved for subtractions.

<b>Underscore:</b>

first_name, last_name, master_card, inter_city.

<b>Upper Camel Case (Pascal Case):</b>

FirstName, LastName, MasterCard, InterCity.

<b>Lower Camel Case:</b>

JavaScript programmers tend to use camel case that starts with a lowercase letter:

firstName, lastName, masterCard, interCity.

## 5.10 JavaScript Character Set

​	JavaScript uses the <b>Unicode</b> character set.

​	Unicode covers (almost) all the characters, punctuations, and symbols in the world.



# 6. JavaScript Comments

​	JavaScript comments can be used used to explain JavaScript code, and to make it more readable.

​	JavaScript comments can also be used to prevent execution, when testing alternative code.



# 7. JavaScript Variables

<span style="font-size: 20px;">4 Ways to Declare a JavaScript Variable:</span>

* Using <span style="color: red;">var</span>
* Using <span style="color: red;">let</span>
* Using <span style="color: red;">const</span>
* Using nothing

## 7.1 What are Variables?

​	Variables are containers for storing data (storing data values).

​	In this example, <span style="color: red;">x</span>, <span style="color: red;">y</span>, and <span style="color: red;">z</span>, are variables, declared with the <span style="color: red;">var</span> keyword:

```
var x = 5;
var y = 6;
var z = x + y;
```

<span style="font-size: 20px;">When to Use JavaScript var?</span>

​	Always declare JavaScript variables with <span style="color: red;">var</span>, <span style="color: red;">let</span>, or <span style="color: red;">const</span>.

​	The <span style="color: red;">var</span> keyword is used in all JavaScript code from 1995 to 2015.

​	The <span style="color: red;">let</span> and <span style="color: red;">const</span> keywords were added to JavaScript in 2015.

​	If you want your code to run in older browsers, you must use <span style="color: red;">var</span>.

## 7.2 When to Use JavaScript const?

​	If you want a general rule: always declare variables with <span style="color: red;">const</span>.

​	If you think the value of the variable can change, use <span style="color: red;">let</span>.

​	In this example, <span style="color: red;">price1</span>, <span style="color: red;">price2</span>, and <span style="color: red;">total</span>, are variables:

```
const price1 = 5;
const price2 = 6;
let total = price1 + price2;
```

## 7.3 Just Like Algebra

​	Just like in algebra, variables hold values.

## 7.4 JavaScript Identifiers

​	All JavaScript <b>variables</b> must be <b>identified</b> with <b>unique names</b>.

​	These unique names are called <b>identifiers</b>.

​	Identifiers can be short names (like x and y) or more descriptive names (age, sum, totalVolume).

​	The general rules for constructing names for variables (unique identifiers) are:

* Names can contain letters, digits, underscores, and dollar signs.
* Names must begin with a letter.
* Names can also begin with $ and _ (but we will not use it in this tutorial)
* Names are case sensitive (y and Y are different variables).
* Reserved words (like JavaScript keywords) cannot be used as names.

## 7.5 The Assignment Operator

​	In JavaScript, the equal sign (=) is an "assignment" operator, not an "equal to" operator.

​	This is different from algebra. The following does not make sense in algebra:

`x = x + 5`

​	In JavaScript, however, it makes perfect sense: it assigns the value of x + 5 to x.

​	(It calculates the value of x + 5 and puts the result into x.)

<b>Note:</b> The "equal to" operator is written like == in JavaScript.

## 7.6 JavaScript Data Types

​	JavaScript variables can hold numbers like 100 and text values like "John Doe".

​	In programming, text values are called text strings.

​	JavaScript can handle many types of data, but for now, just think of numbers and strings.

​	Strings are written inside double or single quotes. Numbers are written without quotes. If you put a number in quotes, it will be treated as a text string.

## 7.7 Declaring a JavaScript Variable

​	Creating a variable in JavaScript is called "declaring" a variable.

​	You declare a JavaScript variable with the <span style="color: red;">var</span> or the <span style="color: red;">let</span> keyword. After the declaration, the variable has no value (technically it is <span style="color: red;">undefined</span>). To <b>assing</b> a value to the variable, use the equal sign.

```
<script>
let carName = "Volvo";
document.getElementById("demo").innerHTML = carName;
</script>
```

<b>Note:</b> It's a good programming practice to declare all variables at the beginning of a script.

## 7.8 One Statement, Many Variables

​	You can declare many variables in one statement.

​	Start the statement with <span style="color: red;">let</span> and separate the variables by <b>comma</b>:

```
let person = "John Doe", carName = "Volvo", price = 200, 
distinct = "No 1";
```

## 7.9 Value = undefined

​	In computer programs, variables are often declared without a value. The value can be something that has to be calculated, or something that will be provided later, like use input.

​	A variable declared without a value will have the value <span style="color: red;">undefined</span>. 

## 7.10 Re-Declaring JavaScript Variables

​	If you re-declare a JavaScript variable declared with <span style="color: red;">var</span>, it will not lose its value.

​	The variable <span style="color: red;">carName</span> will still have the value "Volvo" after execution of these statements:

```
var varName = "Volvo";
var carName;
```

<b>Note:</b> You cannot re-declare a variable declared with <span style="color: red;">let</span> or <span style="color: red;">const</span>. This will not work:

```
let carName = "Volvo";
let carName;
```

## 7.11 JavaScript Arithmetic

​	As with algebra, you can do arithmetic with JavaScript variables, using operators like <span style="color: red;">=</span> and <span style="color: red;">+</span>:

```
let x = 5 + 2 + 3;
```

​	You can also add strings, but strings will be concatenated:

```
let x = "John" + " " + "Doe";
```

​	This will be treated as strings, and concatenated:

```
let x = "5" + 2 + 1;
```

## 7.12 JavaScript Dollar Sign $

​	Using the dollar sign is not very common in JavaScript, but professional programmers often use it as an alias for the main function in a JavaScript library.

​	In the JavaScript library jQuery, for instance, the main function <span style="color: red;">$</span> is used to select HTML elements. In jQuery <span style="color: red;">$("p");</span> means "select all p elements".

## 7.13 JavaScript Underscore (_)

​		Using the underscore is not very common in JavaScript, but a convention among professional programmers is to use it as an alias for "private (hidden)" variables.



# 8. JavaScript Let

## 8.1 Cannot be Redeclared

```
let x = "John Doe";
let x = 0;
```

## 8.2 Block Scope

​	Before ES6 (2015), JavaScript had <b>Global Scope</b> and <b>Function Scope</b>.

​	ES6 introduced two important new JavaScript keywords: <span style="color: red;">let</span> and <span style="color: red;">const</span>.

​	These two keywords provide <b>Block Scope</b> in JavaScript. Variables declared inside a { } block cannot be accessed from outside the block:

```
{
	let x = 2;
}
```

​	Variables declared with the <span style="color: red;">var</span> keyword can NOT have scope. Variables declared inside a { } block can be accessed from outside the block.

```
{
	var x = 2;
}
```

## 8.3 Redeclaring Variables

​	Redeclaring a variable using the <span style="color: red;">var</span> keyword can impose problems. Redeclaring a variable inside a block will also redeclare the variable outside the block:

```
var x = 10;		//x is 10
{
	var x = 2;	//x is 2
}
// x is 2
```

​	Redeclaring a variable using the <span style="color: red;">let</span> keyword can solve this problem.

​	Redeclaring a variable inside a block will not redeclare the variable outside the block:

```
let x = 10;		//x is 10
{
	let x = 2;	// x is 2
}
// x is 10
```

## 8.4 Redeclaring

​	Redeclaring a JavaScript variable with <span style="color: red;">var</span> is allowed anywhere in a program:

```
var x = 2;	//x is 2
var x = 3;	//x is 3
```

​	With <span style="color: red;">let</span>, redeclaring a variable in the same block is NOT allowed:

```
var x = 2;	//Allowed
let x = 3;	//Not allowd
{
	let x = 2;	//Allowed
	let x = 3;	//Not allowed
}
{
	let x = 2;	//Allowed
	var x = 3;	//Not allowed
}
```

​	Redeclaring a variable with <span style="color: red;">let</span>, in another block, IS allowed:

```
let x = 2;		//Allowed
{
	let x = 3;	//Allowed
}
{
	let x = 4;	//Allowed
}
```

## 8.5 Let Hoisting

​	Variables defined with <span style="color: red;">var</span> are <b>hoisted</b> to the top and can be initialized at any time.

​	Meaning: You can use the variable before it is declared:

```
carName = "Volvo";
var carName;
```

​	If you want to learn more about hoisting, study the chapter JavaScript Hoisting.

​	Variables defined with <span style="color: red;">let</span> are also hoisted to the top of the block, but not initialized.

​	Meaning: Using a <span style="color: red;">let</span> variable before it is declared will result in a <span style="color: red;">ReferenceError</span>:

```
carName = "Saab";
let carName = "Volvo";
```



# 9. JavaScript Const

* The <span style="color: red;">const</span> keyword was introduced in ES6 (2015).
* Variables defined with <span style="color: red;">const</span> cannot be Redeclared.
* Variables defined with <span style="color: red;">const</span> cannot be Reassigned.
* Variables defined with <span style="color: red;">const</span> have Block Scope.

## 9.1 Cannot be Reassigned

​	A <span style="color: red;">const</span> variable cannot be reassigned:

```
const PI = 3.141592653589793;
PI = 3.14;			//This will give an error
PI = PI + 10;		//This will also give an error
```

## 9.2 Must be Assigned

​	JavaScript <span style="color: red;">const</span> variables must be assigned a value when they are declared:

```
const PI = 3.1415;	//Correct
const PI;
PI = 3.1415;		//Incorrect
```

<span style="font-size: 20px;">When to use JavaScript const?</span>

<b>Always declare a variable with </b><span style="color: red;"><b>const</b></span> <b>when you know that the value should not be changed.</b>

Use <span style="color: red;">const</span> when you declare:

* A new Array
* A new Object
* A new Function
* A new RegExp

## 9.3 Constant Objects and Arrays

​	The keyword <span style="color: red;">const</span> is a little misleading.

​	It does not define a constant value. It defines a constant reference to a value.

​	Because of this you can NOT:

* Reassign a constant value
* Reassign a constant array
* Reassign a constant object

​	But you CAN:

* Change the elements of constant array
* Change the properties of constant object

## 9.4 Constant Arrays

​	You can change the elements of a constant array:

```
const cars = ["Saab", "Volvo", "BMW"];	//You can create a constant array;
cars[0] = "Toyota";						//You can change an element
cars.push("Audi");						//You can add an element
```

​	But you can NOT reassign the array:

```
const cars = ["Saab", "Volvo", "BMW"];
cars = ["Toyota", "Volvo", "Audi"];
```

## 9.5 Constant Objects

​	You can change the properties of a constant object:

```
const car = {type:"Fiat", model="500", color:"white"};	//You can create a const object
car.color = "red";		//You can change a property
car.owner = "Johnson";	//You can add a property
```

​	But you can NOT reassign the object:

```
const car = {type:"Fiat", model:500", color:"white"};
car = {type:"Volvo", model:"EX60", color:"red"};	//Error
```

## 9.6 Block Scope

​	Declaring a variable with <span style="color: red;">const</span> is similar to <span style="color: red;">let</span> when it comes to <b>Block Scope</b>.

​	The x declared in the block, in this example, is not the same as the x declared outside the block:

```
const x = 10;	//Here x is 10
{
	const x = 2;	//Here x is 2
}
//Here x is 10
```

## 9.7 Redeclaring

​	Redeclaring a JavaScript <span style="color: red;">var</span> variable is allowed anywhere in a program:

```
var x = 2;
var x = 3;
x = 4;		//All allowed
```

​	Redeclaring an existing <span style="color: red;">var</span> or <span style="color: red;">let</span> variable to <span style="color: red;">const</span>, in the same scope, is not allowed:

```
var x = 2;	//Allowed
const x = 2;//Not allowed
{
	let x = 2;		//Allowed
	const x = 2;	//Not allowed
}
{
	const x = 2;	//Allowed
	const x = 2;	//Not allowed
}
```

​	Reassigning an existing <span style="color: red;">const</span> variable, in the same scope, is not allowed:

```
const x = 2;	//Allowed
x = 2;			//Not allowed
var x = 2;		//Not allowed
let x = 2;		//Not allowed
consst x = 2;	//Not allowed
{
	const x = 2;	//Allowed
	x = 2;			//Not allowed
	var x = 2;		//Not allowed
	let x = 2;		//Not allowed
	const x = 2;	//Not allowed
}
```

​	Redeclaring a variable with <span style="color: red;">const</span>, in another scope, or in another block, is allowed:

```
const x = 2;		//Allowed
{
	const x = 3;	//Allowed
}
{
	const x = 4;	//Allowed
}
```

## 9.8 Hoisting

​	Variables defined with <span style="color: red;">var</span> are <b>hosited</b> to the top and can be initialized at any time.

​	Meaning: You can use the variable before it is declared:

```
carName = "Volvo";
var carName;
```

​	If you want to learn more about hoisting, study the chapter JavaScript Hoisting.

​	Variables defined with <span style="color: red;">const</span> are also hoisted to the top, but not initialized.

​	Meaning: Using a <span style="color: red;">const</span> variable before it is declared will result in a <span style="color: red;">ReferenceError</span>:

```
alert(carName);
const carName = "Volvo";
```



# 10. JavaScript Operators

## 10.1 JavaScript Assignment

​	The <b>Assignment Operator</b> (=) assigns a value to a variable:

```
let x = 10;
let x = 5;
```

## 10.2 JavaScript Addition

​	The <b>Addition Operator</b> (+) adds numbers:

```
let x = 5;
let y = 2;
let z = x + y;
```

## 10.3 JavaScript Multiplication

​	The <b>Multiplication Operator</b> (*) multiplies numbers:

```
let x = 5;
let y = 2;
let z = x * y;
```

## 10.4 Types of JavaScript Operators

​	There are different types of JavaScript operators:

* Arithmetic Operators
* Assignment Operators
* Comparison Operators
* String Operators
* Logical Operators
* Bitwise Operators
* Ternary Operators
* Type Operators

​	I omit this section, please manipulate the relevant documents.



# 11. JavaScript Arithmetic

## 11.1 JavaScript Arithmetic Operator

​	Arithmetic operators perform arithmetic on numbers (literals or variables).

| Operator | Description                                                  |
| :------- | :----------------------------------------------------------- |
| +        | Addition                                                     |
| -        | Subtraction                                                  |
| *        | Multiplication                                               |
| **       | Exponentiation ([ES2016](https://www.w3schools.com/js/js_2016.asp)) |
| /        | Division                                                     |
| %        | Modulus (Remainder)                                          |
| ++       | Increment                                                    |
| --       | Decrement                                                    |

## 11.2 Operators and Operands

​	The numbers (in an arithmetic operation) are called <b>operands</b>.

​	The operation (to be performed between the two operands) is defined by an <b>operator</b>.

## 11.3 Operator Precedence

​	Multiplication (*) and division (/) have higher <b>precedence</b> than addition (+) and subtraction (-). When many operations have the same precedence, they are computed from left to right.



## 12. JavaScript Assignment

## 12.1 JavaScript Assignment Operators

| Operator | Example | Same As    |
| :------- | :------ | :--------- |
| =        | x = y   | x = y      |
| +=       | x += y  | x = x + y  |
| -=       | x -= y  | x = x - y  |
| *=       | x *= y  | x = x * y  |
| /=       | x /= y  | x = x / y  |
| %=       | x %= y  | x = x % y  |
| **=      | x **= y | x = x ** y |

## 12.2 Shift Assignment Operators

| Operator | Example  | Same As     |
| :------- | :------- | :---------- |
| <<=      | x <<= y  | x = x << y  |
| >>=      | x >>= y  | x = x >> y  |
| >>>=     | x >>>= y | x = x >>> y |

## 12.3 Bitwise Assignment Operators

| &=   | x &= y  | x = x & y  |
| ---- | ------- | ---------- |
| ^=   | x ^= y  | x = x ^ y  |
| \|=  | x \|= y | x = x \| y |

## 12.4 Logical Assignment Operators

| Operator | Example   | Same As            |
| :------- | :-------- | :----------------- |
| &&=      | x &&= y   | x = x && (x = y)   |
| \|\|=    | x \|\|= y | x = x \|\| (x = y) |
| ??=      | x ??= y   | x = x ?? (x = y)   |



# 13. JavaScript Data Types

<span style="font-size: 20px;">JavaScript has 8 Datatypes</span>

* String
* Number
* BigInt
* Boolean
* Undefined
* Null
* Symbol
* Object

<span style="font-size: 20px;">The Object Datatype</span>

* An object
* An array
* A date

```
//Numbers:
let length = 16;
var weight = 7.5;
//Strings:
let color = "Yellow";
var lastName = "Johnson";
//Booleans
let x = true;
let y = false;
//Object:
const person = {firstName:"John", lastName:"Doe"};
//Array object:
const cars = ["Saab", "Volvo", "BMW"];
//Date object:
const date = new Date("2023-04-11");
```

<b>Note:</b> A JavaScript variable can hold any type of data.

## 13.1 The Concept of Data Types

​	In programming, data types is an important concept.

​	To be able to operate on variables, it it important to know something about the data type.

​	Without data types, a computer cannot safely solve this:

```
let x = 16 + "Volvo";
```

​	(Does it make any sense to add "Volvo" to sixteen? Will it produce an error or will it produce a result?) JavaScript will treat the example above as:

```
let x = "16" + "Volvo";
```

​	Pay attention to that JavaScript evaluates expressions from left to right. Different sequences can produce different results:

```
let x = 16 + 4 + "BYD";
```

<span style="color: blue;">Result:</span> 20BYD

## 13.2 JavaScript Types are Dynamic

​	JavaScript has dynamic types. This means that the same variable can be used to hold different data types:

```
let x;	//Undefined
x = 5;	//Number
x = "John";
```

## 13.3 JavaScript Strings

​	A string (or a text string) is a series of characters like "John Doe".

​	Strings are written with quotes. You can use single or double quotes.

​	You can use quotes inside a string, as long as they don't match the quotes surrounding the string:

```
let answer1 = "It's alright";
let answer2 = "He is called 'Johnny'";
let answer3 = 'I like "BYD"';
```

## 13.4 Exponential Notation

​	Extra large or extra small numbers can be written with scientific (exponential) notation:

```
let y = 123e5;	//123 * 10^5
let z = 123e-5;	//123 * 10^(-5)
```

<b>Note:</b>

​	Most programming languages have many number types:

​	Whole numbers (integers, depend on compiler):

​		byte (8-bit), short(16-bit), int(32-bit), long(64-bit)

​	Real numbers (floating-point):

​		float(32-bit), double(64-bit)

​	<b>JavaScript are always one type:</b>

​		<b>double (64-bit floating point)</b>.

## 13.5 JavaScript BigInt

​	All JavaScript numbers are stored in a 64-bit floating-point format.

​	JavaScript BigInt is a new datatype(2020) that can be used to store integer values that are too big to be represented by a normal JavaScript Number.

```
let x = BigInt("123456789001234567891357924680");
```

## 13.6 JavaScript Objects

​	JavaScript objects are written with curly braces { }.

​	Object properties are written as name:value pairs, separated by commas.

```
const person = {firstName: "John", lastName:"Doe"};
```

## 13.7 The typeof Operator

​	You can use the JavaScript <span style="color: red;">typeof</span> operator to find the type of a JavaScript variable.

​	The <span style="color: red;">typeof</span> operator returns the type of a variable or an expression:

```
typeof ""
typeof 314
```

## 13.8 Undefined & Empty Values

​	In JavaScript, a variable without a value, has the value <span style="color: red;">undefined</span>. The type is also <span style="color: red;">undefined</span>. Any variable can be emptied, by setting the value to <span style="color: red;">undefined</span>. An empty value has nothing to do also with <span style="color: red;">undefined</span>, an empty string has both a legal value and a type.

```
let car;		//undefined
let car = "";	//value is "", typeof is "string"
```

 

# 14. JavaScript Functions

​	A JavaScript function is a block of code designed to perform a particular task.

​	A JavaScript function is executed when "something" invokes it (calls it).

```
function myFunction(p1, p1) {
	return p1 * p2;
}
```

## 14.1 JavaScript Function Syntax

​	A JavaScript function is defined with the <span style="color: red;">function</span> keyword, followed by a <b>name</b> followed by parentheses <b>( )</b>.

​	Function names can contain letters, digits, underscore, and dollar signs (same rules as variables). The parentheses may include parameter names separated by commas:

<b>(parameter1, parameter2, ...)</b>. The code to be executed, by the function, is placed inside curly brackets: <b>{ }</b>.

​	Function <b>parameters</b> are listed inside the parentheses () in the function definition. Function <b>arguments</b> are the <b>values</b> received by the function when it is invoked. Inside the function, the arguments (the parameters) behave as local variables.

## 14.2 Function Invocation

​	The code inside the function will execute when "something" <b>invokes</b> (calls) the function:

* When an event occurs (when a user clicks a button)
* When it is invoked (called) from JavaScript code
* Automatically (self invoked)

​	You will learn a lot more about function invocation later in this tutorial.

## 14.3 Function Return

​	When JavaScript reaches a <span style="color: red;">return</span> statement, the function will stop executing. If the function was invoked from a statement, JavaScript will "return" to execute the code after the invoking statement. Functions often compute a <b>return value</b>. The return value is "returned" back to the "caller":

```
let x = myFunction(4, 3);	//Function is called, return value will end up in x
function myFunction(a, b) {
	return a * b;			//Function returns the product of a and b
}
```

## 14.4 Why Functions?

​	You can reuse code: Define the code once, and use it many times (with different arguments, to produce different results).

```
function toCelsius(fahrenheit) {
	return (5/9) * (fahrenheitt-32);
}
document.getElementById("demo").innerHTML = tooCelsius(77);
```

## 14.5 The () Operator Invokes the Function

​	Using the example above, <span style="color: red;">toCelsius</span> refers to the function object, and <span style="color: red;">toCelsius()</span> refers to the function result.

```
function toCelsius(fahrenheit) {
	return (5/9) * (fahrenheit-32);
}
document.getElementById("demo3").innerHTML = toCelsius;
<!-- HTML -->
<h3>JavaScript Functions:</h3>
<p id="demo3"></p>
<script src="javascript.js"></script>	<!-- Pay attention: Cannot put before the 'id' -->
```

## 14.6 Functions Used as Variable Values

​	Function can be used the same way as you use variables, in all types of formulas, assignments, and calculations.

​	You can use the function directly, as a variable value:

```
let text = "The temperature is " + toCelsius(77) + " Celsius";
```

## 14.7 Local Variables

​	Variables declared within a JavaScript function, become <b>LOCAL</b> to the function. Local variables can only be accessed from within the function. Local variables are created when a function starts, and deleted when the function is completed.

​	

# 15. JavaScript Objects

## 15.1 Real Life Objects, Properties, and Methods

​	If real life, a car is an <b>object</b>.

​	A car has <b>properties</b> like weight and color, and <b>methods</b> like start and stop:

| Object                              | Properties                                                   | Methods                                                      |
| ----------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
| <img src="img/objectExplained.gif"> | car.name = Fiat<br><br>car.model = 500<br><br/>car.weight = 850kg<br><br/>car.color = white | car.start()<br><br/>car.drve()<br><br/>car.brake()<br><br/>car.stop() |

​	All cars have the same <b>properties</b>, but the property <b>values</b> differ from car to car. All cars have the same <b>methods</b>, but the methods are performed <b>at different times</b>.

## 15.2 JavaScript Objects

​	Objects are variables too. But objects can contain many values.

​	This code assigns <b>many values</b> to a <b>variable named car:

```
const car = {type:"Fiat", model:"500", color:"white"};
```

## 15.3 Object Definition

​	You define (and create) a JavaScript object with an object literal:

```
const person = {firstName:"John", lastName:"Doe", age:50};
```

​	Spaces and line breaks are not important. An object definition can span multiple lines:

```
const person = {
	firstName: "John",
	lastName: "Doe",
	age: 50
};
```

## 15.4 Object Properties

​	The <b>name:values</b> pairs in JavaScript objects are called <b>properties</b>:

| Property  | Property Value |
| --------- | -------------- |
| firstName | John           |
| lastName  | Doe            |

## 15.5 Accessing Object Properties

​	You can access object properties in two ways:

`objectName.propertyName`

​	or

`objectName["propertyName"]'

## 15.6 Object Methods

​	Objects can also have <b>methods</b>.

​	Methods are <b>actions</b> that can be performed on objects.

​	Methods are stored in properties as <b>function definitions</b>.

| Property  | Property Value                                            |
| --------- | --------------------------------------------------------- |
| firstName | John                                                      |
| fullName  | function() {return this.firstName + " " + this.lastName;} |

```
const person = {
	firstName	: "John",
	lastName	: "Doe",
	id			: 5566;
	fullName	: function() {
		return this.firstName + " " + this.lastName;//this refers to the person object
	}
}
```

## 15.7 What is <b>this</b>?

​	In JavaScript, the <span style="color: red;">this</span> keyword refers to an <b>object</b>.

​	<b>Which</b> object depends on how <span style="color: red;">this</span> is being invoked (used or called).

​	The <span style="color: red;">this</span> keyword refers to different objects depending on how it is used:

| Descriptions                                                 |
| ------------------------------------------------------------ |
| In an object method, <span style="color: red;">this</span> refers to the <b>object</b>. |
| Alone, <span style="color: red;">this</span> refers to the <b>global object</b>. |
| In a function, <span style="color: red;">this</span> refers to the <b>global object</b>. |
| In a function, in strict mode, <span style="color: red;">this</span> is <span style="color: red;">undefined</span>. |
| In an event, <span style="color: red;">this</span> refers to the <b>element</b> that received the event. |
| Methods like <span style="color: red;">call()</span>, <span style="color: red;">apply()</span>, and <span style="color: red;">bind()</span> can refer <span style="color: red;">this</span> to <b>any object</b>. |

<b>Note:</b> <span style="color: red;">this</span> is not a variable. It is a keyword. You cannot change the value of <span style="color: red;">this</span>.

## 15.8 The <b>this</b> Keyword

​	In a function definition, <span style="color: red;">this</span> refers to the "owner" of the function.

​	In the example above, <span style="color: red;">this</span> is the <b>person object</b> that "owns" the <span style="color: red;">fullName</span> function.

​	In other words, <span style="color: red;">this.firstName</span> means the <span style="color: red;">firstName</span> property of <b>this object</b>.

## 15.9 Accessing Object Methods

​	You access an object method with the following syntax:

`objectName.methodName()`

​	If you access a method <b>without</b> the () parentheses, it will return the <b>function definition</b>:

`name = person.fullName;`

## 15.10 Do Not Declare Strings, Numbers, and Booleans as Objects!

​	When a JavaScript variable is declared with the keyword "<span style="color: red;">new</span>", the variable is created as an object:

```
x = new String();	//Declares x as a String object
y = new Number();
z = new Boolean();
```

​	But, you should avoid <span style="color: red;">String</span>, <span style="color: red;">Number</span>, and <span style="color: red;">Boolean</span> objects. They complicate your code and slow down execution speed.



# 16. JavaScript Events

​	HTML events are "<b>things</b>" that happen to HTML elements.

​	When JavaScript is used in HTML pages, JavaScript can "<b>react</b>" on these events.

## 16.1 HTML Events

​	An HTML event can be something the browser does, or something a user does.

​	Here are some examples of HTML events:

* An HTML web page has finished loading
* An HTML input field was changed
* An HTML button was clicked

​	Often, when events happen, you may want to do something.

​	JavaScript lets you execute code when events are detected.

​	HTML allows event handler attributes, <b>with JavaScript code</b>, to be added to HTML elements.

​	With single quotes:

```
<element event='some JavaScript'>
```

​	With double quotes:

```
<element event="some JavaScript">
```

​	In the following example, an <span style="color: red;">onclick</span> attribute (with code), is added to a <span style="color: red;">\<button></span> element:

```
<p id="demo"></p>
<button onclick="document.getElementById('demo').innerHTML = Date()">The time is?</button>
```

​	In the next example, the code changes the content of its own element:

```
<button onclick="this.innerHTML = Date()">The time is?</button>
```

## 16.2 Common HTML Events

​	Here is a list of some common HTML events:

| Event       | Description                                        |
| ----------- | -------------------------------------------------- |
| onchange    | An HTML element has been changed                   |
| onclick     | The user clicks an HTML element                    |
| onmouseover | The user moves the mouse over an HTML element      |
| onmouseout  | The user moves the mouse away from an HTML element |
| onkeydown   | The user pushed a keyboard key                     |
| onload      | The browser has finished loading the page          |

## 16.3 JavaScript Event Handlers

​	Event handlers can be used to handle and verify user input, user actions, and browser actions:

* Things that should be done every time a page loads
* Things that should be done when the page is closed
* Action that should be performed when a user clicks a button
* Content that should be verified when a user inputs data
* And more ...

​	Many different methods can be used to let JavaScript work with events:

* HTML event attributes can execute JavaScript code directly
* HTML event attributes can call JavaScript functions
* You can assign your own event handler functions to HTML elements
* You can prevent events from being sent or being handled
* And more ...



# 17. JavaScript Strings

​	JavaScript strings are for storing and manipulating text. A JavaScript string is zero or more characters written inside quotes. You can use single or double quotes. You can use quotes inside a string, as long as they don't match the quotes surrounding the string:

```
let answer1 = "He is called 'Johnny'";
let answer2 = 'He is called "Johnny"';
```

## 17.1 String Length

​	To find the length of a string, use the built-in <span style="color: red;">length</span> property:

```
let text = "DFJSFOISHFIOSDHFIOA";
let length = text.length;
```

## 17.2 Escape Character

​	Because strings must be written within quotes, JavaScript will misunderstand this string:

```
let text = "We are the so-called "Vikings" from the north.";
```

​	The string will be chopped to "We are the so-called ".

​	The solution to avoid this problem, is to use the <b>backslash escape character</b>.

​	The backslash (\\) escape character turns special characters into string characters:

| Code | Result | Description  |
| ---- | ------ | ------------ |
| \\'  | '      | Single quote |
| \\"  | "      | Double quote |
| \\\  | \      | Backlash     |

```
let text = "We are the so-called \"Vikings\" from the north.";
```

​	Six other escape sequences are valid in JavaScript:

| Code | Result               |
| ---- | -------------------- |
| \b   | Backspace            |
| \f   | Form Feed            |
| \n   | New Line             |
| \r   | Carriage Return      |
| \t   | Horizontal Tabulator |
| \v   | Vertical Tabulator   |

<b>Note:</b> The 6 escape characters above were originally designed to control typewriters, teletypes, and fax machines. They do not make any sense in HTML.

## 17.3 Breaking Long Code Lines

​	For best readability, programmers often like to avoid code lines longer than 80 characters.

​	If a JavaScript statement does not fit on one line, the best place to break it is after an operator:

```
document.getElementById("demo").innerHTML = 
"Hello Dolly!";
```

​	You can also break up a code line <b>within a text string</b> with a single backslash:

```
document.getElementById("demo").innerHTML = "Hello \
Dolly!";
```

​	But the backslash method is not the preferred method (not have universal support). A safer waay to break up a sting, is to use string addition:

```
document.getElementById("demo").innerHTML = "Hello" +
" Dolly!";
```

​	<span style="color: blue;">And you cannot break up a code line with a backslash</span>:

```
document.getElementById("demo").innerHTML = \
"Hello Dolly!";
```

## 17.4 JavaScript Strings as Objects

​	Normally, JavaScript strings are primitive values, created from literals:

```
let x = "John";
```

​	But strings can also be defined as objects with the keyword <span style="color: red;">new</span>:

```
let y = new String("John");
```

​	<b>Note:</b> Do not create Strings objects. The <span style="color: red;">new</span> keyword complicated the code and slows down execution speed. String objects can produce unexpected results:

```
let x = "John";
let y = new String("John");
```

​	When using the <span style="color: red;">==</span> operator, x and y are <b>equal</b>, but when using the <span style="color: red;">===</span> operator, x and y are <b>not equal</b>. <span style="color: blue;">And comparing two JavaScript objects <b>always</b> returns <b>false</b></span>.



# 18. JavaScript String Methods

## 18.1 JavaScript String Length

​	The <span style="color: red;">length</span> property returns the length of a string:

```
let text = "DSFOJAOIIHFPQKJADSBF"; let length = text.length;
```

## 18.2 Extracting String Parts

​	There are 3 methods for extracting a part of a string:

* <span style="color: red;">slice(start, end)</span>
* <span style="color: red;">substring(start, end)</span>
* <span style="color: red;">substr(start, length)</span>

### 18.2.1 String slice()

​	<span style="color: red;">slice()</span> extracts a part of a string and returns the extracted part in a new string.

```
let text = "Apple, Banana, Kiwi";
let part = text.slice(7, 13);
```

​	If a parameter is negative, the position is counted from the end of the string:

```
let part = text.slice(-12);
```

### 18.2.2 String substring()

​	<span style="color: red;">substring()</span> is similar to <span style="color: red;">slice()</span>. The different is that start and end values less than 0 are treated as 0 in <span style="color: red;">substring()</span>. And if you omit the second parameter, <span style="color: red;">substring()</span> will slice out the rest of the string.

### 18.2.3 String substr()

​	<span style="color: red;">substr()</span> is similar to <span style="color: red;">slice()</span>. The different is that the second parameter specifies the <b>length</b> of the extracted part. If you omit the rest of the string, <span style="color: red;">substr()</span> slice out the rest of the string. And if the first parameter is negative, the position counts from the end of the string.

```
let str = "DFJIODSFJOEIEF";
let part = str.substr(3, 4);
```

## 18.3 Replacing String Content

​	The <span style="color: red;">replace()</span> method replaces a specified value with another value in a string:

```
let text = "Please refer http://pf123.top";
let newText = text.replace("pf123.top", "http://47.113.197.114/");
```

​	<b>Note:</b>

​	The <span style="color: red;">replace()</span> method does not change the string it is called on.

​	The <span style="color: red;">replace()</span> method returns a new string.

​	The <span style="color: red;">replace()</span> method replaces <b>only the first</b> match. If you want to replace all matches, use a regular expression with the /g flag set.

### 18.3.1 replace() is case sensitive

​	To replace case insensitive, use a <b>regular expression</b> with a <span style="color: red;">/i</span> flag (insensitive):

```
let text = "Underssing her was an act of recklessness";
let newText = text.replace(/Recklessness/i, "rude");
```

​	<b>Note:</b> Regular expressions are written without quotes.

### 18.3.2 replace() replace the first one by default

​	To replace all matches, use a <b>regular expression</b> with a <span style="color: red;">/g</span> flag (global match):

```
let text = "It is vandalism, like releasing a zoo full of animals, or blowing up a dam";
let newText = text.replace(/ a /g, " "); 
```

## 18.4 String ReplaceAll()

​	In 2021, JavaScript introduced the string method <span style="color: red;">replaceAll()</span>. The method allows you to specify a regular expression instead of a string to be replaced. If the parameter is a regular expression, the global flag (g) must be set, otherwise a TypeError is thrown:

```
text = text.replaceAll("Cats", "Dogs");
text = text.replaceAll(/Cats/g, "Dogs");
```

## 18.5 Converting to Upper and Lower Case

​	A string is converted to upper case with <span style="color: red;">toUpperCase()</span>, and to lower case with <span style="color: red;">toLowerCase()</span>.

## 18.6 String concat()

​	<span style="color: red;">concat()</span> joins two or more strings. The <span style="color: red;">concat()</span> method can be used instead of the plus operator:

```
let text1 = "We were all a little drunk with spring,";
let text2 = " like the fat bees reeling from flower to flower";
let concat1 = text1.concat("", text2);
let concat2 = text1 + text2;
```

<b>Note:</b> All string methods return a new string. They don't modify the original string. Formally said: Strings are immutable, Strings cannot be changed, only replaced.

## 18.7 String trim()

​	The <span style="color: red;">trim()</span> method removes whitespace from both side of a string:

```
let text1 = "    Library   ";
let textTrimed = text1.trim();
```

### 18.7.1 String trimStart()

​	ECMAScript 2019 added the String method <span style="color: red;">trimStart()</span> to JavaScript, it removes whitespace only from the start of a string;

### 18.7.2 String trimEnd()

## 18.8 String Padding

​	ECMAScript 2017 added two new string methods to JavaScript: <span style="color: red;">padStart()</span> and <span style="color: red;">padEnd()</span> to support padding at the beginning and at the end of a string.

```
let text = "5";
let padded = text.padStart(4, "0");
```

<b>Note:</b> The <span style="color: red;">padStart()</span> and <span style="color: red;">padEnd()</span> method are string method. To pad a number, covert the number to a string first:

```
let numb = 5;
let text = numb.toString();
```

## 18.9 Extracting String Characters

​	There are 3 methods for extracting string characters:

* <span style="color: red;">charAt(position)</span>
* <span style="color: red;">charCodeAt(position)</span>
* Property access [ ]

### 18.9.1 String charAt()

​	The <span style="color: red;">charAt()</span> method returns the character at a specified index (position) in a string:

```
let text = "Lizards skit like quick beige sticks";
let char = text.charAt(0);
```

### 18.9.2 String charCodeAt()

​	The <span style="color: red;">charCodeAt()</span> method returns the unicode of the character at a specified index in a string, the method returns a UTF-16 code (integer between 0 and 65535):

```
let text = "The sky, at sunset, looked like a carnivorous flower";
let char = text.charCodeAt(0);
```

### 18.9.3 Property Access

​	ECMAScript 5 (2009) allows property access [ ] on strings:

```
let text = "Inside us there is something that has no name, that
something is what we are.";
let char = text[0];
```

<b>Note:</b> Property access might be a little <b>unpredictable</b>:

* It makes strings look like arrays (but they are not)
* If no character is found, [ ] returns undefined, while charAt() returns an empty string
* It is read only. str[0] = "A" gives no error (but does not work!)

## 18.10 Converting a String to an Array

​	If you want to work with a string as an array, you can convert it to an array.

### 18.10.1 String split()

​	A string can be converted to array with the <span style="color: red;">split()</span> method:

```
text.split(",");	//Split on commas
text.split(" ");	//Split on spaces
text.split("|");	//Split on pipe
```

​	If the separator is omitted, the returned array will contain the whole string in index [0].

If the separator is "", the returned array will be an array of single characters:

```
text.split("");
```



# 19. JavaScript String Search

<span style="font-size: 20px;">String Search Methods</span>:

* String indexOf()
* String lastIndexOf()
* String search()
* String match()
* String matchAll()
* String includes()
* String startsWith()
* String endWith()

## 19.1 String indexOf()

​	The <span style="color: red;">indexOf()</span> method returns the <b>index</b> (position) the <b>first</b> occurrence of a string in a string:

```
let text = "As she picked up her shoes from the cloest and tiptoed from the room, she felt, for a vertiginous moment, an unlawful excitement.";
let index = text.indexOf("vertiginous");
```

<b>Note:</b> JavaScript counts positions from zero.

## 19.2 String lastIndexOf()

​	The <span style="color: red;">lastIndexOf()</span> method returns the <b>index</b> of the <b>last</b> occurrence of a specified text in a string.

Both <span style="color: red;">indexOf()</span>, and <span style="color: red;">lastIndexOf()</span> return -1 if the text is not found.

​	Both methods accept a second parameter as the starting position for the search:

```
let text = "He'd say \"I love you\" to every man in the squad before rolling out, say it straight, with no joking or smart-ass litt and no warbly Christian smarm in it either, just that brisk declaration like he was tightening the seat belts around everyone's soul.";
let index = text.indexOf("litt", 15);
```

​	The <span style="color: red;">lastIndexOf()</span> methods searches backwards, meaning: if the second parameter is 15, the search starts at position 15, and searched to the beginning of the string.

## 19.3 String search()

​	The <span style="color: red;">search()</span> method searches a string for a string (or a regular expression) and returns the position of the match:

```
let text = "Every native everywhere lives a life of overwhelming and crushing banality and boredom and desperation and depression, and every deed, good and bad, is an attempt to forget this.";	//?I disagree with this description
text.search("boredom");
text.search(/deed/);
```

<span style="font-size: 20px;">Did You Notice?</span>

​	The two methods, <span style="color: red;">indexOf()</span> and <span style="color: red;">search()</span>, are <b>equal</b>?

​	They accept the same arguments (parameters), and return the same value?

​	But if fact, the two methods are <b>NOT</b> equal. These are the differences:

* The <span style="color: red;">search()</span> method cannot take a second start position arguments.
* The <span style="color: red;">indexOf()</span> method cannot take powerful search values (regular expressions).

## 19.4 String match()

​	The <span style="color: red;">match()</span> method returns an array containing the results of matching a string against a string (or a regular expression):

```
let text = "The rain in SPAIN stays mainly in the plain";
text.match("ain");	//return only the first match in the string
text.match(/ain/);
text.match(/ain/g);
text.match(/ain/gi);
```

## 19.5 String matchAll()

​	The <span style="color: red;">matchAll()</span> method returns an iterator containing the results of matching a string against a string (or a regular expression):

```
const iterator = text.matchAll("Cats");
const iterator2 = text.matchAll(/Cats/g);
```

​	If the parameter is a regular expression, the global flag (g) must be set, otherwise a TypeError is thrown.

## 19.6 String includes()

​	The <span style="color: red;">includes()</span> method returns true if a string contains a specified value. Otherwise it return false:

```
text.includes("Donald");
text.includes("Trump", 12);	//match start at position 12
```

## 19.7 String startsWith()

​	The <span style="color: red;">startsWith()</span> method returns <span style="color: red;">true</span> if a string begins with a specified value. Otherwise it returns <span style="color: red;">false</span>. A start position for the search can be specified:

```
text.startsWith("gone", 9);
text.startsWith(/gone/, 9);	//Not supproted!
```

## 19.8 String endsWith()

​	The <span style="color: red;">endsWith()</span> method returns <span style="color: red;">true</span> if a string ends with a specified value, otherwise it returns <span style="color: red;">false</span>.



# 20. JavaScript Template Literals

Synonyms:

* Template Literals
* Template Strings
* String Templates
* Back-Tics Syntax

## 20.1 Back-Tics Syntax

​	<b>Template Literals</b> use back-ticks(``) rather than the quotes ("") to define a string:

```
let text = `Love is the extremely difficult realization that something other than oneself is real.`
```

## 20.2 Quotes Inside Strings

​	With <b>template literals</b>, you can use both single and double quotes inside a string:

```
let text = `We're souls shut inside a "cage" of bones;`;
```

## 20.3 Multiline Strings

​	<b>Template literals</b> allows multiline strings:

```
let text = `Old lovers
go the way of old photograhps,
bleaching out gradually as in 
a slow bath of acid`;
```

## 20.4 Interpolation

​	<b>Template literals</b> provide an easy way to interpolate variables and expressions into strings. The method is called string interpolation. The syntax is:

`${...}`

## 20.5 Variable Substitutions

​	<b>Template literals</b> allow variables in strings:

```
left firstName = ”John";
let text = `First Name is: ${firstName}`
```

​	<b>Note:</b> Automatic replacing of expressions with real values is called <b>string interpolation</b>.

## 20.6 HTML Templates

Example:

```
let header = "Templates Literals";
let tags = ["template literals", "javascript", "es6"];
let html = `<h2>${header}</h2><ul>`;
for (const x of tags) {
	html += `<li>${x}</li>;
}
html += `</ul>`;
```



# 21. JavaScript Numbers

​	JavaScript has only one type of number. Numbers can be written with or without decimals. Extra large or extra small numbers can be written with scientific (exponent) notation:

```
let x = 3.14;
let y = 123e-5;
```

## 21.1 JavaScript Numbers are Always 64-bit Floating Point

​	Unlike many other programming languages, JavaScript does not define different types of numbers, like integers, short, long, floating-point etc.

​	JavaScript numbers are always stored as double precision floating point numbers, following the international IEEE 754 standard. This format stores numbers in 64 bits, where the number (the fraction) is stored in bits 0 to 51, the exponent in bits 52 to 62, and the sign in bit 63:

| Value (aka Fraction/Mantissa) | Exponent          | Sign       |
| ----------------------------- | ----------------- | ---------- |
| 52 bits (0 - 51)              | 11 bits (52 - 62) | 1 bit (63) |

## 21.2 Integer Precision

​	Integers (numbers without a period or exponent notation) are accurate up to 15 digits.

```
let x = 999999999999999;	//15 digits
let y = 9999999999999999;	//y will be 10000000000000000 (1e16)
```

​	The maximum number of decimals is 17.

## 21.3 Floating Precision

​	Floating point arithmetic is <span style="color: blue">not always 100% accurate</span>:

```
let x = 0.2 + 0.1;		// 0.30000000000000004
```

​	To solve the problem above, it helps to multiply and divide:

```
let x = (0.2*10 + 0.1*10) / 10;
```

## 21.4 Adding Numbers and Strings

​	<b>Note:</b>

​	JavaScript uses the + operator for both addition and concatenation. Numbers are added, Strings are concatenated.

```
let x = 10, y = 20;
let z = x + y;			//z is a number (addition)
let a = "10", b = "20";
let c = a + b;			//c is a string (concatentation)
let m = x + a;			//m is a string
```

​	Common mistakes and right answer:

```
let z = "The result is: " + x + y;	//result is "The result is: 10 20"
let n = x + y + a;					//result is "30 10"
```

## 21.5 Numeric Strings

​	JavaScript strings can have numeric content:

```
let x = 100;
let y = "100";
```

​	JavaScript will try to convert strings to numbers in all numeric operations:

```
let z = x / y;
```

## 21.6 NaN - Not a Number

​	<span style="color: red;">NaN</span> is a JavaScript reserved word indicating that a number is not a legal number.

​	Trying to do arithmetic with a non-numeric string will result in <span style="color: red;">NaN</span>:

```
let x = 100 / "Apple";
```

​	You can use the global JavaScript function <span style="color: red;">isNaN()</span> to find out if a value is a not a number:

```
isNan(x);
```

​	Using <span style="color: red;">NaN</span> in a mathematical operation, the result will also be <span style="color: red;">NaN</span>, or might be a concatenation:

```
let x = NaN;
let y = 5;
let z = "5";
let a = x + y;	//NaN
let b = x + z;	//"NaN5"
typeof NaN;		//NaN is a number type
```

## 21.7 Infinity

​	<span style="color: red;">Infinity</span> (or <span style="color: red;">-Infinity</span>) is the value JavaScript will return if you calculate a number outside the largest possible number:

```
let myNumber = 2;
while (myNumber != Infinity) {
	myNumber = myNumber * myNumber;
}
```

​	Division by 0 (zero) also generates  <span style="color: red;">Infinity</span>:

```
let x = 2 / 0;	//Infinity
let y = -2 / 0;	//Infinity
typeof Infinity;	//Infinity is a number type
```

## 21.7 Hexadecimal

​	JavaScript interprets numeric constants as hexadecimal if they are preceded by 0x:

```
lef = x = 0xFF;
```

​	<b>Note:</b> Never write a number with a leading zero (like 07). Some JavaScript versions interpret numbers as octal.

​	By default, JavaScript display numbers as <b>base 10</b> decimals. But you can use the <span style="color: red;">toString()</span> method to output number from <b>base 2</b> to <b>base 36</b>.

​	Hexadecimal is <b>base 16</b>. Decimal is base 10 ...

```
let myNumber = 32;
myNumber.toString(36);	//w
myNumber.toString(16);	//20
myNumber.toString(8);	//40
```

## 21.8 JavaScript Numbers as Objects

​	Normally JavaScript numbers are primitive values created from literals:

```
let x = 123;
```

​	But numbers can also be defined as objects with the keyword <span style="color: red;">new</span>:

```
let y = new Number(123);
```

<b>Note:</b> As explained above, do not create Number objects.



# 22. JavaScript BigInt

​	JavaScript <span style="color: red;">BigInt</span> variables are used to store big integer values that are too bit to represented by a normal JavaScript <span style="color: red;">Number</span>.

## 22.1 Integer Accuracy

​	JavaScript integers are only accurate up to 15 digits (all numbers are stored in 64-bit floating point format IEEE 754 standard). The 64-bit floating format can safely represent integers:

Up to <b>9007199254740991<b> -> +(2^53 - 1) and 

Down to -9007199254740991 -> -(2^53 - 1). Integer values outside this range lost precision.

## 22.2 How to Create a BigInt

​	To create a <span style="color: red;">BigInt</span>, append n to the end of an integer or call <span style="color: red;">BigInt()</span>：

```
let x = 9999999999999999n;
let y = BigInt(1234567890987654321);
```

## 22.3 BigInt: A new JavaScript Datatype

​	The <span style="color: red;">typeof</span> a <span style="color: red;">BigInt</span> is "bigint":

```
let x = BigInt(1);
let type = typeof x;
```

​	<span style="color: red;">BigInt</span> is the second numeric data type in JavaScript (after <span style="color: red;">Number</span>).

## 22.4 BigInt Operators

​	Operators that can be used on a JavaScript <span style="color: red;">Number</span> can also be used on a <span style="color: red;">BigInt</span>.

<span style="color: blue; font-size: 18px;">Notes</span>

​	Arithmetic between a <span style="color: red;">BigInt</span> and a <span style="color: red;">Number</span> is not allowed (type conversion lose information).

​	Unsigned right shift (>>>) can not be done on a <span style="color: red;">BigInt</span> (it does not have a fixed width).

## 22.5 BigInt Decimals

​	A <span style="color: red;">BigInt</span> can not have decimals.

```
let x = 5n;
let y = x / 2;		//Error: cannot mix BigInt and other types.
let y = Number(x) / 2;
```

## 22.6 BigInt Hex, Octal and Binary

​	<span style="color: red;">BigInt</span> can also be written in hexadecimal, octal, or binary ontation:

```
let hex = 0x20000000003n;
let oct = 0o453400000003n;
let bin = 0b10000000000000000000001000001n;
```

## 22.7 Precision Curiosity

​	Rounding can compromise program security:

```
9007199254740992 === 9007199254740993; // is true !!!
```

## 22.8 Minimum and Maximum Safe Integers

​	ES6 added max and min properties to the Number object:

* <span style="color: red;">MAX_SAFE_INTEGER</span>
* <span style="color: red;">MIN_SAFE_INTEGER</span>

```
let x = Number.MAX_SAFE_INTEGER;
```

## 22.9 New Number Methods

​	ES6 also added 2 new methods to the Number object:

* <span style="color: red;">Number.isInteger()</span>
* <span style="color: red;">Number.isSafeInteger()</span>

### 22.9.1 The Number.isInteger() Method

​	The <span style="color: red;">Number.isInteger()</span> method returns <span style="color: red;">true</span> if the argument is an integer:

```
Number.isInteger(232);
```

### 22.9.2 The Number.isSafeInteger() Method

​	A safe integer is an integer that can be exactly represented as a double precision number.

​	The <span style="color: red;">Number.isSafeInteger()</span> method returns <span style="color: red;">true</span> if the argument is a safe integer:

```
Number.isSafeInteger(12345678901234567890);
```

<b>Note:</b> Safe integers are all integers from -(25^53 - 1) to +(25^53 - 1).



## 23. JavaScript Number Methods

## 23.1 JavaScript Number Methods

​	These <b>number methods</b> can be used on all JavaScript numbers:

| Method          | Description                                        |
| --------------- | -------------------------------------------------- |
| toSting()       | Returns a number as a string                       |
| toExponential() | Returns a number written in exponential notaion    |
| toFixed()       | Returns a number written with a number of decimals |
| toPrecisio()    | Returns a number written with a specified lenght   |
| ValueOf()       | Returns a number as a number                       |

## 23.2 The toString() Method

​	The <span style="color: red;">toString()</span> method returns a number as a string.

​	All number methods can be used on any type of numbers (literal, variables, or expressions):

```
let x = 123;
x.toString();
(123).toString();
(100 + 23).toString();	//"123"
```

## 23.3 The toExponential() Method

​	<span style="color: red;">toExponential()</span> returns a string, with a number rounded and written using exponential notation.

​	A parameter defines the number of characters behind the decimal point:

```
let x = 9.656;
x.toExponential();	//9.656e+0 (The parameter is optional. If you don't specify it, JavaScript will not round the number)
x.toExponential(2);	//9.66e+0
x.toExponential(4);	//9.6560e+0
```

## 23.4 The toFixed() Method

​	<span style="color: red;">toFixed()</span> returns a string, with the number written with a specified number of decimals:

```
let x = 9.656;
x.toFixed(0):	//10
x.toFixed(2);	//9.66
x.toFixed(4);	//9.6560
```

## 23.5 The toPrecision() Method

​	<span style="color: red;">toPrecision()</span> returns a string, with a number written with a specified length:

```
let x = 9.656;
x.toPrecision();	//9.656
x.toPrecision(2);	//9.7
x.toPrecision(4);	//9.656
```

## 23.6 The valueOf() Method

​	<span style="color: red;">valueOf()</span> returns a number as a number

```
let x = 123;
x.valueOf();
(123).valueOf();		//123
(100 + 23).valueOf();	//123
```

​	In JavaScript, a number can be a primitive value (typeof = number) or an object (typefo = object). The <span style="color: red;">valueOf()</span> method is used internally in JavaScript to convert Number objects to primitive values. There is no reason to use it in your code.

<b>Note:</b> All JavaScript data types have a <span style="color: red;">valueOf()</span> and a <span style="color: red;">toString()</span> method.

## 23.7 Converting Variables to Numbers

​	There are 3 JavaScript methods that can be used to convert a variable to a number:

| Method       | Description                                             |
| ------------ | ------------------------------------------------------- |
| Number()     | Returns a number converted from its argument            |
| parseFloat() | Parses its argument and returns a floating point number |
| parseInt()   | Parses its argument and returns a whole number          |

<b>Note:</b> The methods above are not <b>number</b> methods. They are <b>global JavaScript methods.

## 23.8 The Number() Method

​	The <span style="color: red;">Number()</span> method can be used to convert JavaScript variables to numbers:

```
Number(true);		//1
Number("10");		//10
Number("  10");		//10
Number("10.33");	//10
Number("10 30");	//cannot be converted, NaN
Number("10,33");	//NaN
Number("John");		//NaN
```

## 23.9 The Number() Method Used on Dates

​	<span style="color: red;">Number()</span> can also convert a date to a number.

```
Number(new Date("1970-01-01"));	//0
Number(new Date("1970-01-02"));	86400000
```

​	<b>Note:</b> The <span style="color: red;">Date()</span> method returns the number of milliseconds (timestamp) since 1.1.1970.

## 23.10 The parseInt() Method

​	<span style="color: red;">parseInt()</span> parses a string and returns a whole number. Spaces are allowed. Only the first number is returned:

```
parseInt("-10");		//-10
parseInt("-10.33");		//-10
parseInt("10 6");		//10
parseInt("10 years");	//10
parserInt("years 10");	//NaN
```

## 23.11 The parseFloat() Method

​	<span style="color: red;">parseFloat()</span> parses a string and returns a number. Spaces are allowed. Only the first number is returned:

```
parseFloat("10");		//10
parseFloat("10.33");	//10.33
parseFloat("10 6");		//10
parseFloat("10 years");	//10
parseFloat("years 10");	//NaN
```

## 23.12 Number Object Methods

​	These <b>object methods</b> belong to the <b>Number</b> object:

| Method                 | Description                                    |
| :--------------------- | :--------------------------------------------- |
| Number.isInteger()     | Returns true if the argument is an integer     |
| Number.isSafeInteger() | Returns true if the argument is a safe integer |
| Number.parseFloat()    | Converts a string to a number                  |
| Number.parseInt()      | Converts a string to a whole number            |

<span style="font-size: 20px;">Number Methods Cannot be Used on Variables</span>

​	The number methods above belong to the JavaScript <b>Number Object</b>.

​	These methods can only be accessed like <span style="color: red;">Number.isInteger()</span>.

​	Using X.inInteger() where X is a variable, will result in an error:

<span style="color: red;">TypeError X.inInteger is not a function</span>.

### 23.12.1 The Number.isInteger() Method

### 23.12.2 The Number.isSafeInteger() Method

### 23.12.3 The Number.parseFloat() Method

### 23.12.4 The Number.parseInt() Method

```
Number.isInteger(10);							//true
Number.isSafeInteger(123214329403290452309);	//false
Number.parseFloat("12 20 30");					//10
Number.parseInt("10 years");					//10
Number.parseInt("years 10");					//NaN
```

<b>Note:</b> The <b>Number</b> methods <span style="color: red;">Number.parstInt()</span> and <span style="color: red;">Number.parseFloat()</span> are the same as the <b>Global</b> methods <span style="color: red;">parseInt()</span> and <span style="color: red;">parseFloat()</span>. The different is that one are type method, and one are global method. The purpose is modularization of globals (to make it easier to use the same JavaScript code outside the browser).



# 24. JavaScript Number Properties

| Property          | Description                                                  |
| ----------------- | ------------------------------------------------------------ |
| EPSILON           | The different between 1 and the smallest number > 1 (floating point number). |
| MAX_VALUE         | The largest number possible in JavaScript                    |
| MIN_VALUE         | The smallest number possible in JavaScript                   |
| MAX_SAFE_INTEGER  | The maximum safe integer (2^53 - 1)                          |
| MIN_SAFE_INTEGER  | The minimum safe integer -(2^53 - 1)                         |
| POSITIVE_INFINITY | Infinity (returned on overflow)                              |
| NEGATIVE_INFINITY | Negative infinity (returned on overflow)                     |
| NaN               | A "Not-a-Number" value                                       |

## 24.1 JavaScript EPSILON

​	<span style="color: red;">Number.EPSILON</span> is the difference between the smallest floating point number greater than 1 and 1.

```
let x = Number.EPSILON;	//2.220446049250313e-16
```

## 24.2 JavaScript MAX_VALUE

​	<span style="color: red;">Number.MAX_VALUE</span> is a constant representing the largest possible number in JavaScript.

```
let x = Number.MAX_VALUE;
```

<span style="font-size: 20px;">Number Properties Cannot be Used on Variables</span>

​	Number properties belong to the JavaScript <b>Number Object</b>.

​	These properties can only be accessed as <span style="color: red;">Number.MAX_VALUE</span>.

​	Using x.MAX_VALUE, where x is a variable or a value, will return <span style="color: red;">undefined</span>:

```
let x = 6;
x.MAX_VALUE;
```

## 24.3 JavaScript MIN_VALUE

<span style="color: red;">Number.MIN_VALUE</span> is a constant representing the lowest possible number in JavaScript.

## 24.4 JavaScript MAX_SAFE_INTEGER & MIN_SAFE_INTEGER

​	<span style="color: red;">Number.MAX_SAFE_INTEGER</span> represents the maximum safe integer in JavaScript, <span style="color: red;">Number.MIN_SAFE_INTEGER</span> represents the minimum safe integer in JavaScript.

<span style="color: red;">Number.MAX_SAFE_INTEGER</span> is (2^53 - 1), <span style="color: red;">Number.MIN_SAFE_INTEGER</span> is -(2^53 - 1).

## 24.5 JavaScript POSITIVE_INFINITY

```
let x = Number.POSITIVE_INFINITY;
```

​	<span style="color: red;">POSITIVE_INFINITY</span> is returned on overflow:

```
let x = 1 / 0;
```

## 24.6 JavaScript NEGATIVE_INFINITY

```
let x = Number.NEGATIVE_INFINITY;
```

​	<span style="color: red;">NEGATIVE_INFINITY</span> is returned on overflow:

```
let x = -1 / 0;
```

## 24.7 JavaScript NaN - Not a Number

​	<span style="color: red;">NaN</span> is a JavaScript reserved word for a number that is not a legal number.

```
let x = Number.NaN;
```

​	Trying to do arithmetic with a non-numeric string will result in <span style="color: red;">NaN</span>:

```
let x = 100 / "Apple";
```



# 25. JavaScript Arrays

## 25.1 Why Use Arrays

​	If you have a list of items (a list of car names, for example), storing the cars in single variables could look like this:

```
let car1 = "Saab";
let car2 = "Volvo";
let car3 = "BMW";
```

​	However, what if you want to loop through the cars and find a specific one? And what if you had not 3 cars, but 300?!

​	The solution is an array! An array can hold many values under a single name, and you can access the values by referring to an index number.

## 25.2 Creating an Array

​	Using an array literal is the easiest way to create a JavaScript Array. Syntax:

```
const array_name = [item1, item2, ...];
```

<b>Note:</b> It is common practice to declare arrays with the <span style="color: red;">const</span> keyword.

​	You can also create an array, and then provide the elements:

```
const cars = [];
cars[0] = "Saab";
cars[1] = "Volvo";
cars[2] = "BMW";
```

## 25.3 Using the JavaScript Keyword new

​	The following example also creates an Array, and assign values to it:

```
const cars new Array("Saab", "Volvo", "BMW");
```

## 25.4 Accessing Array Elements

​	You access an array element by referring to the <b>index number</b>.

```
const cars = ["Saab", "Volvo", "BMW"];
let car = cars[0];
```

## 25.5 Changing an Array Element

​	This statement changes the value of the first element in <span style="color: red;">cars</span>:

```
cars[0] = "Opel";
```

## 25.6 Access the Full Array

​	With JavaScript, the full array can be accessed by referring to the array name:

```
document.getElementById("demo").innerHTML = cars;
```

## 25.7 Arrays are Objects

​	Arrays are a special type of objects. The <span style="color: red;">typeof</span> operator in JavaScript returns "object" for arrays. But JavaScript arrays are best described as arrays. Arrays use <b>numbers</b> to access its "elements". In this example, <span style="color: red;">person[0]</span> returns John:

```
const person = ["John", "Doe", 46];	//?
```

​	On the other hand, objects use <b>names</b> to access its "members". In this example, <span style="color: red;">person.firstName</span> returns John:

```
const person = {first:"John", lastName:"Doe", age:46};
```

## 25.8 Array Elements Can Be Objects

​	Arrays are special kinds of objects. Because of this, you can have variables of diffreent types in the same Array:

```
myArray[0] = Date.now;		//object
myArray[1] = myFunction;	//function
myArray[2] = myCars;		//array
```

## 25.9 Array Properties and Methods

​	The real strength of JavaScript arrays are the built-in array properties and methods:

```
cars.length;	//Returns the number of elements
cars.sort();	//Sorts the array
```

## 25.10 Looping Array Elements

​	One way to loop through an array, is using a <span style="color: red;">for</span> loop:

```
const fruits = ["Banana", "Orange", "Apple", "Mango"];
let fLen = fruits.length;
let text = "<ul>";
for (let i = 0; i < fLen; i++) {
	text += "<li>" + fruits[i] + "</li>";
}
text += "</ul>";
```

​	You can also use the <span style="color: red;">Array.forEach()</span> function:

```
let text = "<ul>";
fruits.forEach(myFunction);
text += "</ul>";

function myFunction(value) {
	text += "<li>" + value + "</li>";
}
```

## 25.11 Adding Array Elements

​	The easiest way to add a new element to an array is using the <span style="color: red;">push()</span> method:

```
fruits.push("Lemon");
```

​	New element can also be added to an array using the <span style="color: red;">length</span> property:

```
fruits[fruits.length] = "Lemon";
```

<b>Note:</b> Adding elements with high indexes can create undefined "holes" in an array.

## 25.12 Associative Arrays

​	Many programming languages support arrays with named indexes.

​	Arrays with named indexes are called associative arrays (or hashes).

​	JavaScript does <b>not</b> support arrays with named indexes, in JavaScript, <b>arrays</b> always usr <b>numbered indexes</b>.

```
const person = [];
person[0] = "John";
person.length;
person[0];
```

​	<b>Note:</b> If you use named indexes, JavaScript will redefine the array to an object. After that, some array methods and properties will produce <b>incorrect results</b>.

```
const person = [];
person["firstName"] = "John";
person.length;				//Will return 0
person[0];					//Will return undefined
```

## 25.13 The Difference Between Arrays and Objects

​	In JavaScript, <b>arrays</b> use <b>numbered indexes</b>.

​	In JavaScript, <b>objects</b> use <b>named indexes</b>.

## 25.14 When to Use Arrays. When to use Objects.

* JavaScript does not support associative arrays.

* You should use <b>objects</b> when you want the element names to be <b>strings (text)</b>.
* You should use <b>arrays</b> when you want the element names to be <b>numbers</b>.

## 25.15 JavaScript new Array()

​	JavaScript has a built-in array constructor <span style="color: red;">new Array()</span>. But you can safely use <span style="color: red;">[ ]</span> instead. The <span style="color: red;">new</span> keyword may produce some unexpected results:

```
const points = new Array(40, 100, 1);	//create an array with three elements
const points = new Array(40);			//Create an array with one "????" elements, in fact are 40 undefined elements
points[0];			//undefined
```

## 25.16 How to Recognize an Array

​	A common question is: How do I know if a variable is an array?

​	The problem is that the JavaScript operator <span style="color: red;">typeof</span> returns "<span style="color: red;">object</span>".

### 25.16.1 Array.isArray()

​	To solve this problem, ECMAScript 5 defined a new method <span style="color: red;">Array.isArray()</span>:

```
fruits.isArray(fruits);
```

### 25.16.2 instanceof

​	The <span style="color: red;">instanceof()</span> operator returns true if an object is created by a given constructor:

```
const fruits = ["Banana", "Orange", "Apple"];
fruits instanceof Array;
```



# 26. JavaScript Array Methods

## 26.1 Converting Arrays to Strings

​	The JavaScript method <span style="color: red;">toString()</span> converts an array to a string of (comma separated) array values.

```
document.getElementById("demo").innerHTML = fruits.toString();
```

​	The <span style="color: red;">join()</span> method also joins all array elements into a string. It behaves just like <span style="color: red;">toString()</span>, but in addition you can specify the separator:

```
document.getElementById("demo").innerHTML = fruits.join(" * ");
```

## 26.2 Popping and Pushing

​	When you work with arrays, it is easy to remove elements and add new elements.

​	This is what popping and pushing is:

​	Popping items <b>out</b> of an array, or pushing items <b>into</b> an array.

### 26.2.1 Array pop()

​	The <span style="color: red;">pop()</span> method removes the last element form an array:

```
let fruit = fruits.pop();
```

​	The <span style="color: red;">pop()</span> method returns the value that was "popped out";

## 26.2.2 Array push()

​	The <span style="color: red;">push()</span> method adds a new element to an array (at the end):

```
let length = fruist.push("Kiwi");
```

​	The <span style="color: red;">push()</span> method returns the new array length.

## 26.3 Shifting Elements

​	Shifting is equivalent to popping, but working on the first element instead of the last.

### 26.3.1 Array shift()

​		The <span style="color: red;">shift()</span> method removes the first array element and "shifts" all other elements to a lower index, and returns the value that was "shifted out":

```
let fruit = fruits.shift();
```

### 26.3.2 Array unshift()

​	The <span style="color: red;">unshift()</span> method adds a new element to an array (at the beginning), and "unshifts" older elements, <span style="color: red;">unshift()</span> returns the new array length:

```
fruits.unshift("Lemon");
```

## 26.4 Changing Elements

​	Array elements are accessed using their <b>index number</b>.

### 26.4.1 Array length

​	The <span style="color: red;">length</span> property provides an easy way to append a new element to an array:

```
fruits[fruits.length] = "Kiwi";
```

### 26.4.2 Array delete()

<b>Note:</b> Array elements can be deleted using the JavaScript operator <span style="color: red;">delete</span>. Using <span style="color: red;">delete</span> leaves <span style="color: red;">undefined</span> holes in the array. Use pop() or shift() instead.

```
delete fruits[0];		
```

### 26.4.3 Merging (Concatenating) Arrays

​	The <span style="color: red;">concat()</span> method creates a new array by merging existing arrays:

```
const myGirls = ["Cecilie", "Lone"];
const myBoys = ["Emil", "Tobias", "Linus"];
const myChildren = myGrils.concat(myBoys);
```

​	The <span style="color: red;">concat()</span> method (distinguish <span style="color:blue;">operator, function, property, method</span>) can take any number of array arguments, and can also take string as arguments:

```
const myChildren = arr1.concat(arr2, arr3);
const myRelative = arr1.concat("Peter");
```

### 26.4.4 Flattening an Array

​	Flattening an array is the process of reducing the dimensionality of an array.

​	Thee flat() method creates a new array with sub-array elements concatenated to a specified depth:

```
const myArr = [[1,2],[3,4],[5,6]];
const newArr = myArr.flat();	//[1,2,3,4,5,6];
```

## 26.5 Splicing and Slicing Arrays

​	The <span style="color: red;">splice()</span> method adds new items to an array. The <span style="color: red;">slice()</span> method slices out a piece of an array.

### 26.5.1 Array splice()

```
fruits.splic(2, 0, "Lemon", "Kiwi");
```

​	The first parameter (2) defines the position <b>where</b> new elements should be <b>added</b> (spliced in); The second parameter (0) defines <b>how many</b> elements should be <b>removed</b>; The rest of the parameters define the new elements to be <b>added</b>.

​	The <span style="color: red;">splice()</span> method returns an array with the deleted items. Practice it.

## 26.5.2 Using splice() to Remove Elements

​	With clever parameter setting, you can use <span style="color: red;">splice()</span> to remove elements without leaving "holes" is the array:

```
fruits.splice(0, 1);
```

### 26.5.3 Array slice()

​	The <span style="color: red;">slice()</span> method slices out a piece of an array into a new array. This example slices out a part of an array starting from array element 1:

```
const citrus = fruits.slice(1);
```

<b>Note:</b> The <span style="color: red;">slice()</span> method creates a new array, and does not remove any elements from the source array.

​	The method can take two arguments like <span style="color: red;">slice(1, 3)</span>. The method then selects elements from the start argument, and up to (but not including) the end argument. If the end argument is omitted, the <span style="color: red;">slice()</span> method slices out the rest of the array.

## 26.6 Automatic toString()

​	JavaScript automatically converts an array to a comma separated string when a primitive value is expected. This is always the case when you try to output an array:

```
document.getElementById("demo").innerHTML = fruits.toString();
document.getElementById("demo").innerHTML = fruist;
```

## 26.7 Finding Max and Min Values in an Array

​	There are no built-in functions for finding the highest or lowest value in a JavaScript array.

## 26.8 Sorting Arrays

​	Sorting arrays are covered in the next chapter of this tutorial.



# 27. JavaScript Sorting Arrays

## 27.1 Sorting an Array

​	The <span style="color: red;">sort()</span> method sorts an array alphabetically (don't create a new array!):

```
const fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.sort();	//fruits be: Apple,Banana,Mango,Orange
```

## 27.2 Reversing an Array

​	The <span style="color: red;">reverse()</span> method reverses the elements in an array.

```
fruits.sort().reverse();	//new fruits
```

## 27.3 Numeric Sort

​	By default, the <span style="color: red;">sort()</span> function sorts values as <b>strings</b>.

​	This works well for strings, however, if numbers are stored as strings, "25" is bigger than "100", because "2" is bigger than "1". You can fix this by providing a <b>compare function</b>:

```
<h3>JavaScript Sorting Arrays:</h3>
<p id="demo10-1"></p>
<p id="demo10-2"></p>
<!-- script -->
const points10 = [10, 100, 1, 5, 4, 24, 32];
document.getElementById("demo10-1").innerHTML = points10;
points10.sort(function(a, b){return a - b;});
document.getElementById("demo10-2").innerHTML = points10;
```

## 27.4 The Compare Function

​	The purpose of the compare function is to define an alternative sort order. The compare function should return a negative, zero, or positive value, depending on the arguments.

​	When the <span style="color: red;">sort()</span> function compares two values, it sends the values to the compare function, and sorts the values according to the returned value. For example, if the result is negative, above <span style="color: red;">a</span> is sorted before <span style="color: red;">b</span>.

## 27.5 Sorting an Array in Random Order (*)

```
const points = [40, 100, 2, 4, 84, 99, 20];
points.sort(function(){return 0.5 - Math.random();});
```

## 27.6 The Fisher Yates Method

​	*The above example, array.sort(), is not accurate. It will favor some numbers over the others.

​	The most popular correct method, is called the Fisher Yates shuffle, and was introduced in data science as early as 1938! In JavaScript the method can be translated to this:

```
for (let i = points.length - 1; i > 0; i--) {
	let j = Math.floor(Math.random() * (i+1));
	let k = points[i];
	points[i] = points[j];
	points[j] = k;
}
```

## 27.7 Find the Highest (or Lowest) Array Value

​	There are no built-in functions for finding the max or min value in an array.

​	However, after you have stored an array, you can use the index to obtain the highest and lowest values. Sorting ascending:

```
points.sort(function(a, b){return a - b;});
```

​	Sorting descending:

```
points.sort(function(a, b){return b - a;});
```

<b>Note:</b> Sorting a whole array is a very inefficient method if you only want to find the highest (or lowest) value.

### 27.7.1 Using Math.max() on an Array

​	You can use <span style="color: red;">Math.min.apply</span> to find the highest number in an array:

```
function myArrayMax(arr) {
	return Math.min.apply(null, arr);
}
```

​	<b>Note:</b> <span style="color: red;">Math.min.apply(null, [1, 2, 3])</span> is equivalent to <span style="color: red;">Math.min(1, 2, 3)</span>.

### 27.7.2 My Min / Max JavaScript Methods

​	The fastest solution is to use a "home made" method.

​	This function loops through an array comparing each value with the highest value found:

```
function myArrayMax(arr) {
	let len = arr.length;
	let max = -Infinity;
	while (len--) {
		if (arr[len] > man) {
			max = arr[len];
		}
	}
	return max;
}
```

​	And lowest value:

```
function myArrayMin(arr) {
	let len = arr.length;
	len min = Infinity;
	while (len--) {
		if (arr[len] < min) {
			min = arr[len];
		}
	}
	return min;
}
```

## 27.8 Sorting Object Arrays

​	JavaScript arrays often contain objects:

```
const car = [
	{type:"Volvo", year:2016},
	{type:"Saab", year:2001},
	{type:"BMW", year:2010}
];
```

​	Even if objects have properties of different data types, the <span style="color: red;">sort()</span> method can be used to sort the array. The solution is to write a compare function to compare the property values:

```
cars.sort(function(a, b){return a.year - b.year;});
```

​	Comparing string properties is a little more complex:

```
cars.sort(function(a, b) {
	let x = a.type.toLowerCase();
	let y = b.type.toLowerCase();
	if(x < y) {return -1;}
	if(x > y) {return 1;}
	return 0;
});
```

## 27.9 Stable Array sort()

​	ES2019 <b>revised</b> the Array <span style="color: red;">sort()</span> method.

​	Before 2019, the specification allowed unstable string algorithm such as QuickSort. After ES2019, browsers must use a stable sorting algorithm:

​	When sorting elements on a value, the elements must keep their relative position to other elements with the same value:

```
const myArr = [
	{name:"Honor 6x", price:1000},
	{name: "Mate 5", price: 1000},
	{name: "Xiaomi 2", price: 1000},
	{name: "Vivo", price: 1100},
	{name: "Apple", price: 1100},
	{name: "Oppo", price: 1100}
];
```

​	In the example above, when sorting on price, the result is not allowed to come out with the names in an other relative position like this:

```
Mate 5 		1000
Honor 6x 	1000
Xiaomi 2 	1000
Vivo		1100
Oppo		1100
Apple		1100
```



# 28. JavaScript Array Iteration

## 28.1 JavaScript Array forEach()

​	The <span style="color: red;">forEach()</span> method calls a function (a callback function) once for each array element:

```
const numbers = [34, 45, 10, 29, 16, 63];
let txt = "";
number.forEach(myFunction);
function myFunction(value, index, array) {
	txt += value + "<br>";
}
```

​	Note that the function takes 2 arguments:

* The item value
* The item index
* The array itself

​	The example above uses only the value parameter. The example can be rewritten to:

```
function myFunction(value) {
	txt += value + "<br>";
}
```

## 28.2 Array map()

​	The <span style="color: red;">map()</span> method creates a new array by performing a function on each array element. The <span style="color: red;">map()</span> method does not execute the function for array elements without values. The <span style="color: red;">map()</span> method also does not change the original array!

```
const numbers1 = [43, 92, 41, 52, 60];
const numbers2 = numbers1.map(myFunction);
/*When a callback function uses only the value parameter, the index
	and array parameters can be omitted. */
function myFunction(value, index, array) {
	return value * 2;
}
```

## 28.3 Array flatMap()

​	ES2019 added the array <span style="color: red;">flatMap()</span> method to JS. The <span style="color: red;">flatMap()</span> method first maps all elements of an array and then creates a new array by flattening the array.

```
const myArr = [1, 2, 3, 4, 5 ,6];
const newArr = myArr.flatMap((x) => x * 2);
```

## 28.4 Array filter()

​	The <span style="color: red;">filter()</span> method creates a new array with array elements that pass a test. This example creates a new array from elements with a value larger than 18:

```
const numbers = [12, 45, 78, 30, 20, 17];
const over18 = number.filter(myFunction);
function myFunction(value, index, array) {
	return value >= 18;
}
```

## 28.5 Array reduce()

​	The <span style="color: red;">reduce()</span> method runs a function on each array element to produce (reduce it to) a single value. The <span style="color: red;">reduce()</span> method works from left-to-right in the array. See also <span style="color: red;">reduceRight()</span>.

​	<b>Note:</b> The <span style="color: red;">reduce()</span> method does not reduce the original array.

```
const number = [1, 2];
let sum = numbers.reduce(myFunction);
function myFunction(total, value, index, array) {
	return total + value;
}
```

​	Note that the function takes 4 arguments, and the last 2 parameters can be omitted.

​	The <span style="color: red;">reduce()</span> method can accept an initial value:

```
let sum = numbers.reduce(myFunction, 100);
```

## 28.6 Array reduceRight()

​	This method works from right-to-left in the array.

## 28.7 Array every()

​	The <span style="color: red;">every()</span> method checks if all array values pass a test. This example return false:

```
const ages = [18, 28, 39];
let allOver18 = ages.every(myFunction);
function myFunction(value, index, array) {	//arguments can be omitted
	return value > 18;
}
```

## 28.8 Array some()

​	The <span style="color: red;">some()</span> method checks if some array values pass a test. The features are similar to above functions:

```
let someOver18 = ages.some(myFunction);
function myFunction(value, index, array) {
	return value > 18;
}
```

## 28.9 Array indexOf()

​	The <span style="color: red;">indexOf()</span> method searches an array for an element value and returns its position:

```
const fruits = ["Apple", "Orange", "Apple", "Kiwi"];
let position = fruits.indexOf("Apple") + 1;		//1
```

​	<b>Syntax</b>

`array.indexOf(item, start)`

​	<span style="color: red;">Array.indexOf()</span> return -1 if the item is not found, if the item present more than one, it returns the position of the first occurrence.

## 28.10 Array lastIndexOf()

​	<span style="color: red;">Array.lastIndexOf()</span> returns the position of the last occurrence of the specified element.

`array.lastIndexOf(item, start);`

## 28.11 Array find()

​	The <span style="color: red;">find()</span> method returns the value of the first array element that passed a test function.

```
const numbers = [3, 45, 29];
let first = numbers.find(myFunction);
function myFunction(value, index, array) {
	return value > 18;
}
```

## 28.12 Array findIndex()

​	The <span style="color: red;">findIndex()</span> method returns the index of the first array element that passes a test function. Similar to find().

## 28.13 Array from()

​	The <span style="color: red;">Array.form()0</span> method returns an Array object from an object with a length property or any iterable object.

```
Array.from("ABCD");	//returns A,B,C,D
```

## 28.14 Array keys()

​	The <span style="color: red;">Array.keys()</span> method returns an Array Iterator object with the keys of an array:

```
const fruits = ["Banana", "Orange", "Mango", "Kiwi"];
const keys = fruits.keys();		//0, 1, 2, 3
for (let x of keys) {	
	text += x + "<br>";
}
```

## 28.15 Array entries()

​	The <span style="color: red;">entires()</span> method returns an Array Iterator object with key:value pairs:

```
const fruits = ["Banana", "Orange", "Mango", "Kiwi"];
const f = fruits.entries();		//0,Banana 1,Orange 2,Mango 3,Kiwi
for (let x of f) {	
	doceument.getElementById("deom").innerHTML += x;
}
```

​	The above returns:

[0, "Banana"]

[1, "Orange"]

[2, "Mango"]

[3, "Kiwi"]

## 28.16 Array includes()

​	ECMAScript 2016 introduced <span style="color: red;">Array.includes()</span> to arrays. This allow us to check if an element is present in an array (including NaN, unlike indexOf)

```
const fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.includes("Kiwi");
```

## 28.17 Array Spred (...)

​	The ... operator expands an iterable (like an array) into more elements:

```
const q1 = ["Jan", "Feb", "Mar"];
const q2 = ["Apr", "May", "Jun"];
const q3 = ["Jul", "Aug", "Sep"];
const q4 = ["Oct", "Nov", "May"];
const year = [...q1, ...q2, ...q3, ...q4];
```



# 29. JavaScript Array Const

## 29.1 ECMAScript 2015 (ES6)

​	In 2015, JavaScript introduced an important new keyword: <span style="color: red;">const</span>.

​	It has become a common practice to declare array using <span style="color: red;">const</span>.

## 29.2 Cannot be Reassigned

​	An array declared with <span style="color: red;">const</span> cannot be reassigned:

```
const cars = ["Saab", "Volvo", "BMW"];
cars = ["Toyota", "Volvo", "Audi"];		//ERROR
```

## 29.3 Arrays are Not Constants

​	The keyword <span style="color: red;">const</span> is a little misleading. It does NOT define a constant array, it defines a constant reference to an array.

​	Because of this, we can still change the elements of a constant array.

## 29.4 Elements Can be Reassigned

​	You can change the elements of a constant array:

```;
const cars = ["Saab", "Volvo", "BMW"];
cars[0] = "Toyota";
cars.push("Audi");
```

## 29.5 Assigned when Declared

​	JavaScript <span style="color: red;">const</span> variables must be assigned a value when they are declared.

​	Meaning: An array declared with <span style="color: red;">const</span> must be initialized when it is declared.

```
const cars;		//not work
cars = [...];
```

​	On the other hand, arrays declared with <span style="color: red;">var</span> can be initialized at any time, and can even <span style="color:blue;">use the array before it is declared</span>:

```
cars = ["Saab", "Volvo", "BMW"];
var cars;
```

## 29.6 Const Block Scope

​	An array declared with <span style="color: red;">const</span> has <b>Block Scope</b>.

​	An array declared in a block is not the same as an array declared outside the block:

```
const cars = ["Saab", "Volvo"];		//cars[0] is "Saab"
{
	const cars = ["Toyota", "BMW"];	//cars[0] is "Toyota"
}
//cars[0] is "Saab"
```

​	On the other hand, an array declared with <span style="color: red;">var</span> does not have block scope:

```
var cars = ["Saab", "Volvo"];		//cars[0] is "Saab"
{
	var cars = ["Toyota", "BMW"];	//cars[0] is "Toyota"
}
//cars[0] is "Toyota"
```

## 29.7 Redeclaring Arrays

​	Redeclaring an array declared with <span style="color: red;">var</span> is allowed anywhere in a program:

```
var cars = [...];	//Allowed
var cars = [...];	//Allowed
cars = [...];		//Allowed
```

​	Redeclaring or reassigning an array to <span style="color: red;">const</span>, in the same scope, or in the same block, is not allowed.

```
var cars = ["Volvo", "BMW"];	//Allowed
const cars = ["Volvo", "BMW"];	//Not allowed
{
	var cars = ["Volvo", "BMW"];	//Allowed (or const)
	const cars = ["Volvo", "BMW"];	//Not allowed
}
```



# 30. JavaScript Date Objects

Examples:

```
const d = new Date();
const d = new Date("2023-04-13");
```

<b>Note:</b> 

​	Date objects are static. The "clock" is not "running".

​	The computer clock is ticking, date objects are not.

## 30.1 Date Output

​	By default, JavaScript will use the browser's time zone and display a date as a full text string.

## 30.2 Creating Date Objects

​	Date objects are created with the <span style="color: red;">new Date()</span> constructor. There are <b>9 ways</b> to create a new date object:

```
new Date();
new Date(date string);
new Date(year, month);
new Date(year, month, day);
new Date(year, month, day, hours);
new Date(year, month, day, hours, minutes);
new Date(year, month, day, hours, minutes, seconds);
new Date(year, month, day, hours, minutes, seconds, milliseconds);
new Date(milliseconds);
```

### 30.2.1 new Date()

​	<span style="color: red;">new Date()</span> creates a date object with the <b>curreent date and time</b>:

```
const d = new Date();
```

### 30.2.2 new Date(date string)

​	<span style="color: red;">new Date(date string)</span> creates a date object form a <b>date string</b>:

```
const d = new Date("October 13, 2014 11:13:00");
const d = neww Date("2022-01-02");
```

### 30.2.3 new Date(year, month, ....)

​	<span style="color: red;">new Date(year, month, ...)</span> creates a date object with a <b>specified date and time</b>.

​	7 numbers specify year, month, day, hour, minute, second, and millisecond:

```
const d = new Date(2011, 11, 11, 11, 11, 11, 0);
```

<b>Note:</b> JavaScript counts months from <b>0</b> to <b>11</b>, January is 0, December is 11.

​	Specifying a month/day higher than max, will not result in an error <span style="color:blue;">but add the overflow to the next year/month</span>:

```
const d = Date(2018, 15, 24, 10, 33, 30)	//Wed Apr 24 2019 10::33:30
```

## 30.3 Previous Century

​	One and two digit years will be interpreted as 19**:

```
const d = new Date(99, 9, 9);
```

<span style="font-size: 20px;"> JS Stores Dates as Milliseconds</span>

​	JS stores dates as number of milliseconds since January 01, 1970.

​	<b>Zero time is January 01, 1970 00:00:00 UTC</b>.

## 30.4 new Date(milliseconds)

​	<span style="color: red;">new Date(milliseconds)</span> create a new date object as <b>milliseconds</b> plus zero time.

```
const d = neww Date(-100000000000);
```

```
<h3>JavaScript Dates:</b>
<p id="demo12"></p>
<!-- The result is: Fri May 05 1911 00:00:00 GMT+0800 (中国标准时间), why? -->
const date = new Date(013, 4, 5);
document.getElementById("demo12").innerHTML = date;
```

## 30.5 Date Methods

​	When a date object is created, a number of <b>methods</b> allow you to operate on it.

​	Date methods allow you to get and set the year, month, day, hour, minute, second, and millisecond of date objects, using either local time or UTC (universal, or GMT) time.

## 30.6 Displaying Dates

​	JavaScript by default output dates in full text string format:

`Thu Apr 13 2023 20:19:20 GMT+0800 (中国标准时间)`

​	When you display a date object in HTML, it is automatically converted to a sting, with the <span style="color: red;">toString()</span> method.

```
const d = new Date();
d.toString();
```

​	The <span style="color: red;">toDateString()</span> method converts a date to a more readable format:

```
const d = new Date();
d.toDateString();	//Thu Apr 13 2023
```

​	The <span style="color: red;">toUTCString()</span> method converts a date to a string using the UTC standard:

```
cosnt d = new Date();
d.toUTCString();	//Thu, 13 Apr 2023 12:48:51 GMT
```

​	The <span style="color: red;">toISOString()</span> method converts a date to a string using the ISO standard:

```
const d = new Date();
d.toISOString();	//2023-04-13T12:50:19.420Z
```



# 31. JavaScript Date Formats

## 31.1 Date Input

​	There are generally 3 types of JS date input formats:

| Type       | Example                                   |
| ---------- | ----------------------------------------- |
| ISO Date   | "2015-03-25" (The International Standard) |
| Short Date | "03/25/2015"                              |
| Long Date  | "Mar 25 2015" or "25 Mar 2015"            |

## 31.2 Date Output

​	Independent of input format, JS will (by default) output dates in full text string format.

## 31.3 ISO Dates

​	ISO 8061 is the international standard for the representation of dates and times. The ISO 8601 syntax (YYYY-MM-DD) is also the preferred JS date format:

```
const d = new Date("2015-09-09");
```

<b>Note:</b> The computed date will be relative to your time zone.

## 31.4 ISO Dates (Year and Month)

​	ISO dates can be written without specifying the day (YYYY-MM):

```
const d = new Date("2033-04");
```

​	It can also be written without month and day.

## 31.5 ISO Dates (Date-Time)

​	ISO dates can be written with added hours, minutes, and seconds (YYYY-MM-DDTHH:MM:SSZ):

```
const d = new Date("2015-04-03T12:21:35Z");
```

​	Date and time is separated with a capital T. UTC time is defined with a capital letter Z. If you want to modify the time relative to UTC, remove the Z and add +HH:MM or -HH:MM instead:

```
const d = new Date("2015-04-03T12:00:00-06:30");
```

<b>Note:</b> UTC (Universal Time Coordinated) is the same as GMT (Greenwich Mean Time).

## 31.6 Time Zones

​	When setting a date, without specifying the time zone, JS will use the browser's time zone.

​	In other words: If a date/time is created in GMT, the date/time will be converted to CDT (Central US Daylight Time) if a user browses from central US.

<span style="font-size:20px;">WARNINGS!</span>

	1. In some browsers, months or days with no leading zeroes may produce an error:

```
const d = new Date("2015-3-4");
```

2. The behavior of "YYYY/MM/DD" is undefined, some browsers will try to guess the format, some will return NaN:

```;
cosnt d = new Date("2015/03/04");
```

3. The behavior of "DD-MM-YYYY" is also undefined:

```
const d = new Date("12-03-2015");
```

## 31.7 Long Dates

```
const d = new Date("Mar 25 2015");
const d = new Date("25 Mar 2015");	//month and day can be in any order
const d = new Date("January 25 2015");	//month can be written in full, or abbreviated
const d = new Date("JANUARY, 25, 2015");	//commas are ignored, names are case insensitive
```

## 31.8 Date Input - Parsing Dates

​	If you have a valid date string, you can use the <span style="color: red;">Date.parse()</span> method to convert it to milliseconds, it returns the number of milliseconds between the date and January 1, 1970:

```
let msec = Date.parset("March 21, 2012");
```

​	And you can then use the number of milliseconds to <b>convert it to a date</b> object:

```
const d = newDate(msec);
```



# 32. JavaScript Get Date Methods

## 32.1 The new Date() Constructor

​	In JavaScript, date objects are created with <span style="color: red;">new Date()</span>.

​	<span style="color: red;">new Date()</span> returns a date object with the current date and time.

```
const date = new Date();
```

## 33.2 Date Get Methods

| Method            | Description                                          |
| ----------------- | ---------------------------------------------------- |
| getFullYear()     | Get <b>year</b> as a four digit number (yyyy)        |
| getMonth()        | Get <b>month</b> as a number (0-11)                  |
| getDate()         | Get <b>day</b> as a number (1-31)                    |
| getDay()          | Get <b>weekday</b> as a number (0-6)                 |
| getHours()        | Get <b>hour</b> (0-23)                               |
| getMinutes()      | Get <b>minute</b> (0-59)                             |
| getSeconds()      | Get <b>second</b> (0-59)                             |
| getMilliseconds() | Get <b>millisecond</b> (0-999)                       |
| getTime()         | Get <b>time</b> (milliseconds since January 1, 1970) |

<b>Note1:</b>

​	The get methods above return <b>Local time</b>.

​	<b>Universal time</b> (UTC) is documented at the bottom of this page.

<b>Note 2:</b>

​	The get methods return information from existing date objects.

​	In a date object, the time is static. The "clock" is not "running".

​	The time in a date object is NOT the same current time.

## 33.3 The getFullYear() Method

​	The <span style="color: red;">getFullYear()</span> method returns the year of a date as a four digit number:

```
const d = new Date("2021-03-22");
d.getFullYear();		//2021
```

<b>Warning!</b>

​	Old JavaScript code might use the non-standard method getYear().

​	getYear() is supposed to return a 2-digit year.

​	getYear() is deprecated. Do not use it!

## 33.4 The getMonth() Method

​	The <span style="color: red;">getMonth()</span> method returns the month of a date as a number (0-11).

<b>Note:</b>

​	In JavaScript, January is month number 0, February is number 1, ...

```
const d = new Date("2023-04-15");
d.getMonth();			//4
```

<b>Note:</b>

​	You can use an array of names to return the month as a name:

```
const months = ["January", "February", "March", "April", "May",
"June", "July", "August", "September", "Octobar", "November", "December"];
const d = new Date("2020-03-15");
let month = months[d.getMonth()];
```

## 33.5 The getDate() Method

​	The <span style="color: red;">getDate()</span> method returns the day of a date as a number (1-31):

```
const d = new Date("2011-11-11");
d.getDate();			//11
```

## 33.6 The getHours() Method

​	The <span style="color: red;">getHours()</span> method returns the hours of a date as a number (0-23):

```
const d = new Date("2011-11-11");
d.getHours();			//8
```

## 33.7 The getMinutes() Method

​	The <span style="color: red;">getMinutes()</span> method returns the minutes of a date as a number (0-59)：

```
const d = new Date("2011-11-11");
d.getMinutes();			//0
```

## 33.8 The getSeconds() Method

​	The <span style="color: red;">getSecond()</span> method returns the seconds of a date as a number (0-59):

```
const d = new Date("2011-11-11");
d.getSeconds();			//0
const d2 = new Date();
d2.getSeconds();		//some number
```

## 33.9 The getMilliseconds() Method

​	The <span style="color: red;">getMilliseconds()</span> method returns the milliseconds of a date as a number (0-999):

```
const d = new Date();
d.getMilliseconds();
```

## 33.10 The getDay() Method

​	The <span style="color: red;">getDay()</span> method returns the weekday of a date as a number (0-6):

```
const d = new Date("2011-11-11");
d.getDay();			//5
const d2 = new Date();
d2.getDay();		//4
```

<b>Note:</b>

​	In JavaScript, the first day of the week (day 0) is Sunday. Some countries in the world consider the first day of the week to be Monday.

## 33.11 The getTime() Method

​	The <span style="color: red;">getTime()</span> method returns the number of milliseconds since January 1, 1970:

```
const d = new Date();
d.getTime();			//1681400624874
```

## 33.12 The Date.now() Method

​	<span style="color: red;">Date.now()</span> returns the number of milliseconds since January 1, 1970:

```
let ms = Date.now();
const minute = 1000 * 60;
const hour = minute * 60;
const day = hour * 24;
const year = day * 365;
let years = Math.round(Date.now() / year);	//Calculate the number of years since January 1, 1970
```

​	<span style="color: red;">Date.now()</span> is a static method of the Date object. You cannot use it on a date object like <span style="color: red;">myDate.now()</span>. The syntax is always <span style="color: red;">Date.now()</span>

## 33.13 UTC Date Get Methods

| Method               | Same As           | Description                  |
| :------------------- | :---------------- | :--------------------------- |
| getUTCDate()         | getDate()         | Returns the UTC date         |
| getUTCFullYear()     | getFullYear()     | Returns the UTC year         |
| getUTCMonth()        | getMonth()        | Returns the UTC month        |
| getUTCDay()          | getDay()          | Returns the UTC day          |
| getUTCHours()        | getHours()        | Returns the UTC hour         |
| getUTCMinutes()      | getMinutes()      | Returns the UTC minutes      |
| getUTCSeconds()      | getSeconds()      | Returns the UTC seconds      |
| getUTCMilliseconds() | getMilliseconds() | Returns the UTC milliseconds |

​	UTC methods use UTC time (Coordinated Universal Time)

​	UTC time is the same as GMT (Greenwich Mean Time)

​	The different between Local time and UTC time can be up to 24 hours.

## 33.14 The getTimezoneOffset() Method

​	The <span style="color: red;">getTimezoneOffset()</span> method returns the difference (in minutes) between local time an UTC time:

```
let diff = d.getTimezoneOffset();	//-480
```



## 34. JavaScript Date Set Methods

<span style="font-size: 20px;">Set Date Methods</span>

​	Set Date methods are used for setting a part of a date:

| Method            | Description                                       |
| ----------------- | ------------------------------------------------- |
| setDate()         | Set the day as a number (1-31)                    |
| setFullYear()     | Set the year (optionally month and day)           |
| setHours()        | Set the hour (0-23)                               |
| setMilliseconds() | Set the milliseconds (0-999)                      |
| setMinutes()      | Set the minutes (0-59)                            |
| setMonth()        | Set the month (0-11)                              |
| setSeconds()      | Set the seconds (0-59)                            |
| setTime()         | Set the time (milliseconds since January 1, 1970) |

## 34.1 The setFullYear() Method

​	The <span style="color: red;">setFullYear()</span> method sets the year of a date object.

```
const d = new Date();
d.setFullYear(2023);
```

​	The <span style="color: red;">setFullYear()</span> method can <b>optionally</b> set month and day:

```
d.setFullYear(2023, 4, 14);
```

## 34.2 The setMonth() Method

​	The <span style="color: red;">setMonth()</span> method sets the month of a date object (0-11).

## 34.3 The setDate() Method

​	The <span style="color: red;">setDate()</span> sets the day of a date object (1-31), this method can also be used to <b>add days</b> to a date.

```
const d = new Date();
d.setDate(15);
d.setDate(d.getDate() + 50);
```

## 34.4 The setHours() Method

​	The <span style="color: red;">setHours()</span> method sets the hours of a date object (0-23).

## 34.5 The setMinutes() Method

​	The <span style="color: red;">setMinutes()</span> method sets the minutes of a date object (0-59).

## 34.6 The setSeconds() Method

​	The <span style="color: red;">setSeconds()</span> method sets the seconds of a date object (0-59).

## 34.7 Compare Dates

​	Dates can easily be compared. The following example compares today's date with January 14, 2100:

```
let text = "";
const today = new Date();
const someday = new Date();
someday.setFullYear(2100, 0, 14);
if(someday > today) {
	text = "Today is before January 14, 2100.";
} else if(someday < today) {
	text = "Today is after January 14, 2100.";
} else {
	text = "Today is January 14, 2100!";
}
```



# 35. JavaScript Math Object

​	The JavaScript Math object allows you to perform mathematical tasks on numbers.

## 35.1 The Math Object

​	Unlike other objects, the Math object has no constructor. The Math object is static. 

​	All methods and properties can be used without creating a Math object first!

## 35.2 Math Properties (Constants)

​	The syntax for any Math property is: <span style="color: red;">Math.property</span>.

​	JavaScript provides 8 mathematical constants that can be accessed as Math properties:

```
Math.E			//returns Euler's number
Math.PI			//returns PI
Math.SQRT2		//returns the square root of 2
Math.SQRT1_2	//returns the square root of 1/2
Math.LN2		//returns the natural logarithm of 2
Math.LN10		//returns the natural logarithm of 10
Math.LOG2E		//returns base 2 logarithm of E
Math.LOG10E		//returns base 10 logarithm of E
```

## 35.3 Math Methods

​	The syntax for Math any methods is: <span style="color: red;">Math.method(number)</span>.

### 35.3.1 Number to Integer

​	There are 4 common methods to round a number to an integer:

| Method        | Description                                   |
| ------------- | --------------------------------------------- |
| Math.round(x) | Returns x rounded to its nearest integer      |
| Math.ceil(x)  | Returns x rounded up to its nearest integer   |
| Math.floor(x) | Returns x rounded down to its nearest integer |
| Math.trunc(x) | Returns the integer part of x (new in ES6)    |

### 35.3.2 Math.sign()

​	<span style="color: red;">Math.sign()</span> returns if x is negative, null or positive.

### 35.3.3 Math.pow()

​	<span style="color: red;">Math.pow(x, y)</span> returns the value of x to the power of y (x ^ y).

### 35.3.4 Math.sqrt()

​	<span style="color: red;">Math.sqrt(x)</span> returns the square root of x.

### 35.3.5 Math.abs()

​	<span style="color: red;">Math.abs()</span> returns the absolute (positive) value of x.

### 35.3.6 Math.sin() & Math.cos()

​	<span style="color: red;">Math.sin()</span> returns the sine of the angle x (given in radians). If you want to use degrees instead of radians, you have to convert degrees to radians:

```
Math.sin(90 * Mathh.PI / 180);	//the sine of 90 degrees
```

​	<span style="color: red;">Math.cos()</span> similar to Math.sin().

### 35.3.7 Math.min() & Math.max()

​	<span style="color: red;">Math.min()</span> and <span style="color: red;">Math.max()</span> can be used to find the lowest or highest value in a list of arguments:

```
Math.min(0, 120, 33, -32, 3, -9, 20, -0);
Math.max(1, 8, 89, -44, 72, 10);
```

### 35.3.8 Math.random()

​	<span style="color: red;">Math.random()</span> returns a random number between 0 (inclusive), and 1 (exclusive).

### 35.3.9 The Math.log*() Method

​	logarithm of x:

```
Math.log(2);
Math.log2(2);
Math.log10(2);
```

## 35.4 JavaScript Math Methods

| Method                                                       | Description                                                  |
| :----------------------------------------------------------- | :----------------------------------------------------------- |
| [abs(x)](https://www.w3schools.com/jsref/jsref_abs.asp)      | Returns the absolute value of x                              |
| [acos(x)](https://www.w3schools.com/jsref/jsref_acos.asp)    | Returns the arccosine of x, in radians                       |
| [acosh(x)](https://www.w3schools.com/jsref/jsref_acosh.asp)  | Returns the hyperbolic arccosine of x                        |
| [asin(x)](https://www.w3schools.com/jsref/jsref_asin.asp)    | Returns the arcsine of x, in radians                         |
| [asinh(x)](https://www.w3schools.com/jsref/jsref_asinh.asp)  | Returns the hyperbolic arcsine of x                          |
| [atan(x)](https://www.w3schools.com/jsref/jsref_atan.asp)    | Returns the arctangent of x as a numeric value between -PI/2 and PI/2 radians |
| [atan2(y, x)](https://www.w3schools.com/jsref/jsref_atan2.asp) | Returns the arctangent of the quotient of its arguments      |
| [atanh(x)](https://www.w3schools.com/jsref/jsref_atanh.asp)  | Returns the hyperbolic arctangent of x                       |
| [cbrt(x)](https://www.w3schools.com/jsref/jsref_cbrt.asp)    | Returns the cubic root of x                                  |
| [ceil(x)](https://www.w3schools.com/jsref/jsref_ceil.asp)    | Returns x, rounded upwards to the nearest integer            |
| [cos(x)](https://www.w3schools.com/jsref/jsref_cos.asp)      | Returns the cosine of x (x is in radians)                    |
| [cosh(x)](https://www.w3schools.com/jsref/jsref_cosh.asp)    | Returns the hyperbolic cosine of x                           |
| [exp(x)](https://www.w3schools.com/jsref/jsref_exp.asp)      | Returns the value of Ex                                      |
| [floor(x)](https://www.w3schools.com/jsref/jsref_floor.asp)  | Returns x, rounded downwards to the nearest integer          |
| [log(x)](https://www.w3schools.com/jsref/jsref_log.asp)      | Returns the natural logarithm (base E) of x                  |
| [max(x, y, z, ..., n)](https://www.w3schools.com/jsref/jsref_max.asp) | Returns the number with the highest value                    |
| [min(x, y, z, ..., n)](https://www.w3schools.com/jsref/jsref_min.asp) | Returns the number with the lowest value                     |
| [pow(x, y)](https://www.w3schools.com/jsref/jsref_pow.asp)   | Returns the value of x to the power of y                     |
| [random()](https://www.w3schools.com/jsref/jsref_random.asp) | Returns a random number between 0 and 1                      |
| [round(x)](https://www.w3schools.com/jsref/jsref_round.asp)  | Rounds x to the nearest integer                              |
| [sign(x)](https://www.w3schools.com/jsref/jsref_sign.asp)    | Returns if x is negative, null or positive (-1, 0, 1)        |
| [sin(x)](https://www.w3schools.com/jsref/jsref_sin.asp)      | Returns the sine of x (x is in radians)                      |
| [sinh(x)](https://www.w3schools.com/jsref/jsref_sinh.asp)    | Returns the hyperbolic sine of x                             |
| [sqrt(x)](https://www.w3schools.com/jsref/jsref_sqrt.asp)    | Returns the square root of x                                 |
| [tan(x)](https://www.w3schools.com/jsref/jsref_tan.asp)      | Returns the tangent of an angle                              |
| [tanh(x)](https://www.w3schools.com/jsref/jsref_tanh.asp)    | Returns the hyperbolic tangent of a number                   |
| [trunc(x)](https://www.w3schools.com/jsref/jsref_trunc.asp)  | Returns the integer part of a number (x)                     |



# 36. JavaScript Random

## 36.1 Math.random()

​	<span style="color: red;">Math.random()</span> returns a random number between 0 (inclusive), and 1 (exclusive).

## 36.2 Random Integers

​	<span style="color: red;">Math.random()</span> used with <span style="color: red;">Math.floor()</span> can be used to return random integers:

```
Math.floor(Math.random() * 10);	//returns a random integer from 0 to 9
```

<b>Note:</b>

​	There is no such thing as JavaScript integers. We are talking about numbers with no decimals here.

```
Math.floor(Math.random() * 101);	//returns a random integer from 0 to 100
```

## 36.3 A Proper Random Function

​	As you can see from the example above, it might be a good idea to create a proper random function to use for all random integer purposes. This JS function always returns a random number between min (included) and max(exclued):

```
function getRndInteger(min, max) {
	return Math.floor(Math.random() * (max - min)) + min;
}
```

​	To include max:

```
function getRndInteger(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}
```



# 37. JavaScript Booleans

## 37.1 Boolean Values

​	JavaScript has a <b>Boolean</b> data type. It can only take the values <b>true</b> or <b>false</b>.

## 37.2 The Boolean() Function

​	You can use the <span style="color: red;">Boolean()</span> function to find out if an expression (or a variable) is true:

```
Boolean(10 > 9);
```

​	Or even easier:

```
(10 > 9);
```

## 37.3 Comparisions and Conditions

| Operator | Description  | Example             |
| -------- | ------------ | ------------------- |
| ==       | equal to     | if (day == "Mondy") |
| >        | greater than | if (salary > 9000)  |
| <        | less than    | if (age < 18)       |

## 37.4 Everything With a "Value" is True

```
Boolean(3.14);		//true
Boolean(-12);		//true
Boolean("false");	//true
Boolean(1 + 2);		//true
Boolean(0);			//false!
```

## 37.5 Everything Without a "Value" is False

```
let x = 0;				//Boolen() is false
let y = -0;				//false
let a = "";				//empty string: false
let b;					//undefined: false
let c = null;			//null: false
let d = false;			//false: false
let x = 10 / "Hello";	//NaN: false
```

## 37.6 Booleans as Objects

​	Normally JavaScript booleans are primitive values created from literals:

```
let x = false;
```

​	But booleans can also be defined as objects with the keyword <span style="color: red;">new</span>:

```
let y = new Boolean(false);
```

<b>Note:</b> Do not create Boolean objects. The <span style="color: red;">new</span> keyword complicates the code and slows down execution speed. Boolean objects can produce unexpected results:

```
let x = false, y = new Boolean(false);
(x == y);				//equal
(x === y);				//not equal
let a = new Boolean(false);
(y == a);				//false (not equal)
(y === a);				//false
```

<b>Note:</b> Comparing two JavaScript objects <b>always</b> return <b>false</b>.



# 38. JavaScript Comparison and Logical Operators

## 38.1 Comparison Operators

​	Comparison operators are used in logical statement to determine equality or difference between variables or values. Given that <span style="color: red;">x = 5</span>, the table below explains the comparison operators:

| Operator | Description                       | Comparing                          | Returns                 |
| -------- | --------------------------------- | ---------------------------------- | ----------------------- |
| ==       | equal to                          | x == 8<br>x == 5<br>x == "5"       | false<br> true<br> true |
| ===      | equal value and equal type        | x === 5 <br> x === "5"<br>         | true<br> false          |
| !=       | not equal                         | x != 8                             | true                    |
| !==      | not equal value or not equal type | x !== 5 <br> x !== "5"<br> x !== 8 | false<br> true<br> true |
| >        | greater than                      | x > 8                              | false                   |
| <        | less than                         | x < 8                              | true                    |
| >=       | greater than or equal to          | x >= 8                             | false                   |
| <=       | less than or equal to             | x <= 8                             | true                    |

## 38.2 How Can it be Used

​	Comparison operators can be used in conditional statements to compare values and take action depending on the result:

```
if (age < 18) text = "Too young to buy alcohol";
```

## 38.3 Logical Operator

​	Logical operators are used to determine the logic between variables or values.

​	Given the <span style="color: red;">x = 6</span> and <span style="color: red;">y = 3</span>, the table below explains the logical operators:

| Operator | Description | Example                       |
| -------- | ----------- | ----------------------------- |
| &&       | and         | (x < 10 && y > 1) is true     |
| \|\|     | or          | (x == 5 \|\| y == 5) is false |
| !        | not         | !(x == y) is true             |

## 38.4 Conditional (Ternary) Operator

​	JavaScript also contains a conditional operator that assigns a value to a variable based on some condition:

```
variabelname = (condition) ? value1 : value2:
let voteable = (age >= 18) ? true: false;
```

## 38.5 Comparing Different Types

​	Comparing data of different types may give unexpected results.

​	When comparing a string with a number, JavaScript will convert the string to a number when doing the comparison. An empty string converts to 0. A non-numeric string converts to <span style="color: red;">NaN</span> which is always <span style="color: red;">false</span>.

| Case        | Value  |
| ----------- | ------ |
| 2 < 12      | true   |
| 2 < "12"    | true   |
| 2 < "John"  | false  |
| 2 == "John" | false  |
| "2" > "12"  | false* |
| "2" < "12"  | true*  |

​	When comparing two strings, "2" will be greater than "12", because (alphabetically) 1 is less than 2. To secure a proper result, variables should be converted to the proper type before comparison:

```
age = Number(age);
if(isNaN(age)) {
	voteable = "Input is not a number";
	/*some error handler*/
} else {
	voteable = (age < 18) ? false : true;
}
```

## 38.6 The Nullish Coalescing Operator (??)

​	The <span style="color: red;">??</span> operator returns the first argument if it is not <b>nullish</b> (<span style="color: red;">null</span> or <span style="color: red;">undefined</span>). Otherwise it returns the second argument:

```
let name = null, text = "missing";
let result = name ?? text;		//name is null, cannot use it, so let is "missing"
```

## 38.7 The Optional Chaining Operator (?.)

​	The <span style="color: red;">?.</span> operator returns <span style="color: red;">undefined</span> if an object is <span style="color: red;">undefined</span> or null (instead of throwing an error):

```
const car = {type:"Fiat", model:"500", color:"white"};
document.getElementById("demo").innerHTML = car ?. name;	//undefined
				// if car is undefined, name = null.
```



# 39. JavaScript if, else, and else if

​	Conditional statements are used to perform different actions based on different conditions.

## 39.1 Conditional Statements

​	Very often when you write code, you want to perform different actions for different decisions. You can use conditional statements in you code to do this. In JavaScript we have the following conditional statements:

* Use <span style="color: red;">if</span> to specify a block of code to be executed, if a specified condition is true.
* Use <span style="color: red;">else</span> to specify a block of code to be executed, if the same condition is false.
* Use <span style="color: red;">else if</span> to specify a new condition to test, if the first condition is false.
* Use <span style="color: red;">switch</span> to specify many alternative blocks of code to be executed.

## 39.2 The if & else & else if Statement

```
if (condition1) {
	//block of code to be exectued if conditioon1 is true
} else if(condition2) {
	//block of code to be executed if condition1 is false and condition2 is true
} else {
	//block of code to be executed if condition1 and conditon2 are both false
}
```

## 39.3 JavaScript Switch Statement

​	Use the <span style="color: red;">switch</span> statement to select one of many code blocks to be executed.

<span style="font-size:20px;">Syntax</span>

```
switch(expression) {
	case x:
		//...
		break;
	case y:
		//...
		break;
	default:
		//...
}
```

### 39.3.1 The break Keyword

​	When JavaScript reaches a <span style="color: red;">break</span> keyword, it breaks out of the switch block. This will stop the execution inside the switch block. It is not necessary to break the last case in a switch block, the block breaks there anyway.

### 39.3.2 The default Keyword

### 39.3.3 Common Code Blocks

​	Sometimes you will want different switch cases to use the same code.

```
switch (new Date().getDay()) {
	case 4:
	case 5:
		text = "Soon it is Weekend";
		break;
	case 0:
	case 6:
		text = "It is Weekend";
		break;
	default:
		text = "Looking forward to the weekend";
}
```

### 39.3.4 Switching Details

​	If multiple cases matches a case value, the <b>first</b> case is selected. If no matching cases are found, the program continues to the <b>default</b> label. If no default label is found, the program continues to the statement(s) <b>after the switch</b>.

### 39.3.5 Strict Comparison

​	Switch cases use <b>strict</b> comparison (===). The values must be of the same type to match.



# 40. JavaScript Loop

## 40.1 JavaScript Loops

​	Loops are handy, if you want to run the same code over and over again, each time with a different value.

## 40.2 Different Kinds of Loops

* <span style="color: red;">for</span> - loops through a block of code a number of times
* <span style="color: red;">for/in</span> - loops through the properties of an object
* <span style="color: red;">for/of</span> - loops through the values of an iterable object
* <span style="color: red;">while</span> - loops through a block of code while a specified condition is true
* <span style="color: red;">do/while</span> - also loops through a block of code while a specified condition is true

## 40.3 The For Loop

​	The <span style="color: red;">for</span> statement creates a loop with 3 optional experssions:

```
for(expression1; expression2; expression3) {
	//code block to be executed
}	
```

​	<b>Expression1</b> is executed (one time) before the execution of the code block.

​	<b>Expression2</b> defines the condition for executing the code block, it's calculated each before the code block.

​	<b>Expression3</b> is executed (every time) after the code block has been executed.

### 40.3.1 Loop Scope

​	Using <span style="color: red;">var</span> in a loop:

```
var i = 5;
for(var i = 0; i < 10; i++) {

}
//Here i is 10
```

​	Using <span style="color: red;">let</span> in a loop:

```
let i = 5;
for(let i = 0; i < 10; i++) {

}
//Here i is 5
```

​	In the first example, using <span style="color: red;">var</span>, the variable declared in the loop redeclares the variable outside the loop. In the second example, using <span style="color: red;">let</span>, the variable declared in the loop does not declared the variable outside the loop. So, when <span style="color: red;">let</span> is used to declare the i variable in a loop, the i variable will only be visible within the loop.

## 40.4 For In

### 40.4.1 The For In Loop

​	The JavaScript <span style="color: red;">for in</span> statement loops through the properties of an Object:

```
for (key in object) {
	//code block
}
```

### 40.4.2 For In Over Arrays

​	The JavaScript <span style="color: red;">for in</span> statement can also loop over the properties of an Array:

```
for (variable in array) {
	//code
}
```

<b>Note:</b> Do not use <b>for in</b> over an Array if the index <b>order</b> is important. 

​	The index order is implementation-dependent, and array values may not be accessed in the order you expect. It is better to use a <b>for</b> loop, a <b>for of</b> loop, or <b>Array.forEach()</b> when the order is important.

### 40.4.3 Array.forEach()

​	The <span style="color: red;">forEach()</span> method calls a function (a callback fuction) once for each array element. Refer previous chapter.

```
const numbers = [34, 32, -3, 93, 2];
let txt = "";
numbers.forEach(myFunction);
function myFunction(value, index, array) {
	txt += value;
}
```

## 40.5 For Of

### 40.5.1 The For Of Loop

​	The JavaScript <span style="color: red;">for of</span> statement loops through the values of an iterable object.

​	It lets you loop over iterable data structures such as Arrays, Strings, Maps, NodeLists, and more:

```
for (varibale of iterable) {
	//code block
}
```

<b>variable</b> - For every iteration the value of the next property is assigned to the variable. Variable can be declared with <span style="color: red;">const</span>, <span style="color: red;">let</span>, or <span style="color: red;">var</span>.

<b>iterable</b> - An object that has iterable properties.

### 40.5.2 Looping over an Array

```
const cars = ["BYD", "VolvO", "Mini"];
let text = "";
for (let x of cars) {
	text += x;
}
```

### 40.5.3 Looping over a String

```
let languate = "JavaScript";
let text = "";
for (let x of language) {
	text += x + "<br>";			//J			
}								//a
```

## 40.6 While Loop

### 40.6.1 The While Loop

​	The <span style="color: red;">while</span> loop loops through a block of code as long as a specified condition is true:

```
while (i < 10) {
	text += "The number is:" + i + "<br>";
	i++;
}
```

### 40.6.2 The Do While Loop

​	The <span style="color: red;">do while</span> loop is a variant of the while loop. This loop will execute the code block once, before checking if the condition is true, then it will repeat the loop as long as the condition is true:

```
do {
	text += "The number is:" + i + "<br>";
	i++;
} while (i < 0);
```

### 40.6.3 Comparing For and While

​	If you have read the previous chapter, about the for loop, you will discover that a while loop is much the same as a for loop, with statement 1 and statement 3 omitted.

```
for (;cars[i];) {
	text += cars[i];
	i++;
}
while (cars[i]) {
	text += cars[i];
	i++;
}
```



# 41. JavaScript Break and Continue

​	The <span style="color: red;">break</span> statement "jumps out" of a loop.

​	The <span style="color: red;">continue</span> statement "jumps over" one iteration in the loop (continues with the next iteration).

## 41.1 JavaScript Labels

​	To label JavaScript statements you precede the statements with a label name and a colon:

```
label:
	statements
```

​	The <span style="color: red;">break</span> and the <span style="color: red;">continue</span> statements are the only JavaScript statements that can "jump out of" a code block.

```
break Labelname;
continue Labelname;
```

​	With a label reference, the break statement can be used to <b>jump out of any code  block</b>:

```
cosnt cars = ["BYD", "Toyota", "Volvo"];
list: {
	text += cars[0] + "<br>";
	break list;					//jump out of the code block
	text += cars[1] + "<br>";
}
```



# 42. JavaScript Iterables

​	Iterables are iterable-objects (like Arrays).

​	Iterables can be accessed with simple and efficient code.

​	Iterables can be iterated over with <span style="color: red;">for..of</span> loops

## 42.1 The For Of Loop

​	The JavaScript <span style="color: red;">for..of</span> statement loops through the elements of an iterable object:

```
for (variable of iterable) {
	//code block
}
```

## 42.2 Iterating

​	Iterating is easy to understand. It simply means looping over a sequence of elements.

​	Here are some easy examples:

* Iterating over a String
* Iterating over an Array

## 42.3 Iterating Over a String

​	You can use a <span style="color: red;">for..of</span> loop to iterate over the elements of a string:

```
const name = "W3Schools";
for (const x of name) {
	//code block
}
```

## 42.4 Iterating Over an Array

​	You can use a <span style="color: red;">for..of</span> loop to iterate over the elements of an Array:

```
const letters = ["a", "b", "c"];
for (const x of letters) {
	//code block
}
```

## 42.5 Iterating Over a Set

​	You can use a <span style="color: red;">for..of</span> loop to iterate over the elements of a Set:

```
const letters = neww Set(["a", "b", "c"]);
for (const x of letters) {
	//code block
}
```

## 42.6 Iterating Over a Map

​	You can use a <span style="color: red;">for..of</span> loop to iterate over the elements of a Map:

```
const fruits = new Map([
	["apples", 500],
	["bananas", 300],
	["oranges", 200]
]);
for (const x of fruits) {
	//code block
}
```



# 43. JavaScript Sets

​	A JavaScript Set is a collection of unique values.

​	Each value can only occur once in a Set.

## 43.1 Essential Set Methods

| Method          | Description                                      |
| :-------------- | :----------------------------------------------- |
| new Set()       | Creates a new Set                                |
| add()           | Adds a new element to the Set                    |
| delete()        | Removes an element from a Set                    |
| has()           | Returns true if a value exists in the Set        |
| forEach()       | Invokes a callback for each element in the Set   |
| values()        | Returns an iterator with all the values in a Set |
| <b>Property</b> | <b>Description</b>                               |
| size            | Returns the number of elements in a Set          |

## 43.2 How to Create a Set

​	You can create a JavaScript Set by:

* Passing an Array to <span style="color: red;">new Set()</span>
* Create a new Set and use <span style="color: red;">add()</span> to add values
* Create a new Set and use <span style="color: red;">add()</span> to add variables

## 43.3 The new Set() Method

​	Pass an Array to the <span style="color: red;">new Set()</span> constructor:

```
const letters = new Set(["a", "b", "c"]);
```

​	Create a Set and add values:

```
const letters = new Set();
letters.add("a");
letters.add("b");
letters.add("c");
```

​	Create a Set and add variables:

```
const letters = new Set();
const a = "a";
//...
letters.add(a);
//...
```

## 43.4 The add() Method

​	If you add equal elements, only the first will be saved:

```
letters.add("a");
letters.add("b");
letters.add("b");
//...
```

## 43.5 The forEach() Method

​	The <span style="color: red;">forEach()</span> method invokes (calls) a function for each Set elements:

```
const letters = new Set(["a", "b", "c"]);
let text = "";
letters.forEach(function(value, index, array) {
	text += value;
})
```

## 43.6 The values() Method

​	The <span style="color: red;">values()</span> method returns a new iterator object containing all the values in a Set:

```
letters.values();	//[object Set Iterator]
```

​	Now you can use the Iterator object to access the elements:

```
let text = "";
for (const x of letteers.values()) {
	text += x;
}
```



# 44. JavaScript Maps

​	A Map holds key-value pairs where the keys can be any datetype.

​	A Map remembers the original insertion order of the keys.

## 44.1 Essential Map Methods

| Method          | Description                                              |
| :-------------- | :------------------------------------------------------- |
| new Map()       | Creates a new Map                                        |
| set()           | Sets the value for a key in a Map                        |
| get()           | Gets the value for a key in a Map                        |
| delete()        | Removes a Map element specified by the key               |
| has()           | Returns true if a key exists in a Map                    |
| forEach()       | Calls a function for each key/value pair in a Map        |
| entries()       | Returns an iterator with the [key, value] pairs in a Map |
| <b>Property</b> | <b>Description</b>                                       |
| size            | Returns the number of elements in a Map                  |

## 44.2 How to Create a Map

​	You can add elements to a Map with the <span style="color: red;">set()</span> method:

```
const fruits = new Map();
fruits.set("apples", 500);
```

​	The <span style="color: red;">set()</span> method can also be used to change existing Map values:

```
fruits.set("apples", 200);
```

## 44.3 The get() Method

​	The <span style="color: red;">get()</span> method gets the value of a key in a Map:

```
fruits.get("apples");
```

## 44.4 The size Property

​	The <span style="color: red;">size</span> property returns the number of elements in a Map:

```
fruits.size;
```

## 44.5 The delete() Method

​	The <span style="color: red;">delete()</span> method removes a Map element:

```
fruits.delete("apples");
```

## 44.6 The has() Method

​	The <span style="color: red;">has()</span> method returns true if a key exists in a Map:

```
fruits.has("apples");		//true or false
```

## 44.7 JavaScript Objects vs Maps

​	Differences between JavaScript Objects and Map:

|                  | Object                            | Map                           |
| :--------------- | :-------------------------------- | ----------------------------- |
| <b>Iterable</b>  | Not directly iterable             | Directly iterable             |
| <b>Size</b>      | Do not have a size property       | Have a size property          |
| <b>Key Types</b> | Keys must be Strings (or Symbols) | Keys can be any datatype      |
| <b>Key Order</b> | Keys are not well ordered         | Keys are ordered by insertion |
| <b>Defaults</b>  | Have default keys                 | Do not have default keys      |

## 44.8 The forEach() Method

​	The  <span style="color: red;">forEach()</span> method calls a function for each key/value pair in a Map:

```
let text = "";
fruits.forEach(function(value, key) {
	text += key + ' = ' + value;
});
```

<b>Note:</b> <span style="color: blue;">for Map, function parameters are (value, key) ?</span>

## 44.9 The entries() Method

​	The <span style="color: red;">entries()</span> method returns an iterator object with the [key,value] in a Map:

```
let text = "";
for (cosnt x of fruits.entries()) {
	text += x;					//apples,500
}
```



# 45. JavaScript typeof

​	In JavaScript there are 5 different data types that can contain values:

* string, number, boolean, object, function

​	There are 6 types of objects:

* Object, Date, Array, String, Number, Boolean

​	And 2 data types that cannot contain values:

* null, undefined

## 45.1 The typeof Operator

​	You can use the <span style="color: red;">typeof</span> operator for find the data type of a JavaScript varaible:

```
typeof "John";					//string
typeof 3.14						//number
typeof NaN						//number
typeof false					//boolean
typeof [1,2,3]					//object
typeof {name:"John", age: 34}	//object
typeof new Date()				//object
typeof function () {}			//function
typeof myUndefinedCar			//undefined
typeof null						//object
```

<b>Note:</b> You cannot use <span style="color: red;">typeof</span> to determine if a JavaScript object is an array (or a date).

## 45.2  Primitive Date

​	A primitive date value is a single simple date value with no additional properties and methods. The <span style="color: red;">typeof</span> operator can return one of these primitive types:

* string
* number
* boolean
* undefined

```
typeof "John"		//string
type 3.14			//number
typeof true			//boolean
```

## 45.3 Complex Date

​	The <span style="color: red;">typeof</span> operator can return one of two complex types:

* function
* object

​	The <span style="color: red;">typeof</span> operator returns "object" for objects, arrays, and null, does not return "object" for function.

## 45.4 The Data Type of typeof

​	The <span style="color: red;">typeof</span> operator is not a variable. It is an operator. Operator do not have any data type.

​	But, the <span style="color: red;">typeof</span> operator always <b>returns a string</b> (containing the type of the operand).

## 45.5 The constructor Property

​	The <span style="color: red;">constructor</span> property returns the constructor function for all JavaScript variables:

```
"John".constructor			//Returns function String()
(3.14).constructor			//Number()
false.constructor			//Boolean()
[1,2,3].constructor			//Array()
{name:'John'}.constructor	//Object()
new Date().constructor		//Date()
fucntion () {}.constructor	//Function()
```

​	You can check the constructor property to find out if an object is an <span style="color: red;">Array</span>:

```
function isArray(myArray) {
	return myArray.constructor.toString().indexOf("Array") > -1;
}
```

​	Or even simpler, you can check if the object is an <b>Array function</b>:

```
function isArray(myArray) {
	return myArray.constructor === Array;
}
```

## 45.6 Undefined

​	In JS, a variable without a value, has the value <span style="color: red;">undefined</span>. The type is also <span style="color: red;">undefined</span>.

​	Any variable can be emptied, by setting the value to <span style="color: red;">undefined</span>. The type will also be <span style="color: red;">undefined</span>:

```
car = undefined;		//value is undefined, tyep also undefined
```

## 45.7 Empty Values

​	An empty value has nothing to do with <span style="color: red;">undefined</span>.

​	An empty string has both a legal value and a type.

```
let car = "";	//value is "", typeof is "string"
```

## 45.8 Null

​	In JavaScript <span style="color: red;">null</span> is "nothing". It is supposed to be something that doesn't exist.

​	Unfortunately, in JavaScript, the data type of <span style="color: red;">null</span> is an object.

<b>Note:</b> You can consider it a bug in JavaScript that <span style="color: red;">typeof null</span> is an object. It should be <span style="color: red;">null</span>.

​	You can empty an object by setting it to <span style="color: red;">null</span>:

```
let person = {firstName:"John", lastName="Doe"};
person = null;	//value is null, type is still object
```

​	You can also empty an object by setting it to <span style="color: red;">undefined</span>:

```
person = undefined;
```

## 45.9 Difference Between Undefined and Null

​	<span style="color: red;">undefined</span> and <span style="color: red;">null</span> are equal in value but different in type:

```
typeof undefined	//undefined	
typeof null			//object
null === undefined	//false
null == undefined	//true
```

## 45.10 The instanceof Operator

​	The <span style="color: red;">instanceof</span> operator returns <span style="color: red;">true</span> if an object is an instance of the specified object:

```
const cars = ["Saab", "Volvo", "BMW"];
(cars instanceof Array)		//true
(cars instanceof Object)	//true
(cars instanceof String)	//false
(cars instanceof Number)	//false
```

## 45.11 The void Operator

​	The <b>void</b> operator evaluates an expression and returns <b>undefined</b>. This operator is often used to obtain the undefined primitive value, using "void(0)" (useful when evaluating an expression without using the return value).

```
<a href="javascript:void(document.body.style.backgroundColor='red');">
```



# 46. JavaScript Type Conversion

## 46.1 JavaScript Type Conversion

​	JavaScript variables can be converted to a new variable and another data type:

* By the use of a JavaScript function
* <b>Automatically</b> by JavaScript itself

## 46.2 Converting Strings to Numbers

​	The global method <span style="color: red;">Number()</span> converts a variable (or a value) into a number.

​	A numeric string (like "3.14") converts to a number (like 3.14).

​	An empty string (like "") converts to 0.

​	An non numeric string (like "John") converts to <span style="color: red;">NaN</span> (Not a Number).

```
Number("3.14");		//3.14
Number(Math.PI);	//3.141592653589793
Number("  ");		//0
Number("");			//0
Number("99 88");	//NaN
Number("John");		//NaN
```

## 46.3 Number Methods

| Method       | Description                                         |
| :----------- | :-------------------------------------------------- |
| Number()     | Returns a number, converted from its argument       |
|              |                                                     |
| parseFloat() | Parses a string and returns a floating point number |
| parseInt()   | Parses a string and returns an integer              |

## 46.4 The Unary + Operator

​	The <b>unary + operator</b> can be used to convert a variable to a number:

```
let y = "5";	//y is a string
let x = +y;		//x is a number
```

​	If the variable cannot be converted, it will still become a number, but with the value <span style="color: red;">NaN</span>:

```
let y = "John";
let x = + y;	//NaN
```

## 46.5 Converting Numbers to Strings

​	The global method <span style="color: red;">String()</span> can convert numbers to strings.

​	It can be used on any type of numbers, literals, variables, or expressions:

```
String(x)			//returns a string from a number variable x
String(123)			//returns a string from a number literal 123
String(100 + 23)	//returns a string from a number from an expression
```

​	The Number method <span style="color: red;">toString()</span> does the same:

```
x.toString()
(123).toString()
(100 + 23).toString()
```

## 46.6 More Methods

​	In the chapter Number Methods, you will find more methods that can be used to convert numbers to strings:

| Method          | Description                                                  |
| :-------------- | :----------------------------------------------------------- |
| toExponential() | Returns a string, with a number rounded and written using exponential notation. |
| toFixed()       | Returns a string, with a number rounded and written with a specified number of decimals. |
| toPrecision()   | Returns a string, with a number written with a specified length |

## 46.7 Converting Dates to Numbers

​	The global method <span style="color: red;">Number()</span> can be used to convert dates to numbers:

```
d = new Date();
Number(d);
```

​	The date method <span style="color: red;">getTime()</span> does the same:

```
d = new Date();
d.getTime();
```

## 46.8 Converting Dates to Strings

​	The global method <span style="color: red;">String()</span> can convert dates to strings:

```
String(Date());
```

​	The Date method <span style="color: red;">toString()</span> does the same:

```
Date.toString();
```

​	In the chapter Date Methods, you will find more methods that can be used to convert dates to strings:

| Method            | Description                                       |
| :---------------- | :------------------------------------------------ |
| getDate()         | Get the day as a number (1-31)                    |
| getDay()          | Get the weekday a number (0-6)                    |
| getFullYear()     | Get the four digit year (yyyy)                    |
| getHours()        | Get the hour (0-23)                               |
| getMilliseconds() | Get the milliseconds (0-999)                      |
| getMinutes()      | Get the minutes (0-59)                            |
| getMonth()        | Get the month (0-11)                              |
| getSeconds()      | Get the seconds (0-59)                            |
| getTime()         | Get the time (milliseconds since January 1, 1970) |

## 46.9 Converting Booleans to Numbers

​	The global method <span style="color: red;">Number()</span> can also convert booleans to numbers:

```
Number(false);	//returns 0
Number(true);	//returns 1
```

## 46.10 Converting Booleans to Strings

​	The global method <span style="color: red;">String()</span> can convert booleans to strings:

```
String(false);	//return "false"
String(true);	//return "true"
```

​	The Boolean method <span style="color: red;">toString()</span> does the same:

```
false.toString();	//returns "false"
true.toString();	//returns "true"
```

## 46.11 Automatic Type Conversion

​	When JavaScript tries to operate on a "wrong" data type, it will try to convert the value to a "right" type. The result is not always what you expect:

```
5 + null;	//return 5
"5" + null;	//returns "5null"
"5" + 2;	//returns "52"
"5" - 2;	//returns 3
"5" * "2";	//10
```

## 46.12 Automatic String Conversion

​	JavaScript automatically calls the variable's <span style="color: red;">toString()</span> function when you try to "output" an object or a variable:

```
document.getElementById("demo").innerHTML = myVar;
/*
if myVar = {name:"Fjohn"} to "[object Object]"
if myVar = [1,2,3]	to "1,2,3"
if myVar = new Date() to "Fri April 14 2013 17:41:02 GMT..."
*/
```



# 47. JavaScript Bitwise Operations

## 47.1 Bitwise Operators

| Operator | Name                  | Description                                                  |
| :------- | :-------------------- | :----------------------------------------------------------- |
| &        | AND                   | Sets each bit to 1 if both bits are 1                        |
| \|       | OR                    | Sets each bit to 1 if one of two bits is 1                   |
| ^        | XOR                   | Sets each bit to 1 if only one of two bits is 1              |
| ~        | NOT                   | Inverts all the bits                                         |
| <<       | Zero fill left shift  | Shifts left by pushing zeros in from the right and let the leftmost bits fall off |
| >>       | Signed right shift    | Shifts right by pushing copies of the leftmost bit in from the left, and let the rightmost bits fall off |
| >>>      | Zero fill right shift | Shifts right by pushing zeros in from the left, and let the rightmost bits fall off |

<span style="font-size: 20px;">Examples</span>

| Operation | Result | Same as      | Result |
| --------- | ------ | ------------ | ------ |
| 5 & 1     | 1      | 0101 & 0001  | 0001   |
| 5 \| 1    | 5      | 0101 \| 0001 | 0101   |
| ~5        | 10*    | ~0101        | 1010*  |
| 5 << 1    | 10     | 0101 << 1    | 1010   |
| 5 ^ 1     | 4      | 0101 ^ 0001  | 0100   |
| 5 >> 1    | 2      | 0101 >> 1    | 0010   |
| 5 >>> 1   | 2      | 0101 >>> 1   | 0010   |

## 47.2 JavaScript Uses 32 bits Bitwise Operands

​	JavaScript stores numbers as 64 bits floating point numbers, but all bitwise operations are performed on 32 bits binary numbers.

​	Before a bitwise operation is performed, JavaScript converts numbers to 32 bits signed integers. After the bitwise operation is performed, the result is converted back to 64 bits JavaScript numbers.

<b>Note:</b>

​	The example above uses 4 bits unsigned binary numbers. Because of this ~5 returns 10.

​	Since JavaScript uses 32 bits signed integers, it will not return 10. It will return -6:

​	0000000000000000000000000101 (5)

​	1111111111111111111111111010 (-6)

​	A signed integer uses the leftmost bit as the minus sign.

## 47.3 Bitwise AND

​	When a bitwise AND is performed on a pair of bits, it returns 1 if both bits are 1.

## 47.4 Bitwise OR

​	When a bitwise OR is performed on a pair of bits, it returns 1 if one of the bits is 1.

## 47.5 Bitwise XOR

​	When a bitwise XOR is performed on a pair of bits, it returns 1 if the bits are different.

## 47.6 Bitwise AND & OR & NOT

​	Refer relative documents.

## 47.7 Bitwise Left Shift (<<)

​	This is a zero fill left shift.

## 47.8 Right Shift (>> & >>>)

​	<span style="color: red;">>></span> is a sign preserving right shift, and <span style="color: red;">>>></span> is a zero fill right shift.

## 47.9 Converting Decimal to Binary

​	Here is a function to convert:

```
function dec2bin(dec) {
	return (dec >>> 0).toString(2);
}
```

## 47.10 Converting Binary to Decimal

```
function bin2dec(bin) {
	return parseInt(bin, 2).toString(10);
}
```



# 48. JavaScript Regular Expressions

## 48.1 What Is a Regular Expression?

​	A regular expression is a sequence of characters that forms a <b>search pattern</b>.

​	When you search for date in a text, you can use this search pattern to describe what you are searching for.

​	A regular expression can be a single character, or a more complicated pattern. It can be used to perform all types of <b>text search</b> and <b>text replace</b> operations.

<span style="font-size: 20px;">Syntax</span>

`/pattern/modifiers`

## 48.2 Using String Methods

​	In JavaScript, regular expressions are often used with the two <b>string methods</b>: <span style="color: red;">search()</span> and <span style="color: red;">replace()</span>.

​	The <span style="color: red;">search()</span> method uses an expression to search for a match, and returns the position of the match. The <span style="color: red;">replace()</span> method returns a modified string where the pattern is replaced.

## 48.3 Using String search() With a Regular Expression

​	The <span style="color: red;">serach()</span> method searches a string for a specified value and returns the position of the match:

```
let text = "Visit W3Schools";
let n = text.search("W3S");
let n2 = text.search(/W3S/i);	//6
```

## 48.4 Using String replace() With a Regular Expression

​	The <span style="color: red;">replace()</span> method replaces a specified value with another value in a string:

```
let text = "Visit Microsoft!";
let result = text.replace("Micro", "W3S");
let result2 = text.replace(/micro/i, "W3S");
```

<span style="font-size: 20px;">Did You Notice?</span>

​	Regular expression arguments (instead of string arguments) can be used in the middles above. Regular expressions can make your search much more powerful (case insensitive for example).

## 48.5 Regular Expression Modifiers & Patterns

​	<b>Modifiers</b> can be used to perform case-insensitive more global searches:

| Modifiers | Description                                                  |
| --------- | ------------------------------------------------------------ |
| i         | Perform case-insensitive matching                            |
| g         | Perform a global match (find all matches rather than stopping after the first match) |
| m         | Perform multiline matching                                   |

​	<b>Brackets</b> are used to find a range of characters:

| Expression | Description                                     |
| ---------- | ----------------------------------------------- |
| [abc]      | Find any of the characters between the brackets |
| [0-9]      | Find any of the digits between the brackets     |
| (x\|y)     | Find any of the alternative separated with \|   |

​	<b>Metacharacters</b> are characters with a special meaning:

| Metacharacter | Description                                                  |
| ------------- | ------------------------------------------------------------ |
| \d            | Find a digit                                                 |
| \s            | Find a whitespace character                                  |
| \b            | Find a match at the beginning of a word like this: \bWORD, or at <br>the end of a word like this: WORD\b |
| \uxxxx        | Find the Unicode character specified by the hexadecimal number xxxx |

​	<b>Quantifies</b> define quuantities:

| Quantifies | Description                                                  |
| ---------- | ------------------------------------------------------------ |
| n+         | Matches any string that contains at least one n              |
| n*         | Matches any string that contains zero or more occurrences of n |
| n?         | Matches any string that contains zero or one occurrences of n |

## 48.6 Using the RegExp Object

### 48.6.1 Using test()

​	The <span style="color: red;">test()</span> method is a RegExp expression method.

​	It searches a string for a pattern, and returns true or false, depending on the result.

​	The following example searches a string for the character "e":

```
const pattern = /e/;
pattern.test("The best thing in life are free!");
//or:
/e/.test("The best things in life are free!");
```

### 48.6.2 Using exec()

​	The <span style="color: red;">exec()</span> method is a RegExp expression method.

​	It searches a string for specified pattern, and returns the found text as an object.

​	If no match is found, it returns an empty (null) object.

​	The following example searches a string for the character "e":

```
/e/.exec("The best things in life are free!");
```

```
const obj = /e/.exec("The best things in life are free!");
document.getElementById("demo").innerHTML =
"Found " + obj[0] + " in position " + obj.index + " in the text: " + obj.input;
//Result:
Found e in position 2 in the text: The best things in life are free!
```



# 49. JavaScript Operator Precedence

​	Operator precedence describes the order in which operations are performed in an alternative arithmetic expression. Multiplication (*) and division (/) have higher <b>precedence</b> than addition (+) and subtraction (-).

<p style="font-size: 22px; text-align: center;">Operator Precedence Values</p>

<p style="text-align: center;">Expression in parentheses are compute <b>before</b> the rest of the expression</p>

<p style="text-align: center;">Function are executed <b>before</b> the result is used in the rest of the expression</p>

| Val  | Operator | Description           | Example                   |
| ---- | -------- | --------------------- | ------------------------- |
| 18   | ( )      | Expression Grouping   | (100 + 50) * 3            |
| 17   | .        | Member Of             | person.name               |
| 17   | [ ]      | Member Of             | person["name"]            |
| 17   | ?.       | Optional Changing     | x ?. y                    |
| 17   | ( )      | Function Call         | myFunction()              |
| 17   | new      | New with Arguments    | new Date("June 5, 2022"); |
| 16   | new      | New without Arguments | new Date()                |

<p style="font-size: 22px; text-align: center;">Increment Operators</p>

<p style="text-align: center;">Potfix increments are executed <b>before</b> prefix increments</p>

| 15   | ++   | Postfix Increment | i++  |
| ---- | ---- | ----------------- | ---- |
| 15   | --   | Postfix Increment | i--  |
| 14   | ++   | Prefix Increment  | ++i  |
| 14   | --   | Prefix Increment  | --i  |

<p style="font-size: 22px; text-align: center;">NOT Operators</p>

| 14   | !    | Logical NOT | !(x == y) |
| ---- | ---- | ----------- | --------- |
| 14   | ~    | Bitwise NOT | ~x        |

<p style="font-size: 22px; text-align: center;">Unary Operator</p>

| 14   | +      | Unary Plus      | +x                 |
| ---- | ------ | --------------- | ------------------ |
| 14   | 1      | Unary Minus     | -x                 |
| 14   | typeof | Data Type       | typeof x           |
| 14   | void   | Evaluate Void   | void(0)            |
| 14   | delete | Property Delete | delete myCar.color |

<p style="font-size: 22px; text-align: center;">Arithmetic Operators</p>

<p style="text-align: center;">Exponentiations are executed <b>before</b> multiplications</p>

<p style="text-align: center;">Multiplicaions and divisions are executed <b>before</b> additions and subtractions</p>

| 13   | **   | Exponentiation     | 10 ** 2        |
| ---- | ---- | ------------------ | -------------- |
| 12   | *    | Multiplication     | 10 * 5         |
| 12   | /    | Division           | 10 / 5         |
| 12   | %    | Division Remainder | 10 % 5         |
| 11   | +    | Addition           | 10 + 5         |
| 11   | -    | Subtraction        | 10 - 5         |
| 11   | +    | Concatenation      | "John" + "Doe" |

<p style="font-size: 22px; text-align: center;">Shift Operators</p>

| 10   | <<   | Shift Left             | x << 2  |
| ---- | ---- | ---------------------- | ------- |
| 10   | >>   | Shift Right (signed)   | x >> 2  |
| 10   | >>>  | Shift Right (unsigned) | x >>> 2 |

<p style="font-size: 22px; text-align: center;">Relational Operations</p>

| 9    | in         | Property in Object | "PI" in Math       |
| ---- | ---------- | ------------------ | ------------------ |
| 9    | instanceof | Instance of Object | x instanceof Array |

<p style="font-size: 22px; text-align: center;">Comarison Operators</p>

| 9    | <    | Less than             | x < y      |
| ---- | ---- | --------------------- | ---------- |
| 9    | <=   | Less than or equal    | x <= y     |
| 9    | >    | Greater than          | x > y      |
| 9    | >=   | Greater than or equal | x >= Array |
| 8    | ==   | Equal                 | x == y     |
| 8    | ===  | Strict equal          | x === y    |
| 8    | !=   | Unequal               | x != y     |
| 8    | !==  | Strict unequal        | x !== y    |

<p style="font-size: 22px; text-align: center;">Bitwise Operators</p>

| 7    | &    | Bitwise AND | x & y  |
| ---- | ---- | ----------- | ------ |
| 6    | ^    | Bitwise XOR | x ^ y  |
| 5    | \|   | BitwiseOR   | x \| y |

<p style="font-size: 22px; text-align: center;">Logical Operators</p>

| 4    | &&   | Logical AND        | x && y   |
| ---- | ---- | ------------------ | -------- |
| 3    | \|\| | Logical OR         | x \|\| y |
| 3    | ??   | Nullish Coalescing | x ?? y   |

<p style="font-size: 22px; text-align: center;">Conditional (ternary) Operator</p>

| 2    | ? :  | Condition | (expression) ? "yes" : "no" |
| ---- | ---- | --------- | --------------------------- |

<p style="font-size: 22px; text-align: center;">Assignment Operators</p>

| 2    | =      | Simple Assignment         | x = y     |
| ---- | ------ | ------------------------- | --------- |
| 2    | :      | Colon Assignment          | x: 5      |
| 2    | +=     | Addition Assignment       | x += y    |
| 2    | -=     | Subtraction Assignment    | x -= y    |
| 2    | *=     | Multiplication Assignment | x *= y    |
| 2    | **=    | Exponentiation Assignment | x **= y   |
| 2    | /=     | Division Assignment       | x /= y    |
| 2    | %=     | Remainder Assignment      | x %= y    |
| 2    | <<=    | Left Shift Assignment     | x <<= y   |
| 2    | >>=    | Right Shift Assignment    | x >>= y   |
| 2    | >>>=   | Unsigned Right Shift      | x >>>= y  |
| 2    | &=     | Bitwise AND Assignment    | x &= y    |
| 2    | \|=    | Bitwise OR Assignment     | x \|= y   |
| 2    | ^=     | Bitwise XOR Assignment    | x ^= y    |
| 2    | &&=    | Logical AND Assignment    | x &= y    |
| 2    | \|\|=  | Logical OR Assignment     | x \|\|= y |
| 2    | =>     | Arrow                     | x => y    |
| 2    | yield  | Pause / Resume            | yield x   |
| 2    | yield* | Delegate                  | yield* x  |
| 2    | ...    | Spread                    | ... x     |
| 1    | ,      | Comma                     | x, y      |



# 50. JavaScript Errors

## 50.1 Throw, and Try...Catch...Finally

​	The <span style="color: red;">try</span> statement defines a code block to run (to try).

​	The <span style="color: red;">catch</span> statement defines a code block to handle any error.

​	The <span style="color: red;">finally</span> statement defines a code block to run regardless of the result.

​	The <span style="color: red;">throw</span> statement defines a custom error.

## 50.2 Errors Will Happen!

​	When executing JavaScript code, different errors can occur.

​	Errors can be coding errors made by the programmer, errors due to wrong input, and other unforeseeable things.

<p style="font-size: 20px;">Example</p>

​	In this example we misspelled "alert" as "adddlert" to deliberately produce an error:

```
<p id="demo"></p>
<script>
try {
	adddlert("Welcome guest!");
} catch(err) {
	document.getElementById("demo").innerHTML = err.message;
}
</script>
```

​	<b>Note:</b> JavaScript catches <b>adddlert</b> as an error, and executes the catch code to handle it.

## 50.3 try and catch

​	The <span style="color: red;">try</span> statement allows you to define a block of code to be tested for errors while it is being executed. The <span style="color: red;">catch</span> statement allows you to define a block of code to be executed, if an error occurs in the try block.

​	The JavaScript statements <span style="color: red;">try</span> and <span style="color: red;">catch</span> come in pairs:

```
try {
	//Block of code to try
} catch(err) {
	//Block of code to handle errors
}
```

## 50.4 Throws Errors

​	When an error occurs, JavaScript will normally stop and generate an error message. The technical term for this is: JavaScript will <b>throw an excepction (throw an error)</b>.

<b>Note:</b> JavaScript will actually create an <b>Error object</b> with two properties: <b>name</b> and <b>message</b>.

## 50.5 The throw Statement

​	The <span style="color: red;">throw</span> statement allows you to create a custom error. Technically you can <b>throw an expection (thorw an error)</b>. The exception can be a JavaScript <span style="color: red;">String</span>, a <span style="color: red;">Number</span>, a <span style="color: red;">Boolean</span> or an <span style="color: red;">Object</span>:

```
throw "Too big";	//throw a text
throw 500;			//throw a number
```

​	If you use <span style="color: red;">throw</span> together with <span style="color: red;">try</span> and <span style="color: red;">catch</span>, you can control program flow and generate custom error messages.

## 50.6 Input Validation Example

​	This example examines input. If the value is wrong, an exception (err) is thrown.

​	The exception (err) is caught by the catch statement and a custom error message is displayed:

```
<h3>JavaScript Errors:</h3>
<input id="demo17-1" type="text">
<button type="button" onclick="myFunction17()">Test Input</button>
<p id="demo17-2"></p>
<!-- JS code -->
function myFunction17() {
	const message = document.getElementById("demo17-2");
	message.innerHTML = "";
	let x = document.getElementById("demo17-1").value;
	try {
		if(x.trim() == "") throw "empty";
		if(isNaN(x)) throw "not a number";
		x = Number(x);
		if(x < 5) throw "too low";
		if(x > 10) throw "too high";
	} catch(err) {
		message.innerHTML = "Input is " + err;
	}
}
```

## 50.7 HTML Validation

​	The code above is just an example. Modern browsers will often use a combination of JavaScript and built-in HTML validation, using predefined validation rules defined in HTML attributes:

```
<input id="demo" type="number" min="5" max="10" step="1">
```

## 58.8 The finally Statement

​	The <span style="color: red;">finally</span> statement lets you execute code, after try and catch, regardless of the result:

```
function myFunction() {
	const message = document.getElementById("p01");
	message.innerHTML = "";
	let x = document.getElementById("demo").value;
	try {
		is(x.trim() == "") throw "is empty";
		if(isNaN(x)) throw "is not a number";
		x = Number(x);
		if(x > 10) throw "is too high";
		if(x < 5) throw "is too low";
	} catch(err) {
		message.innerHTML = "Erro: " + err + ".";
	} finally {
		document.getElemntById("demo").value = "";	//clear the input
	}
}
```

## 58.9 The Error Object

​	JavaScript has a built in error object that provides error information when an error occurs.

​	The error object provides tow useful properties: <b>name</b> and <b>message</b>.

### 58.9.1 Error Object Properties

| Property | Description                                 |
| :------- | :------------------------------------------ |
| name     | Sets or returns an error name               |
| message  | Sets or returns an error message (a string) |

### 58.9.2 Error Name Values

​	Six different values can be returned by the error name proeprty:

| Error Name     | Description                                  |
| :------------- | :------------------------------------------- |
| EvalError      | An error has occurred in the eval() function |
| RangeError     | A number "out of range" has occurred         |
| ReferenceError | An illegal reference has occurred            |
| SyntaxError    | A syntax error has occurred                  |
| TypeError      | A type error has occurred                    |
| URIError       | An error in encodeURI() has occurred         |

### 58.9.3 Eval Error

​	An <span style="color: red;">EvalError</span> indicates an error in the eval() function.

<b>Note:</b> Newer versions of JavaScript do not throw EvalError, Use SyntaxError instead.

### 58.9.4 Range Error

​	A <span style="color: red;">RangeError</span> is thrown if you use a number that is outside the range of legal values.

​	For example: You cannot set the number of significant digits of a number to 500:

```
let num = 1;
try {
	num.toPrecision(500);
} catch(err) {
	document.getElementById("demo").innerHTML = err.name;
}
```

### 58.9.5 Reference Error

​	A <span style="color: red;">ReferenceError</span> is thrown if you use (reference) a variable that has not been declared:

```
let x = 5;
try {
	x = y + 1;
} catch(err) {
	//...
}
```

### 58.9.6 Syntax Error

​	A <span style="color: red;">SyntaxError</span> is thrown if you try to evaluate code with a syntax error.

```
try {
	eval("alert('Hello)");	//Missing ' will produce an erro
} catch(err) {
	//...
}
```

### 58.9.7 Type Error

​	A <span style="color: red;">TypeError</span> is thrown if you use a value that is outside the range of expected types:

```
let num = 1;
try {
	num.toUpperCase();	//Cannot convert a number to upper case
} catch(err) {
	//...
}
```

### 58.9.8 URI (Uniform Resource Identifier) Error

​	A <span style="color: red;">URIError</span> is thrown if you use illegal characters in a URI function:

```
try {
	decodeURI("%%%");	//Cannot URI decode percent signs
} catch(err) {
	//...
}
```

### 58.9.9 Non-Standard Error Object Properties

​	Mozilla and Microsoft define some no-standard error object properties:

​	fileName, lineNumber, columnNumber, stack, description (Microsoft), number (Microsoft).

​	Do not use these properties in public web sites. They will not work in all browsers.



# 59. JavaScript Scope

​	Scope determines the accessibility (visibility) of variables.

​	JavaScript has 3 types of scope:

* Block scope
* Function scope
* Global scope

## 59.1 Block Scope

​	Before ES6 (2015), JavaScript had only <b>Global Scope</b> and <b>Function Scope</b>.

​	ES6 introduced two important new JavaScript keywords: <span style="color: red;">let</span> and <span style="color: red;">const</span>.

​	These two keywords provide <b>Block Scope</b> in JavaScript.

​	Variables declared inside a { } block cannot be accessed from outside the block:

```
{
	let x = 3;
}
```

​	Variables declared with the <span style="color: red;">var</span> keyword can NOT have block scope.

​	Variables declared inside a { } block can be accessed from outside the block:

```
{
	var x = 2;	//Can be accessed outside this block
}
```

## 59.2 Local Scope

​	Variables declared within a JavaScript function, become <b>LOCAL</b> to the function:

```
function myFunction() {
	let carName = "Volvo";	//local 
}
```

## 59.3 Function Scope

​	JavaScript has function scope: Each function creates a new scope.

​	Variables defined inside a function are not accessible from outside the function.

​	Variables declared with <span style="color: red;">var</span>, <span style="color: red;">let</span>, and <span style="color: red;">const</span> are quite similar when declared inside a function.

​	They all have <b>Function Scope</b>:

```
function myFunction() {
	var carName1 = "Volvo";
	let carName2 = "BWM";
	const carName3 = "BYD";
}
```

## 59.4 Global Scope

​	Variables declared <b>Globally</b> (outside any function) have <b>Global Scope</b>.

​	<b>Global</b> variables can be accessed from anywhere in a JavaScript program.

​	Variables declared with <span style="color: red;">var</span>, <span style="color: red;">let</span>, and <span style="color: red;">const</span> are quite similar when declared outside a block.

## 59.5 JavaScript Variables

​	In JS, objects and functions are also variables. Scope determines the accessibility of variables, objects, and functions from different parts of the code.

## 59.6 Automatically Gloabl

​	If you assign a value to a variable that has not be declared, it will automatically become a <b>GLOBAL</b> variable.

​	This code example will declare a global variable <span style="color: red;">carName</span>, even if the value is assigned inside a function:

```
myFunction();
function myFunction() {
	carName = "Volvo";
}
```

## 59.7 Strict Mode

​	All modern browsers support running JavaScript in "Strict Mode".

​	You will learn more about it in a later chapter.

<b>Note:</b> In "Strict Mode", undeclared variables are not automatically global.

## 59.8 Global Variables in HTML

​	With JavaScript, the global scope is the JavaScript environment. In HTML, the global scope is the window object. Global variables defined with the<span style="color: red;">var</span> keyword belong to the window object:

```
var carName = "Volvo";
document.getElementById("demo").innerHTML = "I can display " + window.carName;
```

​	But global variables defined with the <span style="color: red;">let</span> keyword do not belong to the window object:

```
let carName = "Volvo";
document.getElementById("demo").innerHTML = "I can display " + window.carName;
//Result: I can display undefined
```

<b>Warining</b>

​	Do NOT create global variables unless you intend to. Your global variables (or functions) can overwrite window variables (or functions). Any function, including the window object, can overwrite your global variables and function.

## 59.9 The Lifetime of JavaScript Variables

​	The lifetime of a JS variable starts when it is declared.

​	Function (local) variables are deleted when the function is completed. In a web browser, global variables are deleted when you close the browser window (or tab).



# 60. JavaScript Hoisting

​	Hoisting is JavaScript's default behavior of moving declarations to the top.

## 60.1 Declarations are Hoisted

​	In JS, a variable can be declared after it has been used. In other words; a variable can be used before it has been declared.

```
x = 5;
elem = document.getElementById("demo");
elem.innerHTML = x;
var x;			//Declare x
```

## 60.2 The let and const Keywords

​	Variables defined with <span style="color: red;">let</span> and <span style="color: red;">const</span> are hoisted to the top of the block, but not initialized.

​	Meaning: The block of code is aware of the variable, but it cannot be used until it has been declared. Using a <span style="color: red;">let</span> variable before it is declared will result in a <span style="color: blue;">RferenceError</span>.

​	The variable is in a "temporal dead zone" from the start of the block until it is declared:

```
/*Result in a ReferenceError*/
try {
	carName = "Saab";
	let carName = "Volvo";
} catch(err) {
	document.getElementById("demo").innerHTML = err;
}
```

​	Using a <span style="color: red;">const</span> variable before it is declared, is a syntax error, so the code will simply not run:

```
carName = "Volvo";
const carName;
```

## 60.3 JavaScript Initializations are Not Hoisted

​	JavaScript only hoists declarations, not initializations. 

```
var x = 5;
var y = 7;
elem = docuemen.getElementById("demo");
elem.innerHTML = x + " - " + y;
//y is undefined:
var x = 5;
elem = document.getElementById("demo");
elem.innerHTML = x + " - " + y;
var y = 7;
```

​	Why y is undefined in the last example? -> This is because only the declaration (var y), not the initialization (=7) is hoisted to the top.

​	Because of hoisting, y has been declared before it it used, but because initialization are not hoisted, the value of y is undefined:

```
var x = 5;	//Initialize x
var y;		//Declare y
elem = docuemnt.getElementById("demo");
elem.innerHTML = x + " - " + y;		//y is undefined!
y = 7;		//Assign 7 to y
```

## 60.4 Declare Your Variables At the Top!

​	Hoisting is (to many developers) an unknown or overlooked behavior of JavaScript.

​	If a developer doesn't understand hosting, programs may contain bugs (errors).

​	To avoid bugs, always declare all variables at the beginning of every scope.



# 61. JavaScript Use Strict

​	<span style="color: red;">"use strict";</span> Defines that JavaScript code should be executed in "strict mode".

## 61.1 The "use strict" Driective

​	The <span style="color: red;">"use strict"</span> directive was new in ECMASript version 5.

​	It is not a statement, but a literal expression, ignored by earlier versions of JavaScript.

​	The purpose of "use strict" is to indicate that the code should be executed in "strict mode", with strict mode, you can not, for example, use undefined variables.

## 61.2 Declaring Strict Mode

​	Strict mode is declared by adding <span style="color: red;">"use strict";</span> to the beginning of a script or a function.

```
"use strict";
x = 3.14;		//Activate debuggin in browser (F12) to see the error (in consle)
myFunction();
function myFunction() {
	"use strict";
	y = 3.15;
}
```

## 61.3 The "use strict"; Syntax

​	The syntax, for declaring strict mode, was designed to be compatible with older versions of JavaScript. Compiling a numeric literal (4 + 5;) or a string linter ("John Doe";) in a JavaScript program has no side effects. It simply compiles to a non existing variable and dies.

​	So "use strict"; only matters to new compilers that "understand" the meaning of it.

## 61.4 Why Strict Mode?

​	Strict mode makes it easier to write "secure" JavaScript.

​	Strict mode changes previously accepted "bad syntax" into real errors.

​	As an example, in normal JavaScript, mistyping a variable name creates a new global variable. In strict mode, this may throw an error, making it impossible to accidentally create a global variable.

​	In normal JavaScript, a developer will not receive any error feedback assigning values to non-writable properties.

​	In strict mode, any assignment to a non-writable property, a getter-only property, a non-existing property, a non-existing variable, or a non-existing object, will throw an error.

## 61.5 Not Allowed in Strict Mode

1. Using a variable, without declaring it.

```
"use strict";
x = 3.14;
```

2. Using a object, without declaring it.

```
"use strict";
x = {p1: 10, P2: 20};
```

3. Deleting a variable (or object).

```
"use strict";
let x = 3.14;
delete x;
```

4. Deleting a function.

```
"use strict";
function x(p1, p2) {};
delete x;
```

5. Duplicating a parameter name.

```
"use strict";
function x(p1, p1) {}''
```

6. Octal numeric literals.

```
"use strict";
let x = 010;		//This will cause an error
```

7. Octal escape characters.

```
"use strict";
let x = "\010";
```

8. Writing to a read-only property.

```
"use strict";
const obj = {};
Object.defineProperty(obj, "x", {value: 0, writable: false});
obj.x = 3.14;		//This will cause an error
```

9. Deleting an undeletable property.

```
"use strinct";
delete Object.prototype;
```

10. The word <span style="color: red;">eval/arguments</span>  used as a variable.

```
"use strinct";
let eval = 3.14;
let arguments = 6.28;
```

11. The <span style="color: red;">with</span> statement.

```
"use strict";
with (Math){x = cos(2)};
```

12. For security reasons, <span style="color: red;">eval()</span> is not allowed to create variables in the scope from which it was called:

```
"use strict";
eval ("x = 2");
alert(x);		//This will cause an error
```

​	eval() cannot declare a variable using the var/let keyword either:

```
"use strict";
eval("var x = 2");	//or eval("let x = 2");
alert(x);		//Cause an error
```

13. The <span style="color: red;">this</span> keyword in functions behaves differently in strict mode. The <span style="color: red;">this</span> keyword refers to the object that called the function. If the object is not specified, functions in strict mode will return <span style="color: red;">undefined</span> and function in normal mode will return the global object (window) :

```
"use strict";
function myFunction() {
	alert(this);		//alert "undefined"
}
myFunction();
```

14. Future Proof!

​	Keywords reserved for future JavaScript versions can NOT be used as variable names in strict mode.

​	These are:

* implements, interface, let, package, private, protected, public, static, yield.

```
"use strict";
let public = 1500;
```

<span style="color: blue; font-size: 20px;">Watch Out!</span>

​	The "use strict" directive is only recognized at the <b>beginning</b> of a script or a function.



# 62. The JavaScript <b>this</b> Keyword

Example:

```
const person = {
	firstName: "John",
	lastName: "Doe",
	id: 5004,
	fullName: function() {
		return this.firstName + " " + this.lastName;
	}
};
```

## 62.1 What is <b>this</b>?

​	In JavaScript, the <span style="color: red;">this</span> keyword refers to an <b>object</b>.

​	<b>Which</b> object depends on how <span style="color: red;">this</span> is being invoked (used or called).

| In an object method, `this` refers to the **object**.        |
| ------------------------------------------------------------ |
| Alone, `this` refers to the **global object**.               |
| In a function, `this` refers to the **global object**.       |
| In a function, in strict mode, `this` is `undefined`.        |
| In an event, `this` refers to the **element** that received the event. |
| Methods like `call()`, `apply()`, and `bind()` can refer `this` to **any object**. |

<b>Note:</b> <span style="color: red;">this</span> is not a variable, it is a keyword, you cannot change the value of <span style="color: red;">this</span>.

 ## 62.2 this in a Method

​	As above example shows, when used in an object method, <span style="color: red;">this</span> refers to the <b>object</b>.

## 62.3 this Alone

​	When used alone, <span style="color: red;">this</span> refers to the <b>global object</b>. Because <span style="color: red;">this</span> is running in the global scope.

​	In a browser window the global object is <span style="color: red;">[object Window]</span>.

```
let x = this;
```

​	In <b>strict mode</b>, when used alone, <span style="color: red;">this</span> also refers to the <b>global object</b>.

## 62.4 this in a Function (Default)

​	In a function, the <b>global object</b> is the default binding for<span style="color: red;"> this</span>.

​	In a browser window the global object is <span style="color: red;">[object Window]</span>.

```
function myFunction() {
	return this;		//[object Window]
}
```

 ## 62.5 this in a Function (Strict)

​	JavaScript <b>strict mode</b> does not allow default binding.

​	So, when used in a function, in strict mode, <span style="color: red;">this</span> is <span style="color: red;">undefined</span>.

```
"use strict";
function myFunction() {
	return this;		//undefined
}
```

## 62.6 this in Event Handlers

​	In HTML event handlers, <span style="color: red;">this</span> refers to the HTML element that received the event:

```
<button onclick="this.style.display='none'">
Click to Remove mw!
</button>
```

## 62.7 Object Method Binding

​	In these examples (## 61.2), <span style="color: red;">this</span> is the <b>person object</b>:

```
const person = {
	firstName: "John",
	lastName: "Doe",
	id: 5004,
	fullName: function() {
		return this;
	}
};
```

## 62.8 Explicit Function Binding

​	The <span style="color: red;">call()</span> and <span style="color: red;">apply()</span> methods are predefined JavaScript methods.

​	They can both be used to call an object method with another object as argument.

​	The example below calls person1.fullName with person2 as an argument, <b>this</b> refers to person2, even if fullName is a method of person1:

```
const person1 = {
	fullName: function() {
		return this.firstName + " " + this.lastNam;
	}
};
const person2 = {
	firstName: "John",
	lastName: "Doe",
};
person1.fullName.call(person);
```

## 62.9 Function Borrowing

​	With the <span style="color: red;">bind()</span> method, an object can borrow a method from another object.

​	This example creates 2 objects (person and member).

​	The member object borrows the fullname method from the person object:

```
const person = {
	firstName: "John",
	lastName: "Doe",
	fullName: function() {
		return this.fristName + " " + this.lastName;
	}
}
const member = {
	firstName: "Hege",
	lastName: "Nilsen",
}
let fullName = person.fullName.bind(member);
fullName();				//return "Hege Nilsen";
```

## 62.10 This precedence

​	To determine which object <span style="color: red;">this</span> refers to; use the following precedence of order:

| Precedence | Object             |
| ---------- | ------------------ |
| 1          | bind()             |
| 2          | apply() and call() |
| 3          | Object method      |
| 4          | Global scope       |

​	Ask yourself: Is <span style="color: red;">this</span> in a function being called using bind()? Is <span style="color: red;">this</span> in a function being called using apply()? Is <span style="color: red;">this</span> in a function being called using call()? Is <span style="color: red;">this</span> in an object function (method)? And is <span style="color: red;">this</span> in a function in the global scope?



# 63. JavaScript Arrow Function

​	Arrow functions were introduced in ES6.

​	Arrow functions allow us to write shorter function syntex:

```
let myFunction = (a, b) => a * b;
```

```
//Before Arrow:
hello = function() {
	return "Hello World";
}
//With Arrow Function
hello = () => {
	return "Hello World";
}
```

​	It gets shorter! If the function has only one statement, and the statement returns a value, you can remove the brackets and the <span style="color: red;">return</span> keyword:

```
hello = () => "Hello World";
```

​	If you have parameters, you pass them inside the parentheses:

```
hello = (val) => "Hello " + val;
```

​	In fact, if you have only one parameter, you can skip the parentheses as well:

```
hello = val => "Hello" + val;
```

## 63.1 What About this?

​	The handling of <span style="color: red;">this</span> is also different in arrow functions compared to regular functions.

​	In short, with arrow functions there are no binding of <span style="color: red;">this</span>.

​	In regular functions the <span style="color: red;">this</span> keyword represented the object that called the function, which could be the window, the document, a button or whatever.

​	With arrow functions the <span style="color: red;">this</span> keyword always represents the object that defined the arrow function.

```
//With a regular function "this" represents the object that calls the function:
hello = function() {
	document.getElementById("demo").innerHTML += this;
}
window.addEventListener("load", hello);	//window object calls the funcion
document.getElementById("btn").addEventListener("click", hello);//button object calls the function
```

```
//With an arrow function "this" represents the owner of the function
hello = () => {
	document.getElementById("demo").innerHTML += this;
}
window.addEventListener("load", hello);
document.getElementById("btn").addEventListener("click", hello);
```

​	The first example returns two different objects (window and button), and the second example returns the window object twice, <span style="color: blue;"> because the window object is the "owner" of the function</span>.



# 64. JavaScript Classes

​	ECMAScript 2015, also known as ES6, introduced JavaScript Classes.

​	JavaScript Classes are templates for JavaScript Objects.

## 64.1 Class Syntax

​	Use the keyword <span style="color: red;">class</span> to create a class.

​	Always add a method named <span style="color: red;">constructor()</span> :

```
class ClassName {
	constructor() { ... }
}
```

<b>Note:</b> A JavaScript class is <b>not</b> an object. It is a <b>template</b> for JavaScript objects.

## 64.2 Using a Class

​	When you have a class, you can use the class to create objects:

```
class Car {
	constructor(name, year) {
		this.name = name;		//Do not need to declare name elsewhere
		this.year = year;
	}
}
const myCar1 = new Car("Ford", 2014);
const myCar2 = new Car("Audi", 2019);
```

## 64.3 The Constructor Method

​	The constructor method is a special method:

* It has to have the exact name "constructor"
* It is executed automatically when a new object is created
* It is used to initialize object properties

​	If you do not define a constructor method, JavaScript will add an empty constructor method.

## 64.4 Class Methods

​	Class methods are created with the same syntax as object methods.

​	Use the keyword <span style="color: red;">class</span> to create a class, add a <span style="color: red;">constructor()</span> method, and then and any number of methods:

```
class ClassName {
	constructor() {...}
	method_1() {...}
	method_2() {...}
	//...
}
```



# 65. JavaScript Modules

## 65.1 Modules

​	JavaScript modules allow you to break up your code into separate files.

​	This makes it easier to maintain a code-base.

​	Modules are imported from external files with the <span style="color: red;">import</span> statement.

​	Modules also rely on <span style="color: red;">type="module"</span> in the <script> tag.

```
<script type="module">
import message from "./message.js";
</script>
```

## 65.2 Export 

​	Modules with <b>functions</b> or <b>variables</b> can be stored in any external file.

​	There are two types of exports: <b>Name Exports</b> and <b>Default Exports</b>.

### 65.2.1 Named Exports

​	Let us create a file named <span style="color: red;">person.js</span>, and fill it with the things we want to export.

​	You can create named exports two ways. In-line individually, or all at once at the bottom (similar the external keyword in C ?).

1. In-line individually

```
//person.js
export const name = "Jesse";
export const age = 40;
```

2. All at once at the bottom

```
const name = "Jesse";
const age = 40;
export {name, age};
```

### 65.2.2 Default Exports

​	Let us create another file, name <span style="color: red;">message.js</span>, and use it for demonstrating default export.

​	You can only have on default export in a file.

```
const message = () => {
	const name = "Jesse";
	const age = 20;
	return name + " is " + age + " years old.";
}
export default message;
```

## 65.3 Import

​	You can import modules into a file in two ways, based on if they are named exports or default exports.

​	Named exported are constructed using curly braces. Default exports are not.

1. Import from named exports

```
import {name, age} from "./person.js";
```

2. Import from default exports

```
import message from "./message.js";
```

<b>Note:</b>

​	Modules only word with the HTTP(s) protocol.

​	A web-page opened via the file:// protocol cannot use import/export.



## 66. JavaScript JSON

​	JSON is a format for storing and transporting data.

​	JSON is often used when data is sent from a server to a web page.

## 66.1 What is JSON?

* JSON stands fro JavaScript Object Notaion
* JSON is a lightweight data interchange format
* JSON is language independent*
* JSON is "self-describing" and easy to undersant

 	* The JSON syntex is derived from JavaScript object notation syntax, but the JSON format is text only. Code for reading and generating JSON data can be written in any programming language.

## 66.2 JSON Example

​	This JSON syntax defines an empolyees object: an array of 3 employee records (objects):

```
{
"employees":[
	{"firstName":"John", "lastName":"Doe"},
	{"firstName":"Anna", "lastName":"Smith"},
	{"firstName":"Peter", "lastName":"Jones"}
]
}
```

## 66.3 The JSON Format Evaluates to JavaScript Objects

​	The JSON format is syntactically identical to the code for creating JavaScript objects.

​	Because of this similarity, a JavaScript program can easily convert JSON data into native JavaScript objects.

## 66.4 JSON Syntax Rules

* Data is in name/value paris
* Data is separated by commas
* Curly braces hold objects
* Square brackets hold arrays

## 66.5 JSON Date - A Name and a Value

​	JSON data is written as name/value pairs, just like JavaScript object properties.

​	A name/value pair consists of a field name (in double quotes), followed by a colon, followed by a value:

```
"firstName":"John"
```

<b>Note:</b> JSON names requires double quotes. JavaScript names do not.

## 66.6 JSON Objects

​	JSON objects are written inside curly braces.

​	Just like in JavaScript, objects can contain multiple name/value paris:

```
{"firstName":"John", "lastName":"Doe"}
```

## 66.7 JSON Arrays

​	JSON arrays are written inside square brackets. Just like in JavaScript, an array can contain objects:

```
"employees": [
	{"firstName":"John", "lastName":"Doe"},
	{"firstName":"Anna", "lastName":"Smith"}
]
```

## 66.8 Converting a JSON Text to a JavaScript Object

​	A common use of JSON is to readd data from a web server, and display the data in a web page.

​	For simplicity, this can be demonstrated using a string as input.

​	First, create a JavaScript string containing JSON syntx:

```
let text = '{"employees": [' +
	'{"firstName":"John", "lastName":"Doe"},' +
	'{"firstName":"Anna", "lastName":"Smith"},' +	//Here is a redundant comma
	']}';
```

​	Then, use the JavaScript built-in function JSON.parse() to convert the string into a JavaScript object:

```
const obj = JSON.parse(text);
```

​	Finally, use the new JavaScript object in your page:

```
<p id="demo"></p>
<script>
document.getElementById("demo").innerHTML = 
obj.employees[1].firstName + " " + obj.empolyees[1].lastName;
</script>
```

​	<b>Note:</b> You can read more about JSON in JSON turorial.



## 67. JavaScript Debugging

​	Errors can (will) happen, every time you write some new computer code.

## 67.1 Code Debugging

​	Programming code might contain syntax errors, or logical errors.

​	Many of these error are difficult to diagnose.

​	Often, when programming code contains errors, nothing will happen. There are no error messages, and you will no indications where to search for errors. 

​	Searching for (and fixing) errors in programming code is called code debugging. Below is a example, debug when the text has a redundant comma:

```
var obj;
try {
	obj = JSON.parse(text);
} catch(err) {
	alert(err);
}
```

## 67.2 JavaScript Debuggers

​	Debugging is not easy. But fortunately, all modern browsers have a built-in JavaScript debugger. Built-in debuggers can be turned on and off, forcing errors to be reported to the user.

​	With a debugger, you can also set breakpoints (places where code execution can be stopped), and examine variables while the code is executing.

​	Normally (otherwise follow the steps at the bottom of this page), you activate debugging in your browser with the F12 key, and select "Console" in the debugger menu.

## 67.3 The console.log() Method

​	If your browser supports debugging, you can use <span style="color: red;">console.log()</span> to display JavaScript values in the debugger window:

```
<script>
a = 5;
b = 6;
c = a + b;
console.log(c);
</script>
```

## 67.4 Setting Breakpoints

​	In the debugger window, you can set breakpoints in the JavaScript code.

​	At each breakpoint, JavaScript will stop executing, and let you examine JavaScript values.

​	After examining values, you can resume the execution of code (typically with a play button).

<img src="img/breakpoint.jpg">

## 67.5 The debugger Keyword

​	The <span style="color: red;">debugger</span> keyword stops the execution of JavaScript, and calls (if available) the debugging function. This has the same function as setting a breakpoint in the debugger. If no debugging is available, the debugger statement has no effect. With the debugger turned on, this code will stop executing before it executes the third line:

```
let x = 15 * 5;
debugger;
document.getElementById("demo").innerHTML = x;
```

## 67.6 Major Browser's Debugging Tools

​	Omitted.



# 68. JavaScript Style Guide

​	Always use the same coding conventions for all your JavaScript projects.

## 68.1 Coding Conventions

​	Coding conventions are <b>style guidelines for programming</b>. They typically cover:

* Naming and declaration rules for variables and functions.
* Rules for the use of white space, indentation, and comments.
* Programming practices and principles.

​	Coding conventions <b>secure quality</b>:

* Improve code readability
* Make code maintenance easier

​	Coding conventions can be documented rules for teams to follow, or just be your individual coding practice.

## 68.2 Variable Names

​	At W3schools we use <b>camelCase</b> for identifier names (variables and functions).

​	All names start with a <b>letter</b>.

​	At the bottom of this page, you will find a wider discussion about naming rules:

```
firstName = "John";
lastName = "Doe";
price = 10.2;
tax = 0.02;
fullPrice = price + (price * tax);
```

## 68.3 Spaces Around Operators

​	Always put spaces around operators (= + - / *), and after commas:

```
let x = y + 2;
const myArray = ["Volov", "Saab", "BYD"];

```

## 68.4 Code Indentation

​	Always use 2 spaces for indentation of code blocks:

```
function toCelsius(fahreheit) {
  return ( 5 / 9) * (fahreheit - 32);
}
```

​	<b>Note:</b> Do not use tabs (tabulators) for indentation. Different editors interpret tabs differently.

## 68.5 Statement Rules

​	General rules for simple statements:

* Always end a simple with a semicolon.

```
const cars = ["BYD", "BWM"];
const person = {
	firstName: "John",
	lastName:"Doe",
};
```

​	General rules for complex (compound) statements:

* Put the opening bracket at the end of the first line
* Use one space before the opening bracket
* Put the closing bracket on a new line, without leading spaces
* Do not end a complex statement with a semicolon

```
function toCelsius(fahrenheit) {
	retrn (5 / 9) * (fahrenheit - 32);
}
```

## 68.6 Object Rules

​	General rules for object definitions:

* Place the opening bracket on the same line as the object name
* Use colon plus one space between each property and its value
* Use quotes around string values, not around numeric values
* Do not add a comma after the last property-value pair
* Place the closing bracket on a new line, without leading spaces
* Always end an object definition with a semicolon

```
const person = {
  firstName: "John",
  lastName: "Doe",
  age: 50,
  eyeColor: "blue"
};
```

​	Short objects can be written compressed, on one line, using spaces only between properties:

```
const person = {firstName:"John", lastName:"Doe", age:50, eyeColor:"blue"};
```

## 68.7 Line Length < 80

​	For readability, avoid lines longer than 80 characters.

​	If a JavaScript statement does not fit on one line, the best place to break it, is after an operator or a comma:

```
document.getElementById("demo").innerHTML =
"Hello Dolly.";
```

## 68.8 Naming Conventions

​	Always use the same naming convention for all your code. For example:

* Variable and function names written as <b>camelCase</b>
* Global variables written in <b>UPPERCASE</b> (We don't, but it's quite common)
* Constants (like PI) written in <b>UPPERCASE</b>

​	Should you use <b>hyp-hens</b>, <b>camelCase</b>, or <b>under_scores</b> in variable names?

​	This is a question programmers often discuss. The answer depends on who you ask:

<b>Hyphens in HTML and CSS</b>:

​	HTML5 attributes can start with data- (data-quantity, date-price).

​	CSS uses hyphens in property-names (font-szie).

<b>Note:</b> Hyphens can be mistaken as subtraction attempts, so they are not allowed in JavaScript names.

<b>Underscores:</b>

​	Many programmers prefer to use underscores (data_of_birth), especially in SQL databases.

​	Underscores are often used in PHP documentation.

<b>PascalCase:</b>

​	PascalCase is often preferred by C programmers.

<b>camelCase:</b>

​	camelCase is used by JavaScript itself, by jQuery, and other JS libraries.

## 68.9 Accessing HTML Elements

​	A consequence of using "untidy" HTML styles, might result in JavaScript errors.

​	These two JavaScript statements will produce different results:

```
const obj = getElementById("Demo");
cosnt obj = getElementById("demo");
```

​	If possible, use the same naming convention in THML.

## 68.10 File Extensions

​	HTML files should have a <b>.html</b> extension (<b>.html</b> is allowed).

​	CSS files should have a <b>.css</b> extension.

​	JavaScript files should have a <b>.js</b> extension.

## 68.11 Use Lower Case File Names

​	Most web servers (Apache, Unix) are case sensitive about file names:

​	london.jpg cannot be accessed as London.jpg.

​	Other web servers (Microsoft, IIS) are not case sensitive:

​	london.jpg can be accessed as London.jpg or london.jpg.

​	If you use a mix of upper and lower case, you have to be extremely consistent. If you move from a case insensitive, to a case sensitive server, even small errors can break your web site.

​	To avoid these problems, always use lower case file names (if possible).

## 68.12 Performance

​	Coding conventions are not used by computers. Most rules have little impact on the execution of programs. Indentation and extra spaces are not significant in small scripts.

​	For code in development, readability should be preferred. Larger production scripts should be minimized.



# 69. JavaScript Best Practices

​	Avoid global variables, avoid <span style="color: red;">new</span>, avoid <span style="color: red;">==</span>, avoid <span style="color: red;">eval()</span>

## 69.1 Avoid Global Variables

​	Minimize the use of global variables. This includes all data types, objects, and functions. Global variables and functions can be overwritten by other scripts. Use local variables instead, and learn how to use closures.

## 69.2 Always Declare Local Variables

​	All variables used in a function should be declared as <b>local</b> variables.

​	Local variables <b>must</b> be declared with the <span style="color: red;">var</span>, the <span style="color: red;">let</span>, or the <span style="color: red;">const</span> keyword, otherwise they will become global variables.

## 69.3 Declarations on Top

​	It is a good coding practice to put all declarations at the top of each script or function. This wil:

* Give cleaner code
* Provide a single place to look for local variables
* Make it easier to avoid unwanted (implied) global variables
* Reduce the possibility of unwanted re-declarations

## 69.4 Initialize Variables

​	It is a good coding practice to initialize variables when you declare them. This will:

* Given cleaner code
* Provide a single place to initialize variables
* Avoid undefined values

```
let firstName = "";
let price = 0;
const myArray = [];
```

## 69.5 Declare Objects & Arrays with const

​	Declaring objects with const will prevent any accidental change of type:

```
let car1 = {type:"Fiat", model:"500"};
car1 = "Fiat";		//changes object to string
const car2 = {type:"Fiat", model:"500"};
car2 = "Fiat";		//Not possible
let persons = ["John", "Anna"];
persons = 3;		//Changes array to number
const persons2 = ["John"];
persons2 = 3;		//Not possible
```

## 69.6 Don't Use new Object()

* Use <span style="color: red;">""</span> instead of <span style="color: red;">new String()</span>
* Use <span style="color: red;">0</span> instead of <span style="color: red;">new Number()</span>
* Use <span style="color: red;">false</span> instead of <span style="color: red;">new Boolean()</span>
* Use <span style="color: red;">{}</span> instead of <span style="color: red;">new Object()</span>
* Use <span style="color: red;">[]</span> instead of <span style="color: red;">new Array()</span>
* Use <span style="color: red;">/()/</span> instead of <span style="color: red;">new RegExp()</span>
* Use <span style="color: red;">function () {}</span> instead of <span style="color: red;">new Function()</span>

```
let x1 = "";             // new primitive string
let x2 = 0;              // new primitive number
let x3 = false;          // new primitive boolean
const x4 = {};           // new object
const x5 = [];           // new array object
const x6 = /()/;         // new regexp object
const x7 = function(){}; // new function object
```

## 69.7 Beware of Automatic Type Conversions

​	JavaScript is loosely typed. A variable can contain all data types. A variable can change its data type:

```
let x = "Hello";
x = 5;
```

​	Beware that numbers can accidentally be converted to strings or <span style="color: red;">NaN</span>. When doing mathematical operation, JavaScript can convert numbers to strings:

```
let x = 5 + 7;       // x.valueOf() is 12,  typeof x is a number
let x = 5 + "7";     // x.valueOf() is 57,  typeof x is a string
let x = "5" + 7;     // x.valueOf() is 57,  typeof x is a string
let x = 5 - 7;       // x.valueOf() is -2,  typeof x is a number
let x = 5 - "7";     // x.valueOf() is -2,  typeof x is a number
let x = "5" - 7;     // x.valueOf() is -2,  typeof x is a number
let x = 5 - "x";     // x.valueOf() is NaN, typeof x is a number
```

​	Subtracting a string from a string, does not generate an error but returns <span style="color: red;">NaN</span>.

## 69.8 Use === Comparison

​	The <span style="color: red;">==</span> comparison operator always converts (to matching types) before comparison, the <span style="color: red;">===</span> operator forces comparison of values and type.

```
0 == "";        // true
1 == "1";       // true
1 == true;      // true

0 === "";       // false
1 === "1";      // false
1 === true;     // false
```

## 69.9 Use Parameter Defaults

​	If a function is called with a missing argument, the value of the missing argument is set to <span style="color: red;">undefined</span>. Undefined values can break your code. It is a good habit to assign default values to arguments:

```
function myFunction(x, y) {
  if (y === undefined) {
    y = 0;
  }
}
```

​	ECMAScript 2015 allows <span style="color: blue;">default parameters in the function definition</span>:

```
function (a=1, b=1) { /*function code*/ }
```

## 69.10 End Your Switches with Defaults

​	Always end your <span style="color: red;">switch</span> statements with a <span style="color: red;">default</span>. Even if you think there is no need for it:

```
switch (new Date().getDay()) {
  case 0:
    day = "Sunday";
    break;
  case 1:
    day = "Monday";
    break;
  case 2:
    day = "Tuesday";
    break;
  case 3:
    day = "Wednesday";
    break;
  case 4:
    day = "Thursday";
    break;
  case 5:
    day = "Friday";
    break;
  case 6:
    day = "Saturday";
    break;
  default:
    day = "Unknown";
}
```

## 69.11 Avoid Numbers, String, and Boolean as Objects

​	Always treat numbers, strings, or booleans as primitive values. Not as objects.

​	Declaring these types as objects, slows down execution speed, and produce nasty side effects.

```
let x = new String("John");             
let y = new String("John");
(x == y) // is false because you cannot compare objects.
```

## 69.12 Avoid Using eval()

​	The <span style="color: red;">eval()</span> function is used to run text as code. In almost all cases, it should not be necessary to use it. Because it allows arbitrary code to be run, it also represents a security problem.



# 70. JavaScript Common Mistakes

## 70.1 Accidentally Using the Assignment Operator

​	JavaScript programs may generate unexpected results if a programmer accidentally uses an assignment operator (<span style="color: red;">=</span>), instead of a comparison operator (<span style="color: red;">==</span>) in an if statement.

```
let x = 0;
if(x = 10)	//true
```

## 70.2 Expecting Loose Comaparison

​	In regular comparison, data type does not matter. This <span style="color: red;">if</span> statement result true:

```
let x = 10;
let y = "10";
if(x == y)	//true
if(x === y)	//false
```

​	It is a common mistake to forget that <span style="color: red;">switch</span> statements use strict comparison:

```
let x = 10;
switch(x) {
	case 10: alert("Hello");	//true
	case "10": alert("Hello");	//false
}
```

## 70.3 Confusing Addition & Concatenation

​	<b>Additon</b> is about adding <b>numbers</b>.

​	<b>Concatenation</b> is about adding <b>strings</b>.

​	In JavaScript both operations use the same <span style="color: red;">+</span> operator.

​	Because of this, adding a number as a number will produce a different result from adding a number as a string:

```
let x = 10;
x = 10 + 5;	//15
let y = 10;
y += "5";	//"105"
```

## 70.4 Misunderstanding Floats

​	All numbers in JavaScript are stored as 64-bits <b>Floating point numbers</b>.

​	All programming languages, including JavaScript, have difficulties with precise floating point values:

```
let x = 0.1;
let y = 0.2;
let z = x + y;	//not 0.3
```

## 70.5 Breaking a JavaScript String

​	JavaScript will allow you to break a statement into two lines:

```
let x = 
"Hello World!";
```

​	But, breaking a statement in the middle of a string will not work:

```
let x = "Hello
World!";			//undefined
```

​	You must use a "backslash" if you must break a statement in a string:

```
let x = "Hello \
World!";
```

## 70.6 Misplacing Semicolon

​	Because of a misplaced semicolon, this code block will execute regardless of the value of x:

```
if (x == 19);
{
	//some code
}
```

## 70.7 Breaking a Return Statement

​	It is a default JavaScript behavior to close a statement automatically at the end of a line.

​	Because of this, these two example will return the same result:

```
function myFunction(a) {
	let power = 10
	return a * power
}
```

```
function myFunction(a) {
	let power = 10;
	return a * power;
}
```

​	JavaScript will also allow you to break a statement into two lines. Because of this, example 3 will also return the same result:

```
function myFunction(a) {
	let
	power = 10;
	return a * power;
}
```

​	But, this function will return <span style="color: red;">undefined</span>:

```
function myFunction(a) {
	let 
	powert = 10;
	return		//return undefined
	a * power;
}
```

​	<b>Note:</b> JavaScript explain let and return break in different way.

## 70.8 Accessing Arrays with Named Indexes

​	Many programming languages support arrays with named indexes. Arrays with named indexes are called associative arrays (or hashed).

​	JavaScript does <b>not</b> support arrays with named indexes. In JavaScript, <b>arrays</b> use <b>numbered indexes</b>.

```
const person = [];
person[0] = "John";
person[1] = "Doe";
person[2] = 46;
person.length;       // person.length will return 3
person[0];           // person[0] will return "John"
```

​	In JavaScript, <b>objects</b> use <b>named indexes</b>.

​	If you use a named index, when accessing an array, JavaScript will redefine the array to standard object.

​	After the automatic redefinition, array methods and properties will produce undefined or incorrect results:

```
const person = [];
person["firstName"] = "John";
person["lastName"] = "Doe";
person["age"] = 46;
person.length;      // person.length will return 0
person[0];          // person[0] will return undefined
```

## 70.9 Ending Definition with a Comma

​	Trailing commas in object and array definition are legal in ECMAScript 5.

```
person = {firstName:"John", lastName:"Doe", age:46,};
points = [40, 24, 432, 2,];	
```

​	But in JSON, trailing are not allowed:

```
person = {"firstName":"John", "lastName":"Doe", "age":46,};	//error
points = [40, 24, 432, 2,];	
```

## 70.10 Undefined is Not Null

​	JavaScript objects, variables, properties, and methods can be <span style="color: red;">undefined</span>.

​	In addition, empty JavaScript objects can have the value <span style="color: red;">null</span>.

​	This can make it a little bit difficult to test if an object is empty, you can test if an object exists by testing if the type is <span style="color: red;">undefined</span>:

```
if (typeof myObj === "undefined") {
	//...
}
```

​	But you cannot test if an object is <span style="color: red;">null</span>, because this will throws an error if the object is <span style="color: red;">undefined</span>:

```
if (myObj === null)
```

​	To solve this problem, you must test if an object is not <span style="color: red;">null</span>, and not <span style="color: red;">undefined</span>:

```
if(typeof myObj !== "undefined" && myObj !== null) //order do make sense
```



# 71. JavaScript Performance

## 71.1 Reduce Activity in Loops

​	Loops are often used in programming. Each statement in a loop, including the for statement, is executed for each iteration of the loop. Statements or assignments that can be placed outside the loop will make the loop run faset:

```
for (let i = 0; i < arr.length; i++)
//Better code:
let l = arr.length;
for (let i = 0; i < l; i++)
```

## 71.2 Reduce DOM Access

​	Accessing the HTML DOM is very slow, compared to other JavaScript statements.

​	If you expect to access a DOM element several times, access it once, and use it as a local variable:

```
const obj = document.getElementById("demo");
obj.innerHTML = "Hello";
```

## 71.3 Reduce DOM Size

​	Keep the number of elements in the HTML DOM small.

​	This will always improve page loading, and speed up rendering (page display), especially on smaller devices.

​	Every attempt to search the DOM (like getElementByTagName) will benefit from a smaller DOM.

## 71.4 Avoid Unnecessary Variables

​	Don't create new variables if you don't plan to save values.

​	Often you can replace code like this:

```
let fullName = firstName + " " + lastName;
document.getElementById("demo").innerHTML = fullName;
```

​	with:

```
document.getElementById("demo").innerHTML = firstName + " " + lastName;
```

## 71.5 Delay JavaScript Loading

​	Putting your scripts at the bottom of the page body lets the browser load the page first.

​	While a script is downloading, the browser will not start any other downloads. In addition all parsing and rendering activity might be blocked.

<b>Note:</b> The HTTP specification defines that browsers should not download more than two components is parallel.

​	An alternative is to use <span style="color: red;">defer="true"</span> in the script tag. The defer attribute specifies that the script should be executed after the page has finished parsing, but it only works for external scripts.

​	If possible, you can add your script to the page by code, after the page has loaded:

```
<script>
window.onload = function() {
  const element = document.createElement("script");
  element.src = "myScript.js";
  document.body.appendChild(element);
};
</script>
```

## 71.6 Avoid Using with

​	Avoid using the <span style="color: red;">with</span> keyword. It has a negative effect on speed. It also clutters up JavaScript scopes. The <span style="color: red;">with</span> keyword is <b>NOT allowed</b> in strict mode.



# 72. JavaScript Reserved Words

​	In JavaScript you cannot use these reserved word as variables, labels, or function names:

| Reserved words1 | Reserved words2 | Reserved words3 | Reserved words4 |
| --------------- | --------------- | --------------- | --------------- |
| abstract        | arguments       | await*          | boolean         |
| break           | byte            | case            | catch           |
| char            | class*          | const           | continue        |
| debugger        | default         | delete          | do              |
| double          | else            | enum*           | eval            |
| export*         | extends*        | false           | final           |
| finally         | float           | for             | function        |
| goto            | if              | implements      | import*         |
| in              | instanceof      | int             | interface       |
| let*            | long            | native          | new             |
| null            | package         | private         | protected       |
| public          | return          | short           | static          |
| super*          | switch          | synchronized    | this            |
| throw           | throws          | transient       | true            |
| try             | typeof          | var             | void            |
| volatile        | while           | with            | yield           |

​	Words marked with * are new in ECMAScript 5 and 6.

## 72.1 Remove Reserved Words

​	The following reserved words have been remove from the ECMAScript 5/6 standard:

|              |         |           |          |
| ------------ | ------- | --------- | -------- |
| abstract     | boolean | byte      | char     |
| double       | final   | float     | goto     |
| int          | long    | native    | short    |
| synchronized | throws  | transient | volatile |

## 72.2 JavaScript Objects, Properties, and Methods

​	You should also avoid using the name of JavaScript built-in objects, properties, and methods:

|                |          |           |           |
| -------------- | -------- | --------- | --------- |
| Array          | Date     | eval      | function  |
| hasOwnProperty | Infinity | isFinite  | isNaN     |
| isPrototypeOf  | length   | Math      | NaN       |
| name           | Number   | Object    | prototype |
| String         | toString | undefined | valueOf   |

## 72.3 Java Reserved Words

​	JavaScript is often used together with Java. You should avoid using some Java objects and properties as JavaScript identifiers:

|            |             |           |           |
| ---------- | ----------- | --------- | --------- |
| getClass   | java        | JavaArray | javaClass |
| JavaObject | JavaPackage |           |           |

## 72.4 Otheer Reserved Words

​	JavaScript can be used as the programming language in many applications. 

​	You should also avoid using the name of HTML and Window objects and properties:

|             |                    |                    |                   |
| ----------- | ------------------ | ------------------ | ----------------- |
| alert       | all                | anchor             | anchors           |
| area        | assign             | blur               | button            |
| checkbox    | clearInterval      | clearTimeout       | clientInformation |
| close       | closed             | confirm            | constructor       |
| crypto      | decodeURI          | decodeURIComponent | defaultStatus     |
| document    | element            | elements           | embed             |
| embeds      | encodeURI          | encodeURIComponent | escape            |
| event       | fileUpload         | focus              | form              |
| forms       | frame              | innerHeight        | innerWidth        |
| layer       | layers             | link               | location          |
| mimeTypes   | navigate           | navigator          | frames            |
| frameRate   | hidden             | history            | image             |
| images      | offscreenBuffering | open               | opener            |
| option      | outerHeight        | outerWidth         | packages          |
| pageXOffset | pageYOffset        | parent             | parseFloat        |
| parseInt    | password           | pkcs11             | plugin            |
| prompt      | propertyIsEnum     | radio              | reset             |
| screenX     | screenY            | scroll             | secure            |
| select      | self               | setInterval        | setTimeout        |
| status      | submit             | taint              | text              |
| textarea    | top                | unescape           | untaint           |
| window      |                    |                    |                   |

## 72.5 HTML Event Handlers

​	In addition you should avoid using the name of all HTML event handlers, examples:

|           |            |             |             |
| --------- | ---------- | ----------- | ----------- |
| onblur    | onclick    | onerror     | onfocus     |
| onkeydown | onkeypress | onkeyup     | onmouseover |
| onload    | onmouseup  | onmousedown | onsubmit    |



## 73. JavaScript 200 (ES5)

## 73.1 JSON.parse()

​	A common use of JSON is to receive data from a web server. Image you received this text string from a web server:

```
'{"name":"John", "age":26, "city":"New York"}'
```

​	The JavaScript function <span style="color: red;">JSON.parse()</span> is used to convert the text into a JavaScript object:

```
var obj = JSON.parset('{"name":"John", "age":26, "city":"New York"}');
```

## 73.2 JSON.stringify()

​	When sending data to a web server, the data has to be a string.

​	Imagine we have this object in JavaScript:

```
var obj = {name:"John", age: 30, city: "New York"};
```

​	Use the JavaScript function <span style="color: red;">JSON.stringify()</span> to convert it into a string:

```
var myJSON = JSON.stringify(obj);
```

<b>Note:</b> The result will be a string following the JSON notation.

## 73.3 Date.now()

​	<span style="color: red;">Date.now()</span> returns the number of millisecond since zero date (January 1, 1970 00:00:00 UTC)

## 73.4 Date toISOString()

​	The <span style="color: red;">toISOString()</span> method coverts a Date object to a string, using the ISO standard format:

```
const d = new Dat();
d.toISOString();	//2023-04-15T11:18:27.366Z
```

## 73.5 Date toJSON()

​	<span style="color: red;">toJSON()</span> converts a Date object into a string, formatted as a JSON date.

​	JSON dates have the same format as the ISO-8601 standard: YYYY-MM-DDTHH:mm:ss.sssZ

## 73.6 Property Getters and Setters

​	ES5 lets youu define object methods with a syntax that looks like getting or setting a property.

​	This example creates a <b>getter</b> and a <b>setter</b> for the language property:

```
var person = {
  firstName: "John",
  lastName : "Doe",
  language : "NO",
  get lang() {
    return this.language;
  },
  set lang(value) {
    this.language = value;
  }
};
// Set an object property using a setter:
person.lang = "en";
// Display data from the object using a getter:
document.getElementById("demo").innerHTML = person.lang;
```

​	This example uses a setter to secure upper case updates of language:

```
var person = {
	firstName: "John",
	lastName: "Doe",
	language: "NO",
	set lang(value) {
		this.language = value.toUpperCase();
	}
};
person.lang = "en";
document.getElementById("demo").innerHTML = person.language;
```

## 73.7 Object.defineProperty()

​	<span style="color: red;">Object.defineProperty()</span> is a new Object method is ES5.

​	It lets you define an object property and/or change a property's value and/or metadata:

```
// Create an Object:
var person = {
  firstName: "John",
  lastName : "Doe",
  language : "NO",
};
// Change a Property:
Object.defineProperty(person, "language", {
  value: "EN",
  writable : true,
  enumerable : true,
  configurable : true
});
// Enumerate Properties
var txt = "";
for (var x in person) {
  txt += person[x] + "<br>";
}
document.getElementById("demo").innerHTML = txt;
```

​	Next example is the same code, except it hides the language property from enumeration:

```
// Create an Object:
var person = {
  firstName: "John",
  lastName : "Doe",
  language : "NO",
};
// Change a Property:
Object.defineProperty(person, "language", {
  value: "EN",
  writable : true,
  enumerable : false,
  configurable : true
});
// Enumerate Properties
var txt = "";
for (var x in person) {
  txt += person[x] + "<br>";	//language value not listed
}
document.getElementById("demo").innerHTML = txt;
```

​	This example creates a setter and a getter to secure upper case updates of language:

```
/// Create an Object:
var person = {
  firstName: "John",
  lastName : "Doe",
  language : "NO"
};
// Change a Property:
Object.defineProperty(person, "language", {
  get : function() { return language },
  set : function(value) { language = value.toUpperCase()}
});
// Change Language
person.language = "en";
// Display Language
document.getElementById("demo").innerHTML = person.language;
```

## 73.8 E5 Object Methods

​	ES5 added a lot of new Object Methods to JavaScript:

```
// Create object with an existing object as prototype
Object.create(parent, donor)

// Adding or changing an object property
Object.defineProperty(object, property, descriptor)

// Adding or changing object properties
Object.defineProperties(object, descriptors)

// Accessing Properties
Object.getOwnPropertyDescriptor(object, property)

// Returns all properties as an array
Object.getOwnPropertyNames(object)

// Accessing the prototype
Object.getPrototypeOf(object)

// Returns enumerable properties as an array
Object.keys(object)
```

​	Protecting Objects:

```
// Prevents adding properties to an object
Object.preventExtensions(object)

// Returns true if properties can be added to an object
Object.isExtensible(object)

// Prevents changes of object properties (not values)
Object.seal(object)

// Returns true if object is sealed
Object.isSealed(object)

// Prevents any changes to an object
Object.freeze(object)

// Returns true if object is frozen
Object.isFrozen(object)
```

## 73.9 Function Bind()

​	With the <span style="color: red;">bind()</span> method, an object can borrow a method from another object.

​	This example create 2 objects (person and member), member object borrows the fullname method from the person object :

```
const person = {
  firstName:"John",
  lastName: "Doe",
  fullName: function () {
    return this.firstName + " " + this.lastName;
  }
}
const member = {
  firstName:"Hege",
  lastName: "Nilsen",
}
let fullName = person.fullName.bind(member);
```



# 74. JavaScript 2015 (ES6)

## 74.1 JavaScript Promises

​	A Promise is a JavaScript object that links "Producing Code" and "Consuming Code".

​	"Producing Code" can take some time and "Consuming Code" must wait for the result:

```
const myPromise = new Promise(function(myResolve, myReject) {
// "Producing Code" (May take some time)

  myResolve(); // when successful
  myReject();  // when error
});

// "Consuming Code" (Must wait for a fulfilled Promise).
myPromise.then(
  function(value) { /* code if successful */ },
  function(error) { /* code if some error */ }
);	
```

Example:

```
const myPromise = new Promise(function(myResolve, myReject) {
  setTimeout(function() { myResolve("I love You !!"); }, 3000);
});
myPromise.then(function(value) {
  document.getElementById("demo").innerHTML = value;
});
```

## 74.2 The Symbol Type

​	A JavaScript Symbol is a primitive datatype just like Number, String, or Boolean.

​	It represents a unique "hidden" identifier that no other code can accidentally access.

​	For instance, if different coders want to add a person.id property to a person object belonging to a third-party code, they could mix each others values.

​	Using Symbol() to create a unique identifiers, solves this problem:

```
cosnt person = {
	fitstName: "John",
	lastName: "Doe",
	age: 50,
	eyeColor: "blue"
};
let id = Symbol('id');
person[id] = 140353;	//Now person[id] is 140353, but person.id is still undefined
```

<b>Note:</b> Symbols are always unique. If you create tow symbols with the same description they will have different values:

```
Symbol("id") == Symbol("id");	//false
```

## 74.3 Default Parameter Values

​	ES6 allows function parameters to have default values:

```
function myFunction(x, y = 10) {
	return x + y;
}
myFunction(5);		//15
```

## 74.4 Function Rest Parameter

​	The rest parameter (...) allows a function to treat an indefinite number of arguments as an array:

```
function sum(...args) {
	let sum = 0;
	for (let arg of args) sum += arg);
	return sum;
}
let x = sum(1, 2, 3, 4, 5, 6, 7);
```



# 75. JavaScript 2017 & 2018 & 2019

## 75.1 Async Functions

​	<span style="color:blue;">Waiting for a Timeout</span>

```
async function myDisplay() {
  let myPromise = new Promise(function(resolve) {
    setTimeout(function() {resolve("I love You !!");}, 3000);
  });
  document.getElementById("demo").innerHTML = await myPromise;
}
myDisplay();
```

## 75.2 Asynchronous Iteration

​	ECMAScript 2018 added asynchronous iterators and iterables.

​	With asynchronous iterables, we can use the <span style="color: red;">await</span> keyword in <span style="color: red;">for/of</span> loops:

```
for await() {}
```

## 75.3 Promise.finally

​	ECMAScript 2018 finalizes the full implementation of the Promise object with <span style="color: red;">Promise.finally</span>:

```
let myPromise = new Promise();
myPromise.then();
myPromise.catch();
myPromise.finally();
```

## 75.4 Object Rest Properties

​	ECMAScript 2018 added rest properties.

​	This allows us to destruct an object and collect the lefrovers onto a new object:

```
let {x, y, ...z} = {x:1, y:2, a:3, b:4};
x;	//1
y;	//2
z;	//{a:3, b:4}	
```

## 75.5 New JavaScript RegExp Features

​	ECMAScript 2018 added 4 new RegExp features:

* Unicode Property Escapes (\p{...})
* Lookbehide Aeertions (?<=) and (?<!)
* Named Capture Groups
* s (dotAll) Flag

## 75.6 JavaScript Threads

​	In JavaScript you use the Web Workers API to create threads.

​	Worker threads are used to execute code in the background so that the main program can continue execution.

​	Worker threads run simultaneously with the main program. Simultaneous execution of different parts of program can be time-saving.

## 75.7 JavaScript Shared Memory

​	Shared memory is a feature that allows threads (different parts of a program) to access and update the same data in the same memory.

​	Instead of passing data between threads, you can pass a SharedArrayBuffer object that points to the memory where data is saved.

## 75.8 SharedArrayBuffer

​	A SharedArrayBuffer object represents a fixed-length raw binary data buffer simliar to the ArrayBuffer object.

## 75.9 JavaScript Object fromEntries()

​	ES2019 added the object method <span style="color: red;">fromEntries()</span> to JavaScript.

​	The <span style="color: red;">fromEntries()</span> method creates an object from iterable key/value pairs:

```
const fruits = [
	["apples", 300],
	["pears", 200],
	["bananas", 500]
];
const myObj = Object.fromEntries(fruits);	//get a object
```







<span style="color: red;"></span>