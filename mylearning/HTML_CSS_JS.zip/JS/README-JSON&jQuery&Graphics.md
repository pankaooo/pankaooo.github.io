# 1. JSON - Introduction

​	JSON stands for JavaScript Object Notation

​	JSON is a <b>text format</b> for storing and transporting data

​	JSON is "self-describing" and easy to understand

## 1.1 JSON Example

​	This example is a JSON string:

```
'{"name":"John", "age":20, "car":null}'
```

​	It defines an object with 3 properties:

* name
* age
* car

​	Each property has a value. If you parse the JSON string with a JavaScript program, you can access the data as an object:

```
let personName = obj.name;
let personAge = obj.age;
```

## 1.2 What is JSON?

* JSON stands for JavaScript Object Notation
* JSON is a lightweight data-interchange format
* JSON is plain text written in JavaScript object notation
* JSON is used to send data between computers
* JSON is language independent

	* The JSON syntax is derived from JavaScript object notation, but the JSON fromat is text only. Code for reading and generating JSON exists in many programming languages.

​	The JSON format was originally specified by [Douglas Crokford](http://www.crockford.com/)

## 1.3 Why Use JSON?

​	The JSON format is syntactically similar to the code for creating JavaScript objects.

​	Because of this, a JavaScript program can easily convert JSON data into JavaScript objects.

​	Since the format is text only, JSON data can easily be sent between computers, and used by any programming language. JavaScript has a built-in function for converting JSON string into JavaScript objects: <span style="color:red;">JSON.parse()</span>

​	JavaScript also has a built-in function for converting an object into a JSON string: <span style="color:red;">JSON.stringify()</span>

<b>Note:</b> You can receive pure text from a server and use it as a JavaScript object. You can send a JavaScript object to a server in pure text format. You can work with data as JavaScript objects, with no complicated parsing and translations.

## 1.4 Storing Data

​	When storing data, the data has to be a certain format, and regardless of where you choose to store it, <i>text</i> is always one of the legal format. JSON makes it possible to store JavaScript objects as text.



# 2. JSON Syntax

## 2.1 JSON Syntax Rules

​	JSON syntax is derived from JavaScript object notation syntax:

* Data is in name/value pairs
* Data is separated by commas
* Curly braces hold objects
* Square brackets hold arrays

## 2.2 JSON Data - A Name and a Value

​	JSON data is written as name/value pairs (aka key/value pairs). A name/value pair consists of a field name (in double quotes), followed by a colon, followed by a value:

```
"name":value	//JSON names requires double quotes
```

## 2.3 JSON Values

​	In <b>JSON</b>, <i>values</i> must be one of the following data types:

* a string
* a number
* an object
* an array
* a boolean
* null

​	In contract, in <b>JavaScript</b> values can be all of the above, plus any other valid JavaScript expression, including:

* a function
* a date
* undefined



# 3. JSON vs XML

​	Both JSON and XML can be used to receive data from a web server.

​	The following JSON and XML examples both define a employees object, with an array of 3 employees:

```
//JOSN Example:
{"employees":[
	{"firstName":"John", "lastName":"Doe"},
	{"firstName":"Anna", "lastName":"Smith"},
	{"firstName":"Peter", lastName:"Jones"}
]}
```

```
//XML Example:
<employees>
	<employee>
		<firstName>John</firstName><lastName>Doe</lastName>
	</employee>
	<employee>
		<firstName>Anna</firstName><lastName>Smith</lastName>
	</employee>
	<employee>
		<firstName>Peter</firstName><lastName>Jones</lastName>
	</employee>
</employees>
```

## 3.1 JSON is Like XML Because

* Both JOSN and XML are "self describing" (human readable)
* Both JOSN and XML are hierarchical (values within values)
* Both JOSN and XML can be parsed and used by lots of programming language
* Both JOSN and XML can be fetched with an XMLHttpRequest

## 3.2 JSON is Unlike XML Because

* JSON doesn't use end tag
* JSON is shorter
* JSON is quicker to read and write
* JSON can use arrays

​	The biggest difference is:

​		XML has to be parsed with an XML parser, JOSN can be parsed by a standard JavaScript function.

## 3.3 Why JSON is Better Than XML

​	XML is much more difficult to parse than JSON. JSON is parsed into a ready-to-use JavaScript object. For AJAX applications, JSON is faster and easier than XML:

​	Using XML

* Fetch an XML document
* Use the XML DOM to loop through the document
* Extract values and store in variables

​	Using JSON

* Fetch a JSON string
* JSON.parse the JSON string



# 4. JOSN.parse()

​	A common use of JSON is to exchange data to/from a web server. When receiving from a web server, the data is always a string. Parse the data with <span style="color:red;">JSON.parse()</span>, and the data becomes a JavaScript object.

## 4.1 Example - Parsing JSON

​	Imagine we received this text from a web server:

```
'{"name":"John", "age":30, "city":"New York"}'
```

​	Use the JavaScript function <span style="color:red;">JSON.parse()</span> to convert text into a JavaScript object:

```
const obj = JSON.parse('{"name":"John", "age":30, "city":"New York"}');
```

​	<b>Note:</b> Make sure the text is in JSON format, or else you will get a syntax error.

​	Then you can use the JS object in your page:

```
<p id="demo"></p>

<script>
document.getElementById("demo").innerHTML = obj.name;
</script>
```

## 4.2 Array ad JSON

​	When using the <span style="color:red;">JSON.parse()</span> on a JSON derived from an array, the method will return a JavaScript array, instead of a JavaScript object.

```
const text = '["Ford", "BMW", "Audi", "Fiat"]';
const myArr = JSON.parse(text);
```

## 4.3 Exceptions

### 4.3.1 Parsing Dates

​	Date objects are not allowed in JSON. If you need to include a date, write it as a string.

​	You can convert it back into a date object later:

```
const text = '{"name":"John", "birth":"1986-12-14", "city":"New York"}';
const obj = JSON.parse(text);
obj.birth = new Date(obj.birth);	//convert back into date object! 

document.getElementById("demo").innerHTML = obj.name + ", " + obj.birth;
```

​	Or, you can use the second parameter, of the <span style="color:red;">JSON.parse()</span> function, called <i>reviver</i>.

​	The reviver parameter is a function that checks each property, before returning the value:

```
const text = '{"name":"John", "birth":"1986-12-14", "city":"New York"}';
const obj = JSON.parse(text, function (key, value) {
  if (key == "birth") {
    return new Date(value);
  } else {
    return value;
  }
});
document.getElementById("demo").innerHTML = obj.name + ", " + obj.birth;
```

### 4.3.2 Parsing Functions

​	Functions are not allowed in JSON. If you need to include a function, write it as a string.

​	You can convert it back into a function later:

```
const text = '{"name":"John", "age":"function () {return 30;}", "city":"New York"}';
const obj = JSON.parse(text);
obj.age = eval("(" + obj.age + ")");	//convert back into a function
document.getElementById("demo").innerHTML = obj.name + ", " + obj.age();
```

<b>Note:</b> You should avoid using function in JOSN, the functions will lose their scope, and you would have to use <span style="color:red;">eval()</span> to convert them back into functions.



# 5. JSON.stringify()

​	A common use of JSON is to exchange data to/from a web server. When sending data to a web server, the data has to be a string.

​	Convert a JavaScript object into a string with <span style="color:red;">JSON.stringify()</span>.

## 5.1 Stringify a JavaScript Object

​	Imagine we have the object in JavaScript:

```
const obj = {name: "John", age: 30, city: "New York"};
```

​	Use the JavaScript function <span style="color:red;">JOSN.stringify()</span> to convert it into a string:

```
const myJSON = JSON.stringify(obj);
```

​	<span style="color:red;">myJSON</span> is now a string, and ready to be sent to a server.

## 5.2 Stringify a JavaScript Array

​	It is also possible to stringify JavaScript arrays:

```
const arr = ["John", "Peter", "Sally", "Jane"];
const myJSON = JSON.stringify(arr);
```

<b>Note:</b> The result will be a string following the JSON notation.

## 5.3 Storing Data

​	When storing data, the data has to be a certain format, and regardless of where you choose to store it, <i>text</i> is always one of the legal formats. JSON make it possible to store JavaScript objects as text:

```
// Storing data:
const myObj = {name: "John", age: 31, city: "New York"};
const myJSON = JSON.stringify(myObj);
localStorage.setItem("testJSON", myJSON);

// Retrieving data:
let text = localStorage.getItem("testJSON");
let obj = JSON.parse(text);
document.getElementById("demo").innerHTML = obj.name;
```

## 5.4 Exceptions

### 5.4.1 Stringify Dates

​	In JSON, date objects are not allowed. The <span style="color:red;">JSON.stringify()</span> function will convert any dates into strings.

```
const obj = {name: "John", today: new Date(), city : "New York"};
const myJSON = JSON.stringify(obj);
```

### 5.4.2 Stringify Functions

​	In JOSN, functions are not allowed as object values. The <span style="color:red;">JSON.stringify()</span> function will remove any function from a JavaScript object, both the key and the value:

```
const obj = {name: "John", age: function () {return 30;}, city: "New York"};
const myJSON = JSON.stringify(obj);	//function not exists in myJSON
```

​	This can be omitted if you convert your functions into strings before running the <span style="color:red;">JSON.stringify()</span> function:

```
const obj = {name: "John", age: function () {return 30;}, city: "New York"};
obj.age = obj.age.toString();
const myJSON = JSON.stringify(obj);
```

<b>Note:</b> If you send functions using JSON, the functions will lose their scope, and the receiver would have to use eval() to convert them back into functions.



# 6. JOSN Object Literals

​	This is a JSON string:

```
'{"name":"John", "age":30, "car":null}'
```

​	Inside the JSON string there is a JSON object literal:

```
{"name":"John", "age":30, "car":null}
```

​	JSON object literals are surrounded by curly braces {}. JSON object literals contains key/value pairs. Keys and values are separated by a colon.

​	Keys must be strings, and values must be a valid JSON data type:

* string
* number
* object
* array
* boolean
* null

​	Each key/value pair is separated by a comma.

<b>Note:</b> <span style="color:blue;">It is a common mistake to call a JOSN object literal "a JOSN object"</span>.

​	JOSN cannot be an object, JOSN is a string format. The data is only JSON when it is a string format. When it is converted to a JavaScript variable, it becomes a JavaScript object.

## 6.1 JavaScript Objects

​	You can create a JavaScript object from a JOSN object literal:

```
myObj = {"name":"John", "age":30, "car":null};
```

​	Normally, you create a JavaScript object by parsing a JSON string:

```
myJSON = '{"name":"John", "age":30, "car":null}';
myObj = JSON.parse(myJSON);
```

​	<b>Note:</b> Pay attention to the difference.

## 6.2 Accessing Object Values

​	You can access object values by using dot (.) notaion:

```
const myJSON = '{"name":"John", "age":30, "car":null}';
const myObj = JSON.parse(myJSON);
x = myObj.name;
```

​	You can also access object values by using bracket ([]) notation:

```
const myJSON = '{"name":"John", "age":30, "car":null}';
const myObj = JSON.parse(myJSON);
x = myObj["name"];
```

## 6.3 Looping an Object

```
const myJSON = '{"name":"John", "age":30, "car":null}';
const myObj = JSON.parse(myJSON);

let text = "";
for (const x in myObj) {
  text += myObj[x] + ", ";
}
```



# 7. JSON Array Literals

​	This is a JSON string:

```
'["Ford", "BMW", "Fiat"]'
```

​	Inside the JSON string there is a JSON array literal:

```
["Ford", "BMW", "Fiat"]
```

​	Arrays in JSON are almost the same as arrays in JavaScript. In JSON, array values must be of type string, number, object, array, boolean, or null.

​	In JavaScript, array values can be all of the above, plus any other valid JavaScript expression, including functions, dates, and <i>undefined</i>.

## 7.1 JavaScript Arrays

​	You can create a JavaScript array from a literal:

```
myArray = ["Ford", "BMW", "Fiat"];
```

​	You can create a JavaScript array by parsing a JSON string:

```
myJSON = '["Ford", "BMW", "Fiat"]';
myArray = JSON.parse(myJSON);
```

## 7.2 Accessing Array Values

​	You access array values by index:

```
myArray[0];
```

## 7.3 Arrays in Objects

​	Objects can contain arrays:

```
{
"name":"John",
"age":30,
"cars":["Ford", "BMW", "Fiat"]
}
```

## 7.4 Looping Through an Array

​	You can access array values by using a <span style="color:red;">for in</span> loop:

```
for (let i in myObj.cars) {
	x += myObjs.cars[i];
}
```

​	Or you can use a <span style="color:red;">for</span> loop:

```
for (let i = 0; i < myObj.cars.length; i++) {
  x += myObj.cars[i];
}
```



# 8. JOSN Server

## 8.1 Sending Data

​	If you have data stored in a JavaScript object, you can convert the object into JSON, and send it to a server:

```
const myObj = {name: "John", age: 31, city: "New York"};
const myJSON = JSON.stringify(myObj);
window.location = "demo_json.php?x=" + myJSON;
```

## 8.2 Receiving Data

​	If you receive data in JSON format, you can easily convert it into a JavaScript object:

```
const myJSON = '{"name":"John", "age":31, "city":"New York"}';
const myObj = JSON.parse(myJSON);
document.getElementById("demo").innerHTML = myObj.name;
```

## 8.3 JSON From a Server

​	You can request JSON from the server by using an AJAX request.

​	As long as the response from the server is written in JOSN format, you can parse the string into a JavaScript object:

```
//Use the XMLHttpRequest to get data from the server:
const xmlhttp = new XMLHttpRequest();
xmlhttp.onload = function() {
  const myObj = JSON.parse(this.responseText);
  document.getElementById("demo").innerHTML = myObj.name;
};
xmlhttp.open("GET", "json_demo.txt");
xmlhttp.send();
```

## 8.4 Array as JSON

​	When using the <span style="color:red;">JSON.parse()</span> on JSON derived from an array, the method will return a JavaScript array, instead of a JavaScript object:

```
const xmlhttp = new XMLHttpRequest();
xmlhttp.onload = function() {
  const myArr = JSON.parse(this.responseText);
  document.getElementById("demo").innerHTML = myArr[0];
  }
}
xmlhttp.open("GET", "json_demo_array.txt", true);
xmlhttp.send();
```



# 9. JSON PHP

## 9.1 The PHP File

​	PHP has some built-in functions to handle JSON. Objects in PHP can be converted into JSON by using the PHP function <span style="color:red;">json_encode()</span>:

```
<?php
$myObj->name = "John";
$myObj->age = 30;
$myObj->city = "New York";
$myJSON = json_encode($myObj);
echo $myJSON;
?>
```

## 9.2 The Client JavaScript

​	Here is a JavaScript on the client, using an AJAX call to request the PHP file from the example above:

```
const xmlhttp = new XMLHttpRequest();
xmlhttp.onload = function() {
	const myObj = JSON.parse(this.responseText);
	document.getElementById("demo").innerHTML = myObj.name;
}
xmlhttp.open("GET", "demo_file.php");
xmlhttp.send();
```

## 9.3 PHP Array

​	Arrays in PHP will also be converted into JSON when using the PHP function <span style="color:red;">josn_encode()</span>:

```
<?php
$myArr = array("John", "Mary", "Peter", "Sally");
$myJSON = json_encode($myArr);
echo $myJSON;
?>
```

## 9.4 The Client JavaScript

​	Here is a JavaScript on the client, using the AJAX call to request the PHP file from the array example above:

```
var xmlhttp = new XMLHttpRequest();
xmlhttp.onload = function() {
  const myObj = JSON.parse(this.responseText);
  document.getElementById("demo").innerHTML = myObj[2];
}
xmlhttp.open("GET", "demo_file_array.php", true);
xmlhttp.send();
```

## 9.5 PHP Database

​	PHP is a server side programming language, and can be used to access a database.

​	Imagine you have a database on your server, and you want to send a request to it from the client where you ask for the 10 first rows in a table called "customers".

​	On the client, make a JSON object that describes the number of rows you want to return.

​	Before you send the request to the server, convert the JSON object into a string and send it as parameter to the url of the PHP page:

```
const limit = {"limit":10};
const dbParam = JSON.stringify(limit);
xmlhttp = new XMLHttpRequest();
xmlhttp.onload = function() {
  document.getElementById("demo").innerHTML = this.responseText;
}
xmlhttp.open("GET","json_demo_db.php?x=" + dbParam);
xmlhttp.send();
```

Example explained:

* Define an object containing a "limit" property and value.
* Convert the object into a JSON string.
* Send a request to the PHP file, with the JSON string as a parameter.
* Wait until the request returns with the result (as JSON).
* Display the result received from the PHP file.

​	Take a look at the PHP file:

```
<?php
header("Content-Type: application/json; charset=UTF-8");
$obj = json_decode($_GET["x"], false);

$conn = new mysqli("myServer", "myUser", "myPassword", "Northwind");
$stmt = $conn->prepare("SELECT name FROM customers LIMIT ?");
$stmt->bind_param("s", $obj->limit);
$stmt->execute();
$result = $stmt->get_result();
$outp = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($outp);
?>
```

PHP File explained:

* Convert the request into an object, using the PHP function <span style="color:red;">json_decode()</span>.
* Access the database, and fill an array with the requested data.
* Add the array to an object, and return the object as JSON using the <span style="color:red;">json_encode()</span> function.

Use the data:

```
xmlhttp.onload = function() {
  const myObj = JSON.parse(this.responseText);
  let text = "";
  for (let x in myObj) {
    text += myObj[x].name + "<br>";
  }
  document.getElementById("demo").innerHTML = text;
}
```

## 9.6 PHP Method = POST

​	When sending data to the server, it is often to use the HTTP <span style="color:red;">POST</span> method.

​	To send AJAX requests using the <span style="color:red;">POST</span> method, specify the method, and the correct header. The data sent to the server must now be an argument to the <span style="color:red;">send()</span> method:

```
const dbParam = JSON.stringify({"limit":10});
const xmlhttp = new XMLHttpRequest();
xmlhttp.onload = function() {
  const myObj = JSON.parse(this.responseText);
  let text ="";
  for (let x in myObj) {
    text += myObj[x].name + "<br>";
  }
  document.getElementById("demo").innerHTML = text;
}
xmlhttp.open("POST", "json_demo_db_post.php");
xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xmlhttp.send("x=" + dbParam);
```

​	The only difference in the PHP file is the method for getting the transferred data:

```
<?php
header("Content-Type: application/json; charset=UTF-8");
$obj = json_decode($_POST["x"], false);

$conn = new mysqli("myServer", "myUser", "myPassword", "Northwind");
$stmt = $conn->prepare("SELECT name FROM customers LIMIT ?");
$stmt->bind_param("s", $obj->limit);
$stmt->execute();
$result = $stmt->get_result();
$outp = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($outp);
?>
```



# 10. JSON HTML

## 10.1 HTML Table

​	Make an HTML table with data received as JSON:

```
const dbParam = JSON.stringify({table:"customers",limit:20});
const xmlhttp = new XMLHttpRequest();
xmlhttp.onload = function() {
  myObj = JSON.parse(this.responseText);
  let text = "<table border='1'>"
  for (let x in myObj) {
    text += "<tr><td>" + myObj[x].name + "</td></tr>";
  }
  text += "</table>"
  document.getElementById("demo").innerHTML = text;
}
xmlhttp.open("POST", "json_demo_html_table.php");
xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xmlhttp.send("x=" + dbParam);
```

## 10.2 Dynamic HTML Table

​	Make the HTML table based on the value of a dropdown menu:

```
<select id="myselect" onchange="change_myselect(this.value)">
  <option value="">Choose an option:</option>
  <option value="customers">Customers</option>
  <option value="products">Products</option>
  <option value="suppliers">Suppliers</option>
</select>

<script>
function change_myselect(sel) {
  const dbParam = JSON.stringify({table:sel,limit:20});
  const xmlhttp = new XMLHttpRequest();
  xmlhttp.onload = function() {
    const myObj = JSON.parse(this.responseText);
    let text = "<table border='1'>"
    for (let x in myObj) {
      text += "<tr><td>" + myObj[x].name + "</td></tr>";
    }
    text += "</table>"
    document.getElementById("demo").innerHTML = text;
  }
  xmlhttp.open("POST", "json_demo_html_table.php");
  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlhttp.send("x=" + dbParam);
}
</script>
```

## 10.3 HTML Drop Down List

​	Make an HTML drop down list with data received as JSON:

```
const dbParam = JSON.stringify({table:"customers",limit:20});
const xmlhttp = new XMLHttpRequest();
xmlhttp.onload = function() {
  const myObj = JSON.parse(this.responseText);
  let text = "<select>"
  for (let x in myObj) {
    text += "<option>" + myObj[x].name + "</option>";
  }
  text += "</select>"
  document.getElementById("demo").innerHTML = text;
  }
}
xmlhttp.open("POST", "json_demo_html_table.php", true);
xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xmlhttp.send("x=" + dbParam);
```



# 11. JSONP

​	JSONP is a method for sending JSON data without worrying about cross-domain issues.

​	JSONP does not use the <span style="color:red;">XMLHttpRequest</span> object.

​	JSONP uses the <span style="color:red;">\<script></span> tag instead.

## 11.1 JSONP Intro

​	JSONP stands for JSON with Padding.

​	Requesting a file from another domain can cause problems, due to cross-domain policy.

​	Requesting an external <i>script</i> from another domain does not have this problem.

​	JSONP uses this advantage, and request files using the script tag instead of the <span style="color:red;">XMLHttpRequest</span> object.

```
<script src="demo_jsonp.php">
```

## 11.2 The Server File

​	The file on the server wraps the result inside a function call:

```
<?php
$myJSON = '{ "name":"John", "age":30, "city":"New York" }';
echo "myFunc(".$myJOSN.");";
?>
```

​	The result returns a call to function named "myFunc" with the JSON data as a parameter.

​	Make sure that the function exists on the client.

## 11.3 The JavaScript function

​	The function named "myFunc" is located on the client, and ready to handle JSON data:

```
function myFunc(myObj) {
	document.getElementById("demo").innerHTML = myObj.name;
}
```

## 11.4 Creating a Dynamic Script Tag

​	The example above will execute the "myFunc" function when the page is loading, based on where you put the script tag, which is not very satisfying.	

​	The script tag should only be created when needed:

```
function clickButton() {
  let s = document.createElement("script");
  s.src = "demo_jsonp.php";
  document.body.appendChild(s);
}
```

## 11.5 Dynamic JSONP Result

​	The examples above are still very static. Make the example dynamic by sending JSON to the php file, and let the php file return a JSON object based on the information it gets.

```
<?php
header("Content-Type: application/json; charset=UTF-8");
$obj = json_decode($_GET["x"], false);

$conn = new mysqli("myServer", "myUser", "myPassword", "Northwind");
$result = $conn->query("SELECT name FROM ".$obj->$table." LIMIT ".$obj->$limit);
$outp = array();
$outp = $result->fetch_all(MYSQLI_ASSOC);

echo "myFunc(".json_encode($outp).")";
?>
```

PHP File explained:

* Convert the request into an object, using the PHP function <span style="color:red;">json_decode()</span>
* Access the database, and fill an array with the requested data.
* Add the array to an object.
* Convert the array into JSON using the <span style="color:red;">json_encode()</span> function
* Wrap <span style="color:red;">"myFunc()"</span> around the return object.

JavaScript Example:

```
const obj = { table: "products", limit: 10 };
let s = document.createElement("script");
s.src = "jsonp_demo_db.php?x=" + JSON.stringify(obj);
document.body.appendChild(s);

function myFunc(myObj) {
  let txt = "";
  for (let x in myObj) {
    txt += myObj[x].name + "<br>";
  }
  document.getElementById("demo").innerHTML = txt;
}
```

## 11.6 Callback Function

​	When you have no control over the server file, how do you get the server file to call the correct function?

​	Sometimes the server file offers a callback functions as a parameter:

```
<script>
let s = document.createElement("script");
s.src = "demo_jsonp2.php?callback=myDisplayFunction";
document.body.appendChild(s);

function myDisplayFunction(myObj) {
  document.getElementById("demo").innerHTML = myObj.name;
}
</script>
```



# 12. JavaScript / jQuery DOM Selectors

## 12.1 jQuery vs JavaScript

​	[jQuery](https://www.w3schools.com/jquery/default.asp) was created in 2006 by John Resig. It was designed to handle Borwser Incompatibilities and to simplify HTML DOM Manipulation, Event Handling, Animations, and Ajax.

​	For more than 10 years, jQuery has been the most popular JavaScript library in the world.

​	However, after JavaScript Version 5 (2009), most of the jQuery utilities can be solved with a few lines of standard JavaScript:

## 12.2 Finding HTML Element by Id

​	Return the element with id="id01":

```
myElement = $("#id01");
```

​	To JavaScript:

```
myElement = document.getElementById("id01");
```

## 12.3 Finding HTML Elements by Tag Name

​	Return all \<p> elements:

```
myElements = $("p");
```

​	To JavaScript:

```
myElements = document.getElementsByTagName("p");
```

## 12.4 Finding HTML Elements by Class Name

```
myElements = $(".intro");
```

​	To JavaScript:

```
myElements = document.getElementByClassName("intro");
```

## 12.5 Finding HTML Elements by CSS Selectors

​	Return a list of all \<p> elements with class="intor".

```
myElements = $("p.intor");
```

​	To JavaScript:

```
myElements = document.querySelectorAll("p.intro");
```



# 13. JavaScript / jQuery HTML Elements

## 13.1 Set Text Content

​	Set the inner text of an HTML element:

```
myElement.text("Hello Sweden");
//Add this in <head>:
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
```

​	To JavaScript:

```
myElement.textContent = "Hello Swden";
```

## 13.2 Get Text Content

​	Get the inner text of an HTML element:

```
myText = $("#02").text();
```

​	To JavaScript:

```
myText = document.getElementById("02").textContent;
```

## 13.3 Set HTML Content

​	Set the HTML content of an element:

```
myElement.html("<p>Joe Biden</p>");
```

​	To JavaScript:

```
myElement.innerHTML = "<p>Joe Biden</p>";
```

## 13.4 Get HTML Content

​	Get the HTML content of an element:

```
content = myElement.html();
```

​	To JavaScript:

```
content = myElement.innerHTML;
```



# 14. JavaScript / jQuery CSS Styles

## 14.1 Hiding HTML Elements

```
myElement.hide();
```

​	To JavaScript:

```
myElement.style.display = "none";
```

## 14.2 Showing HTML Elements

```
myElement.show()
```

​	To JavaScript:

```
myElement.style.display = "";
```

## 14.3 Styling HTML Elements

​	Change the font size of an HTML element:

```
$("#demo").css("font-size", "35px");
```

​	To JavaScript:

```
document.getElementById("demo").style.fontSize = "35px";
```



# 15. JavaScript / jQuery HTML DOM

##  15.1 Removing HTML Elements

​	Remove an HTML element:

```
$("#id01").remove();
```

​	To JavaScript:

```
document.getElementById("id01").remove();
```

## 15.2 Get Parent Element

​	Return the parent of an HTML element:

```
myParent = $("#02").parent().prop("nodeName");
```

​	To JavaScript:

```
myParent = document.getElementById("02").parentNode.nodeName;
```



# 16. JavaScript Graphics

<span style="font-size: 20px;">Graphic Libraries</span>

​	JavaScript libraries to use for both Artificial Intelligence graphs and other charts:

* Plotly.js
* Char.js
* Google Chart

## 16.1 Plotly.js

​	Plotly.js is a charting library that comes with over 40 chart types, 3D charts, statistical graphs, and SVG maps.

## 16.2 Chart.js

​	Chart.js comes with many built-in chart types:

* Scatter
* Line 
* Bar
* Radar
* Pie and Doughnut
* Polar Area
* Bubble

## 16.3 Google Chart

​	From simple line charts to complex tree maps, Google Chart provides a number of built-in chart types:

* Scatter Chart
* Line Chart
* Bar / Column Chart
* Area Chart
* Pie Chart
* Donut Chart
* Org Chart
* Map / Geo Chart



# 17. HTML Canvas

​	HTML Canvas is perfect for <b>Scatter Plots</b>.

​	HTML Canvas is perfect for <b>Line Graphs</b>.

​	HTML Canvas is perfect for combing <b>Scatter</b> and <b>Lines</b>.

## 17.1 Scatter Plots

```
<canvas id="myCanvas" width="400" height="400" style="border:1px solid grey"></canvas>

<script>
const canvas = document.getElementById("myCanvas");
const ctx = canvas.getContext("2d");
canvas.height = canvas.width;
ctx.transform(1, 0, 0, -1, 0, canvas.height)

const xArray = [50,60,70,80,90,100,110,120,130,140,150];
const yArray = [7,8,8,9,9,9,10,11,14,14,15];

ctx.fillStyle = "red";
for (let i = 0; i < xArray.length-1; i++) {
  let x = xArray[i]*400/150;
  let y = yArray[i]*400/15;
  ctx.beginPath();
  ctx.ellipse(x, y, 3, 3, 0, 0, Math.PI * 2);
  ctx.fill();
}
</script>
```

## 17.2 Line Graphs

```
<canvas id="myCanvas" width="400" height="400" style="border:1px solid grey"></canvas>

<script>
const canvas = document.getElementById("myCanvas");
const ctx = canvas.getContext("2d");
ctx.fillStyle = "#FF0000";
canvas.height = canvas.width;
ctx.transform(1, 0, 0, -1, 0, canvas.height)

let xMax = canvas.height;
let slope = 1.2;
let intercept = 70;

ctx.moveTo(0, intercept);
ctx.lineTo(xMax, f(xMax));
ctx.strokeStyle = "black";
ctx.stroke();

function f(x) {
  return x * slope + intercept;
}
</script>
```

## 17.3 Combined

```
<canvas id="myCanvas" width="400" height="400" style="border:1px solid grey"></canvas>

<script>
const canvas = document.getElementById("myCanvas");
const ctx = canvas.getContext("2d");
ctx.fillStyle = "#FF0000";
canvas.height = canvas.width;
ctx.transform(1, 0, 0, -1, 0, canvas.height)

let xMax = canvas.height;
let yMax = canvas.width;
let slope = 1.2;
let intercept = 70;

const xArray = [50,60,70,80,90,100,110,120,130,140,150];
const yArray = [7,8,8,9,9,9,10,11,14,14,15];

// Plot Scatter
ctx.fillStyle = "red";
for (let i = 0; i < xArray.length-1; i++) {
  let x = xArray[i]*xMax/150;
  let y = yArray[i]*yMax/15;
  ctx.beginPath();
  ctx.ellipse(x, y, 3, 3, 0, 0, Math.PI * 2);
  ctx.fill();
}

// Plot Line
ctx.moveTo(0, intercept);
ctx.lineTo(xMax, f(xMax));
ctx.strokeStyle = "black";
ctx.stroke();

// Line Function<br>
function f(x) {
  return x * slope + intercept;
}
</script>
```



# 18. Plotly.js

## 18.1 Scatter Plots

​	Before using this library, you should add the link in the \<head>:

```
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
```

```
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var xArray = [50,60,70,80,90,100,110,120,130,140,150];
var yArray = [7,8,8,9,9,9,10,11,14,14,15];

// Define Data
var data = [{
  x:xArray,
  y:yArray,
  mode:"markers"
}];

// Define Layout
var layout = {
  xaxis: {range: [40, 160], title: "Square Meters"},
  yaxis: {range: [5, 16], title: "Price in Millions"},  
  title: "House Prices vs. Size"
};

// Display using Plotly
Plotly.newPlot("myPlot", data, layout);
</script> 
```

## 18.2 Line Graphs

```
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var xArray = [50,60,70,80,90,100,110,120,130,140,150];
var yArray = [7,8,8,9,9,9,10,11,14,14,15];

// Define Data
var data = [{
  x: xArray,
  y: yArray,
  mode:"lines"
}];

// Define Layout
var layout = {
  xaxis: {range: [40, 160], title: "Square Meters"},
  yaxis: {range: [5, 16], title: "Price in Millions"},  
  title: "House Prices vs. Size"
};

// Display using Plotly
Plotly.newPlot("myPlot", data, layout);
</script>
```

## 18.3 Linear Graphs

```
<body>
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var exp = "x + 17";

// Generate values
var xValues = [];
var yValues = [];
for (var x = 0; x <= 10; x += 1) {
  xValues.push(x);
  yValues.push(eval(exp));
}

// Define Data
var data = [{
  x: xValues,
  y: yValues,
  mode:"lines"
}];

// Define Layout
var layout = {title: "y = " + exp};

// Display using Plotly
Plotly.newPlot("myPlot", data, layout);
</script>
```

## 18.4 Multiple Lines

```
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var exp1 = "x";
var exp2 = "1.5*x";
var exp3 = "1.5*x + 7";
// Generate values

var x1Values = [];
var x2Values = [];
var x3Values = [];
var y1Values = [];
var y2Values = [];
var y3Values = [];

for (var x = 0; x <= 10; x += 1) {
  x1Values.push(x);
  x2Values.push(x);
  x3Values.push(x);
  y1Values.push(eval(exp1));
  y2Values.push(eval(exp2));
  y3Values.push(eval(exp3));
}

// Define Data
var data = [
  {x: x1Values, y: y1Values, mode:"lines"},
  {x: x2Values, y: y2Values, mode:"lines"},
  {x: x3Values, y: y3Values, mode:"lines"}
];

//Define Layout
var layout = {title: "[y=" + exp1 + "]  [y=" + exp2 + "]  [y=" + exp3 + "]"};

// Display using Plotly
Plotly.newPlot("myPlot", data, layout);
</script>
```

## 18.5 Bar Charts

```
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var xArray = ["Italy", "France", "Spain", "USA", "Argentina"];
var yArray = [55, 49, 44, 24, 15];

var data = [{
  x:xArray,
  y:yArray,
  type:"bar"
}];

var layout = {title:"World Wide Wine Production"};

Plotly.newPlot("myPlot", data, layout);
</script>
```

## 18.6 Horizontal Bar Charts

```
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var xArray = [55, 49, 44, 24, 15];
var yArray = ["Italy ", "France ", "Spain ", "USA ", "Argentina "];

var data = [{
  x:xArray,
  y:yArray,
  type:"bar",
  orientation:"h",
  marker: {color:"rgba(255,0,0,0.6)"}
}];

var layout = {title:"World Wide Wine Production"};

Plotly.newPlot("myPlot", data, layout);
</script>
```

## 18.7 Pie Charts

​	To display a pie instead of bars, change x and y to labels and values, and change the type to "pie":

```
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var xArray = ["Italy", "France", "Spain", "USA", "Argentina"];
var yArray = [55, 49, 44, 24, 15];

var layout = {title:"World Wide Wine Production"};

var data = [{labels:xArray, values:yArray, type:"pie"}];

Plotly.newPlot("myPlot", data, layout);
</script>

```

## 18.8 Donut Charts

```
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var xArray = ["Italy", "France", "Spain", "USA", "Argentina"];
var yArray = [55, 49, 44, 24, 15];

var layout = {title:"World Wide Wine Production"};

var data = [{labels:xArray, values:yArray, hole:.4, type:"pie"}];

Plotly.newPlot("myPlot", data, layout);
</script>
```

## 18.9 Plotting Equations

```
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var exp = "Math.sin(x)";

// Generate values
var xValues = [];
var yValues = [];
for (var x = 0; x <= 10; x += 0.1) {
  xValues.push(x);
  yValues.push(eval(exp));
}

// Display using Plotly
var data = [{x:xValues, y:yValues, mode:"lines"}];
var layout = {title: "y = " + exp};
Plotly.newPlot("myPlot", data, layout);
</script>
```

```
<div id="myPlot" style="width:100%;max-width:700px"></div>

<script>
var exp = "Math.cos(x)";

// Generate values
var xValues = [];
var yValues = [];
for (var x = 0; x <= 10; x += 0.2) {
  yValues.push(eval(exp));
  xValues.push(x);
}

// Display using Plotly
var data = [{x:xValues, y:yValues, mode:"markers"}];
var layout = {title: "y = " + exp};
Plotly.newPlot("myPlot", data, layout);
</script>
```



# 19. Chart.js

## 19.1 How to Use Charts.js?

​	Chart.js is easy to use. <b>First</b>, add a link to the providing CDN (Content Delivery Network):

```
<script
src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js">
</script>
```

​	<b>Then</b>, add a \<canvas> to where you want to draw the chart:

```
<canvas id="myChart" style="width:100%;max-width:700px"></canvas>
```

​	The canvas element must have a unique id.

​	That's all!

### 19.1.1 Typical Scatter Chart Syntax:

```
const myChart = new Chart("myChart", {
  type: "scatter",
  data: {},
  options: {}
});
```

### 19.1.2 Typical Line Chart Syntax:

```
const myChart = new Chart("myChart", {
  type: "line",
  data: {},
  options: {}
});
```

### 19.1.3 Typical Bar Chart Syntax:

```
const myChart = new Chart("myChart", {
  type: "bar",
  data: {},
  options: {}
});
```

## 19.2 Scatter Plots

```
<canvas id="myChart" style="width:100%;max-width:700px"></canvas>

<script>
var xyValues = [
  {x:50, y:7},
  {x:60, y:8},
  {x:70, y:8},
  {x:80, y:9},
  {x:90, y:9},
  {x:100, y:9},
  {x:110, y:10},
  {x:120, y:11},
  {x:130, y:14},
  {x:140, y:14},
  {x:150, y:15}
];

new Chart("myChart", {
  type: "scatter",
  data: {
    datasets: [{
      pointRadius: 4,
      pointBackgroundColor: "rgb(0,0,255)",
      data: xyValues
    }]
  },
  options: {
    legend: {display: false},
    scales: {
      xAxes: [{ticks: {min: 40, max:160}}],
      yAxes: [{ticks: {min: 6, max:16}}],
    }
  }
});
</script>
```

## 19.3 Line Graphs

```
<canvas id="myChart" style="width:100%;max-width:600px"></canvas>

<script>
const xValues = [50,60,70,80,90,100,110,120,130,140,150];
const yValues = [7,8,8,9,9,9,10,11,14,14,15];

new Chart("myChart", {
  type: "line",
  data: {
    labels: xValues,
    datasets: [{
      fill: false,
      lineTension: 0,
      backgroundColor: "rgba(0,0,255,1.0)",
      borderColor: "rgba(0,0,255,0.1)",
      data: yValues
    }]
  },
  options: {
    legend: {display: false},
    scales: {
      yAxes: [{ticks: {min: 6, max:16}}],
    }
  }
});
</script>
```

​	If you set the borderColor to zero, you can <b>scatter plot</b> the line graph:

```
borderColor: "rgba(0,0,0,0)",
```

## 19.4 Multiple Lines

```
<canvas id="myChart" style="width:100%;max-width:600px"></canvas>

<script>
const xValues = [100,200,300,400,500,600,700,800,900,1000];

new Chart("myChart", {
  type: "line",
  data: {
    labels: xValues,
    datasets: [{ 
      data: [860,1140,1060,1060,1070,1110,1330,2210,7830,2478],
      borderColor: "red",
      fill: false
    }, { 
      data: [1600,1700,1700,1900,2000,2700,4000,5000,6000,7000],
      borderColor: "green",
      fill: false
    }, { 
      data: [300,700,2000,5000,6000,4000,2000,1000,200,100],
      borderColor: "blue",
      fill: false
    }]
  },
  options: {
    legend: {display: false}
  }
});
</script>
```

## 19.5 Linear Graphs

```
<canvas id="myChart" style="width:100%;max-width:600px"></canvas>

<script>
const xValues = [];
const yValues = [];
generateData("x * 2 + 7", 0, 10, 0.5);

new Chart("myChart", {
  type: "line",
  data: {
    labels: xValues,
    datasets: [{
      fill: false,
      pointRadius: 1,
      borderColor: "rgba(255,0,0,0.5)",
      data: yValues
    }]
  },    
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "y = x * 2 + 7",
      fontSize: 16
    }
  }
});
function generateData(value, i1, i2, step = 1) {
  for (let x = i1; x <= i2; x += step) {
    yValues.push(eval(value));
    xValues.push(x);
  }
}
</script>
```

## 19.6 Function Graphs

```
<canvas id="myChart" style="width:100%;max-width:600px"></canvas>

<script>
var xValues = [];
var yValues = [];
generateData("Math.sin(x)", 0, 10, 0.5);

new Chart("myChart", {
  type: "line",
  data: {
    labels: xValues,
    datasets: [{
      fill: false,
      pointRadius: 2,
      borderColor: "rgba(0,0,255,0.5)",
      data: yValues
    }]
  },    
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "y = sin(x)",
      fontSize: 16
    }
  }
});
function generateData(value, i1, i2, step = 1) {
  for (let x = i1; x <= i2; x += step) {
    yValues.push(eval(value));
    xValues.push(x);
  }
}
</script>
```

## 19.7 Bar Charts

```
<canvas id="myChart" style="width:100%;max-width:600px"></canvas>

<script>
var xValues = ["Italy", "France", "Spain", "USA", "Argentina"];
var yValues = [55, 49, 44, 24, 15];
var barColors = ["red", "green","blue","orange","brown"];

new Chart("myChart", {
  type: "bar",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "World Wine Production 2018"
    }
  }
});
</script>
```

​	Color only one bar:

```
var barColors = ["blue"];
```

​	Same color all bars:

```
var barColors = "red";
```

​	Color Shades:

```
var barColors = [
  "rgba(0,0,255,1.0)",
  "rgba(0,0,255,0.8)",
  "rgba(0,0,255,0.6)",
  "rgba(0,0,255,0.4)",
  "rgba(0,0,255,0.2)",
];
```

​	Horizontal Bars:

```
type: "horizontalBar",
```

## 19.8 Pie Charts

```
<canvas id="myChart" style="width:100%;max-width:600px"></canvas>

<script>
var xValues = ["Italy", "France", "Spain", "USA", "Argentina"];
var yValues = [55, 49, 44, 24, 15];
var barColors = [
  "#b91d47",
  "#00aba9",
  "#2b5797",
  "#e8c3b9",
  "#1e7145"
];

new Chart("myChart", {
  type: "pie",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "World Wide Wine Production 2018"
    }
  }
});
</script>
```

## 19.9 Doughnut Charts

​	Just change type from "pie" to "doughnut":

```
type: "doughnut";
```



# 20. Google Chart

## 20.1 How to Use Google Chart?

​	To use Google Chart in your web page, <b>add a link</b> to charts loader:

```
<script
src="https://www.gstatic.com/charts/loader.js">
</script>
```

​	Google Chart is easy to use.

​	Just add a <b>\<div></b> element to display the chart:

```
<div id="myChart" style="max-width:700px; height:400px"></div>
```

​	The \<div> element must have a unique id.

​	Then load the Google Graph API:

1. Load the Visualization API and the corechart package
2. Set a callback function to call when the API is loaded

```
google.charts.load('current', {packages:['corechart']});
google.charts.setOnLoadCallback(drawChart);
```

​	That's all!

## 20.2 Line Graph

```
<div id="myChart" style="width:100%; max-width:600px; height:500px;"></div>

<script>
google.charts.load('current',{packages:['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
// Set Data
var data = google.visualization.arrayToDataTable([
  ['Price', 'Size'],
  [50,7],[60,8],[70,8],[80,9],[90,9],
  [100,9],[110,10],[120,11],
  [130,14],[140,14],[150,15]
]);
// Set Options
var options = {
  title: 'House Prices vs. Size',
  hAxis: {title: 'Square Meters'},
  vAxis: {title: 'Price in Millions'},
  legend: 'none'
};
// Draw
var chart = new google.visualization.LineChart(document.getElementById('myChart'));
chart.draw(data, options);
}
</script>
```

## 20.3 Scatter Plots

​	The <b>scatter plot</b> the same data, change google.visualization to ScatterChart:

```
var chart = new
google.visualization.ScatterChart(document.getElementById('myChart'));
```

## 20.4 Bar Charts

```
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
var data = google.visualization.arrayToDataTable([
  ['Contry', 'Mhl'],
  ['Italy',55],
  ['France',49],
  ['Spain',44],
  ['USA',24],
  ['Argentina',15]
]);

var options = {
  title:'World Wide Wine Production'
};

var chart = new google.visualization.BarChart(document.getElementById('myChart'));
  chart.draw(data, options);
}
</script>
```

## 20.5 Pie Charts

​	To convert a <b>Bar</b> Chart to a <b>Pie</b> chart, just replace:

​		google.visualization.<b>BarChart</b>

​	with:

​		google.visualization.<b>PieChart</b>

```
var chart = new
google.visualization.PieChar(document.getElementById('myChart'));
```

## 20.6 3D Pie

​	To display the Pie in 3D, just add <b>is3D: true</b> to the options:

```
var options = {
	title = 'World Wide Wine Production',
	is3D: true
};
```



# 21. D3.js

​	D3.js is a JavaScript library for manipulating HTML data.

## 21.1 How to Use D3.js?

​	To use D3.js in your web page, <b>add a linke</b> to the library:

```
<script src="//d3js.org/d3.v3.min.js"></script>
```

​	This script selects the body element and appends a paragraph with the text "Hello World":

```
d3.select("body").append("p").text("Hello World");
```

## 21.2 Scatter Plot

```
<svg id="myPlot" style="width:500px;height:500px"></svg>

<script>
// Set Dimensions
const xSize = 500; 
const ySize = 500;
const margin = 40;
const xMax = xSize - margin*2;
const yMax = ySize - margin*2;

// Create Random Points
const numPoints = 100;
const data = [];
for (let i = 0; i < numPoints; i++) {
  data.push([Math.random() * xMax, Math.random() * yMax]);
}

// Append SVG Object to the Page
const svg = d3.select("#myPlot")
  .append("svg")
  .append("g")
  .attr("transform","translate(" + margin + "," + margin + ")");

// X Axis
const x = d3.scaleLinear()
  .domain([0, 500])
  .range([0, xMax]);

svg.append("g")
  .attr("transform", "translate(0," + yMax + ")")
  .call(d3.axisBottom(x));

// Y Axis
const y = d3.scaleLinear()
  .domain([0, 500])
  .range([ yMax, 0]);

svg.append("g")
  .call(d3.axisLeft(y));

// Dots
svg.append('g')
  .selectAll("dot")
  .data(data).enter()
  .append("circle")
  .attr("cx", function (d) { return d[0] } )
  .attr("cy", function (d) { return d[1] } )
  .attr("r", 3)
  .style("fill", "Red");
</script>
```



Tue, April 18, 2023. 17:05. Library 2rd floor, zone c, 369.

<span style="color:red;">